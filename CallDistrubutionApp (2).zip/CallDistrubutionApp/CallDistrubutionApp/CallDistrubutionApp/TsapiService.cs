﻿using NLog;
using System;
using System.Collections.Generic;
using System.Configuration;
using System.Data;
using System.Data.SqlClient;
using System.Linq;
using System.Runtime.InteropServices;
using System.Web;
using System.Threading.Tasks;
using Tsapi;

namespace CallDistrubutionApp
{
    public class TsapiService
    {
        #region Member variables

        // Singleton instance
        private readonly static Lazy<TsapiService> _instance = new Lazy<TsapiService>(() => new TsapiService());
        private SqlConnection connection = new SqlConnection(ConfigurationManager.ConnectionStrings["TelephonyConnection"].ConnectionString);
        private static NLog.Logger logger = LogManager.GetCurrentClassLogger();
        
        
        [DllImport("TSAPIApp.dll", CallingConvention = CallingConvention.Cdecl)]
        public static extern bool CallDevice(string callingDevice, string calledDevice);
        #endregion

        #region Constructors

        private TsapiService()
        {
           
            // Because our C# model name differs from table name we have to specify database table name.
            try
            {
                SqlDependency.Stop(ConfigurationManager.ConnectionStrings["TelephonyConnection"].ConnectionString);
                SqlDependency.Start(ConfigurationManager.ConnectionStrings["TelephonyConnection"].ConnectionString);

            }
            catch (Exception ex)
            {
                logger.Error(ex);
            }

        }

        #endregion

        #region Public Methods
        public static TsapiService Instance
        {
            get { return _instance.Value; }
        }
        #endregion

        #region IDisposable Implementation

        public void Dispose()
        {
            // Invoke Stop() in order to remove all DB objects genetated from SqlTableDependency.
            try
            {
                SqlDependency.Stop(ConfigurationManager.ConnectionStrings["TelephonyConnection"].ConnectionString);
            }
            catch (Exception ex)
            {
                logger.Error(ex);
            }

        }

        #endregion
    }
}