﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;
using System.Data;
using ACBDashboard.BL;
using ACBDashboard.Models;

namespace ACBDashboard.Controllers
{
    public class HomeController : Controller
    {
        public ActionResult Index()
        { 
                Session["startdate"] = DateTime.Now;
                Session["enddate"] = DateTime.Now;
                Session["range"] = "1";
                return View();
        }
        public ActionResult ReportAgent()
        {
            return View();
        }
        
        public ActionResult BusinessIndex()
        {
            Session["startdate"] = DateTime.Now;
            Session["enddate"] = DateTime.Now;
            Session["range"] = "1";

            return View();
        }
        public ActionResult BusinessIndexPartial(FormCollection frm)
        {
            int flag = 0;
            try
            {
                if (flag == 0)
                {
                    if (frm["dashtypeNonACD"].ToString() != "" && flag == 0)
                    {
                        if (frm["dashtypeNonACD"].ToString() == "NonACD")
                        {
                            ViewBag.DashType = "NonACD";
                            ViewBag.DashTypeNonACD = "btn-success";
                            ViewBag.DashTypeACD = "btn-default";
                        }

                        flag = 1;

                    }
                }
                if (flag == 0)
                {
                    if (frm["dashtypeACD"].ToString() != "" && flag == 0)
                    {
                        if (frm["dashtypeACD"].ToString() == "ACD")
                        {
                            ViewBag.DashType = "ACD";
                            ViewBag.DashTypeACD = "btn-success";
                            ViewBag.DashTypeNonACD = "btn-default";
                        }
                        flag = 1;
                    }
                }

            }
            catch
            {
                if (flag == 0)
                {
                    ViewBag.DashType = "ACD";
                    ViewBag.DashTypeACD = "btn-success";
                    ViewBag.DashTypeNonACD = "btn-default";
                }

            }

            return PartialView();
        }
        public ActionResult ReportBusinessIndex()
        {
            return View();
        }
        public ActionResult ReportBusinessIndexPartial()
        {
            ACBDashboard.BL.Dashboard db = new Dashboard();
            db.UserId = (((ACBDashboard.BL.User)Session["user"]).Userid);
            db.fromDate = DateTime.Now;
            db.toDate = DateTime.Now;
            db.RadioField = "1";
            return PartialView(db);
        }
        [HttpPost]
        public ActionResult ReportBusinessIndexPartial(FormCollection form, Dashboard db)
        {
            //RCM.BL.Dashboard db = new Dashboard();
            if (form["RadioField"].ToString() == "")
            {
                db.RadioField = "1";
            }
            else
            {
                db.UserId = (((ACBDashboard.BL.User)Session["user"]).Userid);
                db.RadioField = form["RadioField"]; //the value will be the item id of the size
            }
            if (form["RadioField"].ToString() == "1" || form["RadioField"].ToString() == "2" || form["RadioField"].ToString() == "3")
            {
                Dashboard ds = new Dashboard();
                if (form["RadioField"].ToString() == "1")
                {
                    ds.UserId = (((ACBDashboard.BL.User)Session["user"]).Userid);
                    ds.fromDate = Convert.ToDateTime(DateTime.Now);
                    ds.toDate = Convert.ToDateTime(DateTime.Now);
                }
                else if (form["RadioField"].ToString() == "2")
                {
                    ds.UserId = (((ACBDashboard.BL.User)Session["user"]).Userid);
                    ds.fromDate = Convert.ToDateTime(DateTime.Now);
                    ds.toDate = Convert.ToDateTime(DateTime.Now);

                }
                else if (form["RadioField"].ToString() == "3")
                {
                    ds.UserId = (((ACBDashboard.BL.User)Session["user"]).Userid);
                    ds.fromDate = Convert.ToDateTime(DateTime.Now);
                    ds.toDate = Convert.ToDateTime(DateTime.Now);
                }
                else
                {
                    db.UserId = (((ACBDashboard.BL.User)Session["user"]).Userid);
                    db.fromDate = Convert.ToDateTime(DateTime.Now);
                    db.toDate = Convert.ToDateTime(DateTime.Now);
                }
            }
          

            return PartialView(db);
        }
        public ActionResult ReportIndex()
        {

      
            //RCM.BL.Dashboard.fromDate = Convert.ToDateTime(DateTime.Now.ToString());
            //RCM.BL.Dashboard.toDate = Convert.ToDateTime(DateTime.Now.ToString());
            //RCM.BL.Dashboard.RadioField = "0";
            return View();
        }
        //[HttpPost]
        //public ActionResult ReportIndex(FormCollection form)
        //{
        //    RCM.BL.Dashboard.RadioField = form["RadioField"]; //the value will be the item id of the size
        //    if (form["RadioField"].ToString() == "1" || form["RadioField"].ToString() == "2" || form["RadioField"].ToString() == "3")
        //    {
        //        RCM.BL.Dashboard.fromDate = Convert.ToDateTime(DateTime.Now);
        //        RCM.BL.Dashboard.toDate = Convert.ToDateTime(DateTime.Now);
        //    }
        //    else
        //    {
        //        RCM.BL.Dashboard.fromDate = Convert.ToDateTime(form["fromDate"]);
        //        RCM.BL.Dashboard.toDate = Convert.ToDateTime(form["toDate"]);
        //    }
        //    return PartialView();
        //}

        public ActionResult ReportView()
        {
            ACBDashboard.BL.Dashboard db = new Dashboard();
            db.UserId = (((ACBDashboard.BL.User)Session["user"]).Userid);
            db.fromDate = DateTime.Now;
            db.toDate = DateTime.Now;
            db.RadioField = "1";

            return PartialView(db);
        }

        [HttpPost]
        public ActionResult ReportView(FormCollection form, Dashboard db)
        {
            if (form["RadioField"].ToString() == "")
            {
                db.UserId = (((ACBDashboard.BL.User)Session["user"]).Userid);
                db.RadioField = "1";
            }

            else
            {
                db.UserId = (((ACBDashboard.BL.User)Session["user"]).Userid);
                db.RadioField = form["RadioField"]; //the value will be the item id of the size
            }

            if (form["RadioField"].ToString() == "1" || form["RadioField"].ToString() == "2" || form["RadioField"].ToString() == "3")
            {
                Dashboard ds = new Dashboard();
                if (form["RadioField"].ToString() == "1")
                {
                    ds.UserId = (((ACBDashboard.BL.User)Session["user"]).Userid);
                    ds.fromDate = Convert.ToDateTime(DateTime.Now);
                    ds.toDate = Convert.ToDateTime(DateTime.Now);
                }
                else if (form["RadioField"].ToString() == "2")
                {
                    ds.UserId = (((ACBDashboard.BL.User)Session["user"]).Userid);
                    ds.fromDate = Convert.ToDateTime(DateTime.Now);
                    ds.toDate = Convert.ToDateTime(DateTime.Now);

                }
                else if (form["RadioField"].ToString() == "3")
                {
                    ds.UserId = (((ACBDashboard.BL.User)Session["user"]).Userid);
                    ds.fromDate = Convert.ToDateTime(DateTime.Now);
                    ds.toDate = Convert.ToDateTime(DateTime.Now);
                }
                else
                {
                    db.UserId = (((ACBDashboard.BL.User)Session["user"]).Userid);
                    db.fromDate = Convert.ToDateTime(DateTime.Now);
                    db.toDate = Convert.ToDateTime(DateTime.Now);
                }
            }


            return PartialView(db);
        }
        public ActionResult ReportIndexPartial()
        {
            ACBDashboard.BL.Dashboard db = new Dashboard();
            db.UserId = (((ACBDashboard.BL.User)Session["user"]).Userid);
            db.fromDate = DateTime.Now;
            db.toDate = DateTime.Now;
            db.RadioField = "1";
                      
            return PartialView(db);
        }
    
        [HttpPost]
        public ActionResult ReportIndexPartial(FormCollection form, Dashboard db)
        {
            //RCM.BL.Dashboard db = new Dashboard();


            if (form["RadioField"].ToString() == "")
            {
                db.UserId = (((ACBDashboard.BL.User)Session["user"]).Userid);
                db.RadioField = "1";
            }
      
            else
            {
                db.UserId = (((ACBDashboard.BL.User)Session["user"]).Userid);
                db.RadioField = form["RadioField"]; //the value will be the item id of the size
            }

            if (form["RadioField"].ToString() == "1" || form["RadioField"].ToString() == "2" || form["RadioField"].ToString() == "3")
            {
                Dashboard ds = new Dashboard();
                if (form["RadioField"].ToString() == "1")
                {
                 ds.UserId =  (((ACBDashboard.BL.User)Session["user"]).Userid);
                 ds.fromDate = Convert.ToDateTime(DateTime.Now);
                 ds.toDate = Convert.ToDateTime(DateTime.Now);
                }
                else if (form["RadioField"].ToString() == "2")
                {
                    ds.UserId = (((ACBDashboard.BL.User)Session["user"]).Userid);
                    ds.fromDate = Convert.ToDateTime(DateTime.Now);
                   ds.toDate = Convert.ToDateTime(DateTime.Now);

                }
                else if (form["RadioField"].ToString() == "3")
                {
                    ds.UserId = (((ACBDashboard.BL.User)Session["user"]).Userid);
                    ds.fromDate = Convert.ToDateTime(DateTime.Now);
                    ds.toDate = Convert.ToDateTime(DateTime.Now);
                }
                else
                {
                    db.UserId = (((ACBDashboard.BL.User)Session["user"]).Userid);
                    db.fromDate = Convert.ToDateTime(DateTime.Now);
                   db.toDate = Convert.ToDateTime(DateTime.Now);
                }
            }
         
          
            return PartialView(db);
        }
        public ActionResult About()
        {
            ViewBag.Message = "Your application description page.";

            return View();
        }

        public ActionResult Contact()
        {
            ViewBag.Message = "Your contact page.";

            return View();
        }
        [OutputCache(Duration = 3)]
        public ActionResult IndexPartial(FormCollection frm)
        {
            int flag = 0;
            try
            {
                if (flag == 0)
                {
                    if (frm["dashtypeNonACD"].ToString() != "" && flag == 0)
                    {
                        if (frm["dashtypeNonACD"].ToString() == "NonACD")
                        {
                            ViewBag.DashType = "NonACD";
                            ViewBag.DashTypeNonACD = "btn-success";
                            ViewBag.DashTypeACD = "btn-default";
                        }

                        flag = 1;

                    }
                }
                if (flag == 0)
                {
                    if (frm["dashtypeACD"].ToString() != "" && flag == 0)
                    {
                        if (frm["dashtypeACD"].ToString() == "ACD")
                        {
                            ViewBag.DashType = "ACD";
                            ViewBag.DashTypeACD = "btn-success";
                            ViewBag.DashTypeNonACD = "btn-default";
                        }
                        flag = 1;
                    }
                }

            }
            catch
            {
                if (flag == 0)
                {
                    ViewBag.DashType = "ACD";
                    ViewBag.DashTypeACD = "btn-success";
                    ViewBag.DashTypeNonACD = "btn-default";
                }

            }

            return PartialView();
        }
      
        public ActionResult ReportIPartial(string id)
        {
            ViewBag.sbid = id;
            ViewBag.StartDate = Session["startdate"];
            ViewBag.EndDate = Session["enddate"];
            ViewBag.Range = Session["range"];






            return PartialView("ReportIPartial");
            
        }
        public ActionResult ReportIPartialOutBound(string id)
        {
            ViewBag.sbid = id;
            ViewBag.StartDate = Session["startdate"];
            ViewBag.EndDate = Session["enddate"];
            ViewBag.Range = Session["range"];






            return PartialView("ReportIPartialOutBound");

        }
        //HourlyReportIPartialCompliance(InBound)
        public ActionResult HourlyReportIPartialCompliance(string id, string hour,DateTime date)
      {
            ViewBag.sbid = id;
            ViewBag.hour = hour;
            ViewBag.Date = date;
            return PartialView("HourlyReportIPartialCompliance");
        }

        //HourlyReportIPartialCompliance(OutBound)
        public ActionResult HourlyReportIPartialComplianceOutBound(string id, string hour, DateTime date)
        {
            ViewBag.sbid = id;
            ViewBag.Date = date;
            ViewBag.hour = hour;
            return PartialView("HourlyReportIPartialComplianceOutBound");
        }
        [HttpPost]
        public ActionResult ExportToExcel()
        {


            return View();
        }
        
        public ActionResult PiChartPartial()
        {


            return PartialView();
        }
        public ActionResult HourlyComplianceReportIndex()
        {
            ACBDashboard.BL.Dashboard db = new Dashboard();
            db.fromDate = DateTime.Now;
            return PartialView(db);
        }
        [HttpPost]
        public ActionResult HourlyComplianceReportIndex(Dashboard db)
        {
  
            return PartialView(db);
        }
        public ActionResult HourlyComplianceReportDashboardIndex()
        {
            ACBDashboard.BL.Dashboard db = new Dashboard();
            db.fromDate = DateTime.Now;
            return PartialView(db);
        }
        public ActionResult HourlyBusinessComplianceReportIndex()
        {
            ACBDashboard.BL.Dashboard db = new Dashboard();
            db.fromDate = DateTime.Now;
            return PartialView(db);
        }
        [HttpPost]
        public ActionResult HourlyBusinessComplianceReportIndex(Dashboard db)
        {
            return PartialView(db);
        }
        public ActionResult HourlyBusinessComplianceReportDashboardIndex()
        {
            ACBDashboard.BL.Dashboard db = new Dashboard();
            db.fromDate = DateTime.Now;
            return PartialView(db);
        }






    }
}