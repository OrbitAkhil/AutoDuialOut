﻿using ACBDashboard.BL;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;


namespace ACBDashboard.Controllers
{
    public class LoginController : Controller
    {
        
        // GET: Login
        [AllowAnonymous]
        public ActionResult Index()
        {
           
            return View();
        }
        [AllowAnonymous]
        [HttpPost]
        public ActionResult Index(FormCollection FC)
        {
            BL.User objuser = new BL.User();

            if (objuser.validateuser(FC["user"].ToString(), FC["pass"].ToString()))
            {
                //objuser.Userid = FC["user"].ToString();
                //objuser.UserName = "Ramesh " + DateTime.Now.ToString();
                HttpContext.Session["user"] = objuser;
                if(objuser.UserType!=1)
                    return RedirectToAction("businessIndex", "Home");
                else
                return RedirectToAction("Index", "Home");
            }
            else
            {
                TempData["loginmsg"] = "Invalid Credentials";
                return RedirectToAction("Index", "Login");
            }
        }
        [HttpPost]
        public ActionResult Logout(FormCollection FC)
        {

            Session.Abandon();
            return RedirectToAction("Index", "Home");
            
        }
        public ActionResult ResetIndex()
        {

            return PartialView();
        }
        [HttpPost]
        public ActionResult ResetIndex(ResetPassword rp)
        {
            string message = "";
            ResetPassword rr = new ResetPassword();
            string smsg = rr.Reset_Password(rp, ((ACBDashboard.BL.User)Session["user"]).Userid);
        
            if (message == "ok")
            {
                return RedirectToAction("Index","Home");
            }
            return RedirectToAction("Index", "Home");

        }

        

    }
}