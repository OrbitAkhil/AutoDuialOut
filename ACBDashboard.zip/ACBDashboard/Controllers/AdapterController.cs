﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;
using System.Data;
using ACBDashboard.Models;
using System.IO;

namespace ACBDashboard.Controllers
{
    public class AdapterController : Controller
    {
        
        public ActionResult Index()
        {

      
            return View();
        }
        public ActionResult VerientIndex()
        {
            //var month =  "Mar";
            //DateTime date = Convert.ToDateTime(month);
            SQLU SS = new SQLU("");
            VerientAdapterDataAccessLayer MDL = new VerientAdapterDataAccessLayer();
            return View(MDL.Selectalldata());
        }
     
        public ActionResult AddVerientAdapter(VerientAdapter mdl)
        {
            VerientAdapter Mdl = new VerientAdapter();
            SQLU ss = new SQLU("");
            var dt = ss.ShowDataDT("exec sp_RCM_subbusinessmasterCRUD 0,'','','',4");
            var dt1 = ss.ShowDataDT("exec sp_RCM_VersionCRUD 0,'',4");
            Mdl.SubBusinessList = mdl.GetAllSubBusinessList(dt);
            Mdl.VersionList = mdl.GetAllVersionList(dt1);
            // Mdl.VerientAdapterList = mdl.GetAllVerientAdapterDetails(((RCM.BL.User)Session["user"]).Userid);
            return PartialView(Mdl);
        }
        [HttpPost]
        public ActionResult AddVerientAdapter(VerientAdapter mdl,FormCollection frm)
        {
            SQLU ss = new SQLU("");
            string message = "";
            VerientAdapterDataAccessLayer MDL = new VerientAdapterDataAccessLayer();
            if(ModelState.IsValid ==true)
            {
                message = MDL.InsertData(mdl);
                if (ss.IsItOnlyNumbersCheck(message)==true)
                {
                    return Json(new { success = true, msg = "Data saved." });
                }
                else
                { return Json(new { success = false, msg = "Data Not Saved" }); }

            }
            return View();
        

        }
        public ActionResult VerientDelete(string id)
        {
            VerientAdapterDataAccessLayer MDL = new VerientAdapterDataAccessLayer();
            SQLU ss = new SQLU("");
            int msg = 0;
            msg = MDL.DeleteData(id.ToString());
            return RedirectToAction("VerientIndex");
        }

        public ActionResult CMSIndex()
        {
            return View(new CMSAdapter().CMSAdapterDetails(((ACBDashboard.BL.User)Session["user"]).Userid));
        }

        public ActionResult AddCMSAdapter(CMSAdapter mdl)
        {
            VerientAdapter obj = new VerientAdapter();
            CMSAdapter Mdl = new CMSAdapter();
            SQLU ss = new SQLU("");
            var dt = ss.ShowDataDT("exec sp_RCM_subbusinessmasterCRUD 0,'','','',4");
            var dt1 = ss.ShowDataDT("exec sp_RCM_getallCMSVerintList");
            Mdl.SubBusinessList = obj.GetAllSubBusinessList(dt);
            Mdl.CmsVerintList = obj.GetAllCMSVerintList(dt1);
            return PartialView(Mdl);
        }
        [HttpPost]
        public ActionResult AddCMSAdapter(CMSAdapter mdl,FormCollection frm)
        {
            SQLU ss = new SQLU("");
            string message = "";
            CMSAdapterDataAccessLayer MDL = new CMSAdapterDataAccessLayer();
            if (ModelState.IsValid == true)
            {
                message = MDL.InsertData(mdl);
                if (ss.IsItOnlyNumbersCheck(message) == true)
                {
                    return Json(new { success = true, msg = "Data saved." });
                }
                else
                { return Json(new { success = false, msg = "Data Not Saved" }); }

            }
            return View();

            // VerientAdapter obj = new VerientAdapter();
            // CMSAdapter Mdl = new CMSAdapter();
            // string fileText = mdl.Echi_FileLocation[0].ToString();
            //// string fileText = Convert.ToString(file);
            // SQLU ss = new SQLU("");

            // return PartialView(Mdl);
        }
        public ActionResult CMSDelete(string id)
        {
            CMSAdapterDataAccessLayer MDL = new CMSAdapterDataAccessLayer();
            SQLU ss = new SQLU("");
            int msg = 0;
            msg = MDL.DeleteData(id.ToString());
            return RedirectToAction("CMSIndex");
        }
        public ActionResult CDRIndex()
        {
            return View(new CDRAdapter().CDRAdapterDetails(((ACBDashboard.BL.User)Session["user"]).Userid));
        }
        public ActionResult AddCDRAdapter(CDRAdapter mdl)
        {
            VerientAdapter obj = new VerientAdapter();
            CDRAdapter Mdl = new CDRAdapter();
            SQLU ss = new SQLU("");
            var dt = ss.ShowDataDT("exec sp_RCM_subbusinessmasterCRUD 0,'','','',4");
            Mdl.SubBusinessList = obj.GetAllSubBusinessList(dt);
            
            // string fileText = Convert.ToString(file);
            return PartialView(Mdl);
           
        }
        [HttpPost]
        public ActionResult AddCDRAdapter(CDRAdapter mdl, FormCollection frm)
        {
            SQLU ss = new SQLU("");
            string message = "";
            CDRAdapterDataAccessLayer MDL = new CDRAdapterDataAccessLayer();
            if (ModelState.IsValid == true)
            {
                message = MDL.InsertData(mdl);
                if (ss.IsItOnlyNumbersCheck(message) == true)
                {
                    return Json(new { success = true, msg = "Data saved." });
                }
                else
                { return Json(new { success = false, msg = "Data Not Saved" }); }

            }
            return View();
        }
        public ActionResult CDRDelete(string id)
        {
            CDRAdapterDataAccessLayer MDL = new CDRAdapterDataAccessLayer();
            SQLU ss = new SQLU("");
            int msg = 0;
            msg = MDL.DeleteData(id.ToString());
            return RedirectToAction("CDRIndex");
        }
        public ActionResult ExportIndex()
        {
            return View(new Export().ExportDetails(((ACBDashboard.BL.User)Session["user"]).Userid));
        }
        public ActionResult AddExport(Export mdl)
        {
            Export ee = new Export();
            SQLU ss1 = new SQLU("");
            DataSet ds = new DataSet();
            DataSet ds1 = new DataSet();
            DataSet ds2 = new DataSet();
            DataTable allCallVolumeList = new DataTable();
            DataTable allExportRuleList = new DataTable();
            DataTable allFieldList = new DataTable();
            ds = Export.GetCallVolumeList();
            ds1 = Export.GetExportRuleList();
            ds2 = Export.GetFieldList();
            allCallVolumeList = ds.Tables[0];
            allExportRuleList = ds1.Tables[0];
            allFieldList = ds2.Tables[0];
            ViewBag.allCallVolumeList = ss1.ddlListItem(allCallVolumeList, "Text", "ID");
            ViewBag.allExportRuleList = ss1.ddlListItem(allExportRuleList, "Text", "ID");
            ViewBag.allFieldList = (SelectListItem[]) ss1.ddlListItem(allFieldList, "Text", "ID");
            VerientAdapter obj = new VerientAdapter();
            Export Mdl = new Export();
            SQLU ss = new SQLU("");
            var dt = ss.ShowDataDT("exec sp_RCM_subbusinessmasterCRUD 0,'','','',4");
            Mdl.SubBusinessList = obj.GetAllSubBusinessList(dt);

            // string fileText = Convert.ToString(file);
            return PartialView(Mdl);

        }

        //[HttpPost]
        //public ActionResult uploadfile()
        //{
        //    string directory = @"D:\Temp\";

        //    HttpPostedFileBase photo = Request.Files["photo"];

        //    if (photo != null && photo.ContentLength > 0)
        //    {
        //        var fileName = Path.GetFileName(photo.FileName);
        //        photo.SaveAs(Path.Combine(directory, fileName));
        //    }

        //    return RedirectToAction("Index");
        //}
        //[HttpPost]
        //public ActionResult uploadfile(HttpPostedFileBase ExportToLocation)
        //{
        //    string path = Server.MapPath("~/images/");
        //    if (!Directory.Exists(path))
        //    {
        //        Directory.CreateDirectory(path);
        //    }

        //    if (ExportToLocation != null)
        //    {
        //        string fileName = Path.GetFileName(ExportToLocation.FileName);
        //        ExportToLocation.SaveAs(path + fileName);
        //        ViewBag.Message += string.Format("<b>{0}</b> uploaded.<br />", fileName);
        //    }

        //    return View();
        //}
        [HttpPost]
        public ActionResult AddExport(Export mdl, FormCollection frm)

        {
            SQLU ss = new SQLU("");
            string message = "";
            //string ExportFormat = frm["ExportFormat"].ToString();
            //string Frequency = frm["Frequency"].ToString();
            //string Day = frm["Day"].ToString();
            //string WeekDay = frm["WeekDay"].ToString();
            //string Hours = frm["Hours"].ToString();
            //string Minutes = frm["Minutes"].ToString();
            ExportDataAccessLayer MDL = new ExportDataAccessLayer();
            if (ModelState.IsValid == true)
            {
                message = MDL.InsertData(mdl);
                if (ss.IsItOnlyNumbersCheck(message) == true)
                {
                    return Json(new { success = true, msg = "Data saved." });
                }
                else
                { return Json(new { success = false, msg = "Data Not Saved" }); }
            }
            return View();
        }
        public ActionResult ExportDelete(string id)
        {
            ExportDataAccessLayer MDL = new ExportDataAccessLayer();
            SQLU ss = new SQLU("");
            int msg = 0;
            msg = MDL.DeleteData(id.ToString());
            return RedirectToAction("ExportIndex");
        }
       
    }
}