﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;
using System.ComponentModel.DataAnnotations;
using System.Data;
using ACBDashboard.BL;

namespace ACBDashboard.Models
{
    public class SubBusiness
    {
        [Required(ErrorMessage = "Sub Business Name is Required")]
        [Display(Name = "Sub Business Name")]
        public string SubBusinessName { get; set; }
        public string id { get; set; }
              
        [Display(Name = "Business Name")]
        public string BusinessName { get; set; }

        public string SubBusinessId { get; set; }

        public string BusinessId { get; set; }

        public string Checked { get; set; }

        public List<SubBusiness> GetAllSBwithBusiness(string id)
        {
            List<SubBusiness> objL = new List<SubBusiness>();
            System.Data.SqlClient.SqlParameter[] sp = new System.Data.SqlClient.SqlParameter[1];
            sp[0] = new System.Data.SqlClient.SqlParameter("@subbusinessid", SqlDbType.Int);
            sp[0].Value =id;
            SQLU S = new SQLU("");
            DataSet ds = S.GetData("dbo.usp_getallSubBusinessdetails", sp);
            if (ds != null)
                if (ds.Tables[0].Rows.Count > 0)
                {
                    DataTable dt = ds.Tables[0];
                    foreach (DataRow dr in dt.Rows)
                    {
                        SubBusiness MB = new SubBusiness();
                       
                        MB.SubBusinessId = dr["subbusinessid"].ToString();
                        MB.BusinessId = dr["businessid"].ToString();
                        MB.SubBusinessName = dr["subbusinessname"].ToString();
                        MB.BusinessName = dr["businessname"].ToString();
                        objL.Add(MB);

                    }
                }

            return objL;
        }
        public string DeleteSubBusiness(string id)
        {
            System.Data.SqlClient.SqlParameter spout = new System.Data.SqlClient.SqlParameter("@ERROR", SqlDbType.VarChar);
            spout.Direction = ParameterDirection.Output;
            spout.Size = 100;

            System.Data.SqlClient.SqlParameter[] sp = new System.Data.SqlClient.SqlParameter[1];
            sp[0] = new System.Data.SqlClient.SqlParameter("@id", SqlDbType.VarChar);
            sp[0].Value =id;
            SQLU s = new SQLU("");
            string msg = s.ExecuteProcOut("sp_deletesubbusiness", spout, sp);
            //DataSet ds = SQLU.GetData("sp_UTOM_AddBusiness", sp);

            return msg;
        }

        public List<SubBusiness> GetAllSBList()
        {
            List<SubBusiness> objL = new List<SubBusiness>();
            System.Data.SqlClient.SqlParameter[] sp = new System.Data.SqlClient.SqlParameter[0];
          
            SQLU S = new SQLU("");
            DataSet ds = S.GetData("dbo.sp_getAllSBList", sp);
            if (ds != null)
                if (ds.Tables[0].Rows.Count > 0)
                {
                    DataTable dt = ds.Tables[0];
                    foreach (DataRow dr in dt.Rows)
                    {
                        SubBusiness MB = new SubBusiness();

                        MB.SubBusinessId = dr["id"].ToString();
                      
                        MB.SubBusinessName = dr["subbusinessname"].ToString();
                     
                        objL.Add(MB);

                    }
                }

            return objL;
        }
        public DataTable ReturnTable(string ActionType)
        {
            SubBusiness mBusiness = new SubBusiness();
            DataTable DT;
            System.Data.SqlClient.SqlParameter[] sp = new System.Data.SqlClient.SqlParameter[0];
            SQLU s = new SQLU(System.Configuration.ConfigurationManager.AppSettings["CON"]);
            DataSet DS = new DataSet();
            DS = s.GetData("sp_UTOM_SelectSubBusiness", sp);
            DT = DS.Tables[0];
            return DT;
        }
        public bool EditSubBusiness(SubBusiness mBusiness)
        {
            bool isAdded = false;

            System.Data.SqlClient.SqlParameter spout = new System.Data.SqlClient.SqlParameter("@ERROR", SqlDbType.VarChar);
            spout.Direction = ParameterDirection.Output;
            spout.Size = 100;

            System.Data.SqlClient.SqlParameter[] sp = new System.Data.SqlClient.SqlParameter[2];
            sp[0] = new System.Data.SqlClient.SqlParameter("@SubBusinessName", SqlDbType.VarChar);
            sp[0].Value = mBusiness.SubBusinessName;
            //sp[1] = new System.Data.SqlClient.SqlParameter("@Location", SqlDbType.VarChar);
            //sp[1].Value = mBusiness.Location;
            //sp[2] = new System.Data.SqlClient.SqlParameter("@Address", SqlDbType.VarChar);
            //sp[2].Value = mBusiness.Address;
            //sp[3] = new System.Data.SqlClient.SqlParameter("@ContPerson", SqlDbType.VarChar);
            //sp[3].Value = mBusiness.ContPerson;
            sp[1] = new System.Data.SqlClient.SqlParameter("@SubBusinessId", SqlDbType.VarChar);
            sp[1].Value = mBusiness.SubBusinessId;
            SQLU s = new SQLU(System.Configuration.ConfigurationManager.AppSettings["CON"]);
            string msg = s.ExecuteProcOut("[sp_EditSubBusiness]", spout, sp);
            //DataSet ds = SQLU.GetData("sp_UTOM_AddBusiness", sp);
            if (msg != "")

            {
                isAdded = true;
            }

            return isAdded;
        }


    }
    public class CheckModel
    {
        public int Id
        {
            get;
            set;
        }
        public string Name
        {
            get;
            set;
        }
        public bool Checked
        {
            get;
            set;
        }
    }

    public class ItUserSbMappingDataAccessLayer
    {

    }
   
}