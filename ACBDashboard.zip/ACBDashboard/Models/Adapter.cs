﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Data;
using System.Data.SqlClient;
using System.Linq;
using System.Web;

namespace ACBDashboard.Models
{
#region VerientAdapter
    public class VerientAdapter
    {
        public int id { get; set; }
        public string SubBusiness { get; set; }
        public string Version { get; set; }
        public string ServerId { get; set; }
        public string HostName { get; set; }
        public string UserName { get; set; }
        public string Password { get; set; }
        public string Domain { get; set; }

        public List<SubBusiness> SubBusinessList { get; set; }
        [Display(Name="Version")]
        public List<Version> VersionList { get; set; }
        public List<VerientAdapter> VerientAdapterList { get; set; }

        public List<VerientAdapter> GetAllVerientAdapterDetails(string loginid)
        {

            List<VerientAdapter> objL = new List<VerientAdapter>();
            System.Data.SqlClient.SqlParameter[] sp = new System.Data.SqlClient.SqlParameter[1];
            sp[0] = new System.Data.SqlClient.SqlParameter("@loginid", SqlDbType.VarChar);
            sp[0].Value = loginid;
            //sp[1] = new System.Data.SqlClient.SqlParameter("@userid", SqlDbType.Int);
            //sp[1].Value = userid;
            SQLU S = new SQLU("");
            DataSet ds = S.GetData("sp_getallVerientAdapterDetails", sp);
            if (ds != null)
                if (ds.Tables[0].Rows.Count > 0)
                {
                    DataTable dt = ds.Tables[0];
                    foreach (DataRow dr in dt.Rows)
                    {
                        VerientAdapter MB = new VerientAdapter();
                        MB.id = Convert.ToInt16(dr["id"].ToString());
                        MB.SubBusiness = dr["SubBusinessId"].ToString();
                        MB.Version = dr["Version"].ToString();
                        MB.HostName = dr["HostName"].ToString();
                        MB.ServerId = dr["ServerId"].ToString();
                        MB.UserName = dr["UserName"].ToString();
                        MB.Password = dr["Password"].ToString();
                        MB.Domain = dr["Domain"].ToString();


                        objL.Add(MB);

                    }
                }


            return objL;
        }

        public List<SubBusiness> GetAllSubBusinessList(DataTable dt)
        {
            List<SubBusiness> list = null;
            if (dt.Rows.Count > 0)
            {
                list = new List<SubBusiness>();
                foreach (System.Data.DataRow dr in dt.Rows)
                {
                    list.Add(new SubBusiness() { SubBusinessName = dr["subbusinessname"].ToString(), SubBusinessId = dr["id"].ToString() });
                }
            }
            return list;
            //DT Convert To LIST ITEM
            //var convertedList = (from rw in dt.AsEnumerable()
            //                     select new SubBusiness()
            //                     {
            //                         Id = Convert.ToInt32(rw["id"]),
            //                         RangeName = Convert.ToString(rw["RangeName"])
            //                     }).ToList();

            //return convertedList;
        }
        public List<Version> GetAllVersionList(DataTable dt)
        {
            List<Version> list = null;
            if (dt.Rows.Count > 0)
            {
                list = new List<Version>();
                foreach (System.Data.DataRow dr in dt.Rows)
                {
                    list.Add(new Version() { VersionName = dr["Version"].ToString(), VersionID = dr["id"].ToString() });
                }
            }
            return list;
            
        }
        public List<CMSVerint> GetAllCMSVerintList(DataTable dt)
        {
            List<CMSVerint> list = null;
            if (dt.Rows.Count > 0)
            {
                list = new List<CMSVerint>();
                foreach (System.Data.DataRow dr in dt.Rows)
                {
                    list.Add(new CMSVerint() { CMS_Verint = dr["CMS_Verint"].ToString(), CMS_VerintID = dr["id"].ToString() });
                }
            }
            return list;

        }
    }
  public class VerientAdapterDataAccessLayer
    {
        string storedProc = "sp_RCM_VerientAdapterCRUD";
        public string InsertData(VerientAdapter obj)
        {
            SqlConnection con = new SqlConnection(SQLU.con);

            string result = "";
            try
            {
                //id,id,SubBusinessId,Version,ServerId,HostName,UserName,Password,Domain

                SqlCommand cmd = new SqlCommand(storedProc, con);
                cmd.CommandType = CommandType.StoredProcedure;
                cmd.Parameters.AddWithValue("@id", null);  
                cmd.Parameters.AddWithValue("@SubBusinessId", obj.SubBusiness);
                cmd.Parameters.AddWithValue("@Version", obj.Version);
                cmd.Parameters.AddWithValue("@ServerId", obj.ServerId);
                cmd.Parameters.AddWithValue("@HostName", obj.HostName);
                cmd.Parameters.AddWithValue("@UserName", obj.UserName);
                cmd.Parameters.AddWithValue("@Password", obj.Password);
                cmd.Parameters.AddWithValue("@Domain", obj.Domain);
                cmd.Parameters.AddWithValue("@Query", 1);

                con.Open();
                result = cmd.ExecuteScalar().ToString();
                return result;
            }
            catch (Exception ex)
            {
                return result = ex.ToString();
            }
            finally
            {
                con.Close();
            }
        }
        public string UpdateData(VerientAdapter obj)
        {
            SqlConnection con = new SqlConnection(SQLU.con);
            string result = "";
            try
            {
                //ID , UserName , BusinessID , Status , ExtensionID
                SqlCommand cmd = new SqlCommand(storedProc, con);
                cmd.CommandType = CommandType.StoredProcedure;
                cmd.Parameters.AddWithValue("@id", obj.id);
                cmd.Parameters.AddWithValue("@SubBusinessId", obj.SubBusiness);
                cmd.Parameters.AddWithValue("@Version", obj.Version);
                cmd.Parameters.AddWithValue("@ServerId", obj.ServerId);
                cmd.Parameters.AddWithValue("@HostName", obj.HostName);
                cmd.Parameters.AddWithValue("@UserName", obj.UserName);
                cmd.Parameters.AddWithValue("@Password", obj.Password);
                cmd.Parameters.AddWithValue("@Domain", obj.Domain);
                cmd.Parameters.AddWithValue("@Query", 2);
                con.Open();
                result = cmd.ExecuteScalar().ToString();
                return result;
            }
            catch (Exception ex)
            {
                return result = ex.ToString();
            }
            finally
            {
                con.Close();
            }
        }
        public int DeleteData(String ID)
        {
            SqlConnection con = new SqlConnection(SQLU.con);
            int result;
            try
            {
                //ID , UserName , BusinessID , Status , ExtensionID
                SqlCommand cmd = new SqlCommand(storedProc, con);
                cmd.CommandType = CommandType.StoredProcedure;
                cmd.Parameters.AddWithValue("@id", ID);
                cmd.Parameters.AddWithValue("@SubBusinessId", null);
                cmd.Parameters.AddWithValue("@Version", null);
                cmd.Parameters.AddWithValue("@ServerId", null);
                cmd.Parameters.AddWithValue("@HostName", null);
                cmd.Parameters.AddWithValue("@UserName", null);
                cmd.Parameters.AddWithValue("@Password", null);
                cmd.Parameters.AddWithValue("@Domain", null);
                cmd.Parameters.AddWithValue("@Query", 3);
                con.Open();
                result = cmd.ExecuteNonQuery();
                return result;
            }
            catch(Exception ex)
            {
                return result = 0;
            }
            finally
            {
                con.Close();
            }
        }
        public List<VerientAdapter> Selectalldata()
        {
            SqlConnection con = new SqlConnection(SQLU.con);
            DataSet ds = null;
            List<VerientAdapter> custlist = null;
            try
            {
                //ID , UserName , BusinessID , Status , ExtensionID
                SqlCommand cmd = new SqlCommand(storedProc, con);
                cmd.CommandType = CommandType.StoredProcedure;
                cmd.Parameters.AddWithValue("@id", null);
                cmd.Parameters.AddWithValue("@SubBusinessId", null);
                cmd.Parameters.AddWithValue("@Version", null);
                cmd.Parameters.AddWithValue("@ServerId", null);
                cmd.Parameters.AddWithValue("@HostName", null);
                cmd.Parameters.AddWithValue("@UserName", null);
                cmd.Parameters.AddWithValue("@Password", null);
                cmd.Parameters.AddWithValue("@Domain", null);
                cmd.Parameters.AddWithValue("@Query", 4);
                con.Open();
                SqlDataAdapter da = new SqlDataAdapter();
                da.SelectCommand = cmd;
                ds = new DataSet();
                da.Fill(ds);
                custlist = new List<VerientAdapter>();
                for (int i = 0; i < ds.Tables[0].Rows.Count; i++)
                {
                    VerientAdapter cobj = new VerientAdapter();
                    cobj.id = Convert.ToInt32(ds.Tables[0].Rows[i]["id"].ToString());
                    cobj.SubBusiness = ds.Tables[0].Rows[i]["SubBusinessId"].ToString();
                    cobj.Version = ds.Tables[0].Rows[i]["Version"].ToString();
                    cobj.ServerId = ds.Tables[0].Rows[i]["ServerId"].ToString();
                    cobj.HostName = ds.Tables[0].Rows[i]["HostName"].ToString();
                    cobj.UserName = ds.Tables[0].Rows[i]["UserName"].ToString();
                    cobj.Password = ds.Tables[0].Rows[i]["Password"].ToString();
                    cobj.Domain = ds.Tables[0].Rows[i]["Domain"].ToString();
                    custlist.Add(cobj);
                }
                return custlist;
            }
            catch (Exception ex)
            {
                return custlist;
            }
            finally
            {
                con.Close();
            }
        }

        public VerientAdapter SelectDatabyID(string ID)
        {
            SqlConnection con = new SqlConnection(SQLU.con);
            DataSet ds = null;
            VerientAdapter cobj = null;
            try
            {
                //ID , UserName , BusinessID , Status , ExtensionID
                SqlCommand cmd = new SqlCommand(storedProc, con);
                cmd.CommandType = CommandType.StoredProcedure;
                cmd.Parameters.AddWithValue("@id", ID);
                cmd.Parameters.AddWithValue("@SubBusinessId", null);
                cmd.Parameters.AddWithValue("@Version", null);
                cmd.Parameters.AddWithValue("@ServerId", null);
                cmd.Parameters.AddWithValue("@HostName", null);
                cmd.Parameters.AddWithValue("@UserName", null);
                cmd.Parameters.AddWithValue("@Password", null);
                cmd.Parameters.AddWithValue("@Domain", null);
                cmd.Parameters.AddWithValue("@Query", 5);
                SqlDataAdapter da = new SqlDataAdapter();
                da.SelectCommand = cmd;
                ds = new DataSet();
                da.Fill(ds);
                for (int i = 0; i < ds.Tables[0].Rows.Count; i++)
                {
                    cobj = new VerientAdapter();
                    cobj.id = Convert.ToInt32(ds.Tables[0].Rows[i]["id"].ToString());
                    cobj.SubBusiness = ds.Tables[0].Rows[i]["SubBusinessId"].ToString();
                    cobj.Version = ds.Tables[0].Rows[i]["Version"].ToString();
                    cobj.ServerId = ds.Tables[0].Rows[i]["ServerId"].ToString();
                    cobj.HostName = ds.Tables[0].Rows[i]["HostName"].ToString();
                    cobj.UserName = ds.Tables[0].Rows[i]["UserName"].ToString();
                    cobj.Password = ds.Tables[0].Rows[i]["Password"].ToString();
                    cobj.Domain = ds.Tables[0].Rows[i]["Domain"].ToString();

                }
                return cobj;
            }
            catch
            {
                return cobj;
            }
            finally
            {
                con.Close();
            }
        }
    }
    #endregion


#region CDRAdapter
    public class CDRAdapter
    {
        public int id { get; set; }
        public string SubBusiness { get; set; }
        public string CDR_FileLocation { get; set; }
        public List<SubBusiness> SubBusinessList { get; set; }
        public List<CDRAdapter> CDRAdapterDetails(string loginid)
        {

            List<CDRAdapter> objL = new List<CDRAdapter>();
            System.Data.SqlClient.SqlParameter[] sp = new System.Data.SqlClient.SqlParameter[1];
            sp[0] = new System.Data.SqlClient.SqlParameter("@loginid", SqlDbType.VarChar);
            sp[0].Value = loginid;
            //sp[1] = new System.Data.SqlClient.SqlParameter("@userid", SqlDbType.Int);
            //sp[1].Value = userid;
            SQLU S = new SQLU("");
            DataSet ds = S.GetData("sp_getallCDRAdapterDetails", sp);
            if (ds != null)
                if (ds.Tables[0].Rows.Count > 0)
                {
                    DataTable dt = ds.Tables[0];
                    foreach (DataRow dr in dt.Rows)
                    {
                        CDRAdapter MB = new CDRAdapter();
                        MB.id = Convert.ToInt16(dr["id"].ToString());
                        MB.SubBusiness = dr["SubBusinessId"].ToString();
                        MB.CDR_FileLocation = dr["CDR_FileLocation"].ToString();
                      


                        objL.Add(MB);

                    }
                }


            return objL;
        }
     
    }
    public class CDRAdapterDataAccessLayer
    {
        string storedProc = "sp_RCM_CdrAdapterCRUD";
        public string InsertData(CDRAdapter obj)
        {
            SqlConnection con = new SqlConnection(SQLU.con);

            string result = "";
            try
            {
                //id,id,SubBusinessId,Version,ServerId,HostName,UserName,Password,Domain

                SqlCommand cmd = new SqlCommand(storedProc, con);
                cmd.CommandType = CommandType.StoredProcedure;
                cmd.Parameters.AddWithValue("@id", null);
                cmd.Parameters.AddWithValue("@SubBusinessId", obj.SubBusiness);
                cmd.Parameters.AddWithValue("@CDR_FileLocation", obj.CDR_FileLocation);

                cmd.Parameters.AddWithValue("@Query", 1);

                con.Open();
                result = cmd.ExecuteScalar().ToString();
                return result;
            }
            catch (Exception ex)
            {
                return result = ex.ToString();
            }
            finally
            {
                con.Close();
            }
        }
        public string UpdateData(CDRAdapter obj)
        {
            SqlConnection con = new SqlConnection(SQLU.con);
            string result = "";
            try
            {
                //ID , UserName , BusinessID , Status , ExtensionID
                SqlCommand cmd = new SqlCommand(storedProc, con);
                cmd.CommandType = CommandType.StoredProcedure;
                cmd.Parameters.AddWithValue("@id", obj.id);
                cmd.Parameters.AddWithValue("@SubBusinessId", obj.SubBusiness);
                cmd.Parameters.AddWithValue("@CDR_FileLocation", obj.CDR_FileLocation);
                cmd.Parameters.AddWithValue("@Query", 2);
                con.Open();
                result = cmd.ExecuteScalar().ToString();
                return result;
            }
            catch (Exception ex)
            {
                return result = ex.ToString();
            }
            finally
            {
                con.Close();
            }
        }
        public int DeleteData(String ID)
        {
            SqlConnection con = new SqlConnection(SQLU.con);
            int result;
            try
            {
                //ID , UserName , BusinessID , Status , ExtensionID
                SqlCommand cmd = new SqlCommand(storedProc, con);
                cmd.CommandType = CommandType.StoredProcedure;
                cmd.Parameters.AddWithValue("@id", ID);
                cmd.Parameters.AddWithValue("@SubBusinessId", null);
                cmd.Parameters.AddWithValue("@CDR_FileLocation", null);
                cmd.Parameters.AddWithValue("@Query", 3);
                con.Open();
                result = cmd.ExecuteNonQuery();
                return result;
            }
            catch (Exception ex)
            {
                return result = 0;
            }
            finally
            {
                con.Close();
            }
        }
        public List<CDRAdapter> Selectalldata()
        {
            SqlConnection con = new SqlConnection(SQLU.con);
            DataSet ds = null;
            List<CDRAdapter> custlist = null;
            try
            {
                //ID , UserName , BusinessID , Status , ExtensionID
                SqlCommand cmd = new SqlCommand(storedProc, con);
                cmd.CommandType = CommandType.StoredProcedure;
                cmd.Parameters.AddWithValue("@id", null);
                cmd.Parameters.AddWithValue("@SubBusinessId", null);
                cmd.Parameters.AddWithValue("@CDR_FileLocation", null);
                cmd.Parameters.AddWithValue("@Query", 4);
                con.Open();
                SqlDataAdapter da = new SqlDataAdapter();
                da.SelectCommand = cmd;
                ds = new DataSet();
                da.Fill(ds);
                custlist = new List<CDRAdapter>();
                for (int i = 0; i < ds.Tables[0].Rows.Count; i++)
                {
                    CDRAdapter cobj = new CDRAdapter();
                    cobj.id = Convert.ToInt32(ds.Tables[0].Rows[i]["id"].ToString());
                    cobj.SubBusiness = ds.Tables[0].Rows[i]["SubBusinessId"].ToString();
                    cobj.CDR_FileLocation = ds.Tables[0].Rows[i]["CDR_FileLocation"].ToString();
                    custlist.Add(cobj);
                }
                return custlist;
            }
            catch (Exception ex)
            {
                return custlist;
            }
            finally
            {
                con.Close();
            }
        }

        public CDRAdapter SelectDatabyID(string ID)
        {
            SqlConnection con = new SqlConnection(SQLU.con);
            DataSet ds = null;
            CDRAdapter cobj = null;
            try
            {
                //ID , UserName , BusinessID , Status , ExtensionID
                SqlCommand cmd = new SqlCommand(storedProc, con);
                cmd.CommandType = CommandType.StoredProcedure;
                cmd.Parameters.AddWithValue("@id", ID);
                cmd.Parameters.AddWithValue("@SubBusinessId", null);
                cmd.Parameters.AddWithValue("@CDR_FileLocation", null);
                cmd.Parameters.AddWithValue("@Query", 5);
                SqlDataAdapter da = new SqlDataAdapter();
                da.SelectCommand = cmd;
                ds = new DataSet();
                da.Fill(ds);
                for (int i = 0; i < ds.Tables[0].Rows.Count; i++)
                {
                    cobj = new CDRAdapter();
                    cobj.id = Convert.ToInt32(ds.Tables[0].Rows[i]["id"].ToString());
                    cobj.SubBusiness = ds.Tables[0].Rows[i]["SubBusinessId"].ToString();
                    cobj.CDR_FileLocation = ds.Tables[0].Rows[i]["CDR_FileLocation"].ToString();
                }
                return cobj;
            }
            catch
            {
                return cobj;
            }
            finally
            {
                con.Close();
            }
        }
    }
    #endregion


    #region CMSAdapter
    public class CMSAdapter
    {
        public int id { get; set; }
        public int SubBusinessId { get; set; }
        public string SubBusiness { get; set; }
        [Display(Name = "CmsVerint")]
        public string CMS_Verient { get; set; }
        public string Echi_FileLocation { get; set; }

        public List<SubBusiness> SubBusinessList { get; set; }
   
        public List<CMSVerint> CmsVerintList { get; set; }

        public List<CMSAdapter> CMSAdapterDetails(string loginid)
        {

            List<CMSAdapter> objL = new List<CMSAdapter>();
            System.Data.SqlClient.SqlParameter[] sp = new System.Data.SqlClient.SqlParameter[1];
            sp[0] = new System.Data.SqlClient.SqlParameter("@loginid", SqlDbType.VarChar);
            sp[0].Value = loginid;
            //sp[1] = new System.Data.SqlClient.SqlParameter("@userid", SqlDbType.Int);
            //sp[1].Value = userid;
            SQLU S = new SQLU("");
            DataSet ds = S.GetData("sp_getallCMSAdapterDetails", sp);
            if (ds != null)
                if (ds.Tables[0].Rows.Count > 0)
                {
                    DataTable dt = ds.Tables[0];
                    foreach (DataRow dr in dt.Rows)
                    {
                        CMSAdapter MB = new CMSAdapter();
                        MB.id = Convert.ToInt16(dr["id"].ToString());
                        MB.SubBusiness = dr["SubBusiness"].ToString();
                        MB.CMS_Verient = dr["CMS_Verient"].ToString();
                        MB.Echi_FileLocation = dr["Echi_FileLocation"].ToString();



                        objL.Add(MB);

                    }
                }


            return objL;
        }
     

    }
    public class CMSAdapterDataAccessLayer
    {
        string storedProc = "sp_RCM_CmsAdapterCRUD";
        public string InsertData(CMSAdapter obj)
        {
            SqlConnection con = new SqlConnection(SQLU.con);

            string result = "";
            try
            {
                //id,id,SubBusinessId,Version,ServerId,HostName,UserName,Password,Domain

                SqlCommand cmd = new SqlCommand(storedProc, con);
                cmd.CommandType = CommandType.StoredProcedure;
                cmd.Parameters.AddWithValue("@id", null);
                cmd.Parameters.AddWithValue("@SubBusinessId", obj.SubBusinessId);
                cmd.Parameters.AddWithValue("@SubBusiness", obj.SubBusiness);
                cmd.Parameters.AddWithValue("@CMS_Verient", obj.CMS_Verient);
                cmd.Parameters.AddWithValue("@Echi_FileLocation", obj.Echi_FileLocation);
                cmd.Parameters.AddWithValue("@Query", 1);

                con.Open();
                result = cmd.ExecuteScalar().ToString();
                return result;
            }
            catch (Exception ex)
            {
                return result = ex.ToString();
            }
            finally
            {
                con.Close();
            }
        }
        public string UpdateData(CMSAdapter obj)
        {
            SqlConnection con = new SqlConnection(SQLU.con);
            string result = "";
            try
            {
                //ID , UserName , BusinessID , Status , ExtensionID
                SqlCommand cmd = new SqlCommand(storedProc, con);
                cmd.CommandType = CommandType.StoredProcedure;
                cmd.Parameters.AddWithValue("@id", obj.id);
                cmd.Parameters.AddWithValue("@SubBusinessId", obj.SubBusiness);
                cmd.Parameters.AddWithValue("@Version", obj.CMS_Verient);
                cmd.Parameters.AddWithValue("@ServerId", obj.Echi_FileLocation);
                cmd.Parameters.AddWithValue("@Query", 2);
                con.Open();
                result = cmd.ExecuteScalar().ToString();
                return result;
            }
            catch (Exception ex)
            {
                return result = ex.ToString();
            }
            finally
            {
                con.Close();
            }
        }
        public int DeleteData(String ID)
        {
            SqlConnection con = new SqlConnection(SQLU.con);
            int result;
            try
            {
                //ID , UserName , BusinessID , Status , ExtensionID
                SqlCommand cmd = new SqlCommand(storedProc, con);
                cmd.CommandType = CommandType.StoredProcedure;
                cmd.Parameters.AddWithValue("@id", ID);
                cmd.Parameters.AddWithValue("@SubBusinessId", null);
                cmd.Parameters.AddWithValue("@CMS_Verient", null);
                cmd.Parameters.AddWithValue("@Echi_FileLocation", null);

                cmd.Parameters.AddWithValue("@Query", 3);
                con.Open();
                result = cmd.ExecuteNonQuery();
                return result;
            }
            catch (Exception ex)
            {
                return result = 0;
            }
            finally
            {
                con.Close();
            }
        }
        public List<CMSAdapter> Selectalldata()
        {
            SqlConnection con = new SqlConnection(SQLU.con);
            DataSet ds = null;
            List<CMSAdapter> custlist = null;
            try
            {
                //ID , UserName , BusinessID , Status , ExtensionID
                SqlCommand cmd = new SqlCommand(storedProc, con);
                cmd.CommandType = CommandType.StoredProcedure;
                cmd.Parameters.AddWithValue("@id", null);
                cmd.Parameters.AddWithValue("@SubBusinessId", null);
                cmd.Parameters.AddWithValue("@CMS_Verient", null);
                cmd.Parameters.AddWithValue("@Echi_FileLocation", null);

                cmd.Parameters.AddWithValue("@Query", 4);
                con.Open();
                SqlDataAdapter da = new SqlDataAdapter();
                da.SelectCommand = cmd;
                ds = new DataSet();
                da.Fill(ds);
                custlist = new List<CMSAdapter>();
                for (int i = 0; i < ds.Tables[0].Rows.Count; i++)
                {
                    CMSAdapter cobj = new CMSAdapter();
                    cobj.id = Convert.ToInt32(ds.Tables[0].Rows[i]["id"].ToString());
                    cobj.SubBusiness = ds.Tables[0].Rows[i]["SubBusinessId"].ToString();
                    cobj.CMS_Verient = ds.Tables[0].Rows[i]["CMS_Verient"].ToString();
                    cobj.Echi_FileLocation = ds.Tables[0].Rows[i]["Echi_FileLocation"].ToString();
                    custlist.Add(cobj);
                }
                return custlist;
            }
            catch (Exception ex)
            {
                return custlist;
            }
            finally
            {
                con.Close();
            }
        }

        public CMSAdapter SelectDatabyID(string ID)
        {
            SqlConnection con = new SqlConnection(SQLU.con);
            DataSet ds = null;
            CMSAdapter cobj = null;
            try
            {
                //ID , UserName , BusinessID , Status , ExtensionID
                SqlCommand cmd = new SqlCommand(storedProc, con);
                cmd.CommandType = CommandType.StoredProcedure;
                cmd.Parameters.AddWithValue("@id", ID);
                cmd.Parameters.AddWithValue("@SubBusinessId", null);
                cmd.Parameters.AddWithValue("@CMS_Verient", null);
                cmd.Parameters.AddWithValue("@Echi_FileLocation", null);

                cmd.Parameters.AddWithValue("@Query", 5);
                SqlDataAdapter da = new SqlDataAdapter();
                da.SelectCommand = cmd;
                ds = new DataSet();
                da.Fill(ds);
                for (int i = 0; i < ds.Tables[0].Rows.Count; i++)
                {
                    cobj = new CMSAdapter();
                    cobj.id = Convert.ToInt32(ds.Tables[0].Rows[i]["id"].ToString());
                    cobj.SubBusiness = ds.Tables[0].Rows[i]["SubBusinessId"].ToString();
                    cobj.CMS_Verient = ds.Tables[0].Rows[i]["CMS_Verient"].ToString();
                    cobj.Echi_FileLocation = ds.Tables[0].Rows[i]["Echi_FileLocation"].ToString();


                }
                return cobj;
            }
            catch
            {
                return cobj;
            }
            finally
            {
                con.Close();
            }
        }
    }
    #endregion


    #region Export
    public class Export
    {
        public int id { get; set; }
        public string SubBusiness { get; set; }
        public string ExpectedCallVolume { get; set; }
        public string CreateRule { get; set; }
        public string EnterList { get; set; }
        public string ExportToLocation { get; set; }
        public string ExportFormat { get; set; }
        public string FileNamingConvention { get; set; }
        public string ExportSchedule { get; set; }
        public string Frequency { get; set; }
        public string Day { get; set; }
        public string Hours { get; set; }
        public string Minutes { get; set; }
        public string WeekDay { get; set; }
        public List<SubBusiness> SubBusinessList { get; set; }
        public List<Export> CallVolumeList { get; set; }
        public List<Export> ExportRuleList { get; set; }
        public List<Field> allFieldList { get; set; }

        public List<Export> ExportDetails(string loginid)
        {

            List<Export> objL = new List<Export>();
            System.Data.SqlClient.SqlParameter[] sp = new System.Data.SqlClient.SqlParameter[1];
            sp[0] = new System.Data.SqlClient.SqlParameter("@loginid", SqlDbType.VarChar);
            sp[0].Value = loginid;
            //sp[1] = new System.Data.SqlClient.SqlParameter("@userid", SqlDbType.Int);
            //sp[1].Value = userid;
            SQLU S = new SQLU("");
            DataSet ds = S.GetData("sp_getallExportDetails", sp);
            if (ds != null)
                if (ds.Tables[0].Rows.Count > 0)
                {
                    DataTable dt = ds.Tables[0];
                    foreach (DataRow dr in dt.Rows)
                    {
                        Export MB = new Export();
                        MB.id = Convert.ToInt16(dr["id"].ToString());
                        MB.SubBusiness = dr["SubBusiness"].ToString();
                        MB.ExpectedCallVolume = dr["ExpectedCallVolume"].ToString();
                        MB.CreateRule = dr["CreateRule"].ToString();
                        MB.EnterList = dr["EnterList"].ToString();
                        MB.ExportToLocation = dr["ExportToLocation"].ToString();
                        MB.ExportFormat = dr["ExportFormat"].ToString();
                        MB.Frequency = dr["Frequency"].ToString();
                        MB.Day = dr["Day"].ToString();
                        MB.WeekDay = dr["WeekDay"].ToString();
                        MB.Hours = dr["Hours"].ToString();
                        MB.Minutes = dr["Minutes"].ToString();
                        MB.ExportSchedule = dr["ExportSchedule"].ToString();
                        objL.Add(MB);

                    }
                }


            return objL;
        }

        public static DataSet GetCallVolumeList()
        {
            ACBDashboard.BL.User user = (ACBDashboard.BL.User)HttpContext.Current.Session["user"];
            DataSet ds = new DataSet();
            System.Data.SqlClient.SqlParameter[] sp = new System.Data.SqlClient.SqlParameter[0];

            SQLU S = new SQLU(System.Configuration.ConfigurationManager.AppSettings["CON"]);
            ds = S.GetData("sp_RCM_SelectCallVolume", sp);

            return ds;
        }
        public static DataSet GetExportRuleList()
        {
            ACBDashboard.BL.User user = (ACBDashboard.BL.User)HttpContext.Current.Session["user"];
            DataSet ds = new DataSet();
            System.Data.SqlClient.SqlParameter[] sp = new System.Data.SqlClient.SqlParameter[0];

            SQLU S = new SQLU(System.Configuration.ConfigurationManager.AppSettings["CON"]);
            ds = S.GetData("sp_RCM_SelectExportRule", sp);

            return ds;
        }
        public static DataSet GetFieldList()
        {
            ACBDashboard.BL.User user = (ACBDashboard.BL.User)HttpContext.Current.Session["user"];
            DataSet ds = new DataSet();
            System.Data.SqlClient.SqlParameter[] sp = new System.Data.SqlClient.SqlParameter[0];

            SQLU S = new SQLU(System.Configuration.ConfigurationManager.AppSettings["CON"]);
            ds = S.GetData("sp_RCM_getField", sp);

            return ds;
        }
    }
    public class ExportDataAccessLayer
    {
        string storedProc = "sp_RCM_ExportCRUD";
        public string InsertData(Export obj)
        {
            SqlConnection con = new SqlConnection(SQLU.con);

            string result = "";
            try
            {
                

                SqlCommand cmd = new SqlCommand(storedProc, con);
                cmd.CommandType = CommandType.StoredProcedure;
                cmd.Parameters.AddWithValue("@ID",null);
                cmd.Parameters.AddWithValue("@SubBusiness", obj.SubBusiness);
                cmd.Parameters.AddWithValue("@ExpectedCallVolume", obj.ExpectedCallVolume);
                cmd.Parameters.AddWithValue("@CreateRule", obj.CreateRule);
                cmd.Parameters.AddWithValue("@EnterList", obj.EnterList);
                cmd.Parameters.AddWithValue("@ExportToLocation", obj.ExportToLocation);
                cmd.Parameters.AddWithValue("@ExportFormat", obj.ExportFormat);

                cmd.Parameters.AddWithValue("@Frequency", obj.Frequency);
                cmd.Parameters.AddWithValue("@Day", obj.Day);
                cmd.Parameters.AddWithValue("@Hours", obj.Hours);
                cmd.Parameters.AddWithValue("@Minutes", obj.Minutes);
                cmd.Parameters.AddWithValue("@WeekDay", obj.WeekDay);

                cmd.Parameters.AddWithValue("@Query", 1);

                con.Open();
                result = cmd.ExecuteScalar().ToString();
                return result;
            }
            catch (Exception ex)
            {
                return result = ex.ToString();
            }
            finally
            {
                con.Close();
            }
        }
        public string UpdateData(Export obj)
        {
            SqlConnection con = new SqlConnection(SQLU.con);
            string result = "";
            try
            {
                //ID , UserName , BusinessID , Status , ExtensionID
                SqlCommand cmd = new SqlCommand(storedProc, con);
                cmd.CommandType = CommandType.StoredProcedure;
                cmd.Parameters.AddWithValue("@id", null);
                cmd.Parameters.AddWithValue("@SubBusiness", obj.SubBusiness);
                cmd.Parameters.AddWithValue("@ExpectedCallVolume", obj.ExpectedCallVolume);
                cmd.Parameters.AddWithValue("@CreateRule", obj.CreateRule);
                cmd.Parameters.AddWithValue("@EnterList", obj.EnterList);
                cmd.Parameters.AddWithValue("@ExportToLocation", obj.ExportToLocation);
                cmd.Parameters.AddWithValue("@ExportFormat", obj.ExportFormat);
               
                cmd.Parameters.AddWithValue("@Query", 2);
                con.Open();
                result = cmd.ExecuteScalar().ToString();
                return result;
            }
            catch (Exception ex)
            {
                return result = ex.ToString();
            }
            finally
            {
                con.Close();
            }
        }
        public int DeleteData(String ID)
        {
            SqlConnection con = new SqlConnection(SQLU.con);
            int result;
            try
            {
                //ID , UserName , BusinessID , Status , ExtensionID
                SqlCommand cmd = new SqlCommand(storedProc, con);
                cmd.CommandType = CommandType.StoredProcedure;
                cmd.Parameters.AddWithValue("@id", ID);
                cmd.Parameters.AddWithValue("@SubBusiness", null);
                cmd.Parameters.AddWithValue("@ExpectedCallVolume", null);
                cmd.Parameters.AddWithValue("@CreateRule", null);
                cmd.Parameters.AddWithValue("@EnterList", null);
                cmd.Parameters.AddWithValue("@ExportToLocation", null);
                cmd.Parameters.AddWithValue("@ExportFormat", null);
               
                cmd.Parameters.AddWithValue("@Frequency", null);
                cmd.Parameters.AddWithValue("@Day", null);
                cmd.Parameters.AddWithValue("@Hours", null);
                cmd.Parameters.AddWithValue("@Minutes", null);
                cmd.Parameters.AddWithValue("@WeekDay", null);
                cmd.Parameters.AddWithValue("@Query", 3);
                con.Open();
                result = cmd.ExecuteNonQuery();
                return result;
            }
            catch (Exception ex)
            {
                return result = 0;
            }
            finally
            {
                con.Close();
            }
        }
        public List<Export> Selectalldata()
        {
            SqlConnection con = new SqlConnection(SQLU.con);
            DataSet ds = null;
            List<Export> custlist = null;
            try
            {
                //ID , UserName , BusinessID , Status , ExtensionID
                SqlCommand cmd = new SqlCommand(storedProc, con);
                cmd.CommandType = CommandType.StoredProcedure;
                cmd.Parameters.AddWithValue("@id", null);
                cmd.Parameters.AddWithValue("@SubBusiness", null);
                cmd.Parameters.AddWithValue("@ExpectedCallVolume", null);
                cmd.Parameters.AddWithValue("@CreateRule", null);
                cmd.Parameters.AddWithValue("@EnterList", null);
                cmd.Parameters.AddWithValue("@ExportToLocation", null);
                cmd.Parameters.AddWithValue("@ExportFormat", null);
              
                cmd.Parameters.AddWithValue("@Frequency", null);
                cmd.Parameters.AddWithValue("@Day", null);
                cmd.Parameters.AddWithValue("@Hours", null);
                cmd.Parameters.AddWithValue("@Minutes", null);
                cmd.Parameters.AddWithValue("@WeekDay", null);
                cmd.Parameters.AddWithValue("@Query", 4);
                con.Open();
                SqlDataAdapter da = new SqlDataAdapter();
                da.SelectCommand = cmd;
                ds = new DataSet();
                da.Fill(ds);
                custlist = new List<Export>();
                for (int i = 0; i < ds.Tables[0].Rows.Count; i++)
                {
                    Export cobj = new Export();
                    cobj.id = Convert.ToInt32(ds.Tables[0].Rows[i]["id"].ToString());
                    cobj.SubBusiness = ds.Tables[0].Rows[i]["SubBusiness"].ToString();
                    cobj.ExpectedCallVolume = ds.Tables[0].Rows[i]["ExpectedCallVolume"].ToString();
                    cobj.CreateRule = ds.Tables[0].Rows[i]["CreateRule"].ToString();
                    cobj.EnterList = ds.Tables[0].Rows[i]["EnterList"].ToString();
                    cobj.ExportToLocation = ds.Tables[0].Rows[i]["ExportToLocation"].ToString();
                    cobj.ExportFormat = ds.Tables[0].Rows[i]["ExportFormat"].ToString();
                   
                    cobj.Frequency = ds.Tables[0].Rows[i]["Frequency"].ToString();
                    cobj.Day = ds.Tables[0].Rows[i]["Day"].ToString();
                    cobj.Hours = ds.Tables[0].Rows[i]["Hours"].ToString();
                    cobj.Minutes = ds.Tables[0].Rows[i]["Minutes"].ToString();
                    cobj.WeekDay = ds.Tables[0].Rows[i]["Weekday"].ToString();
                    custlist.Add(cobj);
                }
                return custlist;
            }
            catch (Exception ex)
            {
                return custlist;
            }
            finally
            {
                con.Close();
            }
        }

        public Export SelectDatabyID(string ID)
        {
            SqlConnection con = new SqlConnection(SQLU.con);
            DataSet ds = null;
            Export cobj = null;
            try
            {
                //ID , UserName , BusinessID , Status , ExtensionID
                SqlCommand cmd = new SqlCommand(storedProc, con);
                cmd.CommandType = CommandType.StoredProcedure;
                cmd.Parameters.AddWithValue("@id", ID);
                cmd.Parameters.AddWithValue("@SubBusiness", null);
                cmd.Parameters.AddWithValue("@ExpectedCallVolume", null);
                cmd.Parameters.AddWithValue("@CreateRule", null);
                cmd.Parameters.AddWithValue("@EnterList", null);
                cmd.Parameters.AddWithValue("@ExportToLocation", null);
                cmd.Parameters.AddWithValue("@ExportFormat", null);
                
                cmd.Parameters.AddWithValue("@Frequency", null);
                cmd.Parameters.AddWithValue("@Day", null);
                cmd.Parameters.AddWithValue("@Hours", null);
                cmd.Parameters.AddWithValue("@Minutes", null);
                cmd.Parameters.AddWithValue("@WeekDay", null);
                cmd.Parameters.AddWithValue("@Query", 5);
                SqlDataAdapter da = new SqlDataAdapter();
                da.SelectCommand = cmd;
                ds = new DataSet();
                da.Fill(ds);
                for (int i = 0; i < ds.Tables[0].Rows.Count; i++)
                {
                    cobj = new Export();
                    cobj.id = Convert.ToInt32(ds.Tables[0].Rows[i]["id"].ToString());
                    cobj.SubBusiness = ds.Tables[0].Rows[i]["SubBusiness"].ToString();
                    cobj.ExpectedCallVolume = ds.Tables[0].Rows[i]["ExpectedCallVolume"].ToString();
                    cobj.CreateRule = ds.Tables[0].Rows[i]["CreateRule"].ToString();
                    cobj.EnterList = ds.Tables[0].Rows[i]["EnterList"].ToString();
                    cobj.ExportToLocation = ds.Tables[0].Rows[i]["ExportToLocation"].ToString();
                    cobj.ExportFormat = ds.Tables[0].Rows[i]["ExportFormat"].ToString();
                   
                    cobj.Frequency = ds.Tables[0].Rows[i]["Frequency"].ToString();
                    cobj.Day = ds.Tables[0].Rows[i]["Day"].ToString();
                    cobj.Hours = ds.Tables[0].Rows[i]["Hours"].ToString();
                    cobj.Minutes = ds.Tables[0].Rows[i]["Minutes"].ToString();
                    cobj.WeekDay = ds.Tables[0].Rows[i]["Weekday"].ToString();
                }
                return cobj;
            }
            catch
            {
                return cobj;
            }
            finally
            {
                con.Close();
            }
        }
    }
    #endregion

    public class Version
    {
        public int id { get; set; }
        public string VersionID { get; set; }
        public string VersionName { get; set; }
    }
    public class CMSVerint
    {
        public int id { get; set; }
        public string CMS_Verint { get; set; }
        public string CMS_VerintID { get; set; }

    }
    public class Field
    {
        public int ID { get; set; }
        public string Text { get; set; }
      

    }

}