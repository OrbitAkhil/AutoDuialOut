﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Data;
using System.Web.Mvc;
using System.ComponentModel.DataAnnotations;
using System.Data.SqlClient;

namespace ACBDashboard.BL
{
    public class Dashboard
    {
        public  string  RadioField { get; set; }
        [Required]
        [DataType(DataType.Date)]
        [DisplayFormat(DataFormatString = "{0:yyyy-MM-dd}", ApplyFormatInEditMode = true)]
        public  DateTime fromDate { get; set; }
       
        [Required]
        [DataType(DataType.Date)]
        [DisplayFormat(DataFormatString = "{0:yyyy-MM-dd}", ApplyFormatInEditMode = true)]
        public  DateTime toDate { get; set; }

        public string UserId { get; set; }

        #region IT
        //public static DataSet Reportgetdashboard()
        //{
        //    DataSet ds = new DataSet();
        //    System.Data.SqlClient.SqlParameter[] sp = new System.Data.SqlClient.SqlParameter[0];
        //    SQLU S = new SQLU(System.Configuration.ConfigurationManager.AppSettings["CON"]);
        //    ds = S.GetData("usp_getdashboard", sp);

        //    return ds;
        //}
        //public static DataSet getdashboard()
        //{
        //    DataSet ds = new DataSet();
        //    System.Data.SqlClient.SqlParameter[] sp = new System.Data.SqlClient.SqlParameter[0];
        //    SQLU S = new SQLU(System.Configuration.ConfigurationManager.AppSettings["CON"]);
        //    ds = S.GetData("usp_getdashboard", sp);

        //    return ds;

        //}
        public static DataSet getdashboard()
        {
            DataSet ds = new DataSet();
            System.Data.SqlClient.SqlParameter[] sp = new System.Data.SqlClient.SqlParameter[1];
            sp[0] = new System.Data.SqlClient.SqlParameter("@UserId", SqlDbType.VarChar);
            sp[0].Value = "123456";
            SQLU S = new SQLU(System.Configuration.ConfigurationManager.AppSettings["CON"]);
            ds = S.GetData("usp_getdashboard", sp);

            return ds;

        }

        public static DataSet ReportAgentVdngetdashboard()
        {
            DataSet ds = new DataSet();
            System.Data.SqlClient.SqlParameter[] sp = new System.Data.SqlClient.SqlParameter[0];
            SQLU S = new SQLU(System.Configuration.ConfigurationManager.AppSettings["CON"]);
            ds = S.GetData("[sp_AgentSummaryReport]", sp);

            return ds;

        }

        public static DataSet HoulryComplianceReportdashboard(DateTime ReportDate)
        {
            DataSet ds = new DataSet();
            System.Data.SqlClient.SqlParameter[] sp = new System.Data.SqlClient.SqlParameter[1];
            sp[0] = new System.Data.SqlClient.SqlParameter("@ReportDate", SqlDbType.DateTime);
            sp[0].Value = ReportDate.ToString();
            SQLU S = new SQLU(System.Configuration.ConfigurationManager.AppSettings["CON"]);
            ds = S.GetData("[usp_hourlygetdashboard]", sp);

            return ds;

        }

        public static DataTable MergeHoulryComplianceReportdashboard(DateTime ReportDate)
        {

            System.Data.DataSet ds = ACBDashboard.BL.Dashboard.HoulryComplianceReportdashboard(ReportDate);
            System.Data.DataTable dt = ds.Tables[0];
            System.Data.DataTable dtECHI = ds.Tables[1];
            System.Data.DataTable dtCALL = ds.Tables[2];
            System.Data.DataTable dtREC = ds.Tables[3];
            System.Data.DataTable dtOECHI = ds.Tables[4];
            System.Data.DataTable dtOCALL = ds.Tables[5];
            System.Data.DataTable dtOREC = ds.Tables[6];


            System.Data.DataTable dtTwo = MergeTablesByIndex(dtECHI, dtCALL);
            System.Data.DataTable dtThree = MergeTablesByIndex(dtTwo, dtREC);
            System.Data.DataTable dtFour = MergeTablesByIndex(dtThree, dtOECHI);
            System.Data.DataTable dtFive = MergeTablesByIndex(dtFour, dtOCALL);
            System.Data.DataTable dtSix = MergeTablesByIndex(dtFive, dtOREC);


            return dtSix;

        }
        public static DataSet Reportgetdashboard(string UserId,DateTime fromDate, DateTime toDate, string range)
         {
            DataSet ds = new DataSet();
            System.Data.SqlClient.SqlParameter[] sp = new System.Data.SqlClient.SqlParameter[4];
            sp[0] = new System.Data.SqlClient.SqlParameter("@AgentId", SqlDbType.VarChar);
            sp[0].Value = UserId.ToString();
            sp[1] = new System.Data.SqlClient.SqlParameter("@fromDate", SqlDbType.DateTime);
            sp[1].Value = fromDate.ToString();
            sp[2] = new System.Data.SqlClient.SqlParameter("@toDate", SqlDbType.DateTime);
            sp[2].Value = toDate.ToString();
            sp[3] = new System.Data.SqlClient.SqlParameter("@Range", SqlDbType.VarChar);
            sp[3].Value = range;
            SQLU S = new SQLU(System.Configuration.ConfigurationManager.AppSettings["CON"]);
            ds = S.GetData("sp_GetPendingCallReport", sp);
            return ds;
        }
        public static String getColor(string Percentage)
        {

            System.Data.SqlClient.SqlParameter spout = new System.Data.SqlClient.SqlParameter("@Error", SqlDbType.VarChar);
            spout.Direction = ParameterDirection.Output;
            spout.Size = 100;
            System.Data.SqlClient.SqlParameter[] sp = new System.Data.SqlClient.SqlParameter[1];
            sp[0] = new System.Data.SqlClient.SqlParameter("@Percentage", SqlDbType.VarChar);
            sp[0].Value = Percentage;
            SQLU s = new SQLU(System.Configuration.ConfigurationManager.AppSettings["CON"]);
            string msg = s.ExecuteProcOut("sp_getColor", spout, sp);
            //DataSet ds = SQLU.GetData("sp_UTOM_AddBusiness", sp);
            return msg;
        }


        public static DataSet getadmindashboard()
        {
            DataSet ds = new DataSet();
            System.Data.SqlClient.SqlParameter[] sp = new System.Data.SqlClient.SqlParameter[0];
            SQLU S = new SQLU(System.Configuration.ConfigurationManager.AppSettings["CON"]);
            ds = S.GetData("usp_getadmindashboard", sp);
            return ds;

        }
        #endregion 

        #region Business
        public static DataSet Businessgetdashboard()
        {
            ACBDashboard.BL.User user = (ACBDashboard.BL.User)HttpContext.Current.Session["user"];

            DataSet ds = new DataSet();
            System.Data.SqlClient.SqlParameter[] sp = new System.Data.SqlClient.SqlParameter[1];
            sp[0] = new System.Data.SqlClient.SqlParameter("@UserId", SqlDbType.VarChar);
            sp[0].Value = user.Userid.ToString();
            SQLU S = new SQLU(System.Configuration.ConfigurationManager.AppSettings["CON"]);
            ds = S.GetData("usp_getbusinessdashboard", sp);
            return ds;
              
        }
        public static DataSet Businessgetdashboard(DateTime fromDate, DateTime toDate, string range)
        {
            ACBDashboard.BL.User user = (ACBDashboard.BL.User)HttpContext.Current.Session["user"];
            DataSet ds = new DataSet();
            System.Data.SqlClient.SqlParameter[] sp = new System.Data.SqlClient.SqlParameter[4];
            sp[0] = new System.Data.SqlClient.SqlParameter("@UserId", SqlDbType.VarChar);
            sp[0].Value = user.Userid.ToString();
            sp[1] = new System.Data.SqlClient.SqlParameter("@fromDate", SqlDbType.DateTime);
            sp[1].Value = fromDate.ToString();
            sp[2] = new System.Data.SqlClient.SqlParameter("@toDate", SqlDbType.DateTime);
            sp[2].Value = toDate.ToString();
            sp[3] = new System.Data.SqlClient.SqlParameter("@Range", SqlDbType.BigInt);
            sp[3].Value = range;
            SQLU S = new SQLU(System.Configuration.ConfigurationManager.AppSettings["CON"]);
            ds = S.GetData("usp_getBusinessReportData", sp);

            return ds;
        }

        public static DataSet HoulryBusinessComplianceReportdashboard(DateTime ReportDate)
        {
            ACBDashboard.BL.User user = (ACBDashboard.BL.User)HttpContext.Current.Session["user"];
            DataSet ds = new DataSet();
            System.Data.SqlClient.SqlParameter[] sp = new System.Data.SqlClient.SqlParameter[2];
            sp[0] = new System.Data.SqlClient.SqlParameter("@ReportDate", SqlDbType.DateTime);
            sp[0].Value = ReportDate.ToString();
            sp[1] = new SqlParameter("@UserId", SqlDbType.VarChar);
            sp[1].Value = user.Userid;
            SQLU S = new SQLU(System.Configuration.ConfigurationManager.AppSettings["CON"]);
            ds = S.GetData("[usp_Hourlygetbusinessdashboard]", sp);

            return ds;

        }
        public static DataTable MergeHoulryBusinessComplianceReportdashboard(DateTime ReportDate)
        {

            System.Data.DataSet ds = ACBDashboard.BL.Dashboard.HoulryBusinessComplianceReportdashboard(ReportDate);
            System.Data.DataTable dt = ds.Tables[0];
            System.Data.DataTable dtECHI = ds.Tables[1];
            System.Data.DataTable dtCALL = ds.Tables[2];
            System.Data.DataTable dtREC = ds.Tables[3];
            System.Data.DataTable dtOECHI = ds.Tables[4];
            System.Data.DataTable dtOCALL = ds.Tables[5];
            System.Data.DataTable dtOREC = ds.Tables[6];

            System.Data.DataTable dtTwo = MergeTablesByIndex(dtECHI, dtCALL);
            System.Data.DataTable dtThree = MergeTablesByIndex(dtTwo, dtREC);
            System.Data.DataTable dtFour = MergeTablesByIndex(dtThree, dtOECHI);
            System.Data.DataTable dtFive = MergeTablesByIndex(dtFour, dtOCALL);
            System.Data.DataTable dtSix = MergeTablesByIndex(dtFive, dtOREC);
            return dtSix;

        }

        public static DataSet getTFDIDNO(int subbusinessid)
        {
            DataSet ds = new DataSet();
            System.Data.SqlClient.SqlParameter[] sp = new System.Data.SqlClient.SqlParameter[1];
            sp[0] = new System.Data.SqlClient.SqlParameter("@subbusinessid", SqlDbType.Int);
            sp[0].Value = subbusinessid;
            SQLU S = new SQLU(System.Configuration.ConfigurationManager.AppSettings["CON"]);
            ds = S.GetData("usp_getTFDID", sp);
            return ds;

        }
        #endregion


        #region Notification




        #endregion

        public static DataSet ReportPPdashboard(string sbid, DateTime fromDate, DateTime toDate, string range)
        {
            if (range != "0")
            {
                ACBDashboard.BL.User user = (ACBDashboard.BL.User)HttpContext.Current.Session["user"];
                DataSet ds = new DataSet();
                System.Data.SqlClient.SqlParameter[] sp = new System.Data.SqlClient.SqlParameter[4];
                sp[0] = new System.Data.SqlClient.SqlParameter("@SubBusinessID", SqlDbType.VarChar);
                sp[0].Value = sbid.ToString();

                sp[1] = new System.Data.SqlClient.SqlParameter("@fromDate", SqlDbType.DateTime);
                sp[1].Value = fromDate.ToString();
                sp[2] = new System.Data.SqlClient.SqlParameter("@toDate", SqlDbType.DateTime);
                sp[2].Value = toDate.ToString();
                sp[3] = new System.Data.SqlClient.SqlParameter("@Range", SqlDbType.BigInt);
                sp[3].Value = range;
                SQLU S = new SQLU(System.Configuration.ConfigurationManager.AppSettings["CON"]);
                ds = S.GetData("usp_ReportpopupbySBID", sp);

                return ds;
            }
            else
            {
                ACBDashboard.BL.User user = (ACBDashboard.BL.User)HttpContext.Current.Session["user"];
                DataSet ds = new DataSet();
                System.Data.SqlClient.SqlParameter[] sp = new System.Data.SqlClient.SqlParameter[4];
                sp[0] = new System.Data.SqlClient.SqlParameter("@SubBusinessID", SqlDbType.VarChar);
                sp[0].Value = sbid.ToString();

                sp[1] = new System.Data.SqlClient.SqlParameter("@fromDate", SqlDbType.DateTime);
                sp[1].Value = fromDate.ToString();
                sp[2] = new System.Data.SqlClient.SqlParameter("@toDate", SqlDbType.DateTime);
                sp[2].Value = toDate.ToString();
                sp[3] = new System.Data.SqlClient.SqlParameter("@Range", SqlDbType.BigInt);
                sp[3].Value = null;
                SQLU S = new SQLU(System.Configuration.ConfigurationManager.AppSettings["CON"]);
                ds = S.GetData("usp_ReportpopupbySBID", sp);

                return ds;
            }
        }

        public static DataSet ReportPPdashboardOutBound(string sbid, DateTime fromDate, DateTime toDate, string range)
        {
            if (range != "0")
            {
                ACBDashboard.BL.User user = (ACBDashboard.BL.User)HttpContext.Current.Session["user"];
                DataSet ds = new DataSet();
                System.Data.SqlClient.SqlParameter[] sp = new System.Data.SqlClient.SqlParameter[4];
                sp[0] = new System.Data.SqlClient.SqlParameter("@SubBusinessID", SqlDbType.VarChar);
                sp[0].Value = sbid.ToString();

                sp[1] = new System.Data.SqlClient.SqlParameter("@fromDate", SqlDbType.DateTime);
                sp[1].Value = fromDate.ToString();
                sp[2] = new System.Data.SqlClient.SqlParameter("@toDate", SqlDbType.DateTime);
                sp[2].Value = toDate.ToString();
                sp[3] = new System.Data.SqlClient.SqlParameter("@Range", SqlDbType.BigInt);
                sp[3].Value = range;
                SQLU S = new SQLU(System.Configuration.ConfigurationManager.AppSettings["CON"]);
                ds = S.GetData("usp_ReportpopupbySBID_OutBound", sp);

                return ds;
            }
            else
            {
                ACBDashboard.BL.User user = (ACBDashboard.BL.User)HttpContext.Current.Session["user"];
                DataSet ds = new DataSet();
                System.Data.SqlClient.SqlParameter[] sp = new System.Data.SqlClient.SqlParameter[4];
                sp[0] = new System.Data.SqlClient.SqlParameter("@SubBusinessID", SqlDbType.VarChar);
                sp[0].Value = sbid.ToString();

                sp[1] = new System.Data.SqlClient.SqlParameter("@fromDate", SqlDbType.DateTime);
                sp[1].Value = fromDate.ToString();
                sp[2] = new System.Data.SqlClient.SqlParameter("@toDate", SqlDbType.DateTime);
                sp[2].Value = toDate.ToString();
                sp[3] = new System.Data.SqlClient.SqlParameter("@Range", SqlDbType.BigInt);
                sp[3].Value = null;
                SQLU S = new SQLU(System.Configuration.ConfigurationManager.AppSettings["CON"]);
                ds = S.GetData("usp_ReportpopupbySBID_OutBound", sp);

                return ds;
            }
        }
        //HourlyReportPPdashboardInBound
        public static DataSet HourlyReportPPdashboard(string sbid, string  hour , DateTime  Date )
        {
         
                ACBDashboard.BL.User user = (ACBDashboard.BL.User)HttpContext.Current.Session["user"];
                DataSet ds = new DataSet();
                System.Data.SqlClient.SqlParameter[] sp = new System.Data.SqlClient.SqlParameter[3];
                sp[0] = new System.Data.SqlClient.SqlParameter("@SubBusinessID", SqlDbType.VarChar);
                sp[0].Value = sbid.ToString();

                sp[1] = new System.Data.SqlClient.SqlParameter("@hour", SqlDbType.Int);
                sp[1].Value = hour.ToString();

                sp[2] = new System.Data.SqlClient.SqlParameter("@ReportDate", SqlDbType.DateTime);
                sp[2].Value = Date.ToString();
            
            SQLU S = new SQLU(System.Configuration.ConfigurationManager.AppSettings["CON"]);
                ds = S.GetData("usp_HourlyReportpopupbySBID", sp);

                return ds;
           
           
        }
        //HourlyReportPPdashboardOutBound
        public static DataSet HourlyReportPPdashboardOutBound(string sbid, string hour, DateTime Date)
        {

            ACBDashboard.BL.User user = (ACBDashboard.BL.User)HttpContext.Current.Session["user"];
            DataSet ds = new DataSet();
            System.Data.SqlClient.SqlParameter[] sp = new System.Data.SqlClient.SqlParameter[3];
            sp[0] = new System.Data.SqlClient.SqlParameter("@SubBusinessID", SqlDbType.VarChar);
            sp[0].Value = sbid.ToString();

            sp[1] = new System.Data.SqlClient.SqlParameter("@hour", SqlDbType.Int);
            sp[1].Value = hour.ToString();

            sp[2] = new System.Data.SqlClient.SqlParameter("@ReportDate", SqlDbType.DateTime);
            sp[2].Value = Date.ToString();

            SQLU S = new SQLU(System.Configuration.ConfigurationManager.AppSettings["CON"]);
            ds = S.GetData("usp_HourlyReportpopupbySBID_OutBound", sp);

            return ds;


        }
        //public static DataSet ReportCompliancePPdashboard(string sbid)
        //{
        //    RCM.BL.User user = (RCM.BL.User)HttpContext.Current.Session["user"];
        //    DataSet ds = new DataSet();
        //    System.Data.SqlClient.SqlParameter[] sp = new System.Data.SqlClient.SqlParameter[1];
        //    sp[0] = new System.Data.SqlClient.SqlParameter("@SubBusinessID", SqlDbType.VarChar);
        //    sp[0].Value = sbid.ToString();
        //    SQLU S = new SQLU(System.Configuration.ConfigurationManager.AppSettings["CON"]);
        //    ds = S.GetData("usp_ReportpopupbySBID", sp);
        //    return ds;
        //}
        public static string getarray(DataSet ds, string subbusiness)
        {
            string arr = "";
            //DataRow[] result = ds.Tables[1].Select("SubBusinessID=" + subbusiness);
            //foreach (DataRow dr in result)
            //{
            //    arr += "var s1 = [" + dr["ECHICOUNT"] + "," + dr["CDRCOUNT"] + "," + dr["CALLCOUNT"] + "," + dr["CTICOUNT"] + "];" + System.Environment.NewLine;
            //}
            arr= Newtonsoft.Json.JsonConvert.SerializeObject(ds.Tables[1]);

            return arr;

        }



        public static DataTable MergeTablesByIndex(DataTable t1, DataTable t2)
        {
            if (t1 == null || t2 == null) throw new ArgumentNullException("t1 or t2", "Both tables must not be null");

            DataTable t3 = t1.Clone();  // first add columns from table1
            foreach (DataColumn col in t2.Columns)
            {
                string newColumnName = col.ColumnName;
                int colNum = 1;
                while (t3.Columns.Contains(newColumnName))
                {
                    newColumnName = string.Format("{0}_{1}", col.ColumnName, ++colNum);
                }
                t3.Columns.Add(newColumnName, col.DataType);
            }
            var mergedRows = t1.AsEnumerable().Zip(t2.AsEnumerable(),
                (r1, r2) => r1.ItemArray.Concat(r2.ItemArray).ToArray());
            foreach (object[] rowFields in mergedRows)
                t3.Rows.Add(rowFields);

            return t3;
        }
       
    }

   
}