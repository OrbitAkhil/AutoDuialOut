﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;
using System.Data;

using System.ComponentModel.DataAnnotations;

namespace ACBDashboard.BL
{
    public class Business
    {
        public bool AddBusiness(string BusiName, string Location, string AddressOfContact, string ContactPerson,string ContactNumber,string Status, string CreatedBy)
        {
            bool isAdded = false;

            System.Data.SqlClient.SqlParameter spout = new System.Data.SqlClient.SqlParameter("@ERROR", SqlDbType.VarChar);
            spout.Direction = ParameterDirection.Output;
            spout.Size = 100;

            System.Data.SqlClient.SqlParameter[] sp = new System.Data.SqlClient.SqlParameter[7];
            sp[0] = new System.Data.SqlClient.SqlParameter("@BusinessName", SqlDbType.VarChar);
            sp[0].Value = BusiName;
            sp[1] = new System.Data.SqlClient.SqlParameter("@Location", SqlDbType.VarChar);
            sp[1].Value = Location;
            sp[2] = new System.Data.SqlClient.SqlParameter("@Address", SqlDbType.VarChar);
            sp[2].Value = AddressOfContact;
            sp[3] = new System.Data.SqlClient.SqlParameter("@ContPerson", SqlDbType.VarChar);
            sp[3].Value = ContactPerson;
            sp[4] = new System.Data.SqlClient.SqlParameter("@Contactnumber", SqlDbType.VarChar);
            sp[4].Value = ContactNumber;
            sp[5] = new System.Data.SqlClient.SqlParameter("@Status", SqlDbType.VarChar);
            sp[5].Value = Status;
            sp[6] = new System.Data.SqlClient.SqlParameter("@CreatedBy", SqlDbType.VarChar);
            sp[6].Value = CreatedBy;
            SQLU s = new SQLU(System.Configuration.ConfigurationManager.AppSettings["CON"]);
            string msg = s.ExecuteProcOut("sp_UTOM_AddBusiness", spout, sp);
            //DataSet ds = SQLU.GetData("sp_UTOM_AddBusiness", sp);
            if (msg != "")
                
                {
                    isAdded = true;
                }

            return isAdded;
        }
        public string AddSubBusiness(string SubBusiness, int Business, string CreatedBy)
        {
            //bool isAdded = false;
            string msg = "";
            System.Data.SqlClient.SqlParameter spout = new System.Data.SqlClient.SqlParameter("@ERROR", SqlDbType.VarChar);
            spout.Direction = ParameterDirection.Output;
            spout.Size = 100;

            System.Data.SqlClient.SqlParameter[] sp = new System.Data.SqlClient.SqlParameter[3];
            sp[0] = new System.Data.SqlClient.SqlParameter("@SubBusiName", SqlDbType.VarChar);
            sp[0].Value = SubBusiness;
            sp[1] = new System.Data.SqlClient.SqlParameter("@BusinessName", SqlDbType.Int);
            sp[1].Value = Business;
            sp[2] = new System.Data.SqlClient.SqlParameter("@CreatedBy", SqlDbType.VarChar);
            sp[2].Value = CreatedBy;
            SQLU s = new SQLU(System.Configuration.ConfigurationManager.AppSettings["CON"]);
            msg = s.ExecuteProcOut("sp_UTOM_AddSubBusiness", spout, sp);
            return msg;
        }
        public DataTable ReturnTable(string ActionType)
        {
            DataTable DT;
            System.Data.SqlClient.SqlParameter[] sp = new System.Data.SqlClient.SqlParameter[0];
            SQLU s = new SQLU(System.Configuration.ConfigurationManager.AppSettings["CON"]);
            DataSet DS = new DataSet();
            DS = s.GetData("sp_UTOM_SelectBusiness", sp);

            DT = DS.Tables[0];
            return DT;
        }

        public DataTable ReturnLOB()
        {
            DataTable DT;
            System.Data.SqlClient.SqlParameter[] sp = new System.Data.SqlClient.SqlParameter[0];
            SQLU s = new SQLU(System.Configuration.ConfigurationManager.AppSettings["CON"]);
            DataSet DS = new DataSet();
            DS = s.GetData("sp_UTOM_ReturnLOB", sp);
            DT = DS.Tables[0];
            return DT;
        }

        public DataTable ReturnRouter()
        {
            DataTable DT;
            System.Data.SqlClient.SqlParameter[] sp = new System.Data.SqlClient.SqlParameter[0];
            SQLU s = new SQLU(System.Configuration.ConfigurationManager.AppSettings["CON"]);
            DataSet DS = new DataSet();
            DS = s.GetData("sp_GetRouter", sp);
            DT = DS.Tables[0];
            return DT;
        }

        public DataTable GetDNISType()
        {
            DataTable DT;
            System.Data.SqlClient.SqlParameter[] sp = new System.Data.SqlClient.SqlParameter[0];
            SQLU s = new SQLU(System.Configuration.ConfigurationManager.AppSettings["CON"]);
            DataSet DS = new DataSet();
            DS = s.GetData("sp_UTOM_GetDNISType", sp);
            DT = DS.Tables[0];
            return DT;
        }

        public string AddRouter(string RouterIP, string RUser, string Password, string Datacenter, string RackNo, int CardNo, string OEM, string CreatedBy)
        {
            string msg = "";
            System.Data.SqlClient.SqlParameter spout = new System.Data.SqlClient.SqlParameter("@ERROR", SqlDbType.VarChar);
            spout.Direction = ParameterDirection.Output;
            spout.Size = 100;

            System.Data.SqlClient.SqlParameter[] sp = new System.Data.SqlClient.SqlParameter[8];
            sp[0] = new System.Data.SqlClient.SqlParameter("@IP", SqlDbType.VarChar);
            sp[0].Value = RouterIP;
            sp[1] = new System.Data.SqlClient.SqlParameter("@User", SqlDbType.VarChar);
            sp[1].Value = RUser;
            sp[2] = new System.Data.SqlClient.SqlParameter("@Password", SqlDbType.VarChar);
            sp[2].Value = Password;
            sp[3] = new System.Data.SqlClient.SqlParameter("@Datacenter", SqlDbType.VarChar);
            sp[3].Value = Datacenter;
            sp[4] = new System.Data.SqlClient.SqlParameter("@RackNo", SqlDbType.VarChar);
            sp[4].Value = RackNo;
            sp[5] = new System.Data.SqlClient.SqlParameter("@CardNo", SqlDbType.Int);
            sp[5].Value = CardNo;
            sp[6] = new System.Data.SqlClient.SqlParameter("@OEM", SqlDbType.VarChar);
            sp[6].Value = OEM;
            sp[7] = new System.Data.SqlClient.SqlParameter("@CreatedBy", SqlDbType.VarChar);
            sp[7].Value = CreatedBy;
            SQLU s = new SQLU(System.Configuration.ConfigurationManager.AppSettings["CON"]);
            msg = s.ExecuteProcOut("sp_UTOM_AddRouter", spout, sp);

            return msg;
        }
        public  string AddRouterPRIMapping(int RID, string PortNo, string CircuitID, string ServiceProvider, int DNISType, string PRINo, string DNIS, int LOB,
            string CreatedBy)
        {
            string msg;
            System.Data.SqlClient.SqlParameter spout = new System.Data.SqlClient.SqlParameter("@ERROR", SqlDbType.VarChar);
            spout.Direction = ParameterDirection.Output;
            spout.Size = 100;

            System.Data.SqlClient.SqlParameter[] sp = new System.Data.SqlClient.SqlParameter[9];
            sp[0] = new System.Data.SqlClient.SqlParameter("@RID", SqlDbType.Int);
            sp[0].Value = RID;
            sp[1] = new System.Data.SqlClient.SqlParameter("@PortNo", SqlDbType.VarChar);
            sp[1].Value = PortNo;
            sp[2] = new System.Data.SqlClient.SqlParameter("@CircuitID", SqlDbType.VarChar);
            sp[2].Value = CircuitID;
            sp[3] = new System.Data.SqlClient.SqlParameter("@ServiceProvider", SqlDbType.VarChar);
            sp[3].Value = ServiceProvider;
            sp[4] = new System.Data.SqlClient.SqlParameter("@DNISType", SqlDbType.Int);
            sp[4].Value = DNISType;
            sp[5] = new System.Data.SqlClient.SqlParameter("@PRIno", SqlDbType.VarChar);
            sp[5].Value = PRINo;
            sp[6] = new System.Data.SqlClient.SqlParameter("@DNIS", SqlDbType.VarChar);
            sp[6].Value = DNIS;
            sp[7] = new System.Data.SqlClient.SqlParameter("@LOB", SqlDbType.Int);
            sp[7].Value = LOB;
            sp[8] = new System.Data.SqlClient.SqlParameter("@CreatedBy", SqlDbType.VarChar);
            sp[8].Value = CreatedBy;
            SQLU s = new SQLU(System.Configuration.ConfigurationManager.AppSettings["CON"]);
            msg = s.ExecuteProcOut("sp_UTOM_DNISPRILOBMapping", spout, sp);

            return msg;
        }


        public static List<SelectListItem> PopulateDNIS()
        {
            List<SelectListItem> items = new List<SelectListItem>();
            DataTable DT;
            System.Data.SqlClient.SqlParameter[] sp = new System.Data.SqlClient.SqlParameter[0];
            SQLU s = new SQLU(System.Configuration.ConfigurationManager.AppSettings["CON"]);
            DataSet DS = new DataSet();
            DS = s.GetData("sp_UTOM_ReturnDNIS", sp);
            DT = DS.Tables[0];
            foreach (DataRow dr in DT.Rows)
            {
                items.Add(new SelectListItem
                {
                    Text = dr["DNIS"].ToString(),
                    Value = dr["DNISId"].ToString()
                });
            }
           return items;
        }

        public static string AddDNIS(Models.DNISDetails DD)

        {
            string msg;
            System.Data.SqlClient.SqlParameter spout = new System.Data.SqlClient.SqlParameter("@ERROR", SqlDbType.VarChar);
            spout.Direction = ParameterDirection.Output;
            spout.Size = 100;

            System.Data.SqlClient.SqlParameter[] sp = new System.Data.SqlClient.SqlParameter[6];
            sp[0] = new System.Data.SqlClient.SqlParameter("@DNISID", SqlDbType.VarChar);
            sp[0].Value = DD.DNISID;
            sp[1] = new System.Data.SqlClient.SqlParameter("@Threshold", SqlDbType.Int);
            sp[1].Value = DD.Threshold;
            sp[2] = new System.Data.SqlClient.SqlParameter("@Action", SqlDbType.VarChar);
            sp[2].Value = DD.Action;
            sp[3] = new System.Data.SqlClient.SqlParameter("@Email", SqlDbType.VarChar);
            sp[3].Value = DD.Email;
            sp[4] = new System.Data.SqlClient.SqlParameter("@Windoin_min", SqlDbType.VarChar);
            sp[4].Value = DD.Windoin_min;
            sp[5] = new System.Data.SqlClient.SqlParameter("@Window_start", SqlDbType.VarChar);
            sp[5].Value = DD.Window_start;
         
            SQLU s = new SQLU(System.Configuration.ConfigurationManager.AppSettings["CON"]);
            msg = s.ExecuteProcOut("sp_UTOM_DNISMapping", spout, sp);

            return msg;
        }
    }

    public class MBusiness
    {
        [Required(ErrorMessage = "Business Name is Required")]
        public string BusinessName { get; set; }
        [Required(ErrorMessage = "Address  is Required")]
        [Display(Name = "Address")]
        public string AddressOfContact { get; set; }
        [Required(ErrorMessage = "Location is Required")]
        public string Location { get; set; }
        [Required(ErrorMessage = "Contact Person Name is Required")]
        [Display(Name ="Contact Person")]
        public string ContactPerson { get; set; }
        [Display(Name ="Contact Number")]
        [Required(ErrorMessage = "Mobile Number is required.")]
        [RegularExpression(@"^([0-9]{10})$", ErrorMessage = "Invalid Mobile Number.")]
        public string ContactNumber { get; set; }
        [Display(Name ="Status")]
        public string Status { get; set; }
        public string id { get; set; }
      
        public string BusinessId { get; set; }

        public string DeleteBusiness(string id)
        {
            System.Data.SqlClient.SqlParameter spout = new System.Data.SqlClient.SqlParameter("@ERROR", SqlDbType.VarChar);
            spout.Direction = ParameterDirection.Output;
            spout.Size = 100;

            System.Data.SqlClient.SqlParameter[] sp = new System.Data.SqlClient.SqlParameter[1];
            sp[0] = new System.Data.SqlClient.SqlParameter("@id", SqlDbType.VarChar);
            sp[0].Value = id;
            SQLU s = new SQLU("");
            string msg = s.ExecuteProcOut("sp_deleteBusiness", spout, sp);
            //DataSet ds = SQLU.GetData("sp_UTOM_AddBusiness", sp);

            return msg;
        }
        //    public bool EditBusiness(MBusiness mBusiness)
        //{
        //    bool isAdded = false;

        //    System.Data.SqlClient.SqlParameter spout = new System.Data.SqlClient.SqlParameter("@ERROR", SqlDbType.VarChar);
        //    spout.Direction = ParameterDirection.Output;
        //    spout.Size = 100;

        //    System.Data.SqlClient.SqlParameter[] sp = new System.Data.SqlClient.SqlParameter[7];
        //    sp[0] = new System.Data.SqlClient.SqlParameter("@BusinessName", SqlDbType.VarChar);
        //    sp[0].Value = mBusiness.BusinessName;
        //    sp[1] = new System.Data.SqlClient.SqlParameter("@Location", SqlDbType.VarChar);
        //    sp[1].Value =  mBusiness.Location;
        //    sp[2] = new System.Data.SqlClient.SqlParameter("@Address", SqlDbType.VarChar);
        //    sp[2].Value =  mBusiness.AddressOfContact;
        //    sp[3] = new System.Data.SqlClient.SqlParameter("@ContactPerson", SqlDbType.VarChar);
        //    sp[3].Value =  mBusiness.ContactPerson;
        //    sp[4] = new System.Data.SqlClient.SqlParameter("@BusinessId", SqlDbType.VarChar);
        //    sp[4].Value = mBusiness.BusinessId;
        //    sp[5] = new System.Data.SqlClient.SqlParameter("@ContactNumber", SqlDbType.VarChar);
        //    sp[5].Value = mBusiness.ContactNumber;
        //    sp[6] = new System.Data.SqlClient.SqlParameter("@Status", SqlDbType.VarChar);
        //    sp[6].Value = mBusiness.Status;
        //    SQLU s = new SQLU(System.Configuration.ConfigurationManager.AppSettings["CON"]);
        //    string msg = s.ExecuteProcOut("[sp_EditBusiness]", spout, sp);
        //    //DataSet ds = SQLU.GetData("sp_UTOM_AddBusiness", sp);
        //    if (msg != "")

        //    {
        //        isAdded = true;
        //    }

        //    return isAdded;
    }
    
     
   

}