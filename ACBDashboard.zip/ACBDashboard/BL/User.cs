﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;
using System.Data;
using System.ComponentModel.DataAnnotations;
using ACBDashboard.Models;
using System.Data.SqlClient;
using System.ComponentModel.DataAnnotations.Schema;

namespace ACBDashboard.BL
{
    public class User: AuthorizeAttribute
    {
        public string Userid
        {
            get;
            set;
        }
        [Required(ErrorMessage = "User Name is Required")]
        public string UserName
        {
            get;
            set;
        }

        public string UserEmail
        {
            get;
            set;
        }
        public int UserType
        {
            get;
            set;
        }
        [Required(ErrorMessage = "UserType is Required")]
        public string strUserType
        {
            get;
            set;
        }
        public string userBusiness
        {
            get;
            set;
        }

        public bool validateuser(string userid, string pass)
        {
            bool isAuthenticated = false;

            System.Data.SqlClient.SqlParameter[] sp = new System.Data.SqlClient.SqlParameter[2];
            sp[0] = new System.Data.SqlClient.SqlParameter("@user", SqlDbType.VarChar);
            sp[0].Value = userid;
            sp[1] = new System.Data.SqlClient.SqlParameter("@pass", SqlDbType.VarChar);
            sp[1].Value = pass;
            SQLU S = new SQLU(System.Configuration.ConfigurationManager.AppSettings["CON"]);
            DataSet ds =S.GetData("dbo.usp_getuserdata", sp);
            if (ds != null)
            {
                if (ds.Tables[0].Rows.Count > 0)
                {
                    isAuthenticated = true;
                    Userid = ds.Tables[0].Rows[0]["id"].ToString();
                    UserName = ds.Tables[0].Rows[0]["username"].ToString();
                    UserEmail = ds.Tables[0].Rows[0]["useremail"].ToString();
                    UserType = Convert.ToInt16(ds.Tables[0].Rows[0]["usertype"].ToString());
                    strUserType = GetUserType(ds.Tables[0].Rows[0]["usertype"].ToString());

                }
                if (ds.Tables[1].Rows.Count > 0)
                {
                    userBusiness= ds.Tables[1].Rows[0]["businessname"].ToString();
                }
            }


                return isAuthenticated;
            
        }

        protected override bool AuthorizeCore(HttpContextBase httpContext)
        {
            if(httpContext.Session == null)
                return false;

            if (httpContext.Session["user"] != null)
                return true;
            else
             return  false;
        }

        public string GetUserType(string id)
        {
            
            System.Data.SqlClient.SqlParameter spout = new System.Data.SqlClient.SqlParameter("@ERROR", SqlDbType.VarChar);
            spout.Direction = ParameterDirection.Output;
            spout.Size = 100;

            System.Data.SqlClient.SqlParameter[] sp = new System.Data.SqlClient.SqlParameter[1];
            sp[0] = new System.Data.SqlClient.SqlParameter("@usertypeID", SqlDbType.VarChar);
            sp[0].Value = id;
  
            SQLU s = new SQLU("");
            string msg = s.ExecuteProcOut("usp_getusertypebyId", spout, sp);
            //DataSet ds = SQLU.GetData("sp_UTOM_AddBusiness", sp);

   
        
            return msg;

        }



    }

    public class UserDetails
    {
        [Display(Name = "Id")]
      
        public string userid
        { get; set; }

        [Display(Name = "User Name")]
        [Required(ErrorMessage = "User Name is Required")]
        public string username
        { get; set; }
        [Display(Name = "Login Id")]
     
        public string userloginid
        { get; set; }
        [Required(ErrorMessage = "Email Id is Required")]
        [Display(Name = "Email")]
        public string useremail
        { get; set; }

        [Display(Name = "Status")]
        public string  useractive
        { get; set; }

        public List<UserDetails> userskill { get; set; }

        [Required(ErrorMessage = "UserType is Required")]
        [Display(Name = "UserType")]
        public string  usertype
        { get; set; }

        

        public int usertypeid
        { get; set; }

        public int  BusinessID { get; set; }
        public String BusinessName { get; set; }
        public int  SubBusinessID { get; set; }

        public string SkillID { get; set; }
        public string SkillName { get; set; }
        public string ischecked { get; set; }
        public List<UserDetails> SkillListItem { get; set; }

        //public int UserTypeID { get; set; }
        //public List<SubBusiness> sblist { get; set; }
        //public List<SubBusiness> allsblist { get; set; }

        public List<UserDetails> GetAlluser(string loginid)
        {
             return Getuser(loginid,"0");
        }
        public UserDetails Getuserbyid(string loginid, string userid)
        {
            return Getuser(loginid, userid)[0];
        }

        public List<UserDetails> Getuser(string loginid,string userid)
        {

            List<BL.UserDetails> objL = new List<BL.UserDetails>();
            System.Data.SqlClient.SqlParameter[] sp = new System.Data.SqlClient.SqlParameter[0];
            //sp[0] = new System.Data.SqlClient.SqlParameter("@loginid", SqlDbType.VarChar);
            //sp[0].Value = loginid;
            //sp[1] = new System.Data.SqlClient.SqlParameter("@userid", SqlDbType.Int);
            //sp[1].Value = userid;
            SQLU S = new SQLU("");
            DataSet ds = S.GetData("dbo.sp_GetAllUser", sp);
            if (ds != null)
                if (ds.Tables[0].Rows.Count > 0)
                {
                  DataTable dt = ds.Tables[0];
                    foreach (DataRow dr in dt.Rows)
                    {
                        BL.UserDetails MB = new BL.UserDetails();
                        MB.userid = dr["UserID"].ToString();
                        MB.username = dr["username"].ToString();
                        MB.useractive = dr["IsActive"].ToString();
                        MB.SkillName = dr["SkillName"].ToString();
                        objL.Add(MB);
                      
                    }
                }


            return objL;
        }

        public List<UserDetails> Getuser()
        {

            List<BL.UserDetails> objL = new List<BL.UserDetails>();
            System.Data.SqlClient.SqlParameter[] sp = new System.Data.SqlClient.SqlParameter[0];
            //sp[0] = new System.Data.SqlClient.SqlParameter("@loginid", SqlDbType.VarChar);
            //sp[0].Value = loginid;
            //sp[1] = new System.Data.SqlClient.SqlParameter("@userid", SqlDbType.Int);
            //sp[1].Value = userid;
            SQLU S = new SQLU("");
            DataSet ds = S.GetData("dbo.sp_GetAllUser",sp);
            if (ds != null)
                if (ds.Tables[0].Rows.Count > 0)
                {
                    DataTable dt = ds.Tables[0];
                    foreach (DataRow dr in dt.Rows)
                    {
                        BL.UserDetails MB = new BL.UserDetails();
                        MB.userid = dr["UserID"].ToString();
                        MB.username = dr["username"].ToString();
                        MB.useractive = dr["IsActive"].ToString();
                        MB.SkillName = dr["SkillName"].ToString();
                        //MB.BusinessID = Convert.ToInt16(dr["BusinessID"]);
                        //MB.BusinessName = dr["BusinessName"].ToString();
                        // MB.sblist = getSubBusinessList(MB.userid.ToString());
                        //MB.allsblist = getSBusinessList_byBussinessID(MB.BusinessID.ToString());
                        objL.Add(MB);

                    }
                }


            return objL;
        }
        public string DeleteUser(string userloginid)
        {
            System.Data.SqlClient.SqlParameter spout = new System.Data.SqlClient.SqlParameter("@ERROR", SqlDbType.VarChar);
            spout.Direction = ParameterDirection.Output;
            spout.Size = 100;

            System.Data.SqlClient.SqlParameter[] sp = new System.Data.SqlClient.SqlParameter[1];
            sp[0] = new System.Data.SqlClient.SqlParameter("@id", SqlDbType.VarChar);
            sp[0].Value = userloginid;
            SQLU s = new SQLU("");
            string msg = s.ExecuteProcOut("sp_deleteUser", spout, sp);
            //DataSet ds = SQLU.GetData("sp_UTOM_AddBusiness", sp);

            return msg;
        }

        public List<UserDetails> GetSingleUserDetails(string loginid, string UserId)
        {

            List<BL.UserDetails> objL = new List<BL.UserDetails>();
            System.Data.SqlClient.SqlParameter[] sp = new System.Data.SqlClient.SqlParameter[1];
            sp[0] = new System.Data.SqlClient.SqlParameter("@userid", SqlDbType.VarChar);
            sp[0].Value = UserId;

            SQLU S = new SQLU("");
            DataSet ds = S.GetData("dbo.sp_getsingleuser", sp);
            if (ds != null)
                if (ds.Tables[0].Rows.Count > 0)
                {
                    DataTable dt = ds.Tables[0];
                    foreach (DataRow dr in dt.Rows)
                    {
                        userid = dr["userid"].ToString();

                        username = dr["username"].ToString();

                        useractive = dr["isActive"].ToString();
                        userskill = GetUserSkill(userid.ToString());

                    }
                }


            return objL;
        }
        public UserDetails GetuserbyidWithList(string loginid, string userid)
        {
            return GetuserWithList(loginid, userid)[0];
        }
       // DBConnSql dbsql = new DBConnSql("");
        public List<UserDetails> GetuserWithList(string loginid, string userid)
        {

            List<BL.UserDetails> objL = new List<BL.UserDetails>();
            System.Data.SqlClient.SqlParameter[] sp = new System.Data.SqlClient.SqlParameter[1];
            sp[0] = new System.Data.SqlClient.SqlParameter("@userid", SqlDbType.VarChar);
            sp[0].Value = userid;

            SQLU S = new SQLU("");
            DataSet ds = S.GetData("dbo.sp_getsingleuser", sp);
            if (ds != null)
                if (ds.Tables[0].Rows.Count > 0)
                {
                    DataTable dt = ds.Tables[0];
                    foreach (DataRow dr in dt.Rows)
                    {
                        userid = dr["userid"].ToString();

                        username = dr["username"].ToString();

                        useractive = dr["isActive"].ToString();
                        userskill = GetUserSkill(userid.ToString());

                    }
                }


            return objL;
        }

        public string SaveUserSkillMapping(DataTable DT)
        {
            System.Data.SqlClient.SqlParameter spout = new System.Data.SqlClient.SqlParameter("@ERROR", SqlDbType.VarChar);
            spout.Direction = ParameterDirection.Output;
            spout.Size = 100;

            System.Data.SqlClient.SqlParameter[] sp = new System.Data.SqlClient.SqlParameter[1];
            //sp[0] = new System.Data.SqlClient.SqlParameter("@UserID", SqlDbType.VarChar);
            //sp[0].Value = userid;
            //sp[1] = new System.Data.SqlClient.SqlParameter("@UserName", SqlDbType.VarChar);
            //sp[1].Value = username;
            sp[0] = new System.Data.SqlClient.SqlParameter("@Skill", DT);

            SQLU s = new SQLU("");
            string msg = s.ExecuteProcOut("sp_InsertUser", spout, sp);
            //DataSet ds = SQLU.GetData("sp_UTOM_AddBusiness", sp);
            return msg;
        }

        public List<UserDetails> GetUserSkill(string id)
        {
            System.Data.SqlClient.SqlParameter[] sp = new System.Data.SqlClient.SqlParameter[1];

            sp[0] = new System.Data.SqlClient.SqlParameter("@userid", SqlDbType.VarChar);
            sp[0].Value = id;

            SQLU S = new SQLU("");
            var dt = S.ShowDataDT("Exec sp_getuserskillbyUserID '" + id + "'");
            //var subBusinessitems = new SelectListItem[DT.Rows.Count];
            List<UserDetails> list = null;
            if (dt.Rows.Count > 0)
            {
                list = new List<UserDetails>();
                foreach (System.Data.DataRow dr in dt.Rows)
                {
                    list.Add(new UserDetails() { SkillID = dr["SkillNo"].ToString(), SkillName = dr["SkillName"].ToString(), ischecked = dr["Checked"].ToString() });
                }
            }

            return list;
        }
        public List<SubBusiness> getSubBusinessList(string id)
        {
            DataTable DT = new DataTable();
            DT = dbsql.ShowDataDT("Exec sp_getSBlistbyUserID '" + id + "'");
            //var subBusinessitems = new SelectListItem[DT.Rows.Count];
            List<SubBusiness> list = new List<SubBusiness>();
            if (DT.Rows.Count > 0)
            {
                //list = new List<SubBusiness>();
                foreach (System.Data.DataRow dr in DT.Rows)
                {
                    list.Add(new SubBusiness() { SubBusinessName = dr["subbusinessname"].ToString(), SubBusinessId = dr["SubBusinessID"].ToString(), Checked = dr["Checked"].ToString()});
                }
            }
            return list;

        }
        SQLU dbsql = new SQLU("");
        public List<SubBusiness> getSBusinessList_byBussinessID(string businessid)
        {
            DataTable DT = new DataTable();
            DT = dbsql.ShowDataDT("Exec sp_UTOM_SelectSubBusiness '" + businessid + "'");
            //var subBusinessitems = new SelectListItem[DT.Rows.Count];
            List<SubBusiness> list1 = null;
            if (DT.Rows.Count > 0)
            {
                list1 = new List<SubBusiness>();
                foreach (System.Data.DataRow dr in DT.Rows)
                {
                    list1.Add(new SubBusiness() { SubBusinessName = dr["subbusinessname"].ToString(), SubBusinessId = dr["id"].ToString() });
                }
            }
            return list1;

        }
        public DataTable ReturnTable(string ActionType)
        {
            DataTable DT;
            System.Data.SqlClient.SqlParameter[] sp = new System.Data.SqlClient.SqlParameter[0];
            SQLU s = new SQLU(System.Configuration.ConfigurationManager.AppSettings["CON"]);
            DataSet DS = new DataSet();
            DS = s.GetData("sp_UTOM_SelectUserType", sp);
            DT = DS.Tables[0];
            return DT;
        }

        public string Saveuser(UserDetails uDetails,string loginid)
        {
          

            System.Data.SqlClient.SqlParameter spout = new System.Data.SqlClient.SqlParameter("@ERROR", SqlDbType.VarChar);
            spout.Direction = ParameterDirection.Output;
            spout.Size = 100;

            System.Data.SqlClient.SqlParameter[] sp = new System.Data.SqlClient.SqlParameter[6];
            sp[0] = new System.Data.SqlClient.SqlParameter("@userName", SqlDbType.VarChar);
            sp[0].Value = uDetails.username;
            sp[1] = new System.Data.SqlClient.SqlParameter("@useremail", SqlDbType.VarChar);
             sp[1].Value = uDetails.useremail;
            sp[2] = new System.Data.SqlClient.SqlParameter("@useractive", SqlDbType.VarChar);
            sp[2].Value = uDetails.useractive;
            sp[3] = new System.Data.SqlClient.SqlParameter("@userId", SqlDbType.Int);
            sp[3].Value = uDetails.userid;
            //sp[4] = new System.Data.SqlClient.SqlParameter("@userloginid", SqlDbType.VarChar);
            //sp[4].Value = uDetails.userloginid;
            sp[4] = new System.Data.SqlClient.SqlParameter("@updatedby", SqlDbType.VarChar);
            sp[4].Value = loginid;
            sp[5] = new System.Data.SqlClient.SqlParameter("@usertype", SqlDbType.VarChar);
            sp[5].Value = uDetails.usertype;
            SQLU s = new SQLU("");
            string msg = s.ExecuteProcOut("usp_updateuser", spout, sp);
            //DataSet ds = SQLU.GetData("sp_UTOM_AddBusiness", sp);
         
            return msg;
        }
        public string SaveUserSubBusinessMapping(DataTable DT)
        {


            System.Data.SqlClient.SqlParameter spout = new System.Data.SqlClient.SqlParameter("@ERROR", SqlDbType.VarChar);
            spout.Direction = ParameterDirection.Output;
            spout.Size = 100;

            System.Data.SqlClient.SqlParameter[] sp = new System.Data.SqlClient.SqlParameter[1];
            sp[0] = new System.Data.SqlClient.SqlParameter("@UT_UserSbMap",DT);
            //sp[0].Value = DT;
            //sp[1] = new System.Data.SqlClient.SqlParameter("@SubBusiID", SqlDbType.VarChar);
            //sp[1].Value = SubBusiID;
            //sp[2] = new System.Data.SqlClient.SqlParameter("@CreatedBy", SqlDbType.Int);
            //sp[2].Value = loginid;

        
            SQLU s = new SQLU("");
            string msg = s.ExecuteProcOut("sp_userSBusinessMapping", spout, sp);
            //DataSet ds = SQLU.GetData("sp_UTOM_AddBusiness", sp);

            return msg;
        }

        public string UpdateUserSkillMapping(DataTable DT)
        {


            System.Data.SqlClient.SqlParameter spout = new System.Data.SqlClient.SqlParameter("@ERROR", SqlDbType.VarChar);
            spout.Direction = ParameterDirection.Output;
            spout.Size = 100;

            System.Data.SqlClient.SqlParameter[] sp = new System.Data.SqlClient.SqlParameter[2];


            //sp[0] = new System.Data.SqlClient.SqlParameter("@UserID", SqlDbType.VarChar);
            //sp[0].Value = userid;
            //sp[1] = new System.Data.SqlClient.SqlParameter("@UserName", SqlDbType.VarChar);
            //sp[1].Value = username;
            sp[0] = new System.Data.SqlClient.SqlParameter("@isactive", SqlDbType.VarChar);
            sp[0].Value = useractive;
            sp[1] = new System.Data.SqlClient.SqlParameter("@Skill", DT);

            SQLU s = new SQLU("");
            string msg = s.ExecuteProcOut("sp_UpdateUser", spout, sp);
            //DataSet ds = SQLU.GetData("sp_UTOM_AddBusiness", sp);

            return msg;
        }

        public List<UserDetails> GetSkill()
        {
            //JsonResult result = new JsonResult();

            //dropdown Sub Business

            //SubBusinesses.BusinessId = ud.BusinessID;
            //ud.BusinessID = 10000;

            SQLU S = new SQLU("");
            var dt = S.ShowDataDT("Exec sp_GetSkill");
            //var subBusinessitems = new SelectListItem[DT.Rows.Count];
            List<UserDetails> list = null;
            if (dt.Rows.Count > 0)
            {
                list = new List<UserDetails>();
                foreach (System.Data.DataRow dr in dt.Rows)
                {
                    list.Add(new UserDetails() { SkillName = dr["SkillName"].ToString(), SkillID = dr["SkillNo"].ToString() });
                }
            }

            return list;
        }

        public string DeleteUserSubBusinessMapping(string UserId,  string loginid)
        {


            System.Data.SqlClient.SqlParameter spout = new System.Data.SqlClient.SqlParameter("@ERROR", SqlDbType.VarChar);
            spout.Direction = ParameterDirection.Output;
            spout.Size = 100;

            System.Data.SqlClient.SqlParameter[] sp = new System.Data.SqlClient.SqlParameter[2];
            sp[0] = new System.Data.SqlClient.SqlParameter("@UserId", SqlDbType.VarChar);
            sp[0].Value = UserId;
            sp[1] = new System.Data.SqlClient.SqlParameter("@SubBusiID", SqlDbType.VarChar);
            sp[1].Value = loginid;
         


            SQLU s = new SQLU("");
            string msg = s.ExecuteProcOut("sp_DELETEuserSBusinessMapping", spout, sp);
            //DataSet ds = SQLU.GetData("sp_UTOM_AddBusiness", sp);

            return msg;
        }
        public SelectListItem[] getListItems(string ValueColumn , string TextColumn,string PurposeName)
        {
            int i = 0;
            DataTable  DT = ReturnTable(PurposeName);
            SelectListItem[] getListItem = new SelectListItem[DT.Rows.Count];
            i = 0;
            foreach (System.Data.DataRow DR in DT.Rows)
            {
                SelectListItem UTitems = new SelectListItem { Text = DR[TextColumn].ToString(), Value = DR[ValueColumn].ToString() };
                getListItem.SetValue(UTitems, i);
                i++;
            }
            return getListItem;
        }
 

    }
    #region ItUserSBNotification
    public class ItUserSBNotification
    {


        [Display(Name="ID")]
        public int id { get; set; }
        public string userid { get; set; }
        public string userloginid { get; set; }
        [Display(Name = "UserName")]
        public string username { get; set; }
        [Display(Name = "Email")]
        public string useremail { get; set; }
        [Display(Name = "Contact")]
        public string usercontact { get; set; }
        [Display(Name = "NotificationType")]
        public string notificationid { get; set; }
        public string sbid { get; set; }
        public string active { get; set; }
        public string createby { get; set; }
        public DateTime createdate { get; set; }
        public string updateby { get; set; }
        public DateTime updatedate { get; set; }

        public List<UserDetails> userlist { get; set; }
        public List<SubBusiness> SubBusinesslist { get; set; }


        //public List<ItUserSBNotification> GetAllITuser(string loginid)
        //{
        //    return Getuser(loginid, "0");
        //}
        //public ItUserSBNotification Getuserbyid(string loginid, string userid)
        //{
        //    return Getuser(loginid, userid)[0];
        //}

        //public List<ItUserSBNotification> Getuser(string loginid, string userid)
        //{

        //    List<BL.ItUserSBNotification> objL = new List<BL.ItUserSBNotification>();
        //    System.Data.SqlClient.SqlParameter[] sp = new System.Data.SqlClient.SqlParameter[0];

        //    SQLU S = new SQLU("");
        //    DataSet ds = S.GetData("dbo.sp_ITUserDetails", sp);
        //    if (ds != null)
        //        if (ds.Tables[0].Rows.Count > 0)
        //        {
        //            DataTable dt = ds.Tables[0];
        //            foreach (DataRow dr in dt.Rows)
        //            {
        //                BL.ItUserSBNotification MB = new BL.ItUserSBNotification();
        //                MB.id = Convert.ToInt16(dr["id"].ToString());
        //                MB.userid = dr["userid"].ToString();
        //                MB.userloginid = dr["userloginid"].ToString();
        //                MB.username = dr["username"].ToString();
        //                MB.useremail = dr["useremail"].ToString();
        //                MB.notificationid = dr["notificationid"].ToString();
        //                MB.sbid = dr["sbid"].ToString();
        //                MB.active = dr["active"].ToString();
        //                objL.Add(MB);

        //            }
        //        }


        //    return objL;
        //}
        public List<UserDetails> GetITuserlist(string loginid, string userid)
        {

            List<BL.UserDetails> objL = new List<BL.UserDetails>();
            System.Data.SqlClient.SqlParameter[] sp = new System.Data.SqlClient.SqlParameter[2];
            sp[0] = new System.Data.SqlClient.SqlParameter("@loginid", SqlDbType.VarChar);
            sp[0].Value = loginid;
            sp[1] = new System.Data.SqlClient.SqlParameter("@userid", SqlDbType.Int);
            sp[1].Value = userid;
            SQLU S = new SQLU("");
            DataSet ds = S.GetData("dbo.sp_getITUserList", sp);
            if (ds != null)
                if (ds.Tables[0].Rows.Count > 0)
                {
                    DataTable dt = ds.Tables[0];
                    foreach (DataRow dr in dt.Rows)
                    {
                        BL.UserDetails MB = new BL.UserDetails();
                        MB.userid = Convert.ToString(dr["userid"].ToString());
                        MB.username = dr["username"].ToString();
                        MB.useremail = dr["useremail"].ToString();
                        MB.useractive = dr["active"].ToString();

                        objL.Add(MB);

                    }
                }


            return objL;
        }
    }

    public class ItUserSBNotificationDataAccessLayer

    {
        string StoredProc = "sp_ITUserSbNotificationCRUD";
        SqlConnection con = new SqlConnection(SQLU.con);
        public string InsertData(ItUserSBNotification obj)
        {


            string result = "";
            try
            {
                //ID , UserName , BusinessID , IsActive , ExtensionID
                con.Close();
                SqlCommand cmd = new SqlCommand(StoredProc, con);
                cmd.CommandType = CommandType.StoredProcedure;
                //cmd.Parameters.AddWithValue("@ID", obj.ID);  
                cmd.Parameters.AddWithValue("@notificationid", obj.notificationid);
                cmd.Parameters.AddWithValue("@userid", obj.userid);
                cmd.Parameters.AddWithValue("@sbid", obj.sbid);
                cmd.Parameters.AddWithValue("@contact", obj.usercontact);
                cmd.Parameters.AddWithValue("@email", obj.useremail);
                cmd.Parameters.AddWithValue("@Status", 1);
                cmd.Parameters.AddWithValue("@createdate",DateTime.Now.ToString());
                cmd.Parameters.AddWithValue("@Query", 1);

                con.Open();
                result = cmd.ExecuteScalar().ToString();
                return result;
            }
            catch (Exception ex)
            {
                return result = ex.ToString();
            }
            finally
            {
                con.Close();
            }
        }

        public string InsertDataCheckExistance(ItUserSBNotification obj)
        {


            string result = "";
            try
            {
                //ID , UserName , BusinessID , IsActive , ExtensionID
                con.Close();
                SqlCommand cmd = new SqlCommand("sp_ITUserCheckExistance", con);
                cmd.CommandType = CommandType.StoredProcedure;
                //cmd.Parameters.AddWithValue("@ID", obj.ID);  
                cmd.Parameters.AddWithValue("@notificationid", obj.notificationid);
                cmd.Parameters.AddWithValue("@userid", obj.userid);
                cmd.Parameters.AddWithValue("@sbid", obj.sbid);
                cmd.Parameters.AddWithValue("@contact", obj.usercontact);
                cmd.Parameters.AddWithValue("@email", obj.useremail);
                cmd.Parameters.AddWithValue("@Status", 1);
                cmd.Parameters.AddWithValue("@createdate", DateTime.Now.ToString());
                //cmd.Parameters.AddWithValue("@Query", 1);

                con.Open();
                result = cmd.ExecuteScalar().ToString();
                return result;
            }
            catch (Exception ex)
            {
                return result = ex.ToString();
            }
            finally
            {
                con.Close();
            }
        }


        public string UpdateData(ItUserSBNotification obj)
        {

            string result = "";
            try
            {
                //ID , UserName , BusinessID , IsActive , ExtensionID
                SqlCommand cmd = new SqlCommand(StoredProc, con);
                cmd.CommandType = CommandType.StoredProcedure;
                cmd.Parameters.AddWithValue("@username", obj.username);
                cmd.Parameters.AddWithValue("@userid", obj.userid);
                cmd.Parameters.AddWithValue("@sbid", obj.sbid);
                cmd.Parameters.AddWithValue("@contact", obj.usercontact);
                cmd.Parameters.AddWithValue("@email", obj.useremail);
                cmd.Parameters.AddWithValue("@Status", obj.active);
                cmd.Parameters.AddWithValue("@createdate", obj.createdate);

                cmd.Parameters.AddWithValue("@Query", 2);
                con.Open();
                result = cmd.ExecuteScalar().ToString();
                return result;
            }
            catch (Exception ex)
            {
                return result = ex.ToString();
            }
            finally
            {
                con.Close();
            }
        }
        public int DeleteData(String ID)
        {

            int result;
            try
            {
                //ID , UserName , BusinessID , IsActive , ExtensionID
                SqlCommand cmd = new SqlCommand(StoredProc, con);
                cmd.CommandType = CommandType.StoredProcedure;
                cmd.Parameters.AddWithValue("@ID", ID);
    
                cmd.Parameters.AddWithValue("@userid", null);
                cmd.Parameters.AddWithValue("@sbid", null);
                cmd.Parameters.AddWithValue("@contact", null);
                cmd.Parameters.AddWithValue("@email", null);
                cmd.Parameters.AddWithValue("@Status", null);
                cmd.Parameters.AddWithValue("@createdate", null);
                cmd.Parameters.AddWithValue("@Query", 3);
                con.Open();
                result = cmd.ExecuteNonQuery();
                return result;
            }
            catch(Exception ex)
            {
                return result = 0;
            }
            finally
            {
                con.Close();
            }
        }
        public List<ItUserSBNotification> Selectalldata()
        {

            DataSet ds = null;
            List<ItUserSBNotification> custlist = null;
            try
            {
                //ID , UserName , BusinessID , IsActive , ExtensionID
                SqlCommand cmd = new SqlCommand(StoredProc, con);
                cmd.CommandType = CommandType.StoredProcedure;
                cmd.Parameters.AddWithValue("@id", null);
                cmd.Parameters.AddWithValue("@notificationid", null);
                cmd.Parameters.AddWithValue("@userid", null);
                cmd.Parameters.AddWithValue("@sbid", null);
                cmd.Parameters.AddWithValue("@contact", null);
                cmd.Parameters.AddWithValue("@email", null);
                cmd.Parameters.AddWithValue("@Status", null);
                cmd.Parameters.AddWithValue("@createdate", null);
                cmd.Parameters.AddWithValue("@Query", 4);
                con.Open();
                SqlDataAdapter da = new SqlDataAdapter();
                da.SelectCommand = cmd;
                ds = new DataSet();
                da.Fill(ds);
                custlist = new List<ItUserSBNotification>();
                for (int i = 0; i < ds.Tables[0].Rows.Count; i++)
                {
                    ItUserSBNotification cobj = new ItUserSBNotification();
                    cobj.id = Convert.ToInt32(ds.Tables[0].Rows[i]["ID"].ToString());
                    cobj.username = ds.Tables[0].Rows[i]["UserName"].ToString();
                    cobj.userid = ds.Tables[0].Rows[i]["UserID"].ToString();
                    //cobj.userloginid = ds.Tables[0].Rows[i]["userloginid"].ToString();
                    cobj.active = ds.Tables[0].Rows[i]["Status"].ToString();
                    cobj.usercontact = ds.Tables[0].Rows[i]["contact"].ToString();
                    cobj.notificationid = ds.Tables[0].Rows[i]["notificationid"].ToString();
                    cobj.useremail = ds.Tables[0].Rows[i]["email"].ToString();
  
                  
                    custlist.Add(cobj);
                }
                return custlist;
            }
            catch(Exception ex)
            {
                string exp = ex.ToString();
                return custlist;
            }
            finally
            {
                con.Close();
            }
        }

        //public ItUserSBNotification SelectDatabyID(string ID)
        //{
        //    SqlConnection con = new SqlConnection(SQLU.con);
        //    DataSet ds = null;
        //    User cobj = null;
        //    try
        //    {
        //        //ID , UserName , BusinessID , IsActive , ExtensionID
        //        SqlCommand cmd = new SqlCommand(StoredProc, con);
        //        cmd.CommandType = CommandType.StoredProcedure;
        //        cmd.Parameters.AddWithValue("@ID", ID);
        //        cmd.Parameters.AddWithValue("@username", null);
        //        cmd.Parameters.AddWithValue("@userid", null);
        //        cmd.Parameters.AddWithValue("@sbid", null);
        //        cmd.Parameters.AddWithValue("@usercontact", null);
        //        cmd.Parameters.AddWithValue("@useremail", null);
        //        cmd.Parameters.AddWithValue("@active", null);
        //        cmd.Parameters.AddWithValue("@createdate", null);

        //        cmd.Parameters.AddWithValue("@Query", 5);
        //        SqlDataAdapter da = new SqlDataAdapter();
        //        da.SelectCommand = cmd;
        //        ds = new DataSet();
        //        da.Fill(ds);
        //        for (int i = 0; i < ds.Tables[0].Rows.Count; i++)
        //        {
        //            cobj = new ItUserSBNotification();
        //            cobj.ID = Convert.ToInt32(ds.Tables[0].Rows[i]["ID"].ToString());
        //            cobj.UserName = ds.Tables[0].Rows[i]["UserName"].ToString();
        //            cobj.BusinessID = ds.Tables[0].Rows[i]["BusinessID"].ToString();
        //            cobj.BusinessName = ds.Tables[0].Rows[i]["BusinessName"].ToString();
        //            cobj.IsActive = ds.Tables[0].Rows[i]["active"].ToString();

        //        }
        //        return cobj;
        //    }
        //    catch
        //    {
        //        return cobj;
        //    }
        //    finally
        //    {
        //        con.Close();
        //    }
        //}
    }
    #endregion

    public class CheckboxModel
    {
        public int Value { get; set; }
        public string Text { get; set; }
        public bool IsChecked { get; set; }
    }
    public class CheckBoxList
    {
        public List<CheckboxModel> CheckBoxItems { get; set; }
    }


    public class ResetPassword
    {
        [Required]
        public string NewPassword { get; set; }
        [NotMapped]
        [System.ComponentModel.DataAnnotations.Compare("NewPassword")]
        public string ConfirmPassword { get; set; }

        public string OldPassword { get; set; }


        public string Reset_Password(ResetPassword rp,string id)
        {
            string msg = "";
            if (rp.NewPassword == rp.ConfirmPassword)
            {
                System.Data.SqlClient.SqlParameter spout = new System.Data.SqlClient.SqlParameter("@ERROR", SqlDbType.VarChar);
                spout.Direction = ParameterDirection.Output;
                spout.Size = 100;
                System.Data.SqlClient.SqlParameter[] sp = new System.Data.SqlClient.SqlParameter[3];
                sp[0] = new System.Data.SqlClient.SqlParameter("@OldPassword", SqlDbType.VarChar);
                sp[0].Value = rp.OldPassword;
                sp[1] = new System.Data.SqlClient.SqlParameter("@Password", SqlDbType.VarChar);
                sp[1].Value = rp.NewPassword;
                sp[2] = new System.Data.SqlClient.SqlParameter("@userid", SqlDbType.VarChar);
                sp[2].Value = id;
                SQLU s = new SQLU("");
                 msg = s.ExecuteProcOut("sp_ResetPassword", spout, sp);



             

            }
            return msg;

        }
    }
}