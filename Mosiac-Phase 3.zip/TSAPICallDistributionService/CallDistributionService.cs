﻿using Microsoft.AspNet.SignalR;
using NLog;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Configuration;
using System.Data;
using System.Data.SqlClient;
using System.Diagnostics;
using System.Linq;
using System.ServiceProcess;
using System.Text;
using System.Threading;
using System.Threading.Tasks;
using TSAPICallDistributionService.Classes;
using TSAPIClient;
using TSAPIDAL;
using TSAPIDAL.DataAccessLayer;
using TSAPIMaster;

namespace TSAPICallDistributionService
{
    public partial class CallDistributionService : ServiceBase
    {

        private Logger logger = LogManager.GetLogger("OutputLogger");
        private System.Timers.Timer _timer;
        //private readonly string countryCode = config.AppSettings.Settings["DialPrefix"].ToString();
        private readonly int reasonCode = Convert.ToInt32(ConfigurationManager.AppSettings["AgentReasonCode"]);
        private readonly int agentState = Convert.ToInt32(ConfigurationManager.AppSettings["AgentState"]);
        private readonly int workMode = Convert.ToInt32(ConfigurationManager.AppSettings["WorkMode"]);
        private readonly string hostIpAddress = Convert.ToString(ConfigurationManager.AppSettings["HostIpAddress"]);

        public CallDistributionService()
        {

            _timer = new System.Timers.Timer();
            _timer.Interval = Convert.ToDouble(ConfigurationManager.AppSettings["TimerInterval"]);
            _timer.Elapsed += new System.Timers.ElapsedEventHandler(timer_Elapsed);
            InitializeComponent();
        }

        protected override void OnStart(string[] args)
        {
            logger.Info("Call distribution service is started");
            Startup.StartServer();
            Simulator.Instance.OpenStream();
            _timer.Enabled = true;
        }

        protected override void OnStop()
        {
            logger.Info("Call distribution service is stopped");
            if (Simulator.Instance.m_Client == null)
                return;

            Startup.StopServer();
            Simulator.Instance.StopActiveAgentsMonitoring();

            Thread.Sleep(TimeSpan.FromSeconds(30));
            _timer.Enabled = false;
        }

        void timer_Elapsed(object sender, System.Timers.ElapsedEventArgs e)
        {
            try
            {
                _timer.Enabled = false;
                logger.Info("Timer running at {0}", DateTime.Now);
                
                if (Simulator.Instance.Configured)
                {
                    bool validateHandler = Simulator.Instance.CheckHandler();

                    GetUnAllocatedCallCount();

                    if (validateHandler)
                    {
                        CloseUnProcessedForIdleAgent();

                        StopMonitoringForLogoutAgents();

                        StartMonitoringForLoginAgents();

                        var objCall = new Repository();
                        var cmd = new CommandBuilder();
                        cmd.SpName = "sp_AutoDial_CheckNewCalls";
                        DataSet ds_CallCount = objCall.Select(cmd);
                        if (ds_CallCount.Tables.Count > 0 && ds_CallCount.Tables[0].Rows.Count > 0)
                        {
                            int callCount = Convert.ToInt32(ds_CallCount.Tables[0].Rows[0]["CallCount"]);
                            if (callCount > 0)
                            {
                                cmd = new CommandBuilder();
                                cmd.SpName = "sp_AutoDial_GetAgentWithNoActiveCall";
                                cmd.SqlParams = new List<SqlParameter>()
                                {
                                    new SqlParameter("@HostIpAddress",hostIpAddress)
                                };
                                var ds = objCall.Select(cmd);
                                if (ds.Tables[0].Rows.Count > 0)
                                {
                                    //int ctr = 0;
                                    foreach (DataRow dr in ds.Tables[0].Rows)
                                    {
                                        string agentId = Convert.ToString(dr["AgentId"]);
                                        string extensionNo = Convert.ToString(dr["ExtensionNo"]);
                                        int stationCallCount = Convert.ToInt32(dr["CallCount"]);
                                        if (stationCallCount == 0)
                                        {
                                            cmd = new CommandBuilder();
                                            cmd.SpName = "sp_AutoDial_GetUnAllocatedCall";
                                            var ds_UnAllocatedCall = objCall.Select(cmd);
                                            //if (Simulator.Instance.ActiveMonitorDeviceDic.Keys.Contains(extensionNo.ToString()))
                                            //{
                                            if (ds_UnAllocatedCall.Tables.Count > 0 && ds_UnAllocatedCall.Tables[0].Rows.Count > 0)
                                            {
                                                var dr_DropOutCall = ds_UnAllocatedCall.Tables[0].Rows[0];
                                                string callerName, callType, callerNumber, callerNumberWithPrefix;
                                                int callerId = 0;
                                                int recordId = 0;
                                                recordId = Convert.ToInt32(dr_DropOutCall["DropOutId"]);
                                                callerId = Convert.ToInt32(dr_DropOutCall["CallerId"]);
                                                callerName = Convert.ToString(dr_DropOutCall["CallerName"]);
                                                callType = Convert.ToString(dr_DropOutCall["CallType"]);
                                                callerNumber = Convert.ToString(dr_DropOutCall["CallerMobile"]);
                                                callerNumberWithPrefix = Convert.ToString(dr_DropOutCall["CallerMobileWithPrefix"]);

                                                var dropCall = new DropCall() { RecordId = recordId, CallerId = callerId, CallerName = callerName, CallType = callType, CallerNumber = callerNumber, CallerNumberWithPrefix = callerNumberWithPrefix, AgentId = agentId, ExtensionNo = extensionNo, HostIpAddress = hostIpAddress };
                                                logger.Info("Start allocating call to AgentId - {0} , Extension No {1}", agentId, extensionNo);
                                                CheckAgentStateAndAllocateCallToAgent(dropCall);
                                            }
                                            //Thread.Sleep(1500);

                                            //}
                                            //ctr = ctr + 1;
                                        }
                                        
                                    }
                                }
                            }
                        }
                    }
                }
                logger.Info("Timer running end(s) at {0}", DateTime.Now);
                _timer.Enabled = true;
            }
            catch (Exception ex)
            {
                logger.Error(ex);
            }
        }

        #region Private Methods

        private void StartMonitoringForLoginAgents()
        {

            var objCall = new Repository();
            var cmd = new CommandBuilder();
            cmd.SpName = "sp_AutoDial_GetLoginUnMonitoredAgents";
            cmd.SqlParams = new List<SqlParameter>()
            {
                new SqlParameter("@HostIpAddress",hostIpAddress)
            };
            DataSet ds = objCall.Select(cmd);
            if (ds.Tables.Count > 0 && ds.Tables[0].Rows.Count > 0)
            {
                foreach (DataRow dr in ds.Tables[0].Rows)
                {
                    string agentId = Convert.ToString(dr["AgentId"]);
                    string extensionNo = Convert.ToString(dr["ExtensionNo"]);
                    Simulator.Instance.StartMonitoring(agentId, extensionNo);
                }
            }
        }

        private void StopMonitoringForLogoutAgents()
        {

            var objCall = new Repository();
            var cmd = new CommandBuilder();
            cmd.SpName = "sp_AutoDial_GetLogoutMonitoredAgents";
            cmd.SqlParams = new List<SqlParameter>()
            {
                new SqlParameter("@HostIpAddress",hostIpAddress)
            };
            DataSet ds = objCall.Select(cmd);
            if (ds.Tables.Count > 0 && ds.Tables[0].Rows.Count > 0)
            {
                foreach (DataRow dr in ds.Tables[0].Rows)
                {
                    string agentId = Convert.ToString(dr["AgentId"]);
                    string extensionNo = Convert.ToString(dr["ExtensionNo"]);
                    int activeCallCount = Convert.ToInt32(dr["ActiveCallCount"]);
                    int monitorCrossRefId = Convert.ToInt32(dr["MonitorCrossRefInvokeId"]);

                    if (activeCallCount == 0)
                        Simulator.Instance.StopMonitoring(monitorCrossRefId, agentId, extensionNo);
                }
            }

        }

        private void CheckAgentStateAndAllocateCallToAgent(DropCall dropCall)
        {

            BackgroundWorker worker = new BackgroundWorker();
            worker.WorkerReportsProgress = true;
            QueryAgentStateCommand agentStateCmd = null;// new QueryAgentStateCommand(Simulator.Instance.m_Client, dropCall.ExtensionNo);

            worker.DoWork += (o, args) =>
            {
                agentStateCmd = new QueryAgentStateCommand(Simulator.Instance.m_Client, dropCall.ExtensionNo);
                logger.Info("Start getting Agent state for AgentId - {0} , Extension No {1} , DropCallId - {2}", dropCall.AgentId, dropCall.ExtensionNo,dropCall.RecordId);
                agentStateCmd.QueryAgentState();

                worker.ReportProgress(100);
            };

            worker.RunWorkerCompleted += (o, args) =>
            {
                logger.Info("Completed getting Agent state for AgentId - {0} , Extension No - {1} , Agent State - {2} , Work Mode - {3}, DropCallId - {4}", dropCall.AgentId, dropCall.ExtensionNo, agentStateCmd.AgentState, agentStateCmd.WorkMode, dropCall.RecordId);
                //Allocate calls to agem
                if (agentStateCmd.AgentState == (TSAPIClient.CSTA.AgentState_t)agentState && agentStateCmd.WorkMode == (TSAPIClient.ATT.ATTWorkMode_t)workMode && agentStateCmd.TalkState == TSAPIClient.ATT.ATTTalkState_t.TS_IDLE)
                {
                    try
                    {
                        //Re-Check agent whether he is logged in Callback Manager before allocating call .
                        bool isAgentLoggedIn = new LoginRepository().IsAgentLoggedIn(Convert.ToInt32(dropCall.AgentId), Convert.ToInt32(dropCall.ExtensionNo));
                        if (isAgentLoggedIn)
                        {
                            Simulator.Instance.DialCommand(dropCall);
                        }
                        else
                        {
                            try
                            {
                                logger.Info("Reassign current call for AgentId - {0} , Extension No - {1}", dropCall.AgentId, dropCall.ExtensionNo);
                                new TelephonyRepository().ReAllocateCall(dropCall.RecordId);
                            }
                            catch (Exception ex)
                            {
                                logger.Error(ex);
                            }
                        }
                       // logger.Info("Start Allocating call to Extension - {0} ; Agent State - {1}, Work State - {2} ", dropCall.ExtensionNo, agentStateCmd.AgentState.ToString(), agentStateCmd.WorkMode.ToString());
                    }
                    catch (Exception ex)
                    {
                        logger.Error(ex);
                    }
                }
                else
                {
                    try
                    {
                        logger.Info("Reassign current call for AgentId - {0} , Extension No - {1}", dropCall.AgentId, dropCall.ExtensionNo);
                        new TelephonyRepository().ReAllocateCall(dropCall.RecordId);
                    }
                    catch(Exception ex)
                    {
                        logger.Error(ex);
                    }
                }
            };

            worker.RunWorkerAsync();

        }

        private void CloseUnProcessedForIdleAgent()
        {
            var unProcessedCalls = new TelephonyRepository().GetUnProcessedCalls(hostIpAddress);
            if (unProcessedCalls != null && unProcessedCalls.Count > 0)
            {
                foreach (var unProcessedCall in unProcessedCalls)
                {

                    BackgroundWorker worker = new BackgroundWorker();
                    worker.WorkerReportsProgress = true;
                    QueryAgentStateCommand agentStateCmd = null;// new QueryAgentStateCommand(Simulator.Instance.m_Client, unProcessedCall.ExtensionNo.ToString());

                    worker.DoWork += (o, args) =>
                    {
                        agentStateCmd = new QueryAgentStateCommand(Simulator.Instance.m_Client, unProcessedCall.ExtensionNo.ToString());
                        agentStateCmd.QueryAgentState();
                        worker.ReportProgress(100);
                    };

                    worker.RunWorkerCompleted += (o, args) =>
                    {
                        // logger.Info("Completed getting Agent state for AgentId - {0} , Extension No - {1} , Agent State - {2} , Work Mode - {3}", agentId, extensionNo, agentStateCmd.AgentState, agentStateCmd.WorkMode);
                        if (agentStateCmd.TalkState == TSAPIClient.ATT.ATTTalkState_t.TS_IDLE)
                        {
                            try
                            {
                                logger.Info("CloseActiveCallsForIdleAgent : CallerId - {0}, AgentId - {1} , Extension {2} at {3} ", unProcessedCall.CallerId, unProcessedCall.AgentId, unProcessedCall.ExtensionNo.ToString(), DateTime.Now);
                                var activeCall = new TelephonyRepository().UpdateCallToCleared(unProcessedCall.CallerId, unProcessedCall.ExtensionNo.ToString(), hostIpAddress);
                            }
                            catch (Exception ex)
                            {
                                logger.Info(ex);
                            }
                        }
                    };

                    worker.RunWorkerAsync();
                }
            }
            
        }

        private void GetUnAllocatedCallCount()
        {
            Task.Run
            (() =>
            {
                var context = GlobalHost.ConnectionManager.GetHubContext<TelephonyHub>();
                TelephonyRepository telephonyRepository = new TelephonyRepository();
                var dropCallCount = telephonyRepository.GetUnAllocatedCallCount();
                context.Clients.All.showUnAllocatedCallCount(dropCallCount);

            });
        }
        #endregion
    }
}
