﻿using Microsoft.AspNet.SignalR;
using NLog;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Configuration;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using TSAPICallDistributionService.Classes;
using TSAPIClient;
using TSAPIClient.ATT;
using TSAPIClient.CSTA;
using TSAPIDAL;
using TSAPIDAL.DataAccessLayer;
using TSAPIMaster;
using Constants = TSAPIClient.CSTA.Constants;
namespace TSAPICallDistributionService
{
    public sealed class Simulator
    {
        private string tsapiLogin;
        private string tsapiPassword;
        private string tsapiServer;
        private string tsapiApplicationName;
        private string tsapiApplicationVersion;
        private static System.Configuration.Configuration config = ConfigurationManager.OpenExeConfiguration(ConfigurationUserLevel.None);
        Logger consoleLogger = LogManager.GetLogger("ConsoleLogger");
        Logger outputLogger = LogManager.GetLogger("OutputLogger");
        private static readonly string hostIpAddress = Convert.ToString(ConfigurationManager.AppSettings["HostIpAddress"]);
        private static Simulator instance = null;
        private static readonly object padlock = new object();

        Simulator()
        {
            try
            {
                if (config.AppSettings.Settings["ServerID"].Value != "" ||
                    config.AppSettings.Settings["ServerID"].Value != "AVAYA#Switch_Connection#Service_Type#AE_Service")
                {
                    config.AppSettings.Settings["ServerID"].Value = ServerCommand.GetServerName();
                }

                try { this.tsapiServer = config.AppSettings.Settings["ServerID"].Value; }
                catch { this.Configured = false; }
                try { this.tsapiLogin = config.AppSettings.Settings["TSAPI_login"].Value; }
                catch { this.Configured = false; }
                try { this.tsapiPassword = config.AppSettings.Settings["TSAPI_Password"].Value; }
                catch { this.Configured = false; }
                try { this.tsapiApplicationName = config.AppSettings.Settings["ApplicationName"].Value; }
                catch { this.Configured = false; }
                try { this.tsapiApplicationVersion = config.AppSettings.Settings["ApiVersion"].Value; }
                catch { this.Configured = false; }
                //  this.ActiveMonitorDeviceDic = new Dictionary<string, string>();
            }
            catch
            {
                this.Configured = false;
            }
        }

        //  public Dictionary<string, string> ActiveMonitorDeviceDic { get; set; }
        public bool Configured { get; set; }
        public Client m_Client { get; set; }

        public static Simulator Instance
        {
            get
            {
                if (instance == null)
                {
                    lock (padlock)
                    {
                        if (instance == null)
                        {
                            instance = new Simulator();
                        }
                    }
                }
                return instance;
            }
        }

        public void OpenStream()
        {
            if (string.IsNullOrWhiteSpace(tsapiServer))
            {
                return;
            }

            if (string.IsNullOrWhiteSpace(tsapiLogin))
            {
                return;
            }

            if (string.IsNullOrWhiteSpace(tsapiPassword))
            {
                return;
            }

            m_Client = new Client();

            BackgroundWorker worker = new BackgroundWorker();
            worker.WorkerReportsProgress = true;
            var connectCmd = new ConnectCommand(m_Client, tsapiServer, tsapiLogin, tsapiPassword);

            worker.DoWork += (o, args) =>
            {
                connectCmd.Connect();

                worker.ReportProgress(100);
            };

            worker.RunWorkerCompleted += (o, args) =>
            {
                if (connectCmd.Connected)
                {
                    outputLogger.Info("Connected!\n");
                    outputLogger.Info(string.Format("ApiVersion={0}\n", connectCmd.ApiVersion));
                    outputLogger.Info(string.Format("DriverVersion={0}\n", connectCmd.DriverVersion));
                    outputLogger.Info(string.Format("LibraryVersion={0}\n", connectCmd.LibraryVersion));
                    outputLogger.Info(string.Format("ServerVersion={0}\n", connectCmd.ServerVersion));
                    outputLogger.Info(string.Format("PrivateDataVersion={0}\n", connectCmd.PrivateDataVersion));
                    Configured = true;
                    m_Client.TSAPIEvent += onTSAPIEvent;
                }
                else
                {
                    Configured = false;
                    outputLogger.Info("Connection Failed!\n");
                    outputLogger.Info(string.Format("ErrorMessage={0}\n", connectCmd.ErrorMessage));
                }
            };

            outputLogger.Info("connect...\n");
            worker.RunWorkerAsync();
        }

        public void CloseStream()
        {
            BackgroundWorker worker = new BackgroundWorker();
            worker.WorkerReportsProgress = true;
            var connectCmd = new DisconnectCommand(m_Client);

            worker.DoWork += (o, args) =>
            {
                connectCmd.Disconnect();

                worker.ReportProgress(100);
            };

            worker.RunWorkerCompleted += (o, args) =>
            {
                if (connectCmd.Disconnected)
                {
                    outputLogger.Info("Disconnected!\n");
                }
            };

            outputLogger.Info("Disconnecting...\n");
            worker.RunWorkerAsync();
        }

        public void ReActivateHandler()
        {
            if (string.IsNullOrWhiteSpace(tsapiServer))
            {
                return;
            }

            if (string.IsNullOrWhiteSpace(tsapiLogin))
            {
                return;
            }

            if (string.IsNullOrWhiteSpace(tsapiPassword))
            {
                return;
            }

            m_Client = new Client();

            BackgroundWorker worker = new BackgroundWorker();
            worker.WorkerReportsProgress = true;
            var connectCmd = new ConnectCommand(m_Client, tsapiServer, tsapiLogin, tsapiPassword);

            worker.DoWork += (o, args) =>
            {
                connectCmd.Connect();

                worker.ReportProgress(100);
            };

            worker.RunWorkerCompleted += (o, args) =>
            {
                if (connectCmd.Connected)
                {
                    outputLogger.Info("Re-Connected!\n");
                    outputLogger.Info(string.Format("ApiVersion={0}\n", connectCmd.ApiVersion));
                    outputLogger.Info(string.Format("DriverVersion={0}\n", connectCmd.DriverVersion));
                    outputLogger.Info(string.Format("LibraryVersion={0}\n", connectCmd.LibraryVersion));
                    outputLogger.Info(string.Format("ServerVersion={0}\n", connectCmd.ServerVersion));
                    outputLogger.Info(string.Format("PrivateDataVersion={0}\n", connectCmd.PrivateDataVersion));
                    Configured = true;
                    m_Client.TSAPIEvent += onTSAPIEvent;

                    StartActiveStationsMonitoring();

                }
                else
                {
                    Configured = false;
                    outputLogger.Info("Connection Failed!\n");
                    outputLogger.Info(string.Format("ErrorMessage={0}\n", connectCmd.ErrorMessage));
                }
            };

            outputLogger.Info("connect...\n");
            worker.RunWorkerAsync();
        }


        public bool CheckHandler()
        {
            if (new CheckHandlerCommand(m_Client).IsBadHandler())
            {
                Configured = false;
                m_Client.acsAbortStream();
                m_Client = null;
                //  this.ActiveMonitorDeviceDic = new Dictionary<string, string>();
                ReActivateHandler();
                return false;
            }
            return true;
        }

        public void StartActiveStationsMonitoring()
        {
            var activeAgentStationDic = new LoginRepository().GetActiveAgents(hostIpAddress);
            if (activeAgentStationDic != null)
            {
                foreach (var item in activeAgentStationDic)
                {
                    StartMonitoring(item.Key, item.Value);
                }
            }
        }

        public void StartMonitoringAsync(string agentId, string extensionNo)
        {
            //if (this.ActiveMonitorDeviceDic.Keys.Contains(extensionNo))
            //    return;

            BackgroundWorker worker = new BackgroundWorker();
            worker.WorkerReportsProgress = true;
            var monitorExtCmd = new MonitorExtensionCommand(m_Client, extensionNo);

            worker.DoWork += (o, args) =>
            {
                monitorExtCmd.MonitorDevice();

                worker.ReportProgress(100);
            };

            worker.RunWorkerCompleted += (o, args) =>
            {
                if (monitorExtCmd.MonitorCrossRef > -1)
                {
                    //  this.ActiveMonitorDeviceDic.Add(extensionNo, agentId);
                    outputLogger.Info("StartMonitoring - {0} done for AgentId - {1} , Extension No {2} ", monitorExtCmd.MonitorCrossRef, agentId, extensionNo);
                    new TelephonyRepository().StartMonitoringDevice(monitorExtCmd.MonitorCrossRef, agentId, extensionNo);
                }
            };

            outputLogger.Info("StartMonitoring for AgentId - {0} , Extension No {1}", agentId, extensionNo);
            worker.RunWorkerAsync();
        }


        public void StartMonitoring(string agentId, string extensionNo)
        {
            //if (this.ActiveMonitorDeviceDic.Keys.Contains(extensionNo))
            //    return;

            BackgroundWorker worker = new BackgroundWorker();
            worker.WorkerReportsProgress = true;
            MonitorExtensionCommand monitorExtCmd = null ;

            worker.DoWork += (o, args) =>
            {
                monitorExtCmd = new MonitorExtensionCommand(m_Client, extensionNo);
                monitorExtCmd.MonitorDevice();

                worker.ReportProgress(100);
            };

            worker.RunWorkerCompleted += (o, args) =>
            {
                if (monitorExtCmd.MonitorCrossRef > -1)
                {

                    outputLogger.Info("StartMonitoring - {0} done for AgentId - {1} , Extension No {2} ", monitorExtCmd.MonitorCrossRef, agentId, extensionNo);
                    if (new TelephonyRepository().StartMonitoringDevice(monitorExtCmd.MonitorCrossRef, agentId, extensionNo))
                    {
                        //if(!this.ActiveMonitorDeviceDic.Keys.Contains(extensionNo))
                        //    this.ActiveMonitorDeviceDic.Add(extensionNo, agentId);
                    }
                }
            };

            outputLogger.Info("StartMonitoring for AgentId - {0} , Extension No {1}", agentId, extensionNo);
            worker.RunWorkerAsync();
        }

        public void StopStartMonitoring(string agentId, string extensionNo)
        {
            int monitorCrossRefId = new TelephonyRepository().GetAgentMonitorCrossRefId(agentId, extensionNo);
            BackgroundWorker worker = new BackgroundWorker();
            worker.WorkerReportsProgress = true;
            var monitorExtCmd = new MonitorDeviceStopCommand(m_Client, monitorCrossRefId);

            worker.DoWork += (o, args) =>
            {
                monitorExtCmd.StopMonitorDevice();

                worker.ReportProgress(100);
            };

            worker.RunWorkerCompleted += (o, args) =>
            {
                outputLogger.Info("Stop Monitoring for MonitorCrossRefId - {0}", monitorCrossRefId);
                StartMonitoring(agentId, extensionNo);
            };


            worker.RunWorkerAsync();

        }

        /// <summary>
        /// This method is used to stop monitoring of all monitored stations
        /// </summary>
        public void StopActiveAgentsMonitoring()
        {
            int stopAgentMonitoringCtr = 0;
            var activeAgentStationDic = new LoginRepository().GetActiveAgents(hostIpAddress);
            if (activeAgentStationDic != null)
            {
                foreach (var item in activeAgentStationDic)
                {
                    int monitorCrossRefId = new TelephonyRepository().GetAgentMonitorCrossRefId(item.Key, item.Value);

                    BackgroundWorker worker = new BackgroundWorker();
                    worker.WorkerReportsProgress = true;
                    MonitorDeviceStopCommand monitorExtCmd = null;

                    worker.DoWork += (o, args) =>
                    {
                        monitorExtCmd = new MonitorDeviceStopCommand(m_Client, monitorCrossRefId);
                        monitorExtCmd.StopMonitorDevice();
                        worker.ReportProgress(100);
                    };

                    worker.RunWorkerCompleted += (o, args) =>
                    {
                        if (new TelephonyRepository().StopActiveAgentMonitoring(monitorCrossRefId, item.Key, item.Value))
                        {
                            stopAgentMonitoringCtr++;
                            if (stopAgentMonitoringCtr == activeAgentStationDic.Count)
                            {
                                this.m_Client.acsAbortStream();
                            }
                            //if (this.ActiveMonitorDeviceDic.Keys.Contains(extensionNo))
                            //    this.ActiveMonitorDeviceDic.Remove(extensionNo);
                        }

                        outputLogger.Info("Stop Monitoring - {0} done for AgentId - {1} , Extension No {2} ", monitorCrossRefId, item.Key, item.Value);

                    };

                    outputLogger.Info("Stop Monitoring - {0} started for AgentId - {1} , Extension No {2} ", monitorCrossRefId, item.Key, item.Value);

                    worker.RunWorkerAsync();
                }
            }
        }

        public void StopMonitoring(int monitorCrossRefId, string agentId, string extensionNo)
        {
            //if (!this.ActiveMonitorDeviceDic.Keys.Contains(extensionNo))
            //    return;

            BackgroundWorker worker = new BackgroundWorker();
            worker.WorkerReportsProgress = true;
            MonitorDeviceStopCommand monitorExtCmd = null;

            worker.DoWork += (o, args) =>
            {
                monitorExtCmd = new MonitorDeviceStopCommand(m_Client, monitorCrossRefId);
                monitorExtCmd.StopMonitorDevice();
                worker.ReportProgress(100);
            };

            worker.RunWorkerCompleted += (o, args) =>
            {
                if (new TelephonyRepository().StopMonitoringDevice(monitorCrossRefId, agentId, extensionNo))
                {
                    //if (this.ActiveMonitorDeviceDic.Keys.Contains(extensionNo))
                    //    this.ActiveMonitorDeviceDic.Remove(extensionNo);
                }

                outputLogger.Info("Stop Monitoring - {0} done for AgentId - {1} , Extension No {2} ", monitorCrossRefId, agentId, extensionNo);

            };

            outputLogger.Info("Stop Monitoring - {0} started for AgentId - {1} , Extension No {2} ", monitorCrossRefId, agentId, extensionNo);

            worker.RunWorkerAsync();

        }


        public void StopMonitoring(string agentId, string extensionNo)
        {
            //if (!this.ActiveMonitorDeviceDic.Keys.Contains(extensionNo))
            //    return;

            int monitorCrossRefId = new TelephonyRepository().GetAgentMonitorCrossRefId(agentId, extensionNo);
            BackgroundWorker worker = new BackgroundWorker();
            worker.WorkerReportsProgress = true;
            MonitorDeviceStopCommand monitorExtCmd = null;

            worker.DoWork += (o, args) =>
            {
                monitorExtCmd = new MonitorDeviceStopCommand(m_Client, monitorCrossRefId);
                monitorExtCmd.StopMonitorDevice();
                worker.ReportProgress(100);
            };

            worker.RunWorkerCompleted += (o, args) =>
            {
                if (new TelephonyRepository().StopMonitoringDevice(monitorCrossRefId, agentId, extensionNo))
                {
                    //if (this.ActiveMonitorDeviceDic.Keys.Contains(extensionNo))
                    //    this.ActiveMonitorDeviceDic.Remove(extensionNo);
                }

                outputLogger.Info("Stop Monitoring - {0} done for AgentId - {1} , Extension No {2} ", monitorCrossRefId, agentId, extensionNo);

            };

            outputLogger.Info("Stop Monitoring - {0} started for AgentId - {1} , Extension No {2} ", monitorCrossRefId, agentId, extensionNo);

            worker.RunWorkerAsync();

        }

        public void AnswerCall(int callId, string deviceId)
        {
            BackgroundWorker worker = new BackgroundWorker();
            worker.WorkerReportsProgress = true;
            AnswerCallCommand answerCallCmd = null;


            worker.DoWork += (o, args) =>
            {
                answerCallCmd = new AnswerCallCommand(m_Client, callId, deviceId);
                answerCallCmd.AnswerCall();
                worker.ReportProgress(100);
            };

            worker.RunWorkerCompleted += (o, args) =>
            {
                outputLogger.Info("Answer call for Extension No - {0}", deviceId);
            };


            worker.RunWorkerAsync();
        }

        public void EndCall(int callId, string deviceId)
        {
            BackgroundWorker worker = new BackgroundWorker();
            worker.WorkerReportsProgress = true;
            ClearCallCommand clearCallCmd = null;
            worker.DoWork += (o, args) =>
            {
                clearCallCmd = new ClearCallCommand(m_Client, deviceId, callId);
                clearCallCmd.ClearCall();
                worker.ReportProgress(100);
            };

            worker.RunWorkerCompleted += (o, args) =>
            {

            };
            worker.RunWorkerAsync();
        }

        public void HoldCall(int callId, string deviceId)
        {
            BackgroundWorker worker = new BackgroundWorker();
            worker.WorkerReportsProgress = true;

            HoldCallCommand holdCallCmd = null;
            worker.DoWork += (o, args) =>
            {
                holdCallCmd = new HoldCallCommand(m_Client, deviceId, callId);
                holdCallCmd.HoldCall();
                worker.ReportProgress(100);
            };

            worker.RunWorkerCompleted += (o, args) =>
            {
                outputLogger.Info("Hold call for Extension No - {0}", deviceId);
            };


            worker.RunWorkerAsync();
        }

        public void DialCommand(DropCall call)
        {
            //if (!this.ActiveMonitorDeviceDic.Keys.Contains(call.ExtensionNo))
            //    return;

            BackgroundWorker worker = new BackgroundWorker();
            worker.WorkerReportsProgress = true;
            DialCommand dialCommand = null ;

            worker.DoWork += (o, args) =>
            {
                outputLogger.Info("Dial command DoWork log details for DropCallId - {0}, Extension - {1} ; Caller Number {2} ;return CallId {3} - UCID {4} , Error Message - {5} ", call.RecordId, call.ExtensionNo, call.CallerNumberWithPrefix, dialCommand.CallID, string.IsNullOrEmpty(dialCommand.UCID) ? "" : dialCommand.UCID, dialCommand.ErrorMessage);
                dialCommand = new DialCommand(m_Client, call.ExtensionNo, call.CallerNumberWithPrefix);
                dialCommand.Dial();
                worker.ReportProgress(100);
            };

            worker.RunWorkerCompleted += (o, args) =>
            {
                outputLogger.Info("Dial command Completed log details for DropCallId - {0}, Extension - {1} ; Caller Number {2} ;return CallId {3} - UCID {4} , Error Message - {5} ",call.RecordId, call.ExtensionNo, call.CallerNumberWithPrefix,dialCommand.CallID, string.IsNullOrEmpty(dialCommand.UCID) ? "" : dialCommand.UCID, dialCommand.ErrorMessage);
                if (dialCommand.CallID > 0)
                {
                    try
                    {
                        var activeCall = new ActiveCall() {DropOutCallerId = call.RecordId, ExtensionNo = call.ExtensionNo, CallerMobile = call.CallerNumber, CallerName = call.CallerName };
                        IHubContext hubContext = GlobalHost.ConnectionManager.GetHubContext<TelephonyHub>();
                        hubContext.Clients.User(activeCall.ExtensionNo).showAgentActiveCall(activeCall);

                        new TelephonyRepository().SaveDialCallLog(call, dialCommand.CallID, dialCommand.UCID);
                    }
                    catch (Exception ex)
                    {
                        outputLogger.Error(ex);
                    }
                }
            };
            worker.RunWorkerAsync();
        }

        private void onTSAPIEvent(object sender, TSAPIEventArgs e)
        {
            try
            {
                TSAPIEventArgs tsapiEvent = e;
                CSTAEvent_t cstaEvent = e.cstaEvent;
                ATTEvent_t attEvent = e.attEvent;

                switch (cstaEvent.eventHeader.eventClass)
                {
                    case Constants.CSTACONFIRMATION:

                        #region CSTACONFIRMATION

                        switch (cstaEvent.eventHeader.eventType)
                        {
                            case Constants.CSTA_ALTERNATE_CALL_CONF:

                                #region CSTA_ALTERNATE_CALL_CONF

                                {
                                    if (cstaEvent.Event.cstaConfirmation.u.alternateCall != null)
                                    {
                                        CSTAAlternateCallConfEvent_t alternateCall = (CSTAAlternateCallConfEvent_t)cstaEvent.Event.cstaConfirmation.u.alternateCall;

                                        consoleLogger.Info("onTSAPIEvent.CSTA_ALTERNATE_CALL_CONF: alternateCall={0};", alternateCall);
                                    }
                                }

                                break;

                                #endregion CSTA_ALTERNATE_CALL_CONF

                            case Constants.CSTA_ANSWER_CALL_CONF:

                                #region CSTA_ANSWER_CALL_CONF

                                {
                                    if (cstaEvent.Event.cstaConfirmation.u.answerCall != null)
                                    {
                                        CSTAAnswerCallConfEvent_t answerCall = (CSTAAnswerCallConfEvent_t)cstaEvent.Event.cstaConfirmation.u.answerCall;

                                        consoleLogger.Info("onTSAPIEvent.CSTA_ANSWER_CALL_CONF: answerCall={0};", answerCall);
                                    }
                                }

                                break;

                                #endregion CSTA_ANSWER_CALL_CONF

                            case Constants.CSTA_CALL_COMPLETION_CONF:

                                #region CSTA_CALL_COMPLETION_CONF

                                {
                                    if (cstaEvent.Event.cstaConfirmation.u.callCompletion != null)
                                    {
                                        CSTACallCompletionConfEvent_t callCompletion = (CSTACallCompletionConfEvent_t)cstaEvent.Event.cstaConfirmation.u.callCompletion;

                                        consoleLogger.Info(string.Format("onTSAPIEvent.CSTA_CALL_COMPLETION_CONF: callCompletion={0};", callCompletion));
                                    }
                                }

                                break;

                                #endregion CSTA_CALL_COMPLETION_CONF

                            case Constants.CSTA_CLEAR_CALL_CONF:

                                #region CSTA_CLEAR_CALL_CONF

                                {
                                    if (cstaEvent.Event.cstaConfirmation.u.clearCall != null)
                                    {
                                        CSTAClearCallConfEvent_t clearCall = (CSTAClearCallConfEvent_t)cstaEvent.Event.cstaConfirmation.u.clearCall;

                                        consoleLogger.Info("onTSAPIEvent.CSTA_CLEAR_CALL_CONF: clearCall={0};", clearCall);
                                    }
                                }

                                break;

                                #endregion CSTA_CLEAR_CALL_CONF

                            case Constants.CSTA_CONFERENCE_CALL_CONF:

                                #region CSTA_CONFERENCE_CALL_CONF

                                consoleLogger.Info("onTSAPIEvent eventType=CSTA_CONFERENCE_CALL_CONF");
                                {
                                    if (cstaEvent.Event.cstaConfirmation.u.conferenceCall != null)
                                    {
                                        CSTAConferenceCallConfEvent_t conferenceCall = (CSTAConferenceCallConfEvent_t)cstaEvent.Event.cstaConfirmation.u.conferenceCall;

                                        int callID = conferenceCall.newCall.callID;
                                        string device = conferenceCall.newCall.deviceID.device;

                                        consoleLogger.Info(string.Format("onTSAPIEvent.CSTA_CONFERENCE_CALL_CONF: deviceID={0};callID={1};", device, callID));
                                    }
                                }

                                break;

                                #endregion CSTA_CONFERENCE_CALL_CONF

                            case Constants.CSTA_CONSULTATION_CALL_CONF:

                                #region CSTA_CONSULTATION_CALL_CONF

                                consoleLogger.Info("onTSAPIEvent eventType=CSTA_CONSULTATION_CALL_CONF");
                                {
                                    if (cstaEvent.Event.cstaConfirmation.u.consultationCall != null)
                                    {
                                        CSTAConsultationCallConfEvent_t consultationCall = (CSTAConsultationCallConfEvent_t)cstaEvent.Event.cstaConfirmation.u.consultationCall;

                                        string device = consultationCall.newCall.deviceID.device;
                                        int callID = consultationCall.newCall.callID;

                                        consoleLogger.Info(string.Format("onTSAPIEvent.CSTA_CONSULTATION_CALL_CONF: deviceID={0};callID={1};", device, callID));
                                    }
                                }

                                break;

                                #endregion CSTA_CONSULTATION_CALL_CONF

                            case Constants.CSTA_DEFLECT_CALL_CONF:

                                #region CSTA_DEFLECT_CALL_CONF

                                {
                                    consoleLogger.Info(string.Format("onTSAPIEvent eventType=CSTA_DEFLECT_CALL_CONF"));

                                    if (cstaEvent.Event.cstaConfirmation.u.deflectCall != null)
                                    {
                                        CSTADeflectCallConfEvent_t deflectCall = (CSTADeflectCallConfEvent_t)cstaEvent.Event.cstaConfirmation.u.deflectCall;

                                        consoleLogger.Info(string.Format("onTSAPIEvent.CSTA_DEFLECT_CALL_CONF: deflectCall={0};", deflectCall));
                                    }
                                }

                                break;

                                #endregion CSTA_DEFLECT_CALL_CONF

                            case Constants.CSTA_PICKUP_CALL_CONF:

                                #region CSTA_PICKUP_CALL_CONF

                                {
                                    if (cstaEvent.Event.cstaConfirmation.u.pickupCall != null)
                                    {
                                        CSTAPickupCallConfEvent_t pickupCall = (CSTAPickupCallConfEvent_t)cstaEvent.Event.cstaConfirmation.u.pickupCall;

                                        consoleLogger.Info(string.Format("onTSAPIEvent.CSTA_PICKUP_CALL_CONF: pickupCall={0};", pickupCall));
                                    }
                                }

                                break;

                                #endregion CSTA_PICKUP_CALL_CONF

                            case Constants.CSTA_GROUP_PICKUP_CALL_CONF:

                                #region CSTA_GROUP_PICKUP_CALL_CONF

                                {
                                    if (cstaEvent.Event.cstaConfirmation.u.groupPickupCall != null)
                                    {
                                        CSTAGroupPickupCallConfEvent_t groupPickupCall = (CSTAGroupPickupCallConfEvent_t)cstaEvent.Event.cstaConfirmation.u.groupPickupCall;

                                        consoleLogger.Info(string.Format("onTSAPIEvent.CSTA_GROUP_PICKUP_CALL_CONF: groupPickupCall={0};", groupPickupCall));
                                    }
                                }

                                break;

                                #endregion CSTA_GROUP_PICKUP_CALL_CONF

                            case Constants.CSTA_HOLD_CALL_CONF:

                                #region CSTA_HOLD_CALL_CONF

                                {
                                    if (cstaEvent.Event.cstaConfirmation.u.holdCall != null)
                                    {
                                        CSTAHoldCallConfEvent_t holdCall = (CSTAHoldCallConfEvent_t)cstaEvent.Event.cstaConfirmation.u.holdCall;

                                        consoleLogger.Info(string.Format("onTSAPIEvent.CSTA_HOLD_CALL_CONF: holdCall={0};", holdCall));
                                    }
                                }

                                break;

                                #endregion CSTA_HOLD_CALL_CONF

                            case Constants.CSTA_MAKE_CALL_CONF:

                                #region CSTA_MAKE_CALL_CONF

                                {
                                    consoleLogger.Info("onTSAPIEvent eventType=CSTA_MAKE_CALL_CONF");

                                    if (cstaEvent.Event.cstaConfirmation.u.makeCall != null)
                                    {
                                        CSTAMakeCallConfEvent_t makeCall = (CSTAMakeCallConfEvent_t)cstaEvent.Event.cstaConfirmation.u.makeCall;

                                        string ucid = string.Empty;

                                        if (attEvent.u.makeCall != null)
                                        {
                                            ATTMakeCallConfEvent_t attMakeCall = (ATTMakeCallConfEvent_t)attEvent.u.makeCall;

                                            ucid = attMakeCall.ucid.value;
                                        }

                                        consoleLogger.Info(string.Format("onTSAPIEvent.CSTA_MAKE_CALL_CONF: deviceID={0};callID={1};ucid={2}", makeCall.newCall.deviceID.device, makeCall.newCall.callID, ucid));
                                    }
                                }

                                break;

                                #endregion CSTA_MAKE_CALL_CONF

                            case Constants.CSTA_MAKE_PREDICTIVE_CALL_CONF:

                                #region CSTA_MAKE_PREDICTIVE_CALL_CONF

                                {
                                    if (cstaEvent.Event.cstaConfirmation.u.makePredictiveCall != null)
                                    {
                                        CSTAMakePredictiveCallConfEvent_t makePredictiveCall = (CSTAMakePredictiveCallConfEvent_t)cstaEvent.Event.cstaConfirmation.u.makePredictiveCall;

                                        consoleLogger.Info(string.Format("onTSAPIEvent.CSTA_MAKE_PREDICTIVE_CALL_CONF: newCall.callID={0};newCall.deviceID={1};newCall.devIDType={2};", makePredictiveCall.newCall.callID, makePredictiveCall.newCall.deviceID.device, makePredictiveCall.newCall.devIDType));
                                    }
                                }

                                break;

                                #endregion CSTA_MAKE_PREDICTIVE_CALL_CONF

                            case Constants.CSTA_QUERY_MWI_CONF:

                                #region CSTA_QUERY_MWI_CONF

                                {
                                    if (cstaEvent.Event.cstaConfirmation.u.queryMwi != null)
                                    {
                                        CSTAQueryMwiConfEvent_t queryMwi = (CSTAQueryMwiConfEvent_t)cstaEvent.Event.cstaConfirmation.u.queryMwi;

                                        consoleLogger.Info(string.Format("onTSAPIEvent.CSTA_QUERY_MWI_CONF: messages={0};", queryMwi.messages));
                                    }
                                }

                                break;

                                #endregion CSTA_QUERY_MWI_CONF

                            case Constants.CSTA_QUERY_DND_CONF:

                                #region CSTA_QUERY_DND_CONF

                                consoleLogger.Info(string.Format("onTSAPIEvent eventType=CSTA_QUERY_DND_CONF"));
                                {
                                    if (cstaEvent.Event.cstaConfirmation.u.queryDnd != null)
                                    {
                                        CSTAQueryDndConfEvent_t queryDnd = (CSTAQueryDndConfEvent_t)cstaEvent.Event.cstaConfirmation.u.queryDnd;

                                        consoleLogger.Info(string.Format("onTSAPIEvent.CSTA_QUERY_FWD_CONF: doNotDisturb={0};", queryDnd.doNotDisturb));
                                    }
                                }

                                break;

                                #endregion CSTA_QUERY_DND_CONF

                            case Constants.CSTA_QUERY_FWD_CONF:

                                #region CSTA_QUERY_FWD_CONF

                                {
                                    if (cstaEvent.Event.cstaConfirmation.u.queryFwd != null)
                                    {
                                        CSTAQueryFwdConfEvent_t queryFwd = (CSTAQueryFwdConfEvent_t)cstaEvent.Event.cstaConfirmation.u.queryFwd;

                                        consoleLogger.Info(string.Format("onTSAPIEvent.CSTA_QUERY_FWD_CONF: count={0};param={1};", queryFwd.forward.count, queryFwd.forward.param));
                                    }
                                }

                                break;

                                #endregion CSTA_QUERY_FWD_CONF

                            case Constants.CSTA_QUERY_AGENT_STATE_CONF:

                                #region CSTA_QUERY_AGENT_STATE_CONF

                                {
                                    if (cstaEvent.Event.cstaConfirmation.u.queryAgentState != null)
                                    {
                                        CSTAQueryAgentStateConfEvent_t queryAgentState = (CSTAQueryAgentStateConfEvent_t)cstaEvent.Event.cstaConfirmation.u.queryAgentState;

                                        consoleLogger.Info(string.Format("onTSAPIEvent.CSTA_QUERY_AGENT_STATE_CONF: agentState={0};", queryAgentState.agentState));
                                    }
                                }

                                break;

                                #endregion CSTA_QUERY_AGENT_STATE_CONF

                            case Constants.CSTA_QUERY_LAST_NUMBER_CONF:

                                #region CSTA_QUERY_LAST_NUMBER_CONF

                                {
                                    if (cstaEvent.Event.cstaConfirmation.u.queryLastNumber != null)
                                    {
                                        CSTAQueryLastNumberConfEvent_t queryLastNumber = (CSTAQueryLastNumberConfEvent_t)cstaEvent.Event.cstaConfirmation.u.queryLastNumber;

                                        consoleLogger.Info(string.Format("onTSAPIEvent.CSTA_QUERY_LAST_NUMBER_CONF: lastNumber={0};", queryLastNumber.lastNumber));
                                    }
                                }

                                break;

                                #endregion CSTA_QUERY_LAST_NUMBER_CONF

                            case Constants.CSTA_QUERY_DEVICE_INFO_CONF:

                                #region CSTA_QUERY_DEVICE_INFO_CONF

                                {
                                    if (cstaEvent.Event.cstaConfirmation.u.queryDeviceInfo != null)
                                    {
                                        CSTAQueryDeviceInfoConfEvent_t queryDeviceInfo = (CSTAQueryDeviceInfoConfEvent_t)cstaEvent.Event.cstaConfirmation.u.queryDeviceInfo;

                                        consoleLogger.Info(string.Format("onTSAPIEvent.CSTA_QUERY_DEVICE_INFO_CONF: device={0};", queryDeviceInfo.device));
                                    }
                                }

                                break;

                                #endregion CSTA_QUERY_DEVICE_INFO_CONF

                            case Constants.CSTA_RECONNECT_CALL_CONF:

                                #region CSTA_RECONNECT_CALL_CONF

                                {
                                    if (cstaEvent.Event.cstaConfirmation.u.reconnectCall != null)
                                    {
                                        CSTAReconnectCallConfEvent_t reconnectCall = (CSTAReconnectCallConfEvent_t)cstaEvent.Event.cstaConfirmation.u.reconnectCall;

                                        consoleLogger.Info(string.Format("onTSAPIEvent.CSTA_RECONNECT_CALL_CONF: reconnectCall={0};", reconnectCall));
                                    }
                                }

                                break;

                                #endregion CSTA_RECONNECT_CALL_CONF

                            case Constants.CSTA_RETRIEVE_CALL_CONF:

                                #region CSTA_RETRIEVE_CALL_CONF

                                {
                                    if (cstaEvent.Event.cstaConfirmation.u.retrieveCall != null)
                                    {
                                        CSTARetrieveCallConfEvent_t retrieveCall = (CSTARetrieveCallConfEvent_t)cstaEvent.Event.cstaConfirmation.u.retrieveCall;

                                        consoleLogger.Info(string.Format("onTSAPIEvent.CSTA_RECONNECT_CALL_CONF: retrieveCall={0};", retrieveCall));
                                    }
                                }

                                break;

                                #endregion CSTA_RETRIEVE_CALL_CONF

                            case Constants.CSTA_SET_MWI_CONF:

                                #region CSTA_SET_MWI_CONF

                                {
                                    if (cstaEvent.Event.cstaConfirmation.u.setMwi != null)
                                    {
                                        CSTASetMwiConfEvent_t setMwi = (CSTASetMwiConfEvent_t)cstaEvent.Event.cstaConfirmation.u.setMwi;

                                        consoleLogger.Info(string.Format("onTSAPIEvent.CSTA_SET_MWI_CONF: setMwi={0};", setMwi));
                                    }
                                }

                                break;

                                #endregion CSTA_SET_MWI_CONF

                            case Constants.CSTA_SET_DND_CONF:

                                #region CSTA_SET_DND_CONF

                                {
                                    if (cstaEvent.Event.cstaConfirmation.u.setDnd != null)
                                    {
                                        CSTASetDndConfEvent_t setDnd = (CSTASetDndConfEvent_t)cstaEvent.Event.cstaConfirmation.u.setDnd;

                                        consoleLogger.Info(string.Format("onTSAPIEvent.CSTA_SET_DND_CONF: setDnd={0};", setDnd));
                                    }
                                }

                                break;

                                #endregion CSTA_SET_DND_CONF

                            case Constants.CSTA_SET_FWD_CONF:

                                #region CSTA_SET_FWD_CONF

                                {
                                    if (cstaEvent.Event.cstaConfirmation.u.setFwd != null)
                                    {
                                        CSTASetFwdConfEvent_t setFwd = (CSTASetFwdConfEvent_t)cstaEvent.Event.cstaConfirmation.u.setFwd;

                                        consoleLogger.Info(string.Format("onTSAPIEvent.CSTA_SET_FWD_CONF: setFwd={0};", setFwd));
                                    }
                                }

                                break;

                                #endregion CSTA_SET_FWD_CONF

                            case Constants.CSTA_SET_AGENT_STATE_CONF:

                                #region CSTA_SET_AGENT_STATE_CONF

                                {
                                    if (cstaEvent.Event.cstaConfirmation.u.setAgentState != null)
                                    {
                                        CSTASetAgentStateConfEvent_t setAgentState = (CSTASetAgentStateConfEvent_t)cstaEvent.Event.cstaConfirmation.u.setAgentState;
                                        //ATTSetAgentStateConfEvent_t attSetAgentState = (ATTSetAgentStateConfEvent_t)tsapiEvent.attEvent.u.setAgentState;

                                        consoleLogger.Info(string.Format("onTSAPIEvent.CSTA_SET_AGENT_STATE_CONF: setAgentState={0};", setAgentState.ToString()));
                                    }
                                }

                                break;

                                #endregion CSTA_SET_AGENT_STATE_CONF

                            case Constants.CSTA_TRANSFER_CALL_CONF:

                                #region CSTA_TRANSFER_CALL_CONF

                                consoleLogger.Info("onTSAPIEvent eventType=CSTA_TRANSFER_CALL_CONF");
                                {
                                    if (cstaEvent.Event.cstaConfirmation.u.transferCall != null)
                                    {
                                        CSTATransferCallConfEvent_t transferCall = (CSTATransferCallConfEvent_t)cstaEvent.Event.cstaConfirmation.u.transferCall;

                                        string device = transferCall.newCall.deviceID.device;
                                        int callID = transferCall.newCall.callID;

                                        consoleLogger.Info(string.Format("onTSAPIEvent.CSTA_TRANSFER_CALL_CONF: deviceID={0};callID={1};", device, callID));
                                    }
                                }

                                break;

                                #endregion CSTA_TRANSFER_CALL_CONF

                            case Constants.CSTA_UNIVERSAL_FAILURE_CONF:

                                #region CSTA_UNIVERSAL_FAILURE_CONF

                                {
                                    if (cstaEvent.Event.cstaConfirmation.u.universalFailure != null)
                                    {
                                        CSTAUniversalFailureConfEvent_t universalFailure = (CSTAUniversalFailureConfEvent_t)cstaEvent.Event.cstaConfirmation.u.universalFailure;

                                        consoleLogger.Info(string.Format("onTSAPIEvent.CSTA_UNIVERSAL_FAILURE_CONF: error={0};", universalFailure.error));
                                    }
                                }

                                break;

                                #endregion CSTA_UNIVERSAL_FAILURE_CONF

                            case Constants.CSTA_MONITOR_CONF:

                                #region CSTA_MONITOR_CONF

                                {
                                    if (cstaEvent.Event.cstaConfirmation.u.monitorStart != null)
                                    {
                                        CSTAMonitorConfEvent_t monitorStart = (CSTAMonitorConfEvent_t)cstaEvent.Event.cstaConfirmation.u.monitorStart;

                                        consoleLogger.Info(string.Format("onTSAPIEvent.CSTA_MONITOR_CONF: monitorCrossRefID={0};", monitorStart.monitorCrossRefID));
                                    }
                                }

                                break;

                                #endregion CSTA_MONITOR_CONF

                            case Constants.CSTA_CHANGE_MONITOR_FILTER_CONF:

                                #region CSTA_CHANGE_MONITOR_FILTER_CONF

                                {
                                    if (cstaEvent.Event.cstaConfirmation.u.changeMonitorFilter != null)
                                    {
                                        CSTAChangeMonitorFilterConfEvent_t changeMonitorFilter = (CSTAChangeMonitorFilterConfEvent_t)cstaEvent.Event.cstaConfirmation.u.changeMonitorFilter;

                                        consoleLogger.Info(string.Format("onTSAPIEvent.CSTA_CHANGE_MONITOR_FILTER_CONF: monitorFilter={0};", changeMonitorFilter.monitorFilter));
                                    }
                                }

                                break;

                                #endregion CSTA_CHANGE_MONITOR_FILTER_CONF

                            case Constants.CSTA_MONITOR_STOP_CONF:

                                #region CSTA_MONITOR_STOP_CONF

                                {
                                    if (cstaEvent.Event.cstaConfirmation.u.monitorStop != null)
                                    {
                                        CSTAMonitorStopConfEvent_t monitorStop = (CSTAMonitorStopConfEvent_t)cstaEvent.Event.cstaConfirmation.u.monitorStop;

                                        consoleLogger.Info(string.Format("onTSAPIEvent.CSTA_MONITOR_STOP_CONF: monitorStop={0};", monitorStop));
                                    }
                                }

                                break;

                                #endregion CSTA_MONITOR_STOP_CONF

                            case Constants.CSTA_SNAPSHOT_DEVICE_CONF:

                                #region CSTA_SNAPSHOT_DEVICE_CONF

                                {
                                    if (cstaEvent.Event.cstaConfirmation.u.snapshotDevice != null)
                                    {
                                        CSTASnapshotDeviceConfEvent_t snapshotDevice = (CSTASnapshotDeviceConfEvent_t)cstaEvent.Event.cstaConfirmation.u.snapshotDevice;

                                        consoleLogger.Info(string.Format("onTSAPIEvent.CSTA_SNAPSHOT_DEVICE_CONF: snapshotData={0};", snapshotDevice.snapshotData));
                                    }

                                }

                                break;

                                #endregion CSTA_SNAPSHOT_DEVICE_CONF

                            case Constants.CSTA_SNAPSHOT_CALL_CONF:

                                #region CSTA_SNAPSHOT_CALL_CONF

                                {
                                    if (cstaEvent.Event.cstaConfirmation.u.snapshotCall != null)
                                    {
                                        CSTASnapshotCallConfEvent_t snapshotCall = (CSTASnapshotCallConfEvent_t)cstaEvent.Event.cstaConfirmation.u.snapshotCall;

                                        consoleLogger.Info(string.Format("onTSAPIEvent.CSTA_SNAPSHOT_CALL_CONF: snapshotCall={0};", snapshotCall.snapshotData));
                                    }
                                }

                                break;

                                #endregion CSTA_SNAPSHOT_CALL_CONF

                            case Constants.CSTA_ROUTE_REGISTER_REQ_CONF:

                                #region CSTA_ROUTE_REGISTER_REQ_CONF

                                {
                                    if (cstaEvent.Event.cstaConfirmation.u.routeRegister != null)
                                    {
                                        CSTARouteRegisterReqConfEvent_t routeRegister = (CSTARouteRegisterReqConfEvent_t)cstaEvent.Event.cstaConfirmation.u.routeRegister;

                                        consoleLogger.Info(string.Format("onTSAPIEvent.CSTA_ROUTE_REGISTER_REQ_CONF: registerReqID={0};", routeRegister.registerReqID));
                                    }
                                }

                                break;

                                #endregion CSTA_ROUTE_REGISTER_REQ_CONF

                            case Constants.CSTA_ROUTE_REGISTER_CANCEL_CONF:

                                #region CSTA_ROUTE_REGISTER_CANCEL_CONF

                                {
                                    if (cstaEvent.Event.cstaConfirmation.u.routeCancel != null)
                                    {
                                        CSTARouteRegisterCancelConfEvent_t routeCancel = (CSTARouteRegisterCancelConfEvent_t)cstaEvent.Event.cstaConfirmation.u.routeCancel;

                                        consoleLogger.Info(string.Format("onTSAPIEvent.CSTA_ROUTE_REGISTER_CANCEL_CONF: routeRegisterReqID={0};", routeCancel.routeRegisterReqID));
                                    }
                                }

                                break;

                                #endregion CSTA_ROUTE_REGISTER_CANCEL_CONF

                            case Constants.CSTA_ESCAPE_SVC_CONF:

                                #region CSTA_ESCAPE_SVC_CONF

                                {
                                    consoleLogger.Info("onTSAPIEvent eventType=CSTA_ESCAPE_SVC_CONF");

                                    if (cstaEvent.Event.cstaConfirmation.u.escapeService != null)
                                    {
                                        if (tsapiEvent.attEvent != null)
                                        {
                                            if (tsapiEvent.attEvent.eventType == TSAPIClient.ATT.Constants.ATT_QUERY_ACD_SPLIT_CONF)
                                            {
                                                consoleLogger.Info("onTSAPIEvent attEventType=ATT_QUERY_ACD_SPLIT_CONF");

                                                if (tsapiEvent.attEvent.u.queryAcdSplit != null)
                                                {
                                                    ATTQueryAcdSplitConfEvent_t queryAcdSplit = (ATTQueryAcdSplitConfEvent_t)tsapiEvent.attEvent.u.queryAcdSplit;

                                                    consoleLogger.Info(string.Format("onTSAPIEvent.ATT_QUERY_ACD_SPLIT_CONF: agentsLoggedIn={0};", queryAcdSplit.agentsLoggedIn));
                                                }
                                            }
                                            else if (tsapiEvent.attEvent.eventType == TSAPIClient.ATT.Constants.ATT_QUERY_UCID_CONF)
                                            {
                                                consoleLogger.Info("onTSAPIEvent attEventType=ATT_QUERY_UCID_CONF");

                                                if (tsapiEvent.attEvent.u.queryUCID != null)
                                                {
                                                    ATTQueryUcidConfEvent_t queryUCID = (ATTQueryUcidConfEvent_t)tsapiEvent.attEvent.u.queryUCID;

                                                    consoleLogger.Info(string.Format("onTSAPIEvent.ATT_QUERY_UCID_CONF: ucid={0};", queryUCID.ucid.value));
                                                }
                                            }
                                            else if (tsapiEvent.attEvent.eventType == TSAPIClient.ATT.Constants.ATT_SINGLE_STEP_TRANSFER_CALL_CONF)
                                            {
                                                consoleLogger.Info("onTSAPIEvent attEventType=ATT_SINGLE_STEP_TRANSFER_CALL_CONF");

                                                if (tsapiEvent.attEvent.u.ssTransferCallConf != null)
                                                {
                                                    ATTSingleStepTransferCallConfEvent_t ssTransferCallConf = (ATTSingleStepTransferCallConfEvent_t)tsapiEvent.attEvent.u.ssTransferCallConf;

                                                    consoleLogger.Info(string.Format("onTSAPIEvent.ATT_SINGLE_STEP_TRANSFER_CALL_CONF: ucid={0};transferredCall.callID={1};transferredCall.deviceID={2};", ssTransferCallConf.ucid.value, ssTransferCallConf.transferredCall.callID, ssTransferCallConf.transferredCall.deviceID.device));
                                                }
                                            }
                                        }
                                    }
                                }

                                break;

                                #endregion CSTA_ESCAPE_SVC_CONF

                            case Constants.CSTA_SYS_STAT_REQ_CONF:

                                #region CSTA_SYS_STAT_REQ_CONF

                                {
                                    if (cstaEvent.Event.cstaConfirmation.u.sysStatReq != null)
                                    {
                                        CSTASysStatReqConfEvent_t sysStatReq = (CSTASysStatReqConfEvent_t)cstaEvent.Event.cstaConfirmation.u.sysStatReq;

                                        consoleLogger.Info(string.Format("onTSAPIEvent.CSTA_SYS_STAT_REQ_CONF: systemStatus={0};", sysStatReq.systemStatus));
                                    }
                                }

                                break;

                                #endregion CSTA_SYS_STAT_REQ_CONF

                            case Constants.CSTA_SYS_STAT_START_CONF:

                                #region CSTA_SYS_STAT_START_CONF

                                {
                                    if (cstaEvent.Event.cstaConfirmation.u.sysStatStart != null)
                                    {
                                        CSTASysStatStartConfEvent_t sysStatStart = (CSTASysStatStartConfEvent_t)cstaEvent.Event.cstaConfirmation.u.sysStatStart;

                                        consoleLogger.Info(string.Format("onTSAPIEvent.CSTA_SYS_STAT_START_CONF: statusFilter={0};", sysStatStart.statusFilter));
                                    }
                                }

                                break;

                                #endregion CSTA_SYS_STAT_START_CONF

                            case Constants.CSTA_SYS_STAT_STOP_CONF:

                                #region CSTA_SYS_STAT_STOP_CONF

                                {
                                    if (cstaEvent.Event.cstaConfirmation.u.sysStatStop != null)
                                    {
                                        CSTASysStatStopConfEvent_t sysStatStop = (CSTASysStatStopConfEvent_t)cstaEvent.Event.cstaConfirmation.u.sysStatStop;

                                        consoleLogger.Info(string.Format("onTSAPIEvent.CSTA_SYS_STAT_STOP_CONF: sysStatStop={0};", sysStatStop));
                                    }
                                }

                                break;

                                #endregion CSTA_SYS_STAT_STOP_CONF

                            case Constants.CSTA_CHANGE_SYS_STAT_FILTER_CONF:

                                #region CSTA_CHANGE_SYS_STAT_FILTER_CONF

                                {
                                    if (cstaEvent.Event.cstaConfirmation.u.changeSysStatFilter != null)
                                    {
                                        CSTAChangeSysStatFilterConfEvent_t changeSysStatFilter = (CSTAChangeSysStatFilterConfEvent_t)cstaEvent.Event.cstaConfirmation.u.changeSysStatFilter;

                                        consoleLogger.Info(string.Format("onTSAPIEvent.CSTA_CHANGE_SYS_STAT_FILTER_CONF: statusFilterActive={0};", changeSysStatFilter.statusFilterActive));
                                    }
                                }

                                break;

                                #endregion CSTA_CHANGE_SYS_STAT_FILTER_CONF

                            case Constants.CSTA_GETAPI_CAPS_CONF:

                                #region CSTA_GETAPI_CAPS_CONF

                                {
                                    if (cstaEvent.Event.cstaConfirmation.u.getAPICaps != null)
                                    {
                                        CSTAGetAPICapsConfEvent_t getAPICaps = (CSTAGetAPICapsConfEvent_t)cstaEvent.Event.cstaConfirmation.u.getAPICaps;

                                        consoleLogger.Info(string.Format("onTSAPIEvent.CSTA_GETAPI_CAPS_CONF: queryDeviceInfo={0};", getAPICaps.queryDeviceInfo));
                                    }
                                }

                                break;

                                #endregion CSTA_GETAPI_CAPS_CONF

                            case Constants.CSTA_GET_DEVICE_LIST_CONF:

                                #region CSTA_GET_DEVICE_LIST_CONF

                                {
                                    if (cstaEvent.Event.cstaConfirmation.u.getDeviceList != null)
                                    {
                                        CSTAGetDeviceListConfEvent_t getDeviceList = (CSTAGetDeviceListConfEvent_t)cstaEvent.Event.cstaConfirmation.u.getDeviceList;

                                        consoleLogger.Info(string.Format("onTSAPIEvent NumberOfDevices=" + getDeviceList.devList.count.ToString() + ";Index=" + getDeviceList.index.ToString()));

                                    }
                                }

                                break;

                                #endregion CSTA_GET_DEVICE_LIST_CONF

                            case Constants.CSTA_QUERY_CALL_MONITOR_CONF:

                                #region CSTA_QUERY_CALL_MONITOR_CONF

                                {
                                    if (cstaEvent.Event.cstaConfirmation.u.queryCallMonitor != null)
                                    {
                                        CSTAQueryCallMonitorConfEvent_t queryCallMonitor = (CSTAQueryCallMonitorConfEvent_t)cstaEvent.Event.cstaConfirmation.u.queryCallMonitor;
                                    }
                                }

                                break;

                                #endregion CSTA_QUERY_CALL_MONITOR_CONF

                            default:

                                break;
                        }

                        #endregion CSTACONFIRMATION

                        break;

                    case Constants.CSTAUNSOLICITED:

                        #region CSTAUNSOLICITED

                        consoleLogger.Info("onTSAPIEvent eventClass=CSTAUNSOLICITED");

                        int xref = cstaEvent.Event.cstaUnsolicited.monitorCrossRefId;

                        consoleLogger.Info(string.Format("onTSAPIEvent monitorCrossRefId={0}", xref));

                        switch (cstaEvent.eventHeader.eventType)
                        {
                            case Constants.CSTA_CALL_CLEARED:

                                #region CSTA_CALL_CLEARED

                                {
                                    consoleLogger.Info(string.Format("onTSAPIEvent.CSTA_CALL_CLEARED: eventType=CSTA_CALL_CLEARED"));

                                    if (cstaEvent.Event.cstaUnsolicited.u.callCleared != null)
                                    {
                                        CSTACallClearedEvent_t callCleared = (CSTACallClearedEvent_t)cstaEvent.Event.cstaUnsolicited.u.callCleared;

                                        string reason = string.Empty;

                                        if (attEvent != null)
                                        {
                                            if (attEvent.eventType == TSAPIClient.ATT.Constants.ATT_CALL_CLEARED)
                                            {
                                                if (attEvent.u.callClearedEvent != null)
                                                {
                                                    ATTCallClearedEvent_t callClearedEvent = (ATTCallClearedEvent_t)attEvent.u.callClearedEvent;

                                                    reason = callClearedEvent.reason.ToString();
                                                }
                                            }
                                        }


                                        StringBuilder bldr = new StringBuilder();

                                        bldr.Append("onTSAPIEvent.CSTA_CALL_CLEARED: ");
                                        bldr.AppendFormat("clearedCall.callID={0};", callCleared.clearedCall.callID);
                                        bldr.AppendFormat("clearedCall.deviceID={0};", callCleared.clearedCall.deviceID.device);
                                        bldr.AppendFormat("clearedCall.devIDType={0};", callCleared.clearedCall.devIDType);
                                        bldr.AppendFormat("localConnectionInfo={0};", callCleared.localConnectionInfo);
                                        bldr.AppendFormat("cause={0};", callCleared.cause);
                                        bldr.AppendFormat("reason={0};", reason);

                                        consoleLogger.Info(string.Format(bldr.ToString()));
                                    }
                                }

                                break;

                                #endregion CSTA_CALL_CLEARED

                            case Constants.CSTA_CONFERENCED:

                                #region CSTA_CONFERENCED

                                {
                                    consoleLogger.Info("onTSAPIEvent eventType=CSTA_CONFERENCED");

                                    if (cstaEvent.Event.cstaUnsolicited.u.conferenced != null)
                                    {
                                        CSTAConferencedEvent_t conferenced = (CSTAConferencedEvent_t)cstaEvent.Event.cstaUnsolicited.u.conferenced;

                                        /*
                                        secondaryOldCall: this is a callID of the call that was conferenced.
                                        This is usually the ACTIVE call before the conference. This call was
                                        retained by the switch after the conference
                                        */
                                        int secondaryCallID = conferenced.secondaryOldCall.callID;

                                        /*
                                        primaryOldCall: this is a callID of the call that was conferenced.
                                        This is usually the HELD call before the conference. This call
                                        is by the switch after the conference
                                        */
                                        int primaryCallID = conferenced.primaryOldCall.callID;
                                        string device = conferenced.confController.deviceID.device;

                                    }
                                }

                                break;

                                #endregion CSTA_CONFERENCED

                            case Constants.CSTA_CONNECTION_CLEARED:

                                #region CSTA_CONNECTION_CLEARED

                                {
                                    consoleLogger.Info("onTSAPIEvent eventType=CSTA_CONNECTION_CLEARED");

                                    if (cstaEvent.Event.cstaUnsolicited.u.connectionCleared != null)
                                    {
                                        CSTAConnectionClearedEvent_t connectionCleared = (CSTAConnectionClearedEvent_t)cstaEvent.Event.cstaUnsolicited.u.connectionCleared;
                                        ATTConnectionClearedEvent_t attConnectionCleared = (ATTConnectionClearedEvent_t)attEvent.u.connectionCleared; 
                                        int callID = connectionCleared.droppedConnection.callID;
                                        string clearedExt = connectionCleared.droppedConnection.deviceID.device;
                                        string termExt = connectionCleared.releasingDevice.deviceID.device;
                                        if (connectionCleared.cause == CSTAEventCause_t.EC_NONE)
                                        {
                                            SetCallStatusToCleared(callID, clearedExt);
                                        }
                                        else
                                        {
                                            string cause = connectionCleared.cause.ToString();
                                            SetCallStatusToCleared(callID, clearedExt,true, cause);
                                        }
                                        //UpdateCallToCleared(callID, connectionCleared.droppedConnection.deviceID.device);
                                    }
                                }

                                break;

                                #endregion CSTA_CONNECTION_CLEARED

                            case Constants.CSTA_DELIVERED:

                                #region CSTA_DELIVERED

                                {
                                    consoleLogger.Info("onTSAPIEvent eventType=CSTA_DELIVERED");

                                    if (cstaEvent.Event.cstaUnsolicited.u.delivered != null)
                                    {
                                        CSTADeliveredEvent_t delivered = (CSTADeliveredEvent_t)cstaEvent.Event.cstaUnsolicited.u.delivered;
                                        ATTDeliveredEvent_t attDelivered = (ATTDeliveredEvent_t)attEvent.u.deliveredEvent;
                                        
                                        consoleLogger.Info(string.Format("onTSAPIEvent.CSTA_DELIVERED: alertingDevice={0};alertingDeviceType={1};calledDevice={2};calledDeviceType={3};callingDevice={4};callingDeviceType={5};cause={6}", delivered.alertingDevice.deviceID.device, delivered.alertingDevice.deviceIDType, delivered.calledDevice.deviceID.device, delivered.calledDevice.deviceIDType, delivered.callingDevice.deviceID.device, delivered.callingDevice.deviceIDType, delivered.cause));

                                        //if (cstaEvent.Event.cstaUnsolicited.monitorCrossRefId == m_MonitorXRef)
                                        //{
                                        //   m_CallID = delivered.connection.callID;

                                        if (delivered.cause == CSTAEventCause_t.EC_NEW_CALL || delivered.cause == CSTAEventCause_t.EC_REDIRECTED)
                                        {
                                            // Retrieving the information associated with this event
                                            if ((delivered.callingDevice.deviceID.device.Length > 4) && (delivered.calledDevice.deviceID.device.Length > 6))
                                            {
                                                SetCallStatusToDelivered(attDelivered.ucid.value,delivered.connection.callID, delivered.calledDevice.deviceID.device, delivered.callingDevice.deviceID.device);
                                            }

                                        }
                                        //}
                                    }
                                }

                                break;

                                #endregion CSTA_DELIVERED

                            case Constants.CSTA_DIVERTED:

                                #region CSTA_DIVERTED

                                {
                                    consoleLogger.Info("onTSAPIEvent eventType=CSTA_DIVERTED");

                                    if (cstaEvent.Event.cstaUnsolicited.u.diverted != null)
                                    {
                                        CSTADivertedEvent_t diverted = (CSTADivertedEvent_t)cstaEvent.Event.cstaUnsolicited.u.diverted;
                                        int callID = diverted.connection.callID;
                                        string device = diverted.connection.deviceID.device;

                                        consoleLogger.Info(string.Format("callID={0};device={1};", callID, device));
                                    }
                                }

                                break;

                                #endregion CSTA_DIVERTED

                            case Constants.CSTA_ESTABLISHED:

                                #region CSTA_ESTABLISHED

                                {
                                    consoleLogger.Info("onTSAPIEvent eventType=CSTA_ESTABLISHED");

                                    if (cstaEvent.Event.cstaUnsolicited.u.established != null)
                                    {
                                        CSTAEstablishedEvent_t established = (CSTAEstablishedEvent_t)cstaEvent.Event.cstaUnsolicited.u.established;
                                        ATTEstablishedEvent_t attEstablished = (ATTEstablishedEvent_t)attEvent.u.establishedEvent;
                                        
                                        //consoleLogger.Info(string.Format("onTSAPIEvent.CSTA_ESTABLISHED: answeringDevice={0};answeringDeviceType={1};calledDevice={2};calledDeviceType={3};callingDevice={4};callingDeviceType={5};cause={6}",
                                        //    established.answeringDevice.deviceID.device, established.answeringDevice.deviceIDType, established.calledDevice.deviceID.device, established.calledDevice.deviceIDType, established.callingDevice.deviceID.device, established.callingDevice.deviceIDType, established.cause));
                                        //UpdateCallToEstablished(established.establishedConnection.callID, established.callingDevice.deviceID.device, established.answeringDevice.deviceID.device);
                                        SetCallStatusToEstablished(attEstablished.ucid.value, established.establishedConnection.callID, established.callingDevice.deviceID.device);
                                    }
                                }

                                break;

                                #endregion CSTA_ESTABLISHED

                            case Constants.CSTA_FAILED:

                                #region CSTA_FAILED

                                {
                                    consoleLogger.Info("onTSAPIEvent eventType=CSTA_FAILED");

                                    if (cstaEvent.Event.cstaUnsolicited.u.failed != null)
                                    {
                                        CSTAFailedEvent_t failed = (CSTAFailedEvent_t)cstaEvent.Event.cstaUnsolicited.u.failed;

                                        int callID = failed.failedConnection.callID;
                                        string failedDevice = failed.failedConnection.deviceID.device;
                                        string calledDevice = failed.calledDevice.deviceID.device;
                                        string cause = failed.cause.ToString();
                                        SetCallStatusToFailed(callID, calledDevice, failedDevice, cause);
                                        consoleLogger.Info(string.Format("onTSAPIEvent.CSTA_FAILED: callID={0};deviceID={1};", callID, calledDevice));
                                    }
                                }

                                break;

                                #endregion CSTA_FAILED

                            case Constants.CSTA_HELD:

                                #region CSTA_HELD

                                {
                                    consoleLogger.Info("onTSAPIEvent eventType=CSTA_HELD");

                                    if (cstaEvent.Event.cstaUnsolicited.u.held != null)
                                    {
                                        CSTAHeldEvent_t held = (CSTAHeldEvent_t)cstaEvent.Event.cstaUnsolicited.u.held;
                                        int callID = held.heldConnection.callID;
                                        string device = held.heldConnection.deviceID.device;
                                        string holdingDevice = held.holdingDevice.deviceID.device;
                                        if (attEvent != null)
                                        {
                                            if (attEvent.eventType == TSAPIClient.ATT.Constants.ATT_HELD)
                                            {
                                                if (attEvent.u.heldEvent != null)
                                                {
                                                    ATTHeldEvent_t heldEvent = (ATTHeldEvent_t)attEvent.u.heldEvent;
                                                    // heldEvent.consultMode
                                                    consoleLogger.Info(string.Format("onTSAPIEvent.CSTA_HELD: heldEvent:consult Mode = {0} ", heldEvent.consultMode.ToString()));
                                                    if (heldEvent.consultMode == ATTConsultMode_t.ATT_CM_TRANSFER)
                                                        SetCallStatusToCleared(callID, device);
                                                }
                                            }
                                        }

                                        consoleLogger.Info(string.Format("onTSAPIEvent.CSTA_HELD: callID={0};device={1};HoldingDevice={2};cause={3}", callID, device, holdingDevice, held.cause.ToString()));


                                    }
                                }

                                break;

                                #endregion CSTA_HELD

                            case Constants.CSTA_NETWORK_REACHED:

                                #region CSTA_NETWORK_REACHED

                                {
                                    consoleLogger.Info("onTSAPIEvent eventType=CSTA_NETWORK_REACHED");

                                    if (cstaEvent.Event.cstaUnsolicited.u.networkReached != null)
                                    {
                                        CSTANetworkReachedEvent_t networkReached = (CSTANetworkReachedEvent_t)cstaEvent.Event.cstaUnsolicited.u.networkReached;

                                        int callID = networkReached.connection.callID;
                                        string device = networkReached.connection.deviceID.device;

                                        consoleLogger.Info(string.Format("onTSAPIEvent callID={0};deviceID={1};", callID, device));
                                    }

                                }

                                break;

                                #endregion CSTA_NETWORK_REACHED

                            case Constants.CSTA_ORIGINATED:

                                #region CSTA_ORIGINATED

                                {
                                    consoleLogger.Info("onTSAPIEvent eventType=CSTA_ORIGINATED");

                                    if (cstaEvent.Event.cstaUnsolicited.u.originated != null)
                                    {
                                        CSTAOriginatedEvent_t originated = (CSTAOriginatedEvent_t)cstaEvent.Event.cstaUnsolicited.u.originated;

                                        int callID = originated.originatedConnection.callID;
                                        string device = originated.originatedConnection.deviceID.device;
                                        string callingDevice = originated.callingDevice.deviceID.device;
                                        string calledDevice = originated.calledDevice.deviceID.device;

                                        consoleLogger.Info(string.Format("onTSAPIEvent.CSTA_ORIGINATED: callID={0};deviceID={1};callingDevice={2};calledDevice={3};", callID, device, callingDevice, calledDevice));

                                        if (attEvent != null)
                                        {
                                            if (attEvent.eventType == TSAPIClient.ATT.Constants.ATT_ORIGINATED)
                                            {
                                                if (attEvent.u.originatedEvent != null)
                                                {
                                                    ATTOriginatedEvent_t originatedEvent = (ATTOriginatedEvent_t)attEvent.u.originatedEvent;
                                                    consoleLogger.Info(string.Format("onTSAPIEvent.ATT_ORIGINATED: consultMode={0};", originatedEvent.consultMode));
                                                }
                                            }
                                        }
                                    }
                                }

                                break;

                                #endregion CSTA_ORIGINATED

                            case Constants.CSTA_QUEUED:

                                #region CSTA_QUEUED

                                {
                                    consoleLogger.Info("onTSAPIEvent eventType=CSTA_QUEUED");

                                    if (cstaEvent.Event.cstaUnsolicited.u.queued != null)
                                    {
                                        CSTAQueuedEvent_t queued = (CSTAQueuedEvent_t)cstaEvent.Event.cstaUnsolicited.u.queued;

                                        int callID = queued.queuedConnection.callID;
                                        string device = queued.queuedConnection.deviceID.device;

                                        consoleLogger.Info(string.Format("onTSAPIEvent.CSTA_QUEUED: callID={0};deviceID={1};", callID, device));
                                    }
                                }

                                break;

                                #endregion CSTA_QUEUED

                            case Constants.CSTA_RETRIEVED:

                                #region CSTA_RETRIEVED

                                {
                                    consoleLogger.Info("onTSAPIEvent eventType=CSTA_RETRIEVED");

                                    if (cstaEvent.Event.cstaUnsolicited.u.retrieved != null)
                                    {
                                        CSTARetrievedEvent_t retrieved = (CSTARetrievedEvent_t)cstaEvent.Event.cstaUnsolicited.u.retrieved;

                                        int callID = retrieved.retrievedConnection.callID;
                                        string device = retrieved.retrievingDevice.deviceID.device; //this is also the Retreiving Extension(RETRVEXT) and Original Called Device(ORIGCALLEDDEV)                                        

                                        consoleLogger.Info(string.Format("onTSAPIEvent callID={0};deviceID={1};", callID, device));
                                    }
                                }

                                break;

                                #endregion CSTA_RETRIEVED

                            case Constants.CSTA_SERVICE_INITIATED:

                                #region CSTA_SERVICE_INITIATED

                                {
                                    consoleLogger.Info("onTSAPIEvent eventType=CSTA_SERVICE_INITIATED");

                                    if (cstaEvent.Event.cstaUnsolicited.u.serviceInitiated != null)
                                    {
                                        CSTAServiceInitiatedEvent_t serviceInitiated = (CSTAServiceInitiatedEvent_t)cstaEvent.Event.cstaUnsolicited.u.serviceInitiated;

                                        int callID = serviceInitiated.initiatedConnection.callID;
                                        string device = serviceInitiated.initiatedConnection.deviceID.device;
                                        string ucid = string.Empty;

                                        if (attEvent != null)
                                        {
                                            if (attEvent.eventType == TSAPIClient.ATT.Constants.ATT_SERVICE_INITIATED)
                                            {
                                                if (attEvent.u.serviceInitiated != null)
                                                {
                                                    ATTServiceInitiatedEvent_t attServiceInitiated = (ATTServiceInitiatedEvent_t)attEvent.u.serviceInitiated;

                                                    ucid = attServiceInitiated.ucid.value ?? string.Empty;
                                                }
                                            }
                                        }

                                        consoleLogger.Info(string.Format("onTSAPIEvent.CSTA_SERVICE_INITIATED: callID={0};deviceID={1};ucid={2};", callID, device, ucid));
                                    }
                                }

                                break;

                                #endregion CSTA_SERVICE_INITIATED

                            case Constants.CSTA_TRANSFERRED:

                                #region CSTA_TRANSFERRED

                                {
                                    consoleLogger.Info("onTSAPIEvent eventType=CSTA_TRANSFERRED");

                                    if (cstaEvent.Event.cstaUnsolicited.u.transferred != null)
                                    {
                                        CSTATransferredEvent_t transferred = (CSTATransferredEvent_t)cstaEvent.Event.cstaUnsolicited.u.transferred;

                                        consoleLogger.Info(string.Format("onTSAPIEvent.CSTA_TRANSFERRED: callID={0};", transferred.primaryOldCall.callID));

                                        if (attEvent != null)
                                        {
                                            if (attEvent.eventType == TSAPIClient.ATT.Constants.ATT_TRANSFERRED)
                                            {
                                                if (attEvent.u.transferredEvent != null)
                                                {
                                                    ATTTransferredEvent_t transferredEvent = (ATTTransferredEvent_t)attEvent.u.transferredEvent;

                                                    consoleLogger.Info(string.Format("onTSAPIEvent.ATT_TRANSFERRED: transferredEvent.ucid={0};transferredEvent.originalCallInfo.calledDevice={1};transferredEvent.originalCallInfo.callingDevice={2};transferredEvent.originalCallInfo.ucid={3};transferredEvent.distributingDevice={4};transferredEvent.distributingVDN.value={5};;transferredEvent.transferringDevice={6};transferredEvent.transferredDevice.value={7};", transferredEvent.ucid.value, transferredEvent.originalCallInfo.calledDevice.value.deviceID.device, transferredEvent.originalCallInfo.callingDevice.value.deviceID.device, transferredEvent.originalCallInfo.ucid.value, transferredEvent.distributingDevice.value.deviceID.device, transferredEvent.distributingVDN.value.deviceID.device, transferred.transferringDevice.deviceID.device, transferred.transferredDevice.deviceID.device));

                                                    //if (transferred.cause == CSTAEventCause_t.EC_NONE)
                                                    //{
                                                    //    // Retrieving the information associated with this event
                                                    //    if (transferred.transferringDevice.deviceID.device.Length > 4 && transferredEvent.originalCallInfo.callingDevice.value.deviceID.device.Length > 6)
                                                    //    {
                                                    //        InsertTransferCall(transferredEvent.ucid.value, transferred.secondaryOldCall.callID, transferredEvent.originalCallInfo.callingDevice.value.deviceID.device, transferred.transferringDevice.deviceID.device, transferredEvent.originalCallInfo.userEnteredCode.data);
                                                    //    }

                                                    //}
                                                }
                                            }
                                        }
                                    }
                                }

                                break;

                                #endregion CSTA_TRANSFERRED

                            case Constants.CSTA_CALL_INFORMATION:

                                #region CSTA_CALL_INFORMATION

                                {
                                    consoleLogger.Info("onTSAPIEvent eventType=CSTA_CALL_INFORMATION");

                                    if (cstaEvent.Event.cstaUnsolicited.u.callInformation != null)
                                    {
                                        CSTACallInformationEvent_t callInformation = (CSTACallInformationEvent_t)cstaEvent.Event.cstaUnsolicited.u.callInformation;

                                        int callID = callInformation.connection.callID;
                                        string device = callInformation.connection.deviceID.device;

                                        consoleLogger.Info(string.Format("onTSAPIEvent.CSTA_CALL_INFORMATION: callID={0};deviceID={1};", callID, device));
                                    }
                                }

                                break;

                                #endregion CSTA_CALL_INFORMATION

                            case Constants.CSTA_DO_NOT_DISTURB:

                                #region CSTA_DO_NOT_DISTURB

                                {
                                    consoleLogger.Info(string.Format("onTSAPIEvent eventType=CSTA_DO_NOT_DISTURB"));

                                    if (cstaEvent.Event.cstaUnsolicited.u.doNotDisturb != null)
                                    {
                                        CSTADoNotDisturbEvent_t doNotDisturb = (CSTADoNotDisturbEvent_t)cstaEvent.Event.cstaUnsolicited.u.doNotDisturb;
                                        string device = doNotDisturb.device.deviceID.device;
                                        bool doNotDisturbOn = doNotDisturb.doNotDisturbOn;

                                        consoleLogger.Info(string.Format("onTSAPIEvent.CSTA_DO_NOT_DISTURB: deviceID={0};doNotDisturbOn={1};", device, doNotDisturbOn));
                                    }
                                }

                                break;

                                #endregion CSTA_DO_NOT_DISTURB

                            case Constants.CSTA_FORWARDING:

                                #region CSTA_FORWARDING

                                {
                                    consoleLogger.Info("onTSAPIEvent eventType=CSTA_FORWARDING");

                                    if (cstaEvent.Event.cstaUnsolicited.u.forwarding != null)
                                    {
                                        CSTAForwardingEvent_t forwarding = (CSTAForwardingEvent_t)cstaEvent.Event.cstaUnsolicited.u.forwarding;

                                        consoleLogger.Info(string.Format("onTSAPIEvent.CSTA_FORWARDING: deviceID={0};forwardDN={1};", forwarding.device.deviceID, forwarding.forwardingInformation.forwardDN));
                                    }
                                }

                                break;

                                #endregion CSTA_FORWARDING

                            case Constants.CSTA_MESSAGE_WAITING:

                                #region CSTA_MESSAGE_WAITING

                                {
                                    if (cstaEvent.Event.cstaUnsolicited.u.messageWaiting != null)
                                    {
                                        CSTAMessageWaitingEvent_t messageWaiting = (CSTAMessageWaitingEvent_t)cstaEvent.Event.cstaUnsolicited.u.messageWaiting;

                                        consoleLogger.Info(string.Format("onTSAPIEvent.CSTA_MESSAGE_WAITING: deviceID={0};messageWaitingOn={1};", messageWaiting.deviceForMessage.deviceID, messageWaiting.messageWaitingOn));
                                    }
                                }

                                break;

                                #endregion CSTA_MESSAGE_WAITING

                            case Constants.CSTA_LOGGED_ON:

                                #region CSTA_LOGGED_ON

                                {
                                    consoleLogger.Info("onTSAPIEvent eventType=CSTA_LOGGED_ON");

                                    if (cstaEvent.Event.cstaUnsolicited.u.loggedOn != null)
                                    {
                                        CSTALoggedOnEvent_t loggedOn = (CSTALoggedOnEvent_t)cstaEvent.Event.cstaUnsolicited.u.loggedOn;

                                        string device = loggedOn.agentDevice.deviceID.device;
                                        string agentID = loggedOn.agentID.agent;

                                        consoleLogger.Info(string.Format("onTSAPIEvent.CSTA_LOGGED_ON: agentID={0};deviceID={1};", agentID, device));
                                    }
                                }

                                break;

                                #endregion CSTA_LOGGED_ON

                            case Constants.CSTA_LOGGED_OFF:

                                #region CSTA_LOGGED_OFF

                                {
                                    consoleLogger.Info("onTSAPIEvent eventType=CSTA_LOGGED_OFF");

                                    if (cstaEvent.Event.cstaUnsolicited.u.loggedOff != null)
                                    {
                                        CSTALoggedOffEvent_t loggedOff = (CSTALoggedOffEvent_t)cstaEvent.Event.cstaUnsolicited.u.loggedOff;

                                        string device = loggedOff.agentDevice.deviceID.device;
                                        string agentID = loggedOff.agentID.agent;

                                        consoleLogger.Info(string.Format("onTSAPIEvent.CSTA_LOGGED_OFF: agentID={0};deviceID={1};", agentID, device));
                                    }
                                }

                                break;

                                #endregion CSTA_LOGGED_OFF

                            case Constants.CSTA_NOT_READY:

                                #region CSTA_NOT_READY

                                {
                                    consoleLogger.Info("onTSAPIEvent eventType=CSTA_NOT_READY");

                                    if (cstaEvent.Event.cstaUnsolicited.u.notReady != null)
                                    {
                                        CSTANotReadyEvent_t notReady = (CSTANotReadyEvent_t)cstaEvent.Event.cstaUnsolicited.u.notReady;

                                        string device = notReady.agentDevice.deviceID.device;
                                        string agentID = notReady.agentID.agent;

                                        consoleLogger.Info(string.Format("onTSAPIEvent.CSTA_NOT_READY: agentID={0};deviceID={1};", agentID, device));
                                    }
                                }

                                break;

                                #endregion CSTA_NOT_READY

                            case Constants.CSTA_READY:

                                #region CSTA_READY

                                consoleLogger.Info("onTSAPIEvent.CSTA_NOT_READY: eventType=CSTA_READY");
                                {
                                    if (cstaEvent.Event.cstaUnsolicited.u.ready != null)
                                    {
                                        CSTAReadyEvent_t ready = (CSTAReadyEvent_t)cstaEvent.Event.cstaUnsolicited.u.ready;

                                        string device = ready.agentDevice.deviceID.device;
                                        string agentID = ready.agentID.agent;

                                        consoleLogger.Info(string.Format("onTSAPIEvent.CSTA_NOT_READY: agentID={0};deviceID={1};", agentID, device));
                                    }
                                }

                                break;

                                #endregion CSTA_READY

                            case Constants.CSTA_WORK_NOT_READY:

                                #region CSTA_WORK_NOT_READY

                                consoleLogger.Info("onTSAPIEvent.CSTA_WORK_NOT_READY: eventType=CSTA_WORK_NOT_READY");
                                {
                                    if (cstaEvent.Event.cstaUnsolicited.u.workNotReady != null)
                                    {
                                        CSTAWorkNotReadyEvent_t workNotReady = (CSTAWorkNotReadyEvent_t)cstaEvent.Event.cstaUnsolicited.u.workNotReady;

                                        string agentID = workNotReady.agentID.agent;
                                        string device = workNotReady.agentDevice.deviceID.device;

                                        consoleLogger.Info(string.Format("onTSAPIEvent.CSTA_WORK_NOT_READY: agentID={0};deviceID={1};", agentID, device));
                                    }
                                }

                                break;

                                #endregion CSTA_WORK_NOT_READY

                            case Constants.CSTA_WORK_READY:

                                #region CSTA_WORK_READY

                                consoleLogger.Info("onTSAPIEvent eventType=CSTA_WORK_READY");
                                {
                                    if (cstaEvent.Event.cstaUnsolicited.u.workReady != null)
                                    {
                                        CSTAWorkReadyEvent_t workReady = (CSTAWorkReadyEvent_t)cstaEvent.Event.cstaUnsolicited.u.workReady;

                                        string agentID = workReady.agentID.agent;
                                        string device = workReady.agentDevice.deviceID.device;

                                        consoleLogger.Info("onTSAPIEvent.CSTA_WORK_READY: agentID={0};deviceID={1};", agentID, device);
                                    }
                                }

                                break;

                                #endregion CSTA_WORK_READY

                            case Constants.CSTA_BACK_IN_SERVICE:

                                #region CSTA_BACK_IN_SERVICE

                                {
                                    if (cstaEvent.Event.cstaUnsolicited.u.backInService != null)
                                    {
                                        CSTABackInServiceEvent_t backInService = (CSTABackInServiceEvent_t)cstaEvent.Event.cstaUnsolicited.u.backInService;
                                    }
                                }

                                break;

                                #endregion CSTA_BACK_IN_SERVICE

                            case Constants.CSTA_OUT_OF_SERVICE:

                                #region CSTA_OUT_OF_SERVICE

                                {
                                    if (cstaEvent.Event.cstaUnsolicited.u.outOfService != null)
                                    {
                                        CSTAOutOfServiceEvent_t outOfService = (CSTAOutOfServiceEvent_t)cstaEvent.Event.cstaUnsolicited.u.outOfService;
                                    }
                                }

                                break;

                                #endregion CSTA_OUT_OF_SERVICE

                            case Constants.CSTA_PRIVATE_STATUS:

                                #region CSTA_PRIVATE_STATUS

                                {
                                    if (cstaEvent.Event.cstaUnsolicited.u.privateStatus != null)
                                    {
                                        CSTAPrivateStatusEvent_t privateStatus = (CSTAPrivateStatusEvent_t)cstaEvent.Event.cstaUnsolicited.u.privateStatus;
                                    }
                                }

                                break;

                                #endregion CSTA_PRIVATE_STATUS

                            case Constants.CSTA_MONITOR_ENDED:

                                #region CSTA_MONITOR_ENDED

                                {
                                    consoleLogger.Info("onTSAPIEvent eventType=CSTA_MONITOR_ENDED");

                                    if (cstaEvent.Event.cstaUnsolicited.u.monitorEnded != null)
                                    {
                                        CSTAMonitorEndedEvent_t monitorEnded = (CSTAMonitorEndedEvent_t)cstaEvent.Event.cstaUnsolicited.u.monitorEnded;

                                        consoleLogger.Info("onTSAPIEvent.CSTA_MONITOR_ENDED: xref={0};cause={1};", xref, monitorEnded.cause);
                                    }

                                }

                                break;

                                #endregion CSTA_MONITOR_ENDED
                        }

                        #endregion CSTAUNSOLICITED

                        break;

                    case Constants.ACSCONFIRMATION:

                        #region ACSCONFIRMATION

                        consoleLogger.Info("onTSAPIEvent eventClass=ACSCONFIRMATION");

                        switch (cstaEvent.eventHeader.eventType)
                        {
                            case Constants.ACS_OPEN_STREAM_CONF:

                                #region ACS_OPEN_STREAM_CONF

                                {
                                    ACSOpenStreamConfEvent_t acsopen = (ACSOpenStreamConfEvent_t)cstaEvent.Event.acsConfirmation.u.acsopen;
                                }

                                break;

                                #endregion ACS_OPEN_STREAM_CONF

                            case Constants.ACS_CLOSE_STREAM_CONF:

                                #region ACS_CLOSE_STREAM_CONF

                                {
                                    ACSCloseStreamConfEvent_t acsclose = (ACSCloseStreamConfEvent_t)cstaEvent.Event.acsConfirmation.u.acsclose;
                                }

                                break;

                                #endregion ACS_CLOSE_STREAM_CONF

                            case Constants.ACS_SET_HEARTBEAT_INTERVAL_CONF:

                                #region ACS_SET_HEARTBEAT_INTERVAL_CONF

                                {
                                    ACSSetHeartbeatIntervalConfEvent_t acssetheartbeatinterval = (ACSSetHeartbeatIntervalConfEvent_t)cstaEvent.Event.acsConfirmation.u.acssetheartbeatinterval;
                                }

                                break;

                                #endregion ACS_SET_HEARTBEAT_INTERVAL_CONF

                            case Constants.ACS_UNIVERSAL_FAILURE_CONF:

                                #region ACS_UNIVERSAL_FAILURE_CONF

                                {
                                    ACSUniversalFailureConfEvent_t failureEvent = (ACSUniversalFailureConfEvent_t)cstaEvent.Event.acsConfirmation.u.failureEvent;
                                }

                                break;

                                #endregion ACS_UNIVERSAL_FAILURE_CONF

                            default:

                                break;
                        }

                        #endregion ACSCONFIRMATION

                        break;

                    case Constants.ACSUNSOLICITED:

                        #region ACSUNSOLICITED

                        switch (cstaEvent.eventHeader.eventType)
                        {
                            case Constants.ACS_UNIVERSAL_FAILURE:

                                #region ACS_UNIVERSAL_FAILURE

                                {

                                    ACSUniversalFailureEvent_t failureEvent = (ACSUniversalFailureEvent_t)cstaEvent.Event.acsUnsolicited.failureEvent;
                                }

                                break;

                                #endregion ACS_UNIVERSAL_FAILURE
                        }

                        #endregion ACSUNSOLICITED

                        break;
                }
            }
            catch (Exception err)
            {
                consoleLogger.Info("Error in TSAPIFacade.m_Client_CSTAEvent: " + err.ToString());
            }
        }

        private void SetCallStatusToDelivered(string ucid,int callerId, string callerNumber, string extensionNo)
        {
            // Task.Run(() => {
            var activeCall = new TelephonyRepository().UpdateCallToDelivered(ucid,callerId, callerNumber, extensionNo, hostIpAddress);
            if (activeCall != null)
            {
                IHubContext hubContext = GlobalHost.ConnectionManager.GetHubContext<TelephonyHub>();
                hubContext.Clients.User(activeCall.ExtensionNo).deliveredActiveAgentCall(activeCall);
                consoleLogger.Info("Call Delivered for Caller-Id {0} , Caller No {1} , ExtensionNo {2} : ", callerId, callerNumber, extensionNo);
            }
        }

        private void SetCallStatusToEstablished(string ucid, int callerId, string extensionNo)
        {
            //Task.Run(() =>
            //{
            var activeCall = new TelephonyRepository().UpdateCallToEstablished(ucid,callerId, extensionNo, hostIpAddress);
            if (activeCall != null)
            {
                IHubContext hubContext = GlobalHost.ConnectionManager.GetHubContext<TelephonyHub>();
                hubContext.Clients.User(activeCall.ExtensionNo).establishActiveAgentCall(activeCall);
                consoleLogger.Info("Call Established for Caller-Id {0} , ExtensionNo {1} : ", callerId, extensionNo);
            }
            //});

        }

        private void SetCallStatusToCleared(int callerId, string extensionNo,bool isFailed = false,string failureCause = null)
        {
            //Task.Run(() =>
            //{
            var activeCall = new TelephonyRepository().UpdateCallToCleared(callerId, extensionNo, hostIpAddress, isFailed, failureCause);
            if (activeCall != null)
            {
                IHubContext hubContext = GlobalHost.ConnectionManager.GetHubContext<TelephonyHub>();
                hubContext.Clients.User(activeCall.ExtensionNo).clearedActiveAgentCall(activeCall);
                consoleLogger.Info("Call Cleared for Caller-Id {0} , ExtensionNo {1} : ", callerId, extensionNo);
            }
            // });

        }

        private void SetCallStatusToFailed(int callerId, string callerNumber, string extensionNo, string cause)
        {
            //Task.Run(() =>
            //{
            var activeCall = new TelephonyRepository().UpdateCallToFailed(callerId, callerNumber, hostIpAddress, extensionNo, cause);
            if (activeCall != null)
            {
                IHubContext hubContext = GlobalHost.ConnectionManager.GetHubContext<TelephonyHub>();
                hubContext.Clients.User(activeCall.ExtensionNo).failedActiveAgentCall(activeCall);
                consoleLogger.Info("Call Failed for Caller-Id {0} , ExtensionNo {1} : ", callerId, extensionNo);
            }
            //});

        }


    }
}
