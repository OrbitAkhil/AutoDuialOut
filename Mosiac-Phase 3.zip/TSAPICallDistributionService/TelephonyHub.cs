﻿using Microsoft.AspNet.SignalR;
using NLog;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Configuration;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using TSAPICallDistributionService.Classes;
using TSAPIMaster;

namespace TSAPICallDistributionService
{
    public class TelephonyHub : Hub
    {
        Logger outputLogger = LogManager.GetLogger("OutputLogger");
        IHubContext context = GlobalHost.ConnectionManager.GetHubContext<TelephonyHub>();
        private readonly int agentState = Convert.ToInt32(ConfigurationManager.AppSettings["AgentState"]);
        private readonly int workMode = Convert.ToInt32(ConfigurationManager.AppSettings["WorkMode"]);

        public void AddMessage(string name, string message)
        {
            Console.WriteLine("Hub AddMessage {0} {1}\n", name, message);
            Clients.All.addMessage(name, message);
        }

        public void Heartbeat()
        {
            Console.WriteLine("Hub Heartbeat\n");
            Clients.All.heartbeat();
        }

        public void AllocateAgentActiveCall(int extensionNo)
        {
            if (extensionNo <= 0)
                return;

            //BackgroundWorker worker = new BackgroundWorker();
            //worker.WorkerReportsProgress = true;
            //var agentStateCmd = new QueryAgentStateCommand(Simulator.Instance.m_Client, extensionNo.ToString());

            //worker.DoWork += (o, args) =>
            //{
            //    agentStateCmd.QueryAgentState();

            //    worker.ReportProgress(100);
            //};

            //worker.RunWorkerCompleted += (o, args) =>
            //{
            //    if (agentStateCmd.AgentState == (TSAPIClient.CSTA.AgentState_t)agentState && agentStateCmd.WorkMode == (TSAPIClient.ATT.ATTWorkMode_t)workMode && agentStateCmd.TalkState == TSAPIClient.ATT.ATTTalkState_t.TS_IDLE)
            //    {
                    TelephonyRepository telephonyRepository = new TelephonyRepository();
                    var call = telephonyRepository.GetAgentActiveOutgoingCall(extensionNo);

                    if (call == null)
                        return;
                    else if (call.CallStatus == "A")
                        context.Clients.User(call.ExtensionNo.ToString()).showAgentActiveCall(call);
                    else if (call.CallStatus == "D")
                        context.Clients.User(call.ExtensionNo.ToString()).deliveredActiveAgentCall(call);
                    else if (call.CallStatus == "F")
                        context.Clients.User(call.ExtensionNo.ToString()).failedActiveAgentCall(call);
                    else if (call.CallStatus == "E")
                        context.Clients.User(call.ExtensionNo.ToString()).establishActiveAgentCall(call);
                    else if (call.CallStatus == "C")
                        context.Clients.User(call.ExtensionNo.ToString()).clearedActiveAgentCall(call);
                //}
            //};
        }

        //public OutgoingCall GetActiveCall(string extensionNo)
        //{
        //    if (string.IsNullOrEmpty(extensionNo))
        //        return null;
        //    //Create an instance of the Repository class
        //    TelephonyRepository objRepository = new TelephonyRepository();
        //    return objRepository.GetAgentActiveOutgoingCall(Convert.ToInt32(extensionNo));

        //}


        public void ClearCall(int callId, string extensionNo)
        {
            Simulator.Instance.EndCall(callId, extensionNo);
        }

        public void HoldCall(int callId, string extensionNo)
        {
            Simulator.Instance.HoldCall(callId, extensionNo);
        }

        public void AnswerCall(int callId, string extensionNo)
        {
            Simulator.Instance.AnswerCall(callId, extensionNo);
        }

        //public void TransferCall(string extensionNo)
        //{
        //    Simulator.Instance.TransferCall(extensionNo);
        //}


        public override System.Threading.Tasks.Task OnConnected()
        {
            int agentId, extensionNo;
            string uniqueIdentifier;
            Int32.TryParse(this.Context.QueryString["agentId"], out agentId);
            Int32.TryParse(this.Context.QueryString["extensionNo"], out extensionNo);
            uniqueIdentifier = Convert.ToString(this.Context.QueryString["uniqueIdentifier"]);

            new LoginRepository().ReActivateLogin(agentId, extensionNo, uniqueIdentifier);
            outputLogger.Info("Hub OnConnected AgentId - {0} ExtensionNo - {1}  UniqueIdentifier - {2}", agentId, extensionNo, uniqueIdentifier);

            BackgroundWorker worker = new BackgroundWorker();
            worker.WorkerReportsProgress = true;
            var agentStateCmd = new QueryAgentStateCommand(Simulator.Instance.m_Client, extensionNo.ToString());

            worker.DoWork += (o, args) =>
            {
                agentStateCmd.QueryAgentState();

                worker.ReportProgress(100);
            };

            worker.RunWorkerCompleted += (o, args) =>
            {
                if (agentStateCmd.AgentState == TSAPIClient.CSTA.AgentState_t.AG_NULL)
                {
                    context.Clients.User(extensionNo.ToString()).logoutAgent();
                }
                else if (agentStateCmd.ErrorMessage == TSAPIClient.CSTA.CSTAUniversalFailure_t.INVALID_CSTA_DEVICE_IDENTIFIER)
                {
                    context.Clients.User(extensionNo.ToString()).logoutAgent();
                }
                else
                {
                    AllocateAgentActiveCall(extensionNo);
                }
                //else{
                //    Simulator.Instance.StartMonitoring(agentId.ToString(), extensionNo.ToString());
                //}
            };
            worker.RunWorkerAsync();

            return base.OnConnected();

        }

        public override Task OnReconnected()
        {
            int agentId, extensionNo;
            string uniqueIdentifier;
            Int32.TryParse(this.Context.QueryString["agentId"], out agentId);
            Int32.TryParse(this.Context.QueryString["extensionNo"], out extensionNo);
            uniqueIdentifier = Convert.ToString(this.Context.QueryString["uniqueIdentifier"]);
            outputLogger.Info("Hub OnReconnected AgentId - {0} ExtensionNo - {1}  UniqueIdentifier - {2}", agentId, extensionNo, uniqueIdentifier);

            return base.OnReconnected();
        }

        public override Task OnDisconnected(bool stopCalled)
        {
            int agentId, extensionNo;
            string uniqueIdentifier;
            Int32.TryParse(this.Context.QueryString["agentId"], out agentId);
            Int32.TryParse(this.Context.QueryString["extensionNo"], out extensionNo);
            uniqueIdentifier = Convert.ToString(this.Context.QueryString["uniqueIdentifier"]);
            outputLogger.Info("Hub OnDisconnected AgentId - {0} ExtensionNo - {1}  UniqueIdentifier - {2}", agentId, extensionNo, uniqueIdentifier);
            //Simulator.Instance.StopMonitoring(agentId.ToString(), extensionNo.ToString());

            new LoginRepository().DeActivateLogin(agentId, extensionNo, uniqueIdentifier);
            return base.OnDisconnected(stopCalled);
        }

    }
}
