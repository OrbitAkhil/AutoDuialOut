﻿using Newtonsoft.Json;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace TSAPICallDistributionService.Classes
{
    public class UnProcessedCall
    {
       
        public int CallerId { get; set; }

        public string CallerMobile { get; set; }

        public int ExtensionNo { get; set; }
        
        public int AgentId { get; set; }
       
    }
}
