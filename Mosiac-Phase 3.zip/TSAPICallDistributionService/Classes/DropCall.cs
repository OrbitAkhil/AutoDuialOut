﻿using Newtonsoft.Json;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace TSAPICallDistributionService.Classes
{
    public class DropCall
    {
        public int RecordId { get; set; }
        public int CallerId { get; set; }
        public string CallerName { get; set; }
        public string CallerNumber { get; set; }
        public string CallerNumberWithPrefix { get; set; }
        
        public string AgentId { get; set; }
        public string ExtensionNo { get; set; }
        public string CallType { get; set; }
        public string HostIpAddress { get; set; }
    }
}
