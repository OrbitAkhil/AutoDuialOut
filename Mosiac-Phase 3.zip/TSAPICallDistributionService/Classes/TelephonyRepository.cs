﻿using NLog;
using System;
using System.Collections.Generic;
using System.Data.SqlClient;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Data;
using TSAPIDAL;
using TSAPIDAL.DataAccessLayer;

namespace TSAPICallDistributionService.Classes
{
    public class TelephonyRepository
    {
        NLog.Logger logger = LogManager.GetLogger("databaseLogger");

        public List<UnProcessedCall> GetUnProcessedCalls(string hostIpAddress)
        {
            List<UnProcessedCall> calls = null;
            try
            {
                var objCall = new Repository();
                var cmd = new CommandBuilder();
                cmd.SpName = "sp_AutoDial_GetUnProcessedCalls";
                cmd.SqlParams = new List<SqlParameter>()
                {
                    new SqlParameter("@HostIpAddress",hostIpAddress)
                };
                var ds = objCall.Select(cmd);
                if (ds.Tables[0].Rows.Count > 0)
                {
                    calls = new List<UnProcessedCall>();
                    foreach (DataRow dr in ds.Tables[0].Rows)
                    {
                        var call = new UnProcessedCall
                        {
                            CallerId = dr["CallerId"] != DBNull.Value ? Convert.ToInt32(dr["CallerId"]) : 0,
                            CallerMobile = dr["CallerMobile"] != DBNull.Value ? Convert.ToString(dr["CallerMobile"]) : string.Empty,
                            ExtensionNo = dr["ExtensionNo"] != DBNull.Value ? Convert.ToInt32(dr["ExtensionNo"]) : 0,
                            AgentId = dr["AgentId"] != DBNull.Value ? Convert.ToInt32(dr["AgentId"]) : 0
                        };
                        calls.Add(call);
                    }
                }
                return calls;
            }
            catch (Exception ex)
            {
                logger.Error(ex);
            }
            return calls;
        }

        public void ReAllocateCall(int dropOutId)
        {
            try
            {
                var objCall = new Repository();
                var cmd = new CommandBuilder();
                cmd.SpName = "sp_AutoDial_ReAllocateCurrentCall";
                cmd.SqlParams = new List<SqlParameter>()
                {
                    new SqlParameter("@DropOutId",dropOutId)
                };
                 objCall.Update(cmd);
            }
            catch (Exception ex)
            {
                logger.Error(ex);
            }
        }

        public ActiveCall GetAgentActiveOutgoingCall(int extensionNo)
        {
            ActiveCall call = null;
            try
            {
                var objCall = new Repository();
                var cmd = new CommandBuilder();
                cmd.SpName = "sp_AutoDial_GetAgentActiveOutgoingCall";
                cmd.SqlParams = new List<SqlParameter>()
                {
                    new SqlParameter("@ExtensionNo",extensionNo)
                };
                var ds = objCall.Select(cmd);
                if (ds.Tables.Count > 0)
                {
                    var row = ds.Tables[0].Rows[0];
                    call = new ActiveCall
                    {
                        CallerId = row["CallerId"] != DBNull.Value ? Convert.ToInt32(row["CallerId"]) : 0,
                        CallerMobile = row["CallerMobile"] != DBNull.Value ? Convert.ToString(row["CallerMobile"]) : string.Empty,
                        ExtensionNo = row["ExtensionNo"] != DBNull.Value ? Convert.ToString(row["ExtensionNo"]) : string.Empty,
                        CallerName = row["CallerName"] != DBNull.Value ? Convert.ToString(row["CallerName"]) : string.Empty,
                        CallOutgoingDateTime = row["CallOutgoingDateTime"] != DBNull.Value ? Convert.ToDateTime(row["CallOutgoingDateTime"]) : DateTime.MinValue,
                        CallEstablishedDateTime = row["CallEstablishedDateTime"] != DBNull.Value ? Convert.ToDateTime(row["CallEstablishedDateTime"]) : DateTime.MinValue,
                        CallEndDateTime = row["CallEndDateTime"] != DBNull.Value ? Convert.ToDateTime(row["CallEndDateTime"]) : DateTime.MinValue,
                        CallStatus = row["CallStatus"] != DBNull.Value ? Convert.ToString(row["CallStatus"]) : string.Empty,
                        DropOutCallerId = row["DropOutId"] != DBNull.Value ? Convert.ToInt32(row["DropOutId"]) : 0
                    };
                }
            }
            catch (Exception ex)
            {
                logger.Error(ex);
            }
            return call;
        }

        public async Task<bool> CloseCurrentCall(int callerId)
        {
            try
            {
                var objCall = new Repository();
                var cmd = new CommandBuilder();
                cmd.SpName = "sp_AutoDial_CloseCurrentCall";
                cmd.SqlParams = new List<SqlParameter>()
                {
                    new SqlParameter("@CallerId",callerId)
                };
                return await objCall.UpdateAsync(cmd);
            }
            catch (Exception ex)
            {
                logger.Error(ex);
            }
            return false;
        }

        public bool ReAssignCurrentCall(int callerId)
        {
            try
            {
                var objCall = new Repository();
                var cmd = new CommandBuilder();
                cmd.SpName = "sp_AutoDial_ReAssignCurrentCall";
                cmd.SqlParams = new List<SqlParameter>()
                {
                    new SqlParameter("@CallerId",callerId)
                };
                return objCall.Update(cmd);
            }
            catch (Exception ex)
            {
                logger.Error(ex);
            }
            return false;
        }

        public async Task<bool> SaveDisposition(int dispositionId, int callerId)
        {
            try
            {
                var objCall = new Repository();
                var cmd = new CommandBuilder();
                cmd.SpName = "sp_AutoDial_SaveDispositionForActiveCall";
                cmd.SqlParams = new List<SqlParameter>()
                {
                    new SqlParameter("@DispositionId",dispositionId),
                    new SqlParameter("@CallerId",callerId)
                };
                return await objCall.UpdateAsync(cmd);
            }
            catch (Exception ex)
            {
                logger.Error(ex);
            }
            return false;
        }

        public bool SaveDialCallLog(DropCall dropCall, int callId, string ucid)
        {
            try
            {
                var dataAccess = new Repository();
                var cmd = new CommandBuilder();
                cmd.SpName = "sp_AutoDial_SaveDialCallLog";
                cmd.SqlParams = new List<SqlParameter>()
                {
                    new SqlParameter("@CallType",dropCall.CallType),
                    new SqlParameter("@UCID",ucid),
                    new SqlParameter("@CallerId",callId),
                    new SqlParameter("@CallerName",dropCall.CallerName),
                    new SqlParameter("@CallerNumber",dropCall.CallerNumberWithPrefix),
                    new SqlParameter("@AgentId",dropCall.AgentId),
                    new SqlParameter("@ExtensionNo",dropCall.ExtensionNo),
                    new SqlParameter("@RecordId",dropCall.RecordId),
                    new SqlParameter("@HostIpAddress",dropCall.HostIpAddress),
                };
                dataAccess.Update(cmd);
            }
            catch (Exception ex)
            {
                logger.Error(ex);
            }
            return false;
        }

        public bool UpdateAgentUnprocessedCalls(int agentId, int extensionNo)
        {
            try
            {
                var objCall = new Repository();
                var cmd = new CommandBuilder();
                cmd.SpName = "sp_AutoDial_UpdateAgentUnprocessedCalls";
                cmd.SqlParams = new List<SqlParameter>()
                {
                    new SqlParameter("@AgentId",agentId),
                    new SqlParameter("@ExtensionNo",extensionNo)
                };
                return objCall.Update(cmd);
            }
            catch (Exception ex)
            {
                logger.Error(ex);
            }
            return false;
        }

        public Dictionary<string, int> GetUnAllocatedCallCount()
        {
            Dictionary<string, int> dropoutCaseDic = null;
            try
            {

                var objCall = new Repository();
                var cmd = new CommandBuilder();
                cmd.SpName = "sp_AutoDial_GetUnAllocatedWebsiteDropoutCalls";
                var ds = objCall.Select(cmd);
                if (ds != null && ds.Tables.Count > 0)
                {
                    dropoutCaseDic = new Dictionary<string, int>();
                    dropoutCaseDic.Add("NB", ds.Tables[0].Rows[0]["CaseCount"] != DBNull.Value ? Convert.ToInt32(ds.Tables[0].Rows[0]["CaseCount"]) : 0);
                    dropoutCaseDic.Add("HB", ds.Tables[0].Rows[1]["CaseCount"] != DBNull.Value ? Convert.ToInt32(ds.Tables[0].Rows[1]["CaseCount"]) : 0);
                    dropoutCaseDic.Add("SR", ds.Tables[0].Rows[2]["CaseCount"] != DBNull.Value ? Convert.ToInt32(ds.Tables[0].Rows[2]["CaseCount"]) : 0);

                }

            }
            catch (Exception ex)
            {
                logger.Error(ex);
            }
            return dropoutCaseDic;
        }

        public ActiveCall UpdateCallToDelivered(string ucid,int callerId, string callerNumber, string extensionNo, string hostIpAddress)
        {
            try
            {
                ActiveCall call = null;
                var objCall = new Repository();
                var cmd = new CommandBuilder();
                cmd.SpName = "sp_AutoDial_UpdateCallToDelivered";
                cmd.SqlParams = new List<SqlParameter>()
                {
                    new SqlParameter("@UCID",ucid),
                    new SqlParameter("@CallerId",callerId),
                    new SqlParameter("@ExtensionNo",extensionNo),
                    new SqlParameter("@CallerMobile",callerNumber),
                    new SqlParameter("@HostIpAddress",hostIpAddress)
                };
                var ds = objCall.Select(cmd);
                if (ds.Tables.Count > 0)
                {
                    var row = ds.Tables[0].Rows[0];
                    call = new ActiveCall
                    {
                        CallerId = row["CallerId"] != DBNull.Value ? Convert.ToInt32(row["CallerId"]) : 0,
                        CallerMobile = row["CallerMobile"] != DBNull.Value ? Convert.ToString(row["CallerMobile"]) : string.Empty,
                        ExtensionNo = row["ExtensionNo"] != DBNull.Value ? Convert.ToString(row["ExtensionNo"]) : string.Empty,
                        CallerName = row["CallerName"] != DBNull.Value ? Convert.ToString(row["CallerName"]) : string.Empty,
                        CallOutgoingDateTime = row["CallOutgoingDateTime"] != DBNull.Value ? Convert.ToDateTime(row["CallOutgoingDateTime"]) : DateTime.MinValue,
                        CallEstablishedDateTime = row["CallEstablishedDateTime"] != DBNull.Value ? Convert.ToDateTime(row["CallEstablishedDateTime"]) : DateTime.MinValue,
                        CallEndDateTime = row["CallEndDateTime"] != DBNull.Value ? Convert.ToDateTime(row["CallEndDateTime"]) : DateTime.MinValue,
                        CallStatus = row["CallStatus"] != DBNull.Value ? Convert.ToString(row["CallStatus"]) : string.Empty,
                        DropOutCallerId = row["DropOutId"] != DBNull.Value ? Convert.ToInt32(row["DropOutId"]) : 0
                    };
                }
                return call;
            }
            catch (Exception ex)
            {
                logger.Error(ex);
            }
            return null;
        }

        public ActiveCall UpdateCallToEstablished(string ucid, int callerId, string extensionNo, string hostIpAddress)
        {
            try
            {
                ActiveCall call = null;
                var objCall = new Repository();
                var cmd = new CommandBuilder();
                cmd.SpName = "sp_AutoDial_UpdateCallToEstablished";
                cmd.SqlParams = new List<SqlParameter>()
                {
                    new SqlParameter("@UCID",ucid),
                    new SqlParameter("@CallerId",callerId),
                    new SqlParameter("@ExtensionNo",extensionNo),
                    new SqlParameter("@HostIpAddress",hostIpAddress)
                };
                var ds = objCall.Select(cmd);
                if (ds.Tables.Count > 0)
                {
                    var row = ds.Tables[0].Rows[0];
                    call = new ActiveCall
                    {
                        CallerId = row["CallerId"] != DBNull.Value ? Convert.ToInt32(row["CallerId"]) : 0,
                        CallerMobile = row["CallerMobile"] != DBNull.Value ? Convert.ToString(row["CallerMobile"]) : string.Empty,
                        ExtensionNo = row["ExtensionNo"] != DBNull.Value ? Convert.ToString(row["ExtensionNo"]) : string.Empty,
                        CallerName = row["CallerName"] != DBNull.Value ? Convert.ToString(row["CallerName"]) : string.Empty,
                        CallOutgoingDateTime = row["CallOutgoingDateTime"] != DBNull.Value ? Convert.ToDateTime(row["CallOutgoingDateTime"]) : DateTime.MinValue,
                        CallEstablishedDateTime = row["CallEstablishedDateTime"] != DBNull.Value ? Convert.ToDateTime(row["CallEstablishedDateTime"]) : DateTime.MinValue,
                        CallEndDateTime = row["CallEndDateTime"] != DBNull.Value ? Convert.ToDateTime(row["CallEndDateTime"]) : DateTime.MinValue,
                        CallStatus = row["CallStatus"] != DBNull.Value ? Convert.ToString(row["CallStatus"]) : string.Empty,
                        DropOutCallerId = row["DropOutId"] != DBNull.Value ? Convert.ToInt32(row["DropOutId"]) : 0
                    };
                }
                return call;
            }
            catch (Exception ex)
            {
                logger.Error(ex);
            }
            return null;
        }

        public ActiveCall UpdateCallToCleared(int callerId, string extensionNo, string hostIpAddress, bool isFailed = false, string failureCause = null)
        {
            try
            {
                ActiveCall call = null;
                var objCall = new Repository();
                var cmd = new CommandBuilder();
                cmd.SpName = "sp_AutoDial_UpdateCallToCleared";
                cmd.SqlParams = new List<SqlParameter>()
                {
                    new SqlParameter("@CallerId",callerId),
                    new SqlParameter("@ExtensionNo",extensionNo),
                    new SqlParameter("@HostIpAddress",hostIpAddress)
                };
                var sqlParam = new SqlParameter("@IsFailed", isFailed);
                sqlParam.SqlDbType = System.Data.SqlDbType.Bit;
                cmd.SqlParams.Add(sqlParam);
                sqlParam = new SqlParameter("@FailureCause", failureCause);
                cmd.SqlParams.Add(sqlParam);

                var ds = objCall.Select(cmd);
                if (ds.Tables.Count > 0)
                {
                    var row = ds.Tables[0].Rows[0];
                    call = new ActiveCall
                    {
                        CallerId = row["CallerId"] != DBNull.Value ? Convert.ToInt32(row["CallerId"]) : 0,
                        CallerMobile = row["CallerMobile"] != DBNull.Value ? Convert.ToString(row["CallerMobile"]) : string.Empty,
                        ExtensionNo = row["ExtensionNo"] != DBNull.Value ? Convert.ToString(row["ExtensionNo"]) : string.Empty,
                        CallerName = row["CallerName"] != DBNull.Value ? Convert.ToString(row["CallerName"]) : string.Empty,
                        CallOutgoingDateTime = row["CallOutgoingDateTime"] != DBNull.Value ? Convert.ToDateTime(row["CallOutgoingDateTime"]) : DateTime.MinValue,
                        CallEstablishedDateTime = row["CallEstablishedDateTime"] != DBNull.Value ? Convert.ToDateTime(row["CallEstablishedDateTime"]) : DateTime.MinValue,
                        CallEndDateTime = row["CallEndDateTime"] != DBNull.Value ? Convert.ToDateTime(row["CallEndDateTime"]) : DateTime.MinValue,
                        CallStatus = row["CallStatus"] != DBNull.Value ? Convert.ToString(row["CallStatus"]) : string.Empty,
                        DropOutCallerId = row["DropOutId"] != DBNull.Value ? Convert.ToInt32(row["DropOutId"]) : 0
                    };
                }
                return call;
            }
            catch (Exception ex)
            {
                logger.Error(ex);
            }
            return null;
        }


        public ActiveCall UpdateCallToFailed(int callerId, string callerNumber, string hostIpAddress, string extensionNo, string cause)
        {
            ActiveCall call = null;
            try
            {
                
                var objCall = new Repository();
                var cmd = new CommandBuilder();
                cmd.SpName = "sp_AutoDial_UpdateCallToFailed";
                cmd.SqlParams = new List<SqlParameter>()
                {
                    new SqlParameter("@CallerId",callerId),
                    new SqlParameter("@ExtensionNo",extensionNo),
                    new SqlParameter("@CallerNumber",callerNumber),
                    new SqlParameter("@Cause",cause),
                    new SqlParameter("@HostIpAddress",hostIpAddress)
                };
                var ds = objCall.Select(cmd);
                if (ds.Tables.Count > 0)
                {
                    var row = ds.Tables[0].Rows[0];
                    call = new ActiveCall
                    {
                        CallerId = row["CallerId"] != DBNull.Value ? Convert.ToInt32(row["CallerId"]) : 0,
                        CallerMobile = row["CallerMobile"] != DBNull.Value ? Convert.ToString(row["CallerMobile"]) : string.Empty,
                        ExtensionNo = row["ExtensionNo"] != DBNull.Value ? Convert.ToString(row["ExtensionNo"]) : string.Empty,
                        CallerName = row["CallerName"] != DBNull.Value ? Convert.ToString(row["CallerName"]) : string.Empty,
                        CallOutgoingDateTime = row["CallOutgoingDateTime"] != DBNull.Value ? Convert.ToDateTime(row["CallOutgoingDateTime"]) : DateTime.MinValue,
                        CallEstablishedDateTime = row["CallEstablishedDateTime"] != DBNull.Value ? Convert.ToDateTime(row["CallEstablishedDateTime"]) : DateTime.MinValue,
                        CallEndDateTime = row["CallEndDateTime"] != DBNull.Value ? Convert.ToDateTime(row["CallEndDateTime"]) : DateTime.MinValue,
                        CallStatus = row["CallStatus"] != DBNull.Value ? Convert.ToString(row["CallStatus"]) : string.Empty,
                        DropOutCallerId = row["DropOutId"] != DBNull.Value ? Convert.ToInt32(row["DropOutId"]) : 0
                    };
                }
                return call;
            }
            catch (Exception ex)
            {
                logger.Error(ex);
            }
            return call;
        }

        public bool StartMonitoringDevice(int monitorCrossRefId, string agentId, string extensionNo)
        {
            try
            {
                var objCall = new Repository();
                var cmd = new CommandBuilder();
                cmd.SpName = "sp_AutoDial_UpdateAgentMonitorToStart";
                cmd.SqlParams = new List<SqlParameter>()
                {
                    new SqlParameter("@MonitorCrossRefId",monitorCrossRefId),
                    new SqlParameter("@AgentId",agentId),
                    new SqlParameter("@ExtensionNo",extensionNo)
                };
                objCall.Update(cmd);
                return true;
            }
            catch (Exception ex)
            {
                logger.Error(ex);
            }
            return false;
        }

        public bool StopMonitoringDevice(int monitorCrossRefId, string agentId, string extensionNo)
        {
            try
            {
                var objCall = new Repository();
                var cmd = new CommandBuilder();
                cmd.SpName = "sp_AutoDial_UpdateAgentMonitorToStop";
                cmd.SqlParams = new List<SqlParameter>()
                {
                    new SqlParameter("@MonitorCrossRefId",monitorCrossRefId),
                    new SqlParameter("@AgentId",agentId),
                    new SqlParameter("@ExtensionNo",extensionNo)
                };
                objCall.Update(cmd);
                return true;
            }
            catch (Exception ex)
            {
                logger.Error(ex);
            }
            return false;
        }

        public bool StopActiveAgentMonitoring(int monitorCrossRefId, string agentId, string extensionNo)
        {
            try
            {
                var objCall = new Repository();
                var cmd = new CommandBuilder();
                cmd.SpName = "sp_AutoDial_StopActiveAgentMonitoring";
                cmd.SqlParams = new List<SqlParameter>()
                {
                    new SqlParameter("@MonitorCrossRefId",monitorCrossRefId),
                    new SqlParameter("@AgentId",agentId),
                    new SqlParameter("@ExtensionNo",extensionNo)
                };
                objCall.Update(cmd);
                return true;
            }
            catch (Exception ex)
            {
                logger.Error(ex);
            }
            return false;
        }

        public int GetAgentMonitorCrossRefId(string agentId, string extensionNo)
        {
            try
            {
                var objCall = new Repository();
                var cmd = new CommandBuilder();
                cmd.CommandText = "Select top 1 MonitorCrossRefInvokeId from tbl_AutoDial_Login Where AgentId=@AgentId and ExtensionNo=@ExtensionNo order by LoginDateTime desc";
                cmd.SqlParams = new List<SqlParameter>()
                {
                    new SqlParameter("@AgentId",Convert.ToInt32(agentId)),
                    new SqlParameter("@ExtensionNo",Convert.ToInt32(extensionNo))
                };
                object record = objCall.GetScalerRecord(cmd);
                return record != DBNull.Value ? Convert.ToInt32(record) : 0;
            }
            catch (Exception ex)
            {
                logger.Error(ex);
            }
            return 0;
        }

    }
}
