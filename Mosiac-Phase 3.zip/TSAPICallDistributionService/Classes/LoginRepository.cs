﻿using NLog;
using System;
using System.Collections.Generic;
using System.Data.SqlClient;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Data;
using TSAPIDAL;
using TSAPIDAL.DataAccessLayer;

namespace TSAPICallDistributionService.Classes
{
    public class LoginRepository
    {
        NLog.Logger logger = LogManager.GetLogger("OutputLogger");



        public bool CheckExtensionAvailability(int agentId, int extensionNo)
        {

            try
            {
                var objCall = new Repository();
                var cmd = new CommandBuilder();
                cmd.SpName = "sp_AutoDial_CheckExtensionAvailability";
                cmd.SqlParams = new List<SqlParameter>()
                {
                    new SqlParameter("@AgentId",agentId)
                };
                object record = objCall.GetScalerRecord(cmd);
                return record != DBNull.Value ? Convert.ToBoolean(record) : false;
            }
            catch (Exception ex)
            {
                logger.Error(ex);
            }
            return false;
        }


        public Dictionary<string, string> GetActiveAgents(string hostIpAddress)
        {
            Dictionary<string, string> agentWithStationDic = null;
            try
            {

                var objCall = new Repository();
                var cmd = new CommandBuilder();
                cmd.SpName = "sp_AutoDial_GetActiveLoggedinAgent";
                cmd.SqlParams = new List<SqlParameter>()
                {
                    new SqlParameter("@HostIpAddress",hostIpAddress)
                };
                var ds = objCall.Select(cmd);
                if (ds.Tables[0].Rows.Count > 0)
                {
                    agentWithStationDic = new Dictionary<string, string>();
                    foreach (DataRow dr in ds.Tables[0].Rows)
                    {
                        agentWithStationDic.Add(Convert.ToString(dr["AgentId"]), Convert.ToString(dr["ExtensionNo"]));
                    }
                }
            }
            catch (Exception ex)
            {
                logger.Error(ex);
            }
            return agentWithStationDic;
        }

        public int GetAgentLoggedInExtension(int agentId)
        {
            int extensionNo = 0;
            try
            {
                var objCall = new Repository();
                var cmd = new CommandBuilder();
                cmd.SpName = "sp_AutoDial_GetAgentLoggedInExtension";
                cmd.SqlParams = new List<SqlParameter>()
                {
                    new SqlParameter("@AgentId",agentId)
                };
                object record = objCall.GetScalerRecord(cmd);
                return record != DBNull.Value ? Convert.ToInt32(record) : 0;
            }
            catch (Exception ex)
            {
                logger.Error(ex);
            }
            return extensionNo;
        }

        public void AddLoginRecord(int agentId, int extensionNo, string agentLoggedInType, string uniqueIdentifier, string ipAdress, string hostIpAdress)
        {
            try
            {
                var objCall = new Repository();
                var cmd = new CommandBuilder();
                cmd.SpName = "sp_AutoDial_CreateLoginLog";
                cmd.SqlParams = new List<SqlParameter>()
                {
                    new SqlParameter("@AgentId",agentId),
                    new SqlParameter("@ExtensionNo",extensionNo),
                    new SqlParameter("@AgentLoggedInType",agentLoggedInType),
                    new SqlParameter("@SessionId",uniqueIdentifier),
                    new SqlParameter("@IpAddress",ipAdress),
                    new SqlParameter("@HostIpAddress",hostIpAdress)
                };
                objCall.Insert(cmd);
            }
            catch (Exception ex)
            {
                logger.Error(ex);
            }
        }

        public bool UpdateAgentStateForCallAllocation(int agentId, int extensionNo)
        {
            try
            {
                var objCall = new Repository();
                var cmd = new CommandBuilder();
                cmd.SpName = "sp_AutoDial_UpdateAgentStateForCallAllocation";
                cmd.SqlParams = new List<SqlParameter>()
                {
                    new SqlParameter("@AgentId",agentId),
                    new SqlParameter("@ExtensionNo",extensionNo)
                };
                return objCall.Update(cmd);
            }
            catch (Exception ex)
            {
                logger.Error(ex);
                throw ex;
            }
        }

        public void LogoutAgentExistingSession(int agentId)
        {
            try
            {
                var objCall = new Repository();
                var cmd = new CommandBuilder();
                cmd.SpName = "sp_AutoDial_LogoutAgentExistingSession";
                cmd.SqlParams = new List<SqlParameter>()
                {
                    new SqlParameter("@AgentId",agentId)
                };
                objCall.Update(cmd);
            }
            catch (Exception ex)
            {
                logger.Error(ex);
            }
        }

        public void ReActivateLogin(int agentId, int extensionNo, string uniqueIdentifier)
        {
            try
            {
                var objCall = new Repository();
                var cmd = new CommandBuilder();
                cmd.SpName = "sp_AutoDial_ReActivateAgentLogin";
                cmd.SqlParams = new List<SqlParameter>()
                    {
                        new SqlParameter("@AgentId",agentId),
                        new SqlParameter("@ExtensionNo",extensionNo),
                        new SqlParameter("@SessionId",uniqueIdentifier)
                    };
                objCall.Update(cmd);
            }
            catch (Exception ex)
            {
                logger.Error(ex);
            }
        }

        public void DeActivateLogin(int agentId, int extensionNo, string uniqueIdentifier)
        {
            try
            {
                var objCall = new Repository();
                var cmd = new CommandBuilder();
                cmd.SpName = "sp_AutoDial_DeActivateAgentLogin";
                cmd.SqlParams = new List<SqlParameter>()
                    {
                        new SqlParameter("@AgentId",agentId),
                        new SqlParameter("@ExtensionNo",extensionNo),
                        new SqlParameter("@SessionId",uniqueIdentifier)
                    };
                objCall.Update(cmd);
            }
            catch (Exception ex)
            {
                logger.Error(ex);
            }
        }

        public long GetAgentMonitorCrossRefId(int agentId, int extensionNo)
        {
            try
            {
                var objCall = new Repository();
                var cmd = new CommandBuilder();
                cmd.CommandText = "Select top 1 MonitorCrossRefInvokeId from tbl_AutoDial_Login Where AgentId=@AgentId and ExtensionNo=@ExtensionNo order by LoginDateTime desc";
                cmd.SqlParams = new List<SqlParameter>()
                {
                    new SqlParameter("@AgentId",agentId),
                    new SqlParameter("@ExtensionNo",extensionNo)
                };
                object record = objCall.GetScalerRecord(cmd);
                return record != DBNull.Value ? Convert.ToInt64(record) : 0;
            }
            catch (Exception ex)
            {
                logger.Error(ex);
            }
            return extensionNo;
        }


        public bool IsAgentLoggedIn(int agentId, int extensionNo)
        {
            try
            {
                var objCall = new Repository();
                var cmd = new CommandBuilder();
                cmd.SpName = "sp_AutoDial_IsAgentLoggedIn";
                cmd.SqlParams = new List<SqlParameter>()
                {
                    new SqlParameter("@AgentId",agentId),
                    new SqlParameter("@ExtensionNo",extensionNo)
                };
                object record = objCall.GetScalerRecord(cmd);
                return record != DBNull.Value ? Convert.ToBoolean(record) : false;
            }
            catch (Exception ex)
            {
                logger.Error(ex);
            }
            return false;
        }
    }
}
