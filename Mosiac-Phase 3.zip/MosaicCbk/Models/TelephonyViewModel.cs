﻿using MosaicCbk.Repositories;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace MosaicCbk.Models
{
    public class TelephonyViewModel : ViewModelBase
    {
        public Dictionary<string, int> UnAllocatedCallCountDic
        {
            get 
            {   
                TelephonyRepository telephonyRepository = new TelephonyRepository();
                return telephonyRepository.GetUnAllocatedCallCount();
            }
        }
    }
}