﻿using MosaicCbk.App_Classes;
using MosaicCbk.Models;
using MosaicCbk.Repositories;
using NLog;
using System;
using System.Collections.Generic;
using System.Data.SqlClient;
using System.Linq;
using System.Threading.Tasks;
using System.Web;
using System.Web.Mvc;

namespace MosaicCbk.Controllers
{
    [ErrorHandle]
    public class HomeController : ApplicationController<LoggedInAgentViewModel>
    {
        private static NLog.Logger logger = LogManager.GetLogger("databaseLogger");
        private string ExtensionNo { get; set; }
        public HomeController()
        {

        }

        public ActionResult Index()
        {
            var agentViewModel = GetLogOnSessionModel();
            if (agentViewModel.ExtensionNo > 0)
            {
                this.ExtensionNo = agentViewModel.ExtensionNo.ToString();
            }



            if (agentViewModel == null)
                return RedirectToAction("Login", "Account");

            return View(new TelephonyViewModel() { AgentId = agentViewModel.AgentId, AgentName = agentViewModel.AgentName, ExtensionNo = Convert.ToString(agentViewModel.ExtensionNo), UniqueIdentifier = agentViewModel.UniqueIdentifier });
        }

        [HttpPost]
        public async Task<JsonResult> GetCallerInfo(int dropCallerId)
        {
            TelephonyRepository telephonyRepository = new TelephonyRepository();
            var dropCallerInfo = await telephonyRepository.GetDropCallerInfo(dropCallerId);
            return new JsonResult { Data = dropCallerInfo, JsonRequestBehavior = JsonRequestBehavior.DenyGet };
        }

        [HttpPost]
        public async Task<JsonResult> GetCustomerBookings(string callerMobile)
        {
            BookingRepository bookingRepository = new BookingRepository();
            var customerBookingList = await bookingRepository.GetCustomerBookings(callerMobile);
            return new JsonResult { Data = customerBookingList, JsonRequestBehavior = JsonRequestBehavior.DenyGet };
        }

        [HttpPost]
        public JsonResult StartCallAllocation()
        {
            var agentViewModel = GetLogOnSessionModel();
            if (agentViewModel != null && agentViewModel.ExtensionNo > 0)
            {
                LoginRepository loginRepository = new LoginRepository();
                bool isUpdated = loginRepository.UpdateAgentStateForCallAllocation(agentViewModel.AgentId, agentViewModel.ExtensionNo);
                return new JsonResult { Data = isUpdated, JsonRequestBehavior = JsonRequestBehavior.DenyGet };
            }
            return new JsonResult { Data = false, JsonRequestBehavior = JsonRequestBehavior.DenyGet };
        }
        

        [HttpPost]
        public async Task<JsonResult> SaveDisposition(int dispositionId, int callerId, string callbackRequestDateTime = null)
        {
            TelephonyRepository telephonyRepository = new TelephonyRepository();
            if (string.IsNullOrEmpty(callbackRequestDateTime))
            {
                bool isSavedSuccess = await telephonyRepository.SaveDisposition(dispositionId, callerId);
                return new JsonResult { Data = isSavedSuccess, JsonRequestBehavior = JsonRequestBehavior.DenyGet };
            }
            else
            {
                DateTime callbackDateTime;
                DateTime.TryParse(callbackRequestDateTime, out callbackDateTime);
                bool isSavedSuccess = await telephonyRepository.SaveDisposition(dispositionId, callerId, callbackDateTime);
                return new JsonResult { Data = isSavedSuccess, JsonRequestBehavior = JsonRequestBehavior.DenyGet };
            }

            
        }

        [HttpPost]
        public JsonResult GetDispositionList()
        {
            DispositionRepository dispositionRepository = new DispositionRepository();
            var dispositions = dispositionRepository.GetDispositions();
            return new JsonResult { Data = dispositions, JsonRequestBehavior = JsonRequestBehavior.DenyGet };
        }
    }
}