﻿
// Set the date we're counting down to
var countDownDate = new Date().getTime();
SetIdleTime();
function SetIdleTime() {
    // Update the count down every 1 second
    var x = setInterval(function () {

        // Get todays date and time
        var now = new Date().getTime();
        var distance = now - countDownDate;
        // Time calculations for days, hours, minutes and seconds
        var days = Math.floor(distance / (1000 * 60 * 60 * 24));
        var hours = Math.floor((distance % (1000 * 60 * 60 * 24)) / (1000 * 60 * 60));
        var minutes = Math.floor((distance % (1000 * 60 * 60)) / (1000 * 60));
        var seconds = Math.floor((distance % (1000 * 60)) / 1000);

        // Display the result in the element with id="demo"
        var countdownMessage = "";
        if (days > 0)
            countdownMessage += days + "d ";
        if (hours > 0)
            countdownMessage += hours + "h ";
        if (minutes > 0)
            countdownMessage += minutes + "m ";
        if (seconds > 0)
            countdownMessage += seconds + "s ";

        document.getElementById("duration").innerHTML = countdownMessage;
        // If the count down is finished, write some text
        if (distance <= 0) {
            clearInterval(x);
            document.getElementById("duration").innerHTML = "EXPIRED";
        }
        else if (distance >= 600000) {
            clearInterval(x);
            document.getElementById('logoutForm').submit();
        }
    }, 1000);
}

$(function () {

    // Reference the auto-generated proxy for the hub.

    var telephony = $.connection.telephonyHub;
    $.connection.hub.qs = { extensionNo: '@Model.ExtensionNo', agentId: '@Model.AgentId', uniqueIdentifier: '@Model.UniqueIdentifier' };

    // Client side method for receiving the list of notifications on the connected event from the server
    //telephony.client.refreshAgentCall = function (data) {
    //    $("#newCallInfo").empty();
    //    if (data != undefined && data != null) {
    //       // $("#cntNotifications").text(data.length);
    //        for (var i = 0; i < data.length; i++) {
    //            $("#newCallInfo").text(data[i].CallerMobile);
    //        }
    //    }
    //}

    //Client side method which will be invoked from the Global.asax.cs file.

    telephony.client.refreshAgentCall = function (data) {
        // Let's check if the browser supports notifications
        if (!("Notification" in window)) {
            // alert("This browser does not support desktop notification");
        }

            // Let's check whether notification permissions have already been granted
        else if (Notification.permission === "granted") {
            // If it's okay let's create a notification
            var notification = new Notification('IndiGo Screen-Popup', {
                icon: '',
                body: "Hi Agent! An Incoming call from Caller-Id - " + data.CallerMobile + " is detected.!",
                noscreen: false

            });
            notification.onshow = function (e) {
                // alert("hii");
                window.focus();
            };
            notification.onclick = function (e) {
                // alert("hii");
                window.focus();
            };
            notification.noscreen

        }

            // Otherwise, we need to ask the user for permission
        else if (Notification.permission !== "denied") {
            Notification.requestPermission(function (permission) {
                // If the user accepts, let's create a notification
                if (permission === "granted") {
                    var notification = new Notification('IndiGo Screen-Popup', {
                        icon: '',
                        body: "Hi Agent! An Incoming call from Caller-Id - " + data.CallerMobile + " is detected.!",
                        noscreen: false
                    });
                    notification.onshow = function (e) {
                        // alert("hii");
                        window.focus();
                    };
                    notification.onclick = function (e) {
                        // alert("hii");
                        window.focus();
                    };
                }
            });
        }

        //console.log("Start Caller Details " + new Date());
        if (data != null) {
            $("#callerInfo").empty();
            $("#callerInfo").append("<div class='ibox-title'><h5>Caller/PNR Details for  " + data.CallerMobile + "</h5> " + (data.NoOfCall > 1 ? "<div class='ibox-tools'> <span class='label label-warning-light pull-right'>Called " + data.NoOfCall + " time(s)</span></div>" : "") + "" +
                "&nbsp;<span id='newCallNotify' style='display:none;'>Incoming Call Detected..Fetching details from Navitaire..</span>" +
            "</div>" +
            "<div class='ibox-content'>" +
                "<div>" +
                    "<table class='table table-bordered table-hover'>" +
                        "<thead>" +
                            "<tr>" +
                                "<th>Passenger Name</th>" +
                                "<th>Flight Date Time</th>" +
                                "<th>Market</th>" +
                                "<th>Reservation Number</th>" +
                                "<th>Flight Number</th>" +
                                "<th>PNR Status</th>" +
                            "</tr>" +
                        "</thead>" +
                        "<tbody id='CustomerBookingInfo'></tbody>" +
                    "</table>" +
                "</div>" +
            "</div>" +
            "<div class='ibox-title'><h5>Previous Caller History </h5>" + "</div>" +
            "<div class='ibox-content'>" +
                "<div>" +
                    "<table class='table table-bordered table-hover'>" +
                        "<thead>" +
                            "<tr>" +
                                "<th>Sr.</th>" +
                                "<th>Incoming-Call Date & Time</th>" +
                                //"<th>Agent Id</th>" +
                                "<th>Extension No</th>" +
                            "</tr>" +
                        "</thead>" +
                        "<tbody id='CallerHistory'></tbody>" +
                    "</table>" +
                "</div>" +
            "</div>"
            );
        }
        //console.log("End Caller Details " + new Date());
    }

    telephony.client.showLoader = function () {
        //   console.log("Start Loader " + new Date());
        $("#newCallNotify").show();
        $("#CustomerBookingInfo").empty().append("<tr> <td colspan='6'> Loading....</td></tr>");
        $("#CallerHistory").empty().append("<tr> <td colspan='3'> Loading....</td></tr>");
        // console.log("End Loader " + new Date());

    }
    telephony.client.showCustomerBookings = function (custData, callerData) {
        //console.log("Start Customer Details " + new Date());
        $("#CustomerBookingInfo").empty();
        if (custData != undefined && custData != null && custData.length > 0) {
            for (var i = 0; i < custData.length; i++) {
                $("#CustomerBookingInfo").append("<tr> <td> " + custData[i].PaxName + "</td> <td>" + custData[i].FlightDate + "</td> <td>" + custData[i].Market + "</td><td> " + custData[i].RecordLocator + "</td> <td>" + custData[i].FlightNumber + "</td> <td>" + custData[i].PnrStatus + "</td></tr>");
            }
        }
        else {
            $("#CustomerBookingInfo").append("<tr> <td colspan='6'><strong>No record(s) found<strong></td></tr>");
        }
        //console.log("End Customer Details " + new Date());

        //console.log("Start Caller History " + new Date());
        $("#newCallNotify").fadeOut();

        $("#CallerHistory").empty();
        if (callerData != undefined && callerData != null && callerData.length > 0) {
            var serialNo = 0;
            for (var ctr = 0; ctr < callerData.length; ctr++) {
                serialNo = serialNo + 1;
                $("#CallerHistory").append("<tr><td>" + serialNo + ".</td><td>" + moment(callerData[ctr].CallIncomingDateTime).format('DD-MMM-YYYY H:mm') + "</td><td>" + callerData[ctr].ExtensionNo + "</td></tr>");
            }
        }
        else {
            $("#CallerHistory").append("<tr> <td colspan='3'><strong>No record(s) found<strong></td></tr>");
        }
        // console.log("End Caller History " + new Date());
        countDownDate = new Date().getTime();
    }



    // Start the connection.
    $.connection.hub.start().done(function () {

        //When the send button is clicked get the text and user name and send it to server.

        $("#btnRefresh").click(function () {
            $("#callerInfo").empty();
            telephony.server.getActiveCall('@Model.ExtensionNo');
        });

        $("#btnSend").click(function () {
            telephony.server.sendNotification($("#txtCallerId").val(), $("#txtCallerName").val(), $("#txtCallerMobile").val(), $("#txtCallerEmail").val(), $("#txtExtensionNo").val());
        });

    });
});

