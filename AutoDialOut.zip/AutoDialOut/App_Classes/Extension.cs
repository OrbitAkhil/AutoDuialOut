﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace AutoDialOut.App_Classes
{
    public class Extension
    {
        public int ExtensionNo { get; set; }
        public string Status { get; set; }
    }
}