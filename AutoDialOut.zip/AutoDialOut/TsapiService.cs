﻿using AutoDialOut.Hubs;
using AutoDialOut.Repository;
using Microsoft.AspNet.SignalR;
using Microsoft.AspNet.SignalR.Hubs;
using NLog;
using System;
using System.Collections.Generic;
using System.Configuration;
using System.Data;
using System.Data.SqlClient;
using System.Linq;
using System.Runtime.InteropServices;
using System.Web;

namespace AutoDialOut
{
    public class TsapiService
    {
        #region Member variables

        // Singleton instance
        private readonly static Lazy<TsapiService> _instance = new Lazy<TsapiService>(() => new TsapiService(GlobalHost.ConnectionManager.GetHubContext<TelephonyHub>().Clients));
        private IHubConnectionContext<dynamic> Clients { get; set; }
        private SqlConnection connection = new SqlConnection(ConfigurationManager.ConnectionStrings["TelephonyConnection"].ConnectionString);
        private static NLog.Logger logger = LogManager.GetCurrentClassLogger();
        
        
        [DllImport("TSAPIApp.dll", CallingConvention = CallingConvention.Cdecl)]
        public static extern bool CallDevice(string callingDevice, string calledDevice);
        #endregion

        #region Constructors

        private TsapiService(IHubConnectionContext<dynamic> clients)
        {
            this.Clients = clients;

            // Because our C# model name differs from table name we have to specify database table name.
            try
            {
                SqlDependency.Stop(ConfigurationManager.ConnectionStrings["TelephonyConnection"].ConnectionString);
                SqlDependency.Start(ConfigurationManager.ConnectionStrings["TelephonyConnection"].ConnectionString);

                CallInitiateNotification();
            }
            catch (Exception ex)
            {
                logger.Error(ex);
            }

        }

        #endregion

        #region Public Methods
        public static TsapiService Instance
        {
            get { return _instance.Value; }
        }

        public void AllocateAgentActiveCall(int extensionNo)
        {
            if (extensionNo <= 0)
                return;
            TelephonyRepository telephonyRepository = new TelephonyRepository();
            var call = telephonyRepository.GetAgentActiveOutgoingCall(extensionNo);

            if (call == null)
                return;

            var context = GlobalHost.ConnectionManager.GetHubContext<TelephonyHub>();
            if (!string.IsNullOrEmpty(Convert.ToString(call.AgentId)))
            {
                
                if (call.CallStatus == "A")
                {
                    if (Simulator.Instance.CheckAgentLoggedIn(Convert.ToString(call.AgentId)))
                    {
                        if (!CallDevice(call.ExtensionNo.ToString(), call.CallerMobile.ToString()))
                        {
                            logger.Info("Re-Open Stream during make call");
                            Simulator.Instance.ReOpenStream();
                            telephonyRepository.ReAssignCurrentCall(call.CallerId);
                        }
                    }
                }
                else if (call.CallStatus == "D")
                    context.Clients.User(call.ExtensionNo.ToString()).showAgentActiveCall(call);
                else if (call.CallStatus == "E")
                    context.Clients.User(call.ExtensionNo.ToString()).establishActiveAgentCall(call);
                else if (call.CallStatus == "C")
                    context.Clients.User(call.ExtensionNo.ToString()).clearedActiveAgentCall(call);
            }
            else
            {
                context.Clients.User(call.ExtensionNo.ToString()).loggedOffAgent(call);
                telephonyRepository.ReAssignCurrentCall(call.CallerId);
            }
        }
        #endregion

        #region Private Methods


        private void CallInitiateNotification()
        {
            string commandText = @"Select CallerId,CallerName,ExtensionNo,CallOutgoingDateTime,CallEstablishedDateTime,CallEndDateTime,CallStatus From dbo.tbl_AutoDial_Call_Diversion";

            try
            {
                //Start the SQL Dependency
                using (SqlCommand command = new SqlCommand(commandText, connection))
                {
                    if (connection.State == ConnectionState.Closed)
                        connection.Open();

                    SqlDependency dependency = new SqlDependency(command);
                    dependency.OnChange += new OnChangeEventHandler(sqlCallInitiatedDependency_OnChange);
                    // NOTE: You have to execute the command, or the notification will never fire.
                    command.ExecuteReaderAsync();
                }
            }
            catch (Exception ex)
            {
                logger.Error(ex);
            }
        }

        private void sqlCallInitiatedDependency_OnChange(object sender, SqlNotificationEventArgs e)
        {
            try
            {

                //This is how signalrHub can be accessed outside the SignalR Hub Notification.cs file
                var context = GlobalHost.ConnectionManager.GetHubContext<TelephonyHub>();
                TelephonyRepository objRepos = new TelephonyRepository();
                if (e.Type == SqlNotificationType.Change)
                {

                    var callList = objRepos.GetAllOutgoingCalls();
                    foreach (var call in callList)
                    {
                        if (!string.IsNullOrEmpty(Convert.ToString(call.AgentId)))
                        {
                            if (call.CallStatus == "A")
                            {
                                if (Simulator.Instance.CheckAgentLoggedIn(Convert.ToString(call.AgentId)))
                                {
                                    if (!CallDevice(call.ExtensionNo.ToString(), call.CallerMobile.ToString()))
                                    {
                                        logger.Info("Re-Open Stream during make call");
                                        Simulator.Instance.ReOpenStream();
                                        objRepos.ReAssignCurrentCall(call.CallerId);
                                    }
                                }
                                else
                                {
                                    objRepos.ReAssignCurrentCall(call.CallerId);
                                    context.Clients.User(call.ExtensionNo.ToString()).logoutAgent(call);
                                }
                            }
                            else if (call.CallStatus == "D")
                                context.Clients.User(call.ExtensionNo.ToString()).showAgentActiveCall(call);
                            else if (call.CallStatus == "E")
                                context.Clients.User(call.ExtensionNo.ToString()).establishActiveAgentCall(call);
                            else if (call.CallStatus == "C")
                                context.Clients.User(call.ExtensionNo.ToString()).clearedActiveAgentCall(call);
                            //else if (call.CallStatus == "F")
                            //{
                            //    if(Simulator.Instance.ClearCall(call.ExtensionNo.ToString()))
                            //    {
                            //        context.Clients.User(call.ExtensionNo.ToString()).clearedActiveAgentCall(call);
                            //    }
                            //}
                        }
                        else
                        {
                            context.Clients.User(call.ExtensionNo.ToString()).loggedOffAgent(call);
                            objRepos.ReAssignCurrentCall(call.CallerId);
                        }
                    }
                }
                this.CallInitiateNotification();
                //Call the RegisterNotification method again
            }
            catch (Exception ex)
            {
                logger.Error(ex);
            }


        }

        #endregion

        #region IDisposable Implementation

        public void Dispose()
        {
            // Invoke Stop() in order to remove all DB objects genetated from SqlTableDependency.
            try
            {
                SqlDependency.Stop(ConfigurationManager.ConnectionStrings["TelephonyConnection"].ConnectionString);
            }
            catch (Exception ex)
            {
                logger.Error(ex);
            }

        }

        #endregion
    }
}