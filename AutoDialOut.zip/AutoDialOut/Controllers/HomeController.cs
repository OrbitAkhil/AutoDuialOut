﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;
using AutoDialOut.App_Classes;
using System.Web.Helpers;
using AutoDialOut.Repository;
using AutoDialOut.Models;
using NLog;
using System.Configuration;
using System.Data.SqlClient;
using System.Data;
using Microsoft.AspNet.SignalR;
using AutoDialOut.Hubs;
using System.Threading.Tasks;
using Tsapi;
using AutoDialOut;
using System.Runtime.InteropServices; 
namespace AutoDialOut.Controllers
{
    [ErrorHandle]
    public class HomeController : ApplicationController<LoggedInAgentViewModel>
    {
        private static NLog.Logger logger = LogManager.GetLogger("databaseLogger");
        private string ExtensionNo { get; set; }
        private SqlConnection connection = new SqlConnection(ConfigurationManager.ConnectionStrings["TelephonyConnection"].ConnectionString);
        public HomeController()
        {
           
        }

        public ActionResult Index()
        {
            
            var agentViewModel = GetLogOnSessionModel();
            if (agentViewModel.ExtensionNo > 0)
            {
                this.ExtensionNo = agentViewModel.ExtensionNo.ToString();
            }

            if (agentViewModel == null)
                return RedirectToAction("Login", "Account");

            
           // logger.Info("You have visited the Index view");
            return View(new TelephonyViewModel() { AgentId = agentViewModel.AgentId, AgentName = agentViewModel.AgentName, ExtensionNo = Convert.ToString(agentViewModel.ExtensionNo), UniqueIdentifier = agentViewModel.UniqueIdentifier });
        }

        [HttpPost]
        public async Task<JsonResult> GetCallerInfo(int dropCallerId)
        {
            TelephonyRepository telephonyRepository = new TelephonyRepository();
            var dropCallerInfo = await telephonyRepository.GetDropCallerInfo(dropCallerId);
            return new JsonResult { Data = dropCallerInfo, JsonRequestBehavior = JsonRequestBehavior.DenyGet };
        }

        [HttpPost]
        public async Task<JsonResult> GetCustomerBookings(string callerMobile)
        {
            BookingRepository bookingRepository = new BookingRepository();
            var customerBookingList = await bookingRepository.GetCustomerBookings(callerMobile);
            return new JsonResult { Data = customerBookingList, JsonRequestBehavior = JsonRequestBehavior.DenyGet };
        }

        [HttpPost]
        public async Task<JsonResult> CloseCurrentCall(int callerId)
        {
            TelephonyRepository telephonyRepository = new TelephonyRepository();
            bool isClosedSuccess = await telephonyRepository.CloseCurrentCall(callerId);
            return new JsonResult { Data = isClosedSuccess, JsonRequestBehavior = JsonRequestBehavior.DenyGet };
        }

        [HttpPost]
        public async Task<JsonResult> SaveDisposition(int dispositionId, int callerId)
        {
            TelephonyRepository telephonyRepository = new TelephonyRepository();
            bool isSavedSuccess = await telephonyRepository.SaveDisposition(dispositionId, callerId);
            return new JsonResult { Data = isSavedSuccess, JsonRequestBehavior = JsonRequestBehavior.DenyGet };
        }

        [HttpPost]
        public JsonResult GetDispositionList()
        {
            DispositionRepository dispositionRepository = new DispositionRepository();
            var dispositions = dispositionRepository.GetDispositions();
            return new JsonResult { Data = dispositions, JsonRequestBehavior = JsonRequestBehavior.DenyGet };
        }
        
        [HttpPost]
        public ActionResult AllocateAgentActiveCall()
        {
            var agentViewModel = GetLogOnSessionModel();
            if (agentViewModel.ExtensionNo > 0)
            {
                TelephonyRepository telephonyRepository = new TelephonyRepository();
                TsapiService.Instance.AllocateAgentActiveCall(agentViewModel.ExtensionNo);
                return new JsonResult {Data = true,JsonRequestBehavior = JsonRequestBehavior.DenyGet };
            }
            return new JsonResult { Data = false, JsonRequestBehavior = JsonRequestBehavior.DenyGet };
        }
        
        #region Commented Code
        //private void CallClearedNotification()
        //{
        //    //Get the connection string from the Web.Config file. Make sure that the key exists and it is the connection string for the Notification Database and the NotificationList Table that we created


        //    //We have selected the entire table as the command, so SQL Server executes this script and sees if there is a change in the result, raise the event
        //    string commandText = @"Select CallStatus From dbo.tbl_AutoDial_Call_Diversion where CallStatus='C' and ExtensionNo = '" + this.ExtensionNo + "'";

        //    try
        //    {
        //        //Start the SQL Dependency

        //        using (SqlCommand command = new SqlCommand(commandText, connection))
        //        {
        //            if (connection.State == ConnectionState.Closed)
        //                connection.Open();

        //            command.Notification = null;
        //            var sqlDependency = new SqlDependency(command);


        //            sqlDependency.OnChange += new OnChangeEventHandler(sqlCallClearedDependency_OnChange);

        //            // NOTE: You have to execute the command, or the notification will never fire.
        //            string callStatus = (string)command.ExecuteScalar();

        //            if (callStatus == "C")
        //            {
        //                var context = GlobalHost.ConnectionManager.GetHubContext<TelephonyHub>();
        //                context.Clients.User(ExtensionNo.ToString()).clearedAgentCall();
        //            }
        //        }
        //    }
        //    catch (Exception ex)
        //    {
        //        logger.Error(ex);
        //    }
        //}

        //private void sqlCallClearedDependency_OnChange(object sender, SqlNotificationEventArgs e)
        //{
        //    try
        //    {
        //        if (e.Type == SqlNotificationType.Change)
        //        {
        //            CallClearedNotification();
        //        }
        //        //Call the RegisterNotification method again
        //    }
        //    catch (Exception ex)
        //    {
        //        logger.Error(ex);
        //    }
        //}

        #endregion
    }
}