﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace AutoDialOut.DataAccessLayer
{
    public   interface ICrud<T>
    {
        bool Insert(T obj);
        bool Update(T obj);
        Task<bool> UpdateAsync(T obj);
        bool Delete(T obj);
        DataSet Select(T obj);
        Task<DataSet> SelectAsync(T obj);
        object GetScalerRecord(T obj);
    }
}
