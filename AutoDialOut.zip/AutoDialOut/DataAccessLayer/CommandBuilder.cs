﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Data.SqlClient;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace AutoDialOut.DataAccessLayer
{
    public class CommandBuilder : ICommand
    {
        private IConnection connection = null;
        private SqlConnection sqlConnection = null;
        public CommandBuilder()
        {
            connection = new ConnectionManager();
            sqlConnection = connection.Connection;
        }
        public string CommandText
        { get; set; }
        public string SpName
        { get; set; }
        public List<SqlParameter> SqlParams { get; set; }
        /// <summary>
        /// For Insert Update and Delete Queries
        /// </summary>
        /// <returns></returns>
        public bool Execute()
        {
            bool IsExecuted = false;
            using (sqlConnection)
            {
                try
                {
                    if (sqlConnection.State ==  ConnectionState.Closed)
                        sqlConnection.Open();

                    using (var sqlCommand = new SqlCommand(CommandText, sqlConnection))
                    {
                        sqlCommand.CommandType = !string.IsNullOrEmpty(CommandText) ?
                                        CommandType.Text : CommandType.StoredProcedure;
                        sqlCommand.CommandText = !string.IsNullOrEmpty(CommandText) ?
                                        CommandText : SpName;
                        if (SqlParams != null && SqlParams.Count > 0)
                        {
                            SqlParams.ForEach(p => sqlCommand.Parameters.Add(p));
                        }
                        IsExecuted = sqlCommand.ExecuteNonQuery() > 0;
                    }
                }
                catch (Exception)
                {
                    //Handle Exception Here
                }
            }
            return IsExecuted;
        }

        public async Task<bool> ExecuteAsync()
        {
            bool IsExecuted = false;
            using (sqlConnection)
            {
                try
                {
                    if (sqlConnection.State == ConnectionState.Closed)
                        sqlConnection.Open();

                    using (var sqlCommand = new SqlCommand(CommandText, sqlConnection))
                    {
                        sqlCommand.CommandType = !string.IsNullOrEmpty(CommandText) ?
                                        CommandType.Text : CommandType.StoredProcedure;
                        sqlCommand.CommandText = !string.IsNullOrEmpty(CommandText) ?
                                        CommandText : SpName;
                        if (SqlParams != null && SqlParams.Count > 0)
                        {
                            SqlParams.ForEach(p => sqlCommand.Parameters.Add(p));
                        }
                        IsExecuted = await sqlCommand.ExecuteNonQueryAsync() > 0;
                    }
                }
                catch (Exception)
                {
                    //Handle Exception Here
                }
            }
            return IsExecuted;
        }

        /// <summary>
        /// /// For Select Queries
        /// </summary>
        /// <returns></returns>
        public DataSet SelectData()
        {
            var ds = new DataSet();
            using (sqlConnection)
            {
                try
                {
                    if (sqlConnection.State == ConnectionState.Closed)
                         sqlConnection.Open();
                    using (var sqlCommand = new SqlCommand(CommandText, sqlConnection))
                    {
                        sqlCommand.CommandType = !string.IsNullOrEmpty(CommandText) ?
                            CommandType.Text : CommandType.StoredProcedure;
                        sqlCommand.CommandText = !string.IsNullOrEmpty(CommandText) ?
                            CommandText : SpName;

                        if (SqlParams != null && SqlParams.Count > 0)
                            SqlParams.ForEach(p => sqlCommand.Parameters.Add(p));
                        var adapter = new SqlDataAdapter(sqlCommand);
                        adapter.Fill(ds);
                    }
                }
                catch (Exception)
                {
                    //Handle Exception Here
                }

            }
            return ds;
        }

        public Object GetScalerRecord()
        {
            using (sqlConnection)
            {
                try
                {
                    if (sqlConnection.State == ConnectionState.Closed)
                        sqlConnection.Open();
                    using (var sqlCommand = new SqlCommand(CommandText, sqlConnection))
                    {
                        sqlCommand.CommandType = !string.IsNullOrEmpty(CommandText) ?
                            CommandType.Text : CommandType.StoredProcedure;
                        sqlCommand.CommandText = !string.IsNullOrEmpty(CommandText) ?
                            CommandText : SpName;

                        if (SqlParams != null && SqlParams.Count > 0)
                            SqlParams.ForEach(p => sqlCommand.Parameters.Add(p));

                        return sqlCommand.ExecuteScalar();
                    }
                }
                catch (Exception)
                {
                    //Handle Exception Here
                }

            }
            return null;
        }

        /// <summary>
        /// /// For Select Queries
        /// </summary>
        /// <returns></returns>
        public async Task<DataSet> SelectDataAsync()
        {
            var ds = new DataSet();
            using (sqlConnection)
            {
                try
                {
                    if (sqlConnection.State == ConnectionState.Closed)
                        sqlConnection.Open();
                    using (var sqlCommand = new SqlCommand(CommandText, sqlConnection))
                    {
                        sqlCommand.CommandType = !string.IsNullOrEmpty(CommandText) ?
                            CommandType.Text : CommandType.StoredProcedure;
                        sqlCommand.CommandText = !string.IsNullOrEmpty(CommandText) ?
                            CommandText : SpName;

                        if (SqlParams != null && SqlParams.Count > 0)
                            SqlParams.ForEach(p => sqlCommand.Parameters.Add(p));
                        var adapter = new SqlDataAdapter(sqlCommand);
                       await Task.Run(()=> adapter.Fill(ds));
                    }
                }
                catch (Exception)
                {
                    //Handle Exception Here
                }

            }
            return ds;
        }
    }
}
