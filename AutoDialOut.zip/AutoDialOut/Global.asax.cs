﻿using Microsoft.AspNet.SignalR;
using NLog;
using AutoDialOut.App_Classes;
using AutoDialOut.Controllers;
using AutoDialOut.Hubs;
using AutoDialOut.Models;
using AutoDialOut.Repository;
using System;
using System.Collections.Generic;
using System.Configuration;
using System.Data;
using System.Data.SqlClient;
using System.Linq;
using System.Threading.Tasks;
using System.Web;
using System.Web.Mvc;
using System.Web.Optimization;
using System.Web.Routing;
using AutoDialOut;
using System.Runtime.InteropServices;

namespace AutoDialOut
{
    public class MvcApplication : System.Web.HttpApplication
    {
        NLog.Logger logger = LogManager.GetLogger("databaseLogger");
        [DllImport("TSAPIApp.dll", CallingConvention = CallingConvention.Cdecl)]
        public static extern bool OpenConnection();
        [DllImport("TSAPIApp.dll", CallingConvention = CallingConvention.Cdecl)]
        public static extern void CloseConnection();

        protected void Application_Start()
        {
            AreaRegistration.RegisterAllAreas();
            FilterConfig.RegisterGlobalFilters(GlobalFilters.Filters);
            RouteConfig.RegisterRoutes(RouteTable.Routes);
            BundleConfig.RegisterBundles(BundleTable.Bundles);
           // OpenConnection();
           // Simulator.Instance.OpenStream();
        }

        protected void Application_Error(object sender, EventArgs e)
        {
            Exception exception = Server.GetLastError();
            Server.ClearError();
            Response.Redirect("/Account/Login");
        }

        protected void Application_End(object sender, EventArgs e)
        {
          // CloseConnection();
          // Simulator.Instance.AbortStream();
        }
        protected void Session_End(object sender, EventArgs e)
        {
            var session = this.Session;
            if (session != null)
            {
                var logOnSession = session["LogOnSession"] as LoggedInAgentViewModel;
                if(logOnSession != null)
                {
                    new LoginRepository().DeActivateLogin(logOnSession.AgentId, logOnSession.ExtensionNo, logOnSession.UniqueIdentifier);
                }
            }
        }

        
    }
}

