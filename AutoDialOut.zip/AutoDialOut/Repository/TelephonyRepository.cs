﻿using NLog;
using AutoDialOut.App_Classes;
using System;
using System.Collections.Generic;
using System.Data.SqlClient;
using System.Diagnostics;
using System.Linq;
using System.Threading.Tasks;
using System.Web;
using AutoDialOut.Repository;
using AutoDialOut.DataAccessLayer;
using System.Data;

namespace AutoDialOut.Repository
{
    public class TelephonyRepository
    {
        NLog.Logger logger = LogManager.GetLogger("databaseLogger");

        public async Task<DropCall> GetDropCallerInfo(int callerId)
        {
            DropCall dropCall = null;
            try
            {
                var objCall = new CallInfo();
                var cmd = new CommandBuilder();
                cmd.SpName = "sp_GetDropCallerInfo";
                cmd.SqlParams = new List<SqlParameter>()
                {
                    new SqlParameter("@DropOutId",callerId)
                };
                var ds = await objCall.SelectAsync(cmd);
                if (ds.Tables.Count > 0)
                {
                    var row = ds.Tables[0].Rows[0];
                    dropCall = new DropCall();
                    dropCall.CallerName = row["CallerName"] != DBNull.Value ? Convert.ToString(row["CallerName"]) : string.Empty;
                    dropCall.CallerMobile = row["CallerMobile"] != DBNull.Value ? Convert.ToString(row["CallerMobile"]) : string.Empty;
                    dropCall.CallerEmail = row["CallerEmail"] != DBNull.Value ? Convert.ToString(row["CallerEmail"]) : string.Empty;
                    dropCall.FlightDetails = row["FlightDetails"] != DBNull.Value ? Convert.ToString(row["FlightDetails"]) : string.Empty;
                    dropCall.PaxCount = row["PaxCount"] != DBNull.Value ? Convert.ToInt32(row["PaxCount"]) : 0;
                    dropCall.PaxNames = row["PaxNames"] != DBNull.Value ? Convert.ToString(row["PaxNames"]) : string.Empty;
                    dropCall.LostPageName = row["LostPageName"] != DBNull.Value ? Convert.ToString(row["LostPageName"]) : string.Empty;
                    dropCall.Priority = row["Priority"] != DBNull.Value ? Convert.ToString(row["Priority"]) : string.Empty;
                }
            }
            catch (Exception ex)
            {
                logger.Error(ex);
            }
            return dropCall;
        }

        public List<OutgoingCall> GetAllOutgoingCalls()
        {
            List<OutgoingCall> outgoingCallList = new List<OutgoingCall>();
            try
            {
                var objCall = new CallInfo();
                var cmd = new CommandBuilder();
                cmd.SpName = "sp_GetActiveOutgoingCalls";
                var ds = objCall.Select(cmd);
                if (ds.Tables.Count > 0)
                {
                    foreach (DataRow row in ds.Tables[0].Rows)
                    {
                        outgoingCallList.Add(new OutgoingCall
                        {
                            CallerId = row["CallerId"] != DBNull.Value ? Convert.ToInt32(row["CallerId"]) : 0,
                            CallerMobile = row["CallerMobile"] != DBNull.Value ? Convert.ToString(row["CallerMobile"]) : string.Empty,
                            ExtensionNo = row["ExtensionNo"] != DBNull.Value ? Convert.ToString(row["ExtensionNo"]) : string.Empty,
                            AgentId = row["AgentId"] != DBNull.Value ? Convert.ToInt32(row["AgentId"]) : 0,
                            CallerName = row["CallerName"] != DBNull.Value ? Convert.ToString(row["CallerName"]) : string.Empty,
                            CallOutgoingDateTime = row["CallOutgoingDateTime"] != DBNull.Value ? Convert.ToDateTime(row["CallOutgoingDateTime"]) : DateTime.MinValue,
                            CallEstablishedDateTime = row["CallEstablishedDateTime"] != DBNull.Value ? Convert.ToDateTime(row["CallEstablishedDateTime"]) : DateTime.MinValue,
                            CallEndDateTime = row["CallEndDateTime"] != DBNull.Value ? Convert.ToDateTime(row["CallEndDateTime"]) : DateTime.MinValue,
                            CallStatus = row["CallStatus"] != DBNull.Value ? Convert.ToString(row["CallStatus"]) : string.Empty,
                            DropOutCallerId = row["DropOutId"] != DBNull.Value ? Convert.ToInt32(row["DropOutId"]) : 0
                        });
                    }
                }
            }
            catch (Exception ex)
            {
                logger.Error(ex);
            }
            return outgoingCallList;
        }

        public OutgoingCall GetAgentActiveOutgoingCall(int extensionNo)
        {
            OutgoingCall outgoingCall = null;
            try
            {
                var objCall = new CallInfo();
                var cmd = new CommandBuilder();
                cmd.SpName = "sp_GetAgentActiveOutgoingCall";
                cmd.SqlParams = new List<SqlParameter>()
                {
                    new SqlParameter("@ExtensionNo",extensionNo)
                };
                var ds = objCall.Select(cmd);
                if (ds.Tables.Count > 0)
                {
                    var row = ds.Tables[0].Rows[0];
                    outgoingCall = new OutgoingCall
                    {
                        CallerId = row["CallerId"] != DBNull.Value ? Convert.ToInt32(row["CallerId"]) : 0,
                        CallerMobile = row["CallerMobile"] != DBNull.Value ? Convert.ToString(row["CallerMobile"]) : string.Empty,
                        ExtensionNo = row["ExtensionNo"] != DBNull.Value ? Convert.ToString(row["ExtensionNo"]) : string.Empty,
                        CallerName = row["CallerName"] != DBNull.Value ? Convert.ToString(row["CallerName"]) : string.Empty,
                        CallOutgoingDateTime = row["CallOutgoingDateTime"] != DBNull.Value ? Convert.ToDateTime(row["CallOutgoingDateTime"]) : DateTime.MinValue,
                        CallEstablishedDateTime = row["CallEstablishedDateTime"] != DBNull.Value ? Convert.ToDateTime(row["CallEstablishedDateTime"]) : DateTime.MinValue,
                        CallEndDateTime = row["CallEndDateTime"] != DBNull.Value ? Convert.ToDateTime(row["CallEndDateTime"]) : DateTime.MinValue,
                        CallStatus = row["CallStatus"] != DBNull.Value ? Convert.ToString(row["CallStatus"]) : string.Empty,
                        DropOutCallerId = row["DropOutId"] != DBNull.Value ? Convert.ToInt32(row["DropOutId"]) : 0
                    };
                }
            }
            catch (Exception ex)
            {
                logger.Error(ex);
            }
            return outgoingCall;
        }

        public async Task<bool> CloseCurrentCall(int callerId)
        {
            try
            {
                var objCall = new CallInfo();
                var cmd = new CommandBuilder();
                cmd.SpName = "sp_CloseCurrentCall";
                cmd.SqlParams = new List<SqlParameter>()
                {
                    new SqlParameter("@CallerId",callerId)
                };
                return await objCall.UpdateAsync(cmd);
            }
            catch (Exception ex)
            {
                logger.Error(ex);
            }
            return false;
        }

        public bool ReAssignCurrentCall(int callerId)
        {
            try
            {
                var objCall = new CallInfo();
                var cmd = new CommandBuilder();
                cmd.SpName = "sp_ReAssignCurrentCall";
                cmd.SqlParams = new List<SqlParameter>()
                {
                    new SqlParameter("@CallerId",callerId)
                };
                return objCall.Update(cmd);
            }
            catch (Exception ex)
            {
                logger.Error(ex);
            }
            return false;
        }

        public async Task<bool> SaveDisposition(int dispositionId, int callerId)
        {
            try
            {
                var objCall = new CallInfo();
                var cmd = new CommandBuilder();
                cmd.SpName = "sp_SaveDispositionForActiveCall";
                cmd.SqlParams = new List<SqlParameter>()
                {
                    new SqlParameter("@DispositionId",dispositionId),
                    new SqlParameter("@CallerId",callerId)
                };
                return await objCall.UpdateAsync(cmd);
            }
            catch (Exception ex)
            {
                logger.Error(ex);
            }
            return false;
        }

        public bool UpdateAgentUnprocessedCalls(int agentId,int extensionNo)
        {
            try
            {
                var objCall = new CallInfo();
                var cmd = new CommandBuilder();
                cmd.SpName = "sp_UpdateAgentUnprocessedCalls";
                cmd.SqlParams = new List<SqlParameter>()
                {
                    new SqlParameter("@AgentId",agentId),
                    new SqlParameter("@ExtensionNo",extensionNo)
                };
                return  objCall.Update(cmd);
            }
            catch (Exception ex)
            {
                logger.Error(ex);
            }
            return false;
        } 
    }

    public class DispositionRepository
    {
        NLog.Logger logger = LogManager.GetLogger("databaseLogger");
        public List<Disposition> GetDispositions()
        {
            List<Disposition> dispositionList = new List<Disposition>();
            try
            {
                var objCall = new CallInfo();
                var cmd = new CommandBuilder();
                cmd.CommandText = "Select DispositionId,DispositionName from tbl_ScreenPopup_Disposition where Status='A'";
                var ds = objCall.Select(cmd);
                if (ds.Tables.Count > 0)
                {
                    foreach (DataRow row in ds.Tables[0].Rows)
                    {

                        dispositionList.Add(new Disposition
                        {
                            Value = row["DispositionId"] != DBNull.Value ? Convert.ToInt32(row["DispositionId"]) : 0,
                            Name = row["DispositionName"] != DBNull.Value ? Convert.ToString(row["DispositionName"]) : string.Empty
                        });
                    }
                }
            }
            catch (Exception ex)
            {
                logger.Error(ex);
            }
            return dispositionList;
        }


    }
    public class AgentRepository
    {
        NLog.Logger logger = LogManager.GetLogger("databaseLogger");
        public Agent Find(int agentId,  string password)
        {
            Agent agent =  null;
            try
            {
                var objCall = new CallInfo();
                var cmd = new CommandBuilder();
                cmd.SpName = "sp_GetAgentInfo";
                cmd.SqlParams = new List<SqlParameter>()
                {
                    new SqlParameter("@AgentId",agentId),
                    new SqlParameter("@AgentPassword",password)
                };
                var ds = objCall.Select(cmd);
                if (ds.Tables.Count > 0)
                {
                    var row = ds.Tables[0].Rows[0];
                    agent = new Agent
                    {
                        AgentId = row["AgentId"] != DBNull.Value ? Convert.ToInt32(row["AgentId"]) : 0,
                        AgentName = row["AgentName"] != DBNull.Value ? Convert.ToString(row["AgentName"]) : string.Empty,
                        AgentPassword = row["AgentPassword"] != DBNull.Value ? Convert.ToString(row["AgentPassword"]) : string.Empty,
                        SkillSet = row["SkillSet"] != DBNull.Value ? Convert.ToString(row["SkillSet"]) : string.Empty,
                    };
                }
            }
            catch (Exception ex)
            {
                logger.Error(ex);
            }
            return agent;
        }

        public void AddAgent(int agentId,string agentPassword)
        {
            try
            {
                try
                {
                    var objCall = new CallInfo();
                    var cmd = new CommandBuilder();
                    cmd.SpName = "sp_CreateAgent";
                    cmd.SqlParams = new List<SqlParameter>()
                    {
                        new SqlParameter("@AgentId",agentId),
                        new SqlParameter("@AgentPassword",agentPassword)
                    };
                    objCall.Insert(cmd);
                }
                catch (Exception ex)
                {
                    logger.Error(ex);
                }
            }
            catch (Exception ex)
            {
                logger.Error(ex);
            }
        }

    }

    public class ExtensionRepository
    {
        NLog.Logger logger = LogManager.GetLogger("databaseLogger");
        public Extension Find(int extensionNo)
        {
            Extension extension = null;
            try
            {
                var objCall = new CallInfo();
                var cmd = new CommandBuilder();
                cmd.SpName = "sp_GetExtensionInfo";
                cmd.SqlParams = new List<SqlParameter>()
                {
                    new SqlParameter("@ExtensionNo",extensionNo)
                };
                var ds = objCall.Select(cmd);
                if (ds.Tables.Count > 0)
                {
                    var row = ds.Tables[0].Rows[0];
                    extension = new Extension
                    {
                        ExtensionNo = row["ExtensionNo"] != DBNull.Value ? Convert.ToInt32(row["ExtensionNo"]) : 0,
                        Status = row["Status"] != DBNull.Value ? Convert.ToString(row["Status"]) : string.Empty
                    };
                }
            }
            catch (Exception ex)
            {
                logger.Error(ex);
            }
            return extension;
        }

        public void AddExtension(int extensionNo)
        {
            try
            {
                var objCall = new CallInfo();
                var cmd = new CommandBuilder();
                cmd.SpName = "sp_CreateExtension";
                cmd.SqlParams = new List<SqlParameter>()
                    {
                        new SqlParameter("@ExtensionNo",extensionNo)
                    };
                objCall.Insert(cmd);
            }
            catch (Exception ex)
            {
                logger.Error(ex);
            }
        }

    }

    public class LoginRepository
    {
        NLog.Logger logger = LogManager.GetLogger("databaseLogger");

        public List<LoginUser> GetActiveAgents()
        {
            try
            {
                List<LoginUser> loginUsers = null;
                var objCall = new CallInfo();
                var cmd = new CommandBuilder();
                cmd.CommandText = "Select AgentId,ExtensionNo from tbl_AutoDial_Login where LoginStatus='A' ";
                DataSet ds = objCall.Select(cmd);
                if (ds.Tables.Count > 0)
                {
                    loginUsers = new List<LoginUser>();
                    foreach (DataRow row in ds.Tables[0].Rows)
                    {

                        loginUsers.Add(new LoginUser
                        {
                            AgentId = row["AgentId"] != DBNull.Value ? Convert.ToInt32(row["AgentId"]) : 0,
                            ExtensionNo = row["ExtensionNo"] != DBNull.Value ? Convert.ToInt32(row["ExtensionNo"]) : 0
                        });
                    }
                }

                return loginUsers;
            }
            catch (Exception ex)
            {
                logger.Error(ex);
                throw ex;
            }
        }

        public bool CheckExtensionAvailability(int agentId, int extensionNo)
        {

            try
            {
                var objCall = new CallInfo();
                var cmd = new CommandBuilder();
                cmd.SpName = "sp_CheckExtensionAvailability";
                cmd.SqlParams = new List<SqlParameter>()
                {
                    new SqlParameter("@AgentId",agentId)
                };
                object record = objCall.GetScalerRecord(cmd);
                return record != DBNull.Value ? Convert.ToBoolean(record) : false;
            }
            catch (Exception ex)
            {
                logger.Error(ex);
            }
            return false;
        }

        public int GetAgentLoggedInExtension(int agentId)
        {
            int extensionNo = 0;
            try
            {
                var objCall = new CallInfo();
                var cmd = new CommandBuilder();
                cmd.SpName = "sp_GetAgentLoggedInExtension";
                cmd.SqlParams = new List<SqlParameter>()
                {
                    new SqlParameter("@AgentId",agentId)
                };
                object record = objCall.GetScalerRecord(cmd);
                return record != DBNull.Value ? Convert.ToInt32(record) : 0;
            }
            catch (Exception ex)
            {
                logger.Error(ex);
            }
            return extensionNo;
        }

        public void AddLoginRecord(int agentId, int extensionNo,string agentLoggedInType,string uniqueIdentifier)
        {
            try
            {
                var objCall = new CallInfo();
                var cmd = new CommandBuilder();
                cmd.SpName = "sp_CreateLoginLog";
                cmd.SqlParams = new List<SqlParameter>()
                {
                    new SqlParameter("@AgentId",agentId),
                    new SqlParameter("@ExtensionNo",extensionNo),
                  //  new SqlParameter("@AgentLoggedInType",agentLoggedInType),
                    new SqlParameter("@SessionId",uniqueIdentifier)
                };
                objCall.Insert(cmd);
            }
            catch (Exception ex)
            {
                logger.Error(ex);
            }
        }

        public void LogoutAgentExistingSession(int agentId)
        {
            try
            {
                var objCall = new CallInfo();
                var cmd = new CommandBuilder();
                cmd.SpName = "sp_LogoutAgentExistingSession";
                cmd.SqlParams = new List<SqlParameter>()
                {
                    new SqlParameter("@AgentId",agentId)
                };
                objCall.Update(cmd);
            }
            catch (Exception ex)
            {
                logger.Error(ex);
            }
        }

        public void ReActivateLogin(int agentId, int extensionNo,string uniqueIdentifier)
        {
            try
            {
                var objCall = new CallInfo();
                var cmd = new CommandBuilder();
                cmd.SpName = "sp_ReActivateAgentLogin";
                cmd.SqlParams = new List<SqlParameter>()
                    {
                        new SqlParameter("@AgentId",agentId),
                        new SqlParameter("@ExtensionNo",extensionNo),
                        new SqlParameter("@SessionId",uniqueIdentifier)
                    };
                objCall.Update(cmd);
            }
            catch (Exception ex)
            {
                logger.Error(ex);
            }
        }

        public void DeActivateLogin(int agentId, int extensionNo, string uniqueIdentifier)
        {
            try
            {
                var objCall = new CallInfo();
                var cmd = new CommandBuilder();
                cmd.SpName = "sp_DeActivateAgentLogin";
                cmd.SqlParams = new List<SqlParameter>()
                    {
                        new SqlParameter("@AgentId",agentId),
                        new SqlParameter("@ExtensionNo",extensionNo),
                        new SqlParameter("@SessionId",uniqueIdentifier)
                    };
                objCall.Update(cmd);
            }
            catch (Exception ex)
            {
                logger.Error(ex);
            }
        }

        public long GetAgentMonitorCrossRefId(int agentId, int extensionNo)
        {
            try
            {
                var objCall = new CallInfo();
                var cmd = new CommandBuilder();
                cmd.CommandText = "Select top 1 MonitorCrossRefInvokeId from tbl_AutoDial_Login Where AgentId=@AgentId and ExtensionNo=@ExtensionNo order by LoginDateTime desc";
                cmd.SqlParams = new List<SqlParameter>()
                {
                    new SqlParameter("@AgentId",agentId),
                    new SqlParameter("@ExtensionNo",extensionNo)
                };
                object record = objCall.GetScalerRecord(cmd);
                return record != DBNull.Value ? Convert.ToInt64(record) : 0;
            }
            catch (Exception ex)
            {
                logger.Error(ex);
            }
            return extensionNo;
        }

    }
}