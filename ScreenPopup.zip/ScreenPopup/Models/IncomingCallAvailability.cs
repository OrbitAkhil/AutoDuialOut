﻿using Newtonsoft.Json;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace ScreenPopup.Models
{
    public class IncomingCallAvailability
    {
        [JsonProperty(PropertyName = "CallerId")]
        public int CallerId { get; set; }
        [JsonProperty(PropertyName = "AgentId")]
        public int AgentId { get; set; }
        [JsonProperty(PropertyName = "CallerMobile")]
        public string CallerMobile { get; set; }
        [JsonProperty(PropertyName = "ExtensionNo")]
        public string ExtensionNo { get; set; }
        [JsonProperty(PropertyName = "CallIncomingDateTime")]
        public System.DateTime CallIncomingDateTime { get; set; }
        [JsonProperty(PropertyName = "CallEndDateTime")]
        public System.DateTime CallEndDateTime { get; set; }
        
    }
}