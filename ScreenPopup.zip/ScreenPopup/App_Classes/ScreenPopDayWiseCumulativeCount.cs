﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace ScreenPopup.App_Classes
{
    public class ScreenPopDayWiseCumulativeCount
    {
        public DateTime CallIncomingDate { get; set; }
        public int TotalCalls { get; set; }
        public int TotalLoggedInAgents { get; set; }
        public int TotalAgentAttendedCalls { get; set; }
        public decimal AttendCallPercentile { get; set; }
    }
}