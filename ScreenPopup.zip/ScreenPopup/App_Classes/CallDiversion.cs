﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace ScreenPopup.App_Classes
{
    public class CallDiversion
    {
        public int CallerId { get; set; }
        public int ExtensionNo { get; set; }
        public int AgentNo { get; set; }
        public DateTime CallIncomingDateTime { get; set; }
        public DateTime CallEstablishDateTime { get; set; }
        public DateTime CallEndDateTime { get; set; }
        public string CallStatus { get; set; }
    }
}