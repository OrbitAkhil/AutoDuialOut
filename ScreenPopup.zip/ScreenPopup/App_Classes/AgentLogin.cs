﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace ScreenPopup.App_Classes
{
    public class AgentLogin
    {
        public int AgentId { get; set; }
        public int ExtensionNo { get; set; }
        public string LoginStatus { get; set; }
        public DateTime LoginDateTime { get; set; }
    }
}