﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace ScreenPopup.App_Classes
{
    public class AgentWiseCallSummary
    {
        public int AgentId { get; set; }
        public int CallCount { get; set; }
        public DateTime CallIncomingDate { get; set; }
    }
}