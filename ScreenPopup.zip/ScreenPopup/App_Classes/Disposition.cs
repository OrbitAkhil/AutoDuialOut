﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace ScreenPopup.App_Classes
{
    public class Disposition
    {
        public int GroupId { get; set; }
        public string GroupDescription { get; set; }
        
        public int SubGroupId { get; set; }
        public string SubGroupDescription { get; set; }

        public int DispositionId { get; set; }
        public string DispositionDescription { get; set; }
    }
}