﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace ScreenPopup.App_Classes
{
    public class CustomerInfo
    {
        public string CustomerType {get;set;}
        public string CustomerName {get;set;}
        public int TodaysCallCount { get; set; }
        public bool IsTravelAgentCall { get; set; }
        public List<CallerHistory> CallerHistory { get; set; }
    }

    public class CallerHistory
    {
        public string AgentId { get; set; }
        public string AgentName { get; set; }
        public System.DateTime CallIncomingDateTime { get; set; }
        public string CallStatus { get; set; }
        public string ExtensionNo { get; set; }
        public Nullable<System.DateTime> CallEndDateTime { get; set; }
        public Nullable<System.DateTime> CallEstablishedDateTime { get; set; }
        public string Disposition { get; set; }
    }
}