﻿using Microsoft.AspNet.SignalR;
using NLog;
using ScreenPopup.App_Classes;
using ScreenPopup.Controllers;
using ScreenPopup.Models;
using ScreenPopup.Repository;
using System;
using System.Collections.Generic;
using System.Configuration;
using System.Data;
using System.Data.SqlClient;
using System.Linq;
using System.Threading.Tasks;
using System.Web;
using System.Web.Mvc;
using System.Web.Optimization;
using System.Web.Routing;

namespace ScreenPopup
{
    public class MvcApplication : System.Web.HttpApplication
    {
        NLog.Logger logger = LogManager.GetLogger("databaseLogger");
        protected void Application_Start()
        {
            AreaRegistration.RegisterAllAreas();
            FilterConfig.RegisterGlobalFilters(GlobalFilters.Filters);
            RouteConfig.RegisterRoutes(RouteTable.Routes);
            BundleConfig.RegisterBundles(BundleTable.Bundles);
          
        }

        protected void Application_Error(object sender, EventArgs e)
        {
            Exception exception = Server.GetLastError();
            Server.ClearError();
            Response.Redirect("/Account/Login");
        }

        protected void Application_End(object sender, EventArgs e)
        {
           // SqlDependency.Stop(ConfigurationManager.ConnectionStrings["TelephonyConnection"].ConnectionString);
        }
        protected void Session_End(object sender, EventArgs e)
        {
            var session = this.Session;
            if (session != null)
            {
                var logOnSession = session["LogOnSession"] as LoggedInAgentViewModel;
                if(logOnSession != null)
                {
                    new LoginRepository().DeActivateLogin(logOnSession.AgentId, logOnSession.ExtensionNo, logOnSession.UniqueIdentifier);
                }
            }
        }

        
    }
}

