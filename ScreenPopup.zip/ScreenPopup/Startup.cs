﻿using Microsoft.AspNet.SignalR;
using Microsoft.Owin;
using Owin;
using System.Configuration;

[assembly: OwinStartupAttribute(typeof(ScreenPopup.Startup))]
namespace ScreenPopup
{
    public partial class Startup
    {
        public void Configuration(IAppBuilder app)
        {
            ConfigureAuth(app);
            var idProvider = new CustomUserIdProvider();

            GlobalHost.DependencyResolver.Register(typeof(IUserIdProvider), () => idProvider);

          //  string sqlConnectionString = ConfigurationManager.ConnectionStrings["TelephonyConnection"].ConnectionString;
          //  GlobalHost.DependencyResolver.UseSqlServer(sqlConnectionString);
           // app.MapSignalR();

           
        }
    }
}
