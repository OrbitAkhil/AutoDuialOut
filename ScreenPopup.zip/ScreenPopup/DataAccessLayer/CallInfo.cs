﻿using ScreenPopup.DataAccessLayer;
using System;
using System.Collections.Generic;
using System.Data;
using System.Linq;
using System.Threading.Tasks;
using System.Web;

namespace ScreenPopup.DataAccessLayer
{
    public class CallInfo : ICrud<ICommand>
    {
        public async Task<bool> Insert(ICommand obj)
        {
            return await obj.Execute();
        }

        public bool InsertRecord(ICommand obj)
        {
            return obj.ExecuteSync();
        }
        

        public async Task<bool> Update(ICommand obj)
        {
            return await obj.Execute();
        }

        public async Task<bool> Delete(ICommand obj)
        {
            return await obj.Execute();
        }

        public  DataSet Select(ICommand obj)
        {
            return obj.SelectData();
        }

        public object GetScalerRecord(ICommand obj)
        {
            return obj.GetScalerRecord();
        }
    }
}