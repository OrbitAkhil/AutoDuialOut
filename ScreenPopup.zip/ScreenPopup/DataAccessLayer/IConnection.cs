﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Data.SqlClient;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ScreenPopup.DataAccessLayer
{
    public interface IConnection
    {
        SqlConnection Connection { get; }
    }

    public interface ICommand
    {
        string CommandText  // For Inline Sql
        { get; set; }
        string SpName
        { get; set; }
        List<SqlParameter> SqlParams { get; set; }
        Task<bool> Execute();
        bool ExecuteSync();
        DataSet SelectData();
        Object GetScalerRecord();
    }

}
