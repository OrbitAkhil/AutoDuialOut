﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ScreenPopup.DataAccessLayer
{
    public   interface ICrud<T>
    {
        bool InsertRecord(T obj);
        Task<bool> Insert(T obj);
        Task<bool> Update(T obj);
        Task<bool> Delete(T obj);
        DataSet Select(T obj);
        object GetScalerRecord(T obj);
    }
}
