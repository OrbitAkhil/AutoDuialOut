﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Security.Claims;
using System.Threading.Tasks;
using System.Web;
using System.Web.Mvc;
using Microsoft.AspNet.Identity;
using Microsoft.AspNet.Identity.EntityFramework;
using Microsoft.Owin.Security;
using ScreenPopup.Models;
using ScreenPopup.Repository;
using ScreenPopup.App_Classes;
using System.Data.SqlClient;
using System.Configuration;
using NLog;
using System.Net;

namespace ScreenPopup.Controllers
{
    [Authorize]
    [ErrorHandle]
    public class AccountController : ApplicationController<LoggedInAgentViewModel>
    {
        private static NLog.Logger logger = LogManager.GetLogger("databaseLogger");
        

        //
        // GET: /Account/Login
        [AllowAnonymous]
        public ActionResult Login(string returnUrl)
        {
            this.AbandonSession();
            //AuthenticationManager.SignOut();

            ViewBag.ReturnUrl = returnUrl;
            return View(new LoginViewModel() { ShowLogoutPopup = "false" });
        }

        //
        // POST: /Account/Login
        [HttpPost]
        [AllowAnonymous]
        [ValidateAntiForgeryToken]
        public async Task<ActionResult> Login(LoginViewModel model, string returnUrl)
        {
            if (ModelState.IsValid)
            {
                
                AgentRepository agentRepository = new AgentRepository();
                ExtensionRepository extensionRepository = new ExtensionRepository();
                LoginRepository loginRepository = new LoginRepository();

                
                var agent =  agentRepository.Find(Convert.ToInt32(model.AgentId), model.Password);
                var extension = extensionRepository.Find(Convert.ToInt32(model.ExtensionNo));

                if(agent == null)
                {
                    agentRepository.AddAgent(Convert.ToInt32(model.AgentId),model.Password);                
                }

                if(extension == null)
                {
                    extensionRepository.AddExtension(Convert.ToInt32(model.ExtensionNo));    
                }

                
                if (!loginRepository.CheckExtensionAvailability(Convert.ToInt32(model.AgentId), Convert.ToInt32(model.ExtensionNo)))
                {
                    string unqiueIdentifier = Guid.NewGuid().ToString();
                    loginRepository.AddLoginRecord(Convert.ToInt32(model.AgentId), Convert.ToInt32(model.ExtensionNo), unqiueIdentifier, Request.ServerVariables["REMOTE_ADDR"].ToString(), GetIPAddress());
                    LoggedInAgentViewModel loggedInAgentViewModel = new LoggedInAgentViewModel();
                    loggedInAgentViewModel.AgentId = Convert.ToInt32(model.AgentId);
                    loggedInAgentViewModel.ExtensionNo = Convert.ToInt32(model.ExtensionNo);
                    loggedInAgentViewModel.UniqueIdentifier = unqiueIdentifier;
                    loggedInAgentViewModel.LoginDateTime = DateTime.Now;
                    loggedInAgentViewModel.AgentName = agent.AgentName;
                    SetLogOnSessionModel(loggedInAgentViewModel);
                    if (model.AgentId == ConfigurationManager.AppSettings["AdminUserId"].ToString() && model.ExtensionNo == ConfigurationManager.AppSettings["AdminPassword"].ToString())
                        return RedirectToAction("CummulativeDashboard", "Report");

                    logger.Info(string.Format("Agent {0} logged in with Extension No {1}", model.AgentId, model.ExtensionNo));
                    return RedirectToLocal(returnUrl);
                }
                else
                {
                    model.ShowLogoutPopup = "true";
                    TempData["LoginViewModel"] = model;
                    //ModelState.AddModelError("Error", "Agent is already login by other Extension.");
                }
            }

            // If we got this far, something failed, redisplay form
            return View(model);
        }

        //
        // GET: /Account/Register
        [AllowAnonymous]
        public ActionResult Register()
        {
            //LoginRepository loginRepository = new LoginRepository();
            //loginRepository.LogoutAgentExistingSession();
            return View();
        }


        //
        // GET: /Account/Register
        [AllowAnonymous]
        public ActionResult CheckSession()
        {
            LoginRepository loginRepository = new LoginRepository();
            LoginViewModel model = TempData["LoginViewModel"] as LoginViewModel;
            if (model != null)
            {
                AgentRepository agentRepository = new AgentRepository();
                var agent = agentRepository.Find(Convert.ToInt32(model.AgentId), model.Password);
                loginRepository.LogoutAgentExistingSession(Convert.ToInt32(model.AgentId));
                if (agent != null){
                    if (!loginRepository.CheckExtensionAvailability(Convert.ToInt32(model.AgentId), Convert.ToInt32(model.ExtensionNo)))
                    {
                        string unqiueIdentifier = Guid.NewGuid().ToString();
                        loginRepository.AddLoginRecord(Convert.ToInt32(model.AgentId), Convert.ToInt32(model.ExtensionNo), unqiueIdentifier, Request.ServerVariables["REMOTE_ADDR"].ToString(), GetIPAddress());
                        LoggedInAgentViewModel loggedInAgentViewModel = new LoggedInAgentViewModel();
                        loggedInAgentViewModel.AgentId = Convert.ToInt32(model.AgentId);
                        loggedInAgentViewModel.ExtensionNo = Convert.ToInt32(model.ExtensionNo);
                        loggedInAgentViewModel.UniqueIdentifier = unqiueIdentifier;
                        loggedInAgentViewModel.AgentName = string.IsNullOrEmpty(agent.AgentName) ? "Hello Agent" : agent.AgentName ;
                        loggedInAgentViewModel.LoginDateTime = DateTime.Now;
                        SetLogOnSessionModel(loggedInAgentViewModel);

                        if (model.AgentId == ConfigurationManager.AppSettings["AdminUserId"].ToString() && model.ExtensionNo == ConfigurationManager.AppSettings["AdminPassword"].ToString())
                            return RedirectToAction("CummulativeDashboard", "Report");

                        logger.Info(string.Format("Agent {0} logged in with Extension No {1}", model.AgentId, model.ExtensionNo));
                        return RedirectToAction("Index","Home");
                    }
                }
            }
           
            return RedirectToAction("Login");
        }
        
      
      
        
        
        //
        // POST: /Account/LogOff
        [HttpPost]
        [ValidateAntiForgeryToken]
        [AllowAnonymous]
        public ActionResult LogOff()
        {
            var sessionViewModel = GetLogOnSessionModel();
            if (sessionViewModel != null)
                new LoginRepository().DeActivateLogin(sessionViewModel.AgentId, sessionViewModel.ExtensionNo,sessionViewModel.UniqueIdentifier);

            
            this.AbandonSession();
            return RedirectToAction("Login", "Account");
        }


        //
        // GET: /Account/ExternalLoginFailure
        [AllowAnonymous]
        public ActionResult ExternalLoginFailure()
        {
            return View();
        }

        
        public string GetIPAddress()
        {
            //string strHostName = System.Net.Dns.GetHostName();
            ////IPHostEntry ipHostInfo = Dns.Resolve(Dns.GetHostName()); <-- Obsolete
            //IPHostEntry ipHostInfo = Dns.GetHostEntry(strHostName);
            //IPAddress ipAddress = ipHostInfo.AddressList[0];

            return ConfigurationManager.AppSettings["ServerLocalIp"].ToString();
        }

        #region Helpers
        // Used for XSRF protection when adding external logins
        private const string XsrfKey = "XsrfId";

       
        private void AddErrors(IdentityResult result)
        {
            foreach (var error in result.Errors)
            {
                ModelState.AddModelError("", error);
            }
        }

        

        public enum ManageMessageId
        {
            ChangePasswordSuccess,
            SetPasswordSuccess,
            RemoveLoginSuccess,
            Error
        }

        private ActionResult RedirectToLocal(string returnUrl)
        {
            if (Url.IsLocalUrl(returnUrl))
            {
                return Redirect(returnUrl);
            }
            else
            {
                return RedirectToAction("Index", "Home");
            }
        }

        private class ChallengeResult : HttpUnauthorizedResult
        {
            public ChallengeResult(string provider, string redirectUri) : this(provider, redirectUri, null)
            {
            }

            public ChallengeResult(string provider, string redirectUri, string userId)
            {
                LoginProvider = provider;
                RedirectUri = redirectUri;
                UserId = userId;
            }

            public string LoginProvider { get; set; }
            public string RedirectUri { get; set; }
            public string UserId { get; set; }

            public override void ExecuteResult(ControllerContext context)
            {
                var properties = new AuthenticationProperties() { RedirectUri = RedirectUri };
                if (UserId != null)
                {
                    properties.Dictionary[XsrfKey] = UserId;
                }
                context.HttpContext.GetOwinContext().Authentication.Challenge(properties, LoginProvider);
            }
        }
        #endregion
    }
}