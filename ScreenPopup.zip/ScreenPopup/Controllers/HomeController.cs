﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;
using ScreenPopup.App_Classes;
using System.Web.Helpers;
using ScreenPopup.Repository;
using ScreenPopup.Models;
using NLog;
using System.Configuration;
using System.Data.SqlClient;
using System.Data;
using Microsoft.AspNet.SignalR;
using System.Threading.Tasks; 
namespace ScreenPopup.Controllers
{
    [ErrorHandle]
    public class HomeController : ApplicationController<LoggedInAgentViewModel>
    {
        private static NLog.Logger logger = LogManager.GetLogger("databaseLogger");
        private string ExtensionNo { get; set; }
        
        public ActionResult Index()
        {
            
            var agentViewModel = GetLogOnSessionModel();

            if (agentViewModel.ExtensionNo > 0)
            {
                this.ExtensionNo = agentViewModel.ExtensionNo.ToString();
            }

            //if (new TelephonyRepository().IsSqlDependencyInActive(ConfigurationManager.AppSettings["ServerLocalIp"].ToString()))
            //{
            //    TsapiService.Instance.RestartSqlDependencyWithNotification();
            //}
            
            if (agentViewModel == null)
                return RedirectToAction("Login", "Account");

            logger.Info("You have visited the Index view");
            return View(new TelephonyViewModel() { AgentId = agentViewModel.AgentId,AgentName = agentViewModel.AgentName, ExtensionNo= Convert.ToString(agentViewModel.ExtensionNo) , UniqueIdentifier= agentViewModel.UniqueIdentifier});
        }


        [HttpPost]
        public async Task<JsonResult> GetCustomerBookings(string callerMobile)
        {
            BookingRepository bookingRepository = new BookingRepository();
            var customerBookingList = await bookingRepository.GetCustomerBookings(callerMobile);
            return new JsonResult { Data = customerBookingList, JsonRequestBehavior = JsonRequestBehavior.DenyGet };

        }
        [HttpPost]
        public JsonResult GetCallerData(string callerMobile)
        {
           TelephonyRepository telephonyRepository = new TelephonyRepository();
           var callerData = telephonyRepository.GetCallerData(callerMobile);
           return new JsonResult { Data = callerData, JsonRequestBehavior = JsonRequestBehavior.DenyGet };

        }

        [HttpPost]
        public async Task<JsonResult> SaveDisposition(int dispositionId,string remarks, int callerId, string callerMobile, string extensionNo)
        {
            TelephonyRepository telephonyRepository = new TelephonyRepository();
            bool isSavedSuccess = await telephonyRepository.SaveDisposition(dispositionId,remarks, callerId, callerMobile, extensionNo);
            return new JsonResult { Data = isSavedSuccess, JsonRequestBehavior = JsonRequestBehavior.DenyGet };
        }

        [HttpPost]
        public JsonResult GetDispositionList()
        {
            DispositionRepository dispositionRepository = new DispositionRepository();
            var dispositions = dispositionRepository.GetDispositions();
            return new JsonResult { Data = dispositions, JsonRequestBehavior = JsonRequestBehavior.DenyGet };
        }
        
    }
}