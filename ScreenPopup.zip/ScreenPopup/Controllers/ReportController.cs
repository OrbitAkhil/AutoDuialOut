﻿using ScreenPopup.App_Classes;
using ScreenPopup.Models;
using ScreenPopup.Repository;
using System;
using System.Collections.Generic;
using System.Configuration;
using System.Linq;
using System.Web;
using System.Web.Mvc;

namespace ScreenPopup.Controllers
{
    [ErrorHandle]
    public class ReportController : ApplicationController<LoggedInAgentViewModel>
    {
        //
        // GET: /Report/
        public ActionResult Index()
        {
            var agentViewModel = GetLogOnSessionModel();

            if (agentViewModel == null)
                return RedirectToAction("Login", "Account");

            return View();
        }

        public ActionResult CummulativeDashboard()
        {
            var agentViewModel = GetLogOnSessionModel();

            if (agentViewModel == null)
                return RedirectToAction("Login", "Account");

            if (Convert.ToString(agentViewModel.AgentId) == Convert.ToString(ConfigurationManager.AppSettings["AdminUserId"]) && Convert.ToString(agentViewModel.ExtensionNo) == Convert.ToString(ConfigurationManager.AppSettings["AdminPassword"]))
            {
                TelephonyRepository telephonyRepository = new TelephonyRepository();

                return View(new CummulativeDashboardViewModel { DayWiseCumulativeCount = telephonyRepository.GetDayWiseCummulativeSummary() });
            }
            return RedirectToAction("Login", "Account");
        }

        public JsonResult GetAgentWiseCallSummary(DateTime calledDate)
        {
            TelephonyRepository telephonyRepository = new TelephonyRepository();
            var agentCallSummaryList = telephonyRepository.GetAgentWiseCallSummary(calledDate);
            return new JsonResult { Data = agentCallSummaryList, JsonRequestBehavior = JsonRequestBehavior.DenyGet };
        }

        public JsonResult GetAgentTotalIncomingCalls(int agentId,DateTime calledDate)
        {
            TelephonyRepository telephonyRepository = new TelephonyRepository();
            var totalCalls = telephonyRepository.GetAgentTotalIncomingCalls(agentId,calledDate);
            return new JsonResult { Data = totalCalls, JsonRequestBehavior = JsonRequestBehavior.DenyGet };
        }

        public JsonResult GetAgentLoggedInSummary(int agentId, DateTime loggedInDate)
        {
            TelephonyRepository telephonyRepository = new TelephonyRepository();
            var loggedInList = telephonyRepository.GetAgentLoggedInSummary(agentId, loggedInDate);
            return new JsonResult { Data = loggedInList, JsonRequestBehavior = JsonRequestBehavior.DenyGet };
        }

        //public JsonResult GetLoggedInAgents(DateTime loggedInDate)
        //{
        //    LoginRepository loginRepository = new LoginRepository();
        //    var totalLoggedInAgents = loginRepository.GetLoggedInAgentSummary(loggedInDate);
        //    return new JsonResult { Data = totalLoggedInAgents, JsonRequestBehavior = JsonRequestBehavior.DenyGet };
        //}
	}
}