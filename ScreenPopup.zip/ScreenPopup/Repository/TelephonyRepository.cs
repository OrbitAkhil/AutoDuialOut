﻿using NLog;
using ScreenPopup.App_Classes;
using ScreenPopup.DataAccessLayer;
using System;
using System.Collections.Generic;
using System.Data;
using System.Data.SqlClient;
using System.Diagnostics;
using System.Linq;
using System.Threading.Tasks;
using System.Web;

namespace ScreenPopup.Repository
{
    public class TelephonyRepository
    {
        NLog.Logger logger = LogManager.GetLogger("databaseLogger");
        public CustomerInfo GetCallerData(string callerMobile)
        {
            CustomerInfo customerInfo = new CustomerInfo();

            
            try
            {
                var objCall = new CallInfo();
                var cmd = new CommandBuilder();
                cmd.SpName = "sp_Quickpop_GetCallerData";
                cmd.SqlParams = new List<SqlParameter>()
                {
                    new SqlParameter("@CallerMobile",callerMobile)
                };
                var ds = objCall.Select(cmd);
                if(ds.Tables.Count>0)
                {
                    customerInfo.CallerHistory = new List<CallerHistory>();
                   
                    foreach (DataRow row in ds.Tables[0].Rows)
                    {
                        customerInfo.CallerHistory.Add(new CallerHistory
                        {
                            AgentId = row["AgentId"] != DBNull.Value ? Convert.ToString(row["AgentId"]) : string.Empty,
                            AgentName = row["AgentName"] != DBNull.Value ? Convert.ToString(row["AgentName"]) : string.Empty,
                            CallIncomingDateTime = row["CallIncomingDateTime"] != DBNull.Value ? Convert.ToDateTime(row["CallIncomingDateTime"]) : DateTime.MinValue,
                            CallStatus = row["CallStatus"] != DBNull.Value ? Convert.ToString(row["CallStatus"]) : string.Empty,
                            ExtensionNo = row["ExtensionNo"] != DBNull.Value ? Convert.ToString(row["ExtensionNo"]) : string.Empty,
                            CallEstablishedDateTime = row["CallEstablishedDateTime"] != DBNull.Value ? Convert.ToDateTime(row["CallEstablishedDateTime"]) : DateTime.MinValue,
                            CallEndDateTime = row["CallEndDateTime"] != DBNull.Value ? Convert.ToDateTime(row["CallEndDateTime"]) : DateTime.MinValue,
                            Disposition = row["Disposition"] != DBNull.Value ? Convert.ToString(row["Disposition"]) : string.Empty,
                        });
                    }

                    if(ds.Tables[1] != null && ds.Tables[1].Rows.Count>0)
                    {
                        customerInfo.CustomerType = Convert.ToString(ds.Tables[1].Rows[0]["CustomerType"]);
                    }

                    if (ds.Tables[2] != null && ds.Tables[1].Rows.Count > 0)
                    {
                        customerInfo.TodaysCallCount = Convert.ToInt16(ds.Tables[2].Rows[0]["CallCount"]);
                    }

                    if (ds.Tables[3] != null && ds.Tables[1].Rows.Count > 0)
                    {
                        customerInfo.IsTravelAgentCall = Convert.ToBoolean(ds.Tables[3].Rows[0]["IsTravelAgentCall"]);
                    }
                    
                }
            }
            catch (Exception ex)
            {
                logger.Error(ex);
            }
            return customerInfo;
        }

        public ActiveCall GetCallsByExtensionNo(string extensionNo)
        {
            ActiveCall call = null;
            try
            {
                var objCall = new CallInfo();
                var cmd = new CommandBuilder();
                cmd.SpName = "GetLastActiveCallInfo";
                cmd.SqlParams = new List<SqlParameter>()
                {
                    new SqlParameter("@Extension",extensionNo)
                };
                var ds = objCall.Select(cmd);
                if (ds.Tables.Count > 0)
                {
                    if (ds.Tables[0].Rows.Count > 0)
                    {
                        DataRow row = ds.Tables[0].Rows[0];
                        call = new ActiveCall
                        {
                            CallerId = row["CallerId"] != DBNull.Value ? Convert.ToInt32(row["CallerId"]) : 0,
                            CallerMobile = row["CallerMobile"] != DBNull.Value ? Convert.ToString(row["CallerMobile"]) : string.Empty,
                            ExtensionNo = row["ExtensionNo"] != DBNull.Value ? Convert.ToString(row["ExtensionNo"]) : string.Empty,
                            CallIncomingDateTime = row["CallIncomingDateTime"] != DBNull.Value ? Convert.ToDateTime(row["CallIncomingDateTime"]) : DateTime.MinValue,
                            NoOfCall = row["NoOfCall"] != DBNull.Value ? Convert.ToInt32(row["NoOfCall"]) : 0
                        };
                    }
                }
            }
            catch(Exception ex)
            {
                logger.Error(ex);
            }
            return call;
        }

        public bool IsSqlDependencyInActive(string hostIpAdress)
        {
            try
            {
                var objCall = new CallInfo();
                var cmd = new CommandBuilder();
                cmd.SpName = "sp_GetQuickpopActiveCallCount";
                cmd.SqlParams = new List<SqlParameter>()
                {
                    new SqlParameter("@HostIpAddress",hostIpAdress)
                };
                int activeCallCount = Convert.ToInt32(objCall.GetScalerRecord(cmd));
                if (activeCallCount >= 10)
                    return true;

                return false;
            }
            catch (Exception ex)
            {
                logger.Error(ex);
                return false;
            }
        }

        public List<GetAllActiveCalls_Result> GetAllActiveCalls(string ipAddress)
        {
            List<GetAllActiveCalls_Result> activeCalls = new List<GetAllActiveCalls_Result>();
            try
            {
                var objCall = new CallInfo();
                var cmd = new CommandBuilder();
                cmd.SpName = "sp_GetAllActiveCalls";
                cmd.SqlParams = new List<SqlParameter>()
                {
                    new SqlParameter("@IpAddress",ipAddress)
                };
                var ds = objCall.Select(cmd);
                if (ds.Tables.Count > 0)
                {
                    foreach (DataRow row in ds.Tables[0].Rows)
                    {
                        activeCalls.Add(new GetAllActiveCalls_Result
                        {
                            CallerId = row["CallerId"] != DBNull.Value ? Convert.ToInt32(row["CallerId"]) : 0,
                            CallerMobile = row["CallerMobile"] != DBNull.Value ? Convert.ToString(row["CallerMobile"]) : string.Empty,
                            ExtensionNo = row["ExtensionNo"] != DBNull.Value ? Convert.ToString(row["ExtensionNo"]) : string.Empty,
                            TodayCallCount = row["TodayCallCount"] != DBNull.Value ? Convert.ToInt32(row["TodayCallCount"]) : 0,
                            IsTravelAgentCall = row["IsTravelAgentCall"] != DBNull.Value ? Convert.ToBoolean(row["IsTravelAgentCall"]) : false
                        });
                    }
                }
            }
            catch (Exception ex)
            {
                logger.Error(ex);
            }
            return activeCalls;
        }

        public List<GetAllActiveCalls_Result> GetActiveCalls(string extensionNo)
        {
            List<GetAllActiveCalls_Result> activeCalls = null;
            try
            {
                var objCall = new CallInfo();
                var cmd = new CommandBuilder();
                cmd.SpName = "GetAllActiveCalls";
                cmd.SqlParams = new List<SqlParameter>()
                {
                    new SqlParameter("@Extension",extensionNo)
                };
                var ds = objCall.Select(cmd);
                if (ds.Tables.Count > 0)
                {
                    
                    activeCalls = new List<GetAllActiveCalls_Result>();
                    foreach (DataRow row in ds.Tables[0].Rows)
                    {
                        activeCalls.Add(new GetAllActiveCalls_Result
                        {
                            CallerId = row["CallerId"] != DBNull.Value ? Convert.ToInt32(row["CallerId"]) : 0,
                            CallerMobile = row["CallerMobile"] != DBNull.Value ? Convert.ToString(row["CallerMobile"]) : string.Empty,
                            ExtensionNo = row["ExtensionNo"] != DBNull.Value ? Convert.ToString(row["ExtensionNo"]) : string.Empty,
                            TodayCallCount = row["TodayCallCount"] != DBNull.Value ? Convert.ToInt32(row["TodayCallCount"]) : 0,
                            IsTravelAgentCall = row["IsTravelAgentCall"] != DBNull.Value ? Convert.ToBoolean(row["IsTravelAgentCall"]) : false
                        });
                    }
                }
            }
            catch (Exception ex)
            {
                logger.Error(ex);
            }
            return activeCalls;
        }



        public  void UpdateCallStatus(int callerId,string extensionNo)
        {
            try
            {
                var objCall = new CallInfo();
                var cmd = new CommandBuilder();
                cmd.SpName = "UpdateCallStatus";
                cmd.SqlParams = new List<SqlParameter>()
                {
                    new SqlParameter("@CallerId",callerId),
                    new SqlParameter("@ExtensionNo",extensionNo.ToString()),
                    new SqlParameter("@CallStatus","D")
                };
                objCall.Insert(cmd);
            }
            catch (Exception ex)
            {
                logger.Error(ex);
            }
        }

        public List<ScreenPopDayWiseCumulativeCount> GetDayWiseCummulativeSummary()
        {
            List<ScreenPopDayWiseCumulativeCount> dayWiseCummulativeList = new List<ScreenPopDayWiseCumulativeCount>();
            try
            {
                var objCall = new CallInfo();
                var cmd = new CommandBuilder();
                cmd.SpName = "sp_Report_ScreenPop_Cummulative_Count";
                var ds = objCall.Select(cmd);
                if (ds.Tables.Count > 0)
                {
                    foreach (DataRow row in ds.Tables[0].Rows)
                    {
                        dayWiseCummulativeList.Add(new ScreenPopDayWiseCumulativeCount
                        {
                            CallIncomingDate = row["CallIncomingDate"] != DBNull.Value ? Convert.ToDateTime(row["CallIncomingDate"]) : DateTime.MinValue,
                            TotalCalls = row["TotalCalls"] != DBNull.Value ? Convert.ToInt32(row["TotalCalls"]) : 0,
                            TotalLoggedInAgents = row["TotalLoggedInAgents"] != DBNull.Value ? Convert.ToInt32(row["TotalLoggedInAgents"]) : 0,
                            TotalAgentAttendedCalls = row["TotalAgentAttendedCalls"] != DBNull.Value ? Convert.ToInt32(row["TotalAgentAttendedCalls"]) : 0,
                            AttendCallPercentile = ((Convert.ToDecimal(row["TotalLoggedInAgents"])) * 100) / Convert.ToInt32(row["TotalAgentAttendedCalls"])
                        });
                    }
                }
            }
            catch (Exception ex)
            {
                logger.Error(ex);
            }
            return dayWiseCummulativeList;
        }
        
        
        public List<AgentWiseCallSummary> GetAgentWiseCallSummary(DateTime calledDate)
        {
            List<AgentWiseCallSummary> list = null;
            try
            {
                
                var objCall = new CallInfo();
                var cmd = new CommandBuilder();
                cmd.SpName = "sp_Report_ScreenPop_AgentWise_Call_Summary";
                cmd.SqlParams = new List<SqlParameter>()
                {
                    new SqlParameter("@CalledDate",calledDate)
                };
                var ds = objCall.Select(cmd);
                if (ds.Tables.Count > 0)
                {
                    list = new List<AgentWiseCallSummary>();
                    foreach (DataRow row in ds.Tables[0].Rows)
                    {
                        list.Add(new AgentWiseCallSummary
                        {
                            CallIncomingDate = row["CallIncomingDate"] != DBNull.Value ? Convert.ToDateTime(row["CallIncomingDate"]) : DateTime.MinValue,
                            AgentId = row["AgentId"] != DBNull.Value ? Convert.ToInt32(row["AgentId"]) : 0,
                            CallCount = row["CallCount"] != DBNull.Value ? Convert.ToInt32(row["CallCount"]) : 0
                        });
                    }
                }
            }
            catch (Exception ex)
            {
                logger.Error(ex);
            }
            return list;
        }

        public List<CallDiversion> GetAgentTotalIncomingCalls(int agentId,DateTime calledDate)
        {
            List<CallDiversion> callList = null;
            try
            {
                var objCall = new CallInfo();
                var cmd = new CommandBuilder();
                cmd.SpName = "sp_Report_ScreenPop_Get_Agent_Calls";
                cmd.SqlParams = new List<SqlParameter>()
                {
                    new SqlParameter("@CalledDate",calledDate),
                    new SqlParameter("@AgentId",agentId)
                };
                var ds = objCall.Select(cmd);
                if (ds.Tables.Count > 0)
                {
                    callList = new List<CallDiversion>();
                    foreach (DataRow row in ds.Tables[0].Rows)
                    {
                        callList.Add(new CallDiversion
                        {
                            CallerId = row["CallerId"] != DBNull.Value ? Convert.ToInt32(row["CallerId"]) : 0,
                            AgentId = row["AgentId"] != DBNull.Value ? Convert.ToInt32(row["AgentId"]) : 0,
                            ExtensionNo = row["ExtensionNo"] != DBNull.Value ? Convert.ToString(row["ExtensionNo"]) : string.Empty,
                            CallIncomingDateTime = row["CallIncomingDateTime"] != DBNull.Value ? Convert.ToDateTime(row["CallIncomingDateTime"]) : DateTime.MinValue,
                            CallEstablishedDateTime = row["CallEstablishedDateTime"] != DBNull.Value ? Convert.ToDateTime(row["CallEstablishedDateTime"]) : DateTime.MinValue,
                            CallEndDateTime = row["CallEndDateTime"] != DBNull.Value ? Convert.ToDateTime(row["CallEndDateTime"]) : DateTime.MinValue
                        });
                    }
                }
            }
            catch (Exception ex)
            {
                logger.Error(ex);
            }
            return callList;
        }

        public List<AgentLogin> GetAgentLoggedInSummary(int agentId, DateTime loggedInDate)
        {
            List<AgentLogin> agentLoggedInList = null;
            try
            {
                var objCall = new CallInfo();
                var cmd = new CommandBuilder();
                cmd.SpName = "sp_Report_ScreenPop_Get_Agent_LoggedIn_History";
                cmd.SqlParams = new List<SqlParameter>()
                {
                    new SqlParameter("@LoggedInDate",loggedInDate),
                    new SqlParameter("@AgentId",agentId)
                };
                var ds = objCall.Select(cmd);
                if (ds.Tables.Count > 0)
                {
                    agentLoggedInList = new List<AgentLogin>();
                    foreach (DataRow row in ds.Tables[0].Rows)
                    {
                        agentLoggedInList.Add(new AgentLogin
                        {
                            ExtensionNo = row["ExtensionNo"] != DBNull.Value ? Convert.ToInt32(row["ExtensionNo"]) : 0,
                            AgentId = row["AgentId"] != DBNull.Value ? Convert.ToInt32(row["AgentId"]) : 0,
                            LoginStatus = row["LoginStatus"] != DBNull.Value ? Convert.ToString(row["LoginStatus"]) : string.Empty,
                            LoginDateTime = row["LoginDateTime"] != DBNull.Value ? Convert.ToDateTime(row["LoginDateTime"]) : DateTime.MinValue
                        });
                    }
                }
            }
            catch (Exception ex)
            {
                logger.Error(ex);
            }
            return agentLoggedInList;
        }
        
        public async Task<bool> SaveDisposition(int dispositionId,string remarks, int callerId, string callerMobile, string extensionNo)
        {
            try
            {
                var objCall = new CallInfo();
                var cmd = new CommandBuilder();
                cmd.SpName = "sp_SaveQuickPopDisposition";
                cmd.SqlParams = new List<SqlParameter>()
                {
                    new SqlParameter("@DispositionId",dispositionId),
                    new SqlParameter("@Remarks",remarks),
                    new SqlParameter("@CallerId",callerId),
                    new SqlParameter("@CallerMobile",callerMobile),
                    new SqlParameter("@ExtensionNo",extensionNo)
                };
                return await objCall.Update(cmd);
            }
            catch (Exception ex)
            {
                logger.Error(ex);
            }
            return false;
        }
    }


    public class AgentRepository
    {
        NLog.Logger logger = LogManager.GetLogger("databaseLogger");
        public async Task<Agent> FindAsync(int agentId,  string password)
        {
            Agent agent = null;
            try
            {
                using (ESSEntities ent = new ESSEntities())
                {

                    agent = ent.Agents.Where(e => e.AgentId == agentId && e.AgentPassword == password).FirstOrDefault();
                }
            }
            catch (AggregateException ae)
            {
                // Assume we know what's going on with this particular exception.
                // Rethrow anything else. AggregateException.Handle provides
                // another way to express this. See later example.
                foreach (var ex in ae.InnerExceptions)
                {

                    logger.Error(ex);
                    
                }
            }

            return agent;
        }

        public Agent Find(int agentId, string password)
        {
            Agent agent = null;
            try
            {
                using (ESSEntities ent = new ESSEntities())
                {

                    agent = ent.Agents.Where(e => e.AgentId == agentId && e.AgentPassword == password).FirstOrDefault();
                }
            }
            catch (Exception ex)
            {
                logger.Error(ex);
            }
            return agent;
        }

        public void AddAgent(int agentId,string agentPassword)
        {
            try
            {
                using (ESSEntities ent = new ESSEntities())
                {
                    Agent obj = new Agent();
                    obj.AgentId = agentId;
                    //obj.AgentName = agentName;
                    obj.AgentPassword = agentPassword;
                    ent.Agents.Add(obj);
                    ent.SaveChanges();
                }
            }
            catch (Exception ex)
            {
                logger.Error(ex);
            }
        }

    }

    public class ExtensionRepository
    {
        NLog.Logger logger = LogManager.GetLogger("databaseLogger");
        public Extension Find(int extensionNo)
        {
            Extension extension = null;

            try
            {
                using (ESSEntities ent = new ESSEntities())
                {
                    extension = ent.Extensions.Where(e => e.ExtensionNo == extensionNo && e.Status == "A").FirstOrDefault();
                }
            }
            catch (Exception ex)
            {
                logger.Error(ex);
            }

            return extension;
        }

        public void AddExtension(int extensionNo)
        {
            try
            {
                using (ESSEntities ent = new ESSEntities())
                {
                    Extension obj = new Extension();
                    obj.ExtensionNo = extensionNo;
                    obj.Status = "A";

                    ent.Extensions.Add(obj);
                    ent.SaveChanges();
                }
            }
            catch(Exception ex)
            {
                logger.Error(ex);
            }
        }

    }

    public class LoginRepository
    {
        NLog.Logger logger = LogManager.GetLogger("databaseLogger");
        public bool CheckExtensionAvailability(int agentId, int extensionNo)
        {

            try
            {
                using (ESSEntities ent = new ESSEntities())
                {

                    return ent.Logins.Any(e => e.AgentId == agentId && e.LoginStatus == "A");
                }
            }
            catch (Exception ex)
            {
                logger.Error(ex);
            }
            return false;
        }

        public int GetAgentLoggedInExtension(int agentId)
        {
            int extensionNo = 0;
            try
            {
                using (ESSEntities ent = new ESSEntities())
                {

                    var login = ent.Logins.FirstOrDefault(e => e.AgentId == agentId && e.LoginStatus == "A");
                    if (login != null)
                        extensionNo =  login.ExtensionNo;
                }
            }
            catch (Exception ex)
            {
                logger.Error(ex);
            }
            return extensionNo;
        }

        public void AddLoginRecord(int agentId, int extensionNo, string uniqueIdentifier, string ipAdress, string hostIpAdress)
        {
            try
            {
                var objCall = new CallInfo();
                var cmd = new CommandBuilder();
                cmd.SpName = "sp_InsertQuickpopLoginLog";
                cmd.SqlParams = new List<SqlParameter>()
                {
                    new SqlParameter("@AgentId",agentId),
                    new SqlParameter("@ExtensionNo",extensionNo),
                    new SqlParameter("@SessionId",uniqueIdentifier),
                    new SqlParameter("@IpAddress",ipAdress),
                    new SqlParameter("@HostIpAddress",hostIpAdress)
                };
                objCall.InsertRecord(cmd);
            }
            catch (Exception ex)
            {
                logger.Error(ex);
            }
        }

        

        public void LogoutAgentExistingSession(int agentId)
        {
            try
            {
                using (ESSEntities ent = new ESSEntities())
                {
                    var login = ent.Logins.FirstOrDefault(e => e.AgentId == agentId  && e.LoginStatus == "A");
                    if (login != null)
                    {
                        login.LoginStatus = "C";
                        ent.SaveChanges();
                    }

                }
            }
            catch (Exception ex)
            {
                logger.Error(ex);
            }
        }

        public void ReActivateLogin(int agentId, int extensionNo,string uniqueIdentifier)
        {
            try
            {
                using (ESSEntities ent = new ESSEntities())
                {

                    var login = ent.Logins.FirstOrDefault(e => e.AgentId == agentId && e.SessionId == uniqueIdentifier && e.ExtensionNo == extensionNo && e.LoginStatus == "C");
                    if (login != null)
                    {
                        login.LoginStatus = "A";
                        ent.Entry(login).State = System.Data.Entity.EntityState.Modified;
                        ent.SaveChanges();
                    }

                }
            }
            catch (Exception ex)
            {
                logger.Error(ex);
            }
        }

        public void DeActivateLogin(int agentId, int extensionNo, string uniqueIdentifier)
        {
            try
            {
                var objCall = new CallInfo();
                var cmd = new CommandBuilder();
                cmd.SpName = "sp_LogoutQuickpopAgent";
                cmd.SqlParams = new List<SqlParameter>()
                {
                    new SqlParameter("@AgentId",agentId),
                    new SqlParameter("@ExtensionNo",extensionNo),
                    new SqlParameter("@SessionId",uniqueIdentifier)
                };
                objCall.InsertRecord(cmd);
            }
            catch (Exception ex)
            {
                logger.Error(ex);
            }
        }

        

    }


    public class DispositionRepository
    {
        NLog.Logger logger = LogManager.GetLogger("databaseLogger");
        public List<Disposition> GetDispositions()
        {
            List<Disposition> dispositionList = new List<Disposition>();
            try
            {
                var objCall = new CallInfo();
                var cmd = new CommandBuilder();
                cmd.SpName = "sp_GetScreenPopDispositions";
                var ds = objCall.Select(cmd);
                if (ds.Tables.Count > 0)
                {
                    foreach (DataRow row in ds.Tables[0].Rows)
                    {

                        dispositionList.Add(new Disposition
                        {
                            GroupId = row["GroupId"] != DBNull.Value ? Convert.ToInt32(row["GroupId"]) : 0,
                            GroupDescription = row["GroupDescription"] != DBNull.Value ? Convert.ToString(row["GroupDescription"]) : string.Empty,
                            SubGroupId = row["SubGroupId"] != DBNull.Value ? Convert.ToInt32(row["SubGroupId"]) : 0,
                            SubGroupDescription = row["SubGroupDescription"] != DBNull.Value ? Convert.ToString(row["SubGroupDescription"]) : string.Empty,
                            DispositionId = row["DispositionId"] != DBNull.Value ? Convert.ToInt32(row["DispositionId"]) : 0,
                            DispositionDescription = row["DispositionDescription"] != DBNull.Value ? Convert.ToString(row["DispositionDescription"]) : string.Empty
                        });
                    }
                }
            }
            catch (Exception ex)
            {
                logger.Error(ex);
            }
            return dispositionList;
        }


    }
}