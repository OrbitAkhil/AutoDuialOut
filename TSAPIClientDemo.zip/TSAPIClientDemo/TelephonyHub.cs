﻿using System;
using System.Threading.Tasks;
using Microsoft.AspNet.SignalR;

namespace TSAPIClientDemo
{
    public class TelephonyHub : Hub
    {
        public void AddMessage(string name, string message)
        {
            Console.WriteLine("Hub AddMessage {0} {1}\n", name, message);
            Clients.All.addMessage(name, message);
        }

        public void Heartbeat()
        {
            Console.WriteLine("Hub Heartbeat\n");
            Clients.All.heartbeat();
        }

        //public override Task OnConnected()
        //{
        //    Console.WriteLine("Hub OnConnected {0}\n", Context.ConnectionId);
        //    return (base.OnConnected());
        //}

        //public override Task OnDisconnected()
        //{
        //    Console.WriteLine("Hub OnDisconnected {0}\n", Context.ConnectionId);
        //    return (base.OnDisconnected());
        //}

        //public override Task OnReconnected()
        //{
        //    Console.WriteLine("Hub OnReconnected {0}\n", Context.ConnectionId);
        //    return (base.OnDisconnected());
        //}


        public override System.Threading.Tasks.Task OnConnected()
        {
            Console.WriteLine("Hub OnConnected {0}\n", Context.ConnectionId);
            int agentId, extensionNo;
            string uniqueIdentifier;
            Int32.TryParse(this.Context.QueryString["agentId"], out agentId);
            Int32.TryParse(this.Context.QueryString["extensionNo"], out extensionNo);
            uniqueIdentifier = Convert.ToString(this.Context.QueryString["uniqueIdentifier"]);
            //new LoginRepository().ReActivateLogin(agentId, extensionNo, uniqueIdentifier);
            
            return base.OnConnected();

        }

        public override Task OnReconnected()
        {
            Console.WriteLine("Hub OnReconnected {0}\n", Context.ConnectionId);
            return base.OnReconnected();
        }
        public override Task OnDisconnected(bool stopcalled)
        {
            Console.WriteLine("Hub OnDisconnected {0}\n", Context.ConnectionId);
            int agentId, extensionNo;
            string uniqueIdentifier;
            Int32.TryParse(this.Context.QueryString["agentId"], out agentId);
            Int32.TryParse(this.Context.QueryString["extensionNo"], out extensionNo);
            uniqueIdentifier = Convert.ToString(this.Context.QueryString["uniqueIdentifier"]);
            if (agentId > 0)
            {
                //new LoginRepository().DeActivateLogin(agentId, extensionNo, uniqueIdentifier);
            }
            return base.OnDisconnected(stopcalled);
        }

    }
}