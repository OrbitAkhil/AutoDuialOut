﻿using Microsoft.AspNet.SignalR;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace TSAPIClientDemo.Classes
{
    public class CustomUserIdProvider : IUserIdProvider
    {
        public string GetUserId(IRequest request)
        {
            if (request.QueryString["extensionNo"] == null)
            {
                LoginRepository repository = new LoginRepository();
                var extensionNo = repository.GetAgentLoggedInExtension(Convert.ToInt32(request.QueryString["agentId"]));
                return Convert.ToString(extensionNo);
            }

            return Convert.ToString(request.QueryString["extensionNo"]);
        }
    }


}
