﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Runtime.Serialization;
using System.Web;

namespace WebApi.ErrorHelper
{
    /// <summary>
    /// Api Data Exception
    /// </summary>
    [Serializable]
    [DataContract]
    public class ServiceStatus
    {
         [DataMember]
        public int StatusCode { get; set; }
         [DataMember]
        public string StatusMessage { get; set; }
         [DataMember]
        public string ReasonPhrase { get; set; }
    }
}