﻿using BusinessEntities;
using WebApi.ActionFilters;
using MosiacWebDropOutApi.BusinessServices;
using WebApi.Filters;
using NLog;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Net;
using System.Net.Http;
using System.Web.Http;
using System.Threading.Tasks;
using WebApi.ErrorHelper;
using WebApi.ActionFilter;
using System.Text;

namespace WebApi.Controllers
{
    [TestApiAuthenticationFilter]
    [GlobalException]
    [RoutePrefix("api/TestDropCall")]
    public class TestDropCallController : ApiController
    {
        private static NLog.Logger logger = LogManager.GetCurrentClassLogger();
        private readonly IDropCallServices _dropCallServices;
        /// <summary>
        /// Public constructor to initialize dropcall service instance
        /// </summary>
        public TestDropCallController(IDropCallServices dropCallServices)
        {
            _dropCallServices = dropCallServices;
        }

        [Route("Add")]
        [HttpPost]
        public object Add([FromBody]TestDropoutCustomer dropCall)
        {

            if (dropCall == null)
                ModelState.AddModelError("NullableRequest", "Request is mandatory.");

            CaseType category;
            if (!Enum.TryParse(dropCall.CaseType, true, out category))
            {
                //throw bad request exception if you want. but it is fine to pass-through as default FB value.
                ModelState.AddModelError("Invalid Type", "Case type must have valid value. NB - New Booking , HB - Hold Booking , SR - Special Request.");
            }

            if (ModelState.IsValid)
            {
                try
                {
                    //Set priority of calls based on case type
                    switch (category)
                    {
                        case CaseType.NB:
                            dropCall.Priority = Priority.P1;
                            break;
                        case CaseType.HB:
                            dropCall.Priority = Priority.P2;
                            break;
                        case CaseType.SR:
                            dropCall.Priority = Priority.P3;
                            break;
                        default:
                            dropCall.Priority = Priority.P4;
                            break;
                    }
                    dropCall.IsValidRecord = true;
                    _dropCallServices.AddNewTestCall(dropCall);

                    return Request.CreateResponse(HttpStatusCode.Created, new DropoutCustomerResponse { IsRecordSaved = true, Message = "Data saved successfully" });
                }
                catch (Exception ex)
                {

                    logger.Error(ex);
                    return Request.CreateResponse(HttpStatusCode.BadRequest, new DropoutCustomerResponse { IsRecordSaved = false, Error = new Error { Description = ex.Message }, Message = "Data not saved successfully" });
                }
            }
            else
            {
                // the code below should probably be refactored into a GetModelErrors
                // method on your BaseApiController or something like that
                dropCall.IsValidRecord = false;
                _dropCallServices.AddNewTestCall(dropCall);
                var errors = new List<Error>();
                foreach (var state in ModelState)
                {
                    foreach (var error in state.Value.Errors)
                    {
                        errors.Add(new Error { Description = error.ErrorMessage });
                    }
                }
                return Request.CreateResponse(HttpStatusCode.Forbidden, new DropoutCustomerResponse { IsRecordSaved = false, ErrorList = errors, Message = "Data not saved successfully" });
            }
        }


        //[Route("api/DropCall/AddBulk")]
        //[HttpPost]
        //public async Task<object> AddBulk([FromBody]List<DropoutCustomer> dropCallList)
        //{
        //    try
        //    {
        //        if (dropCallList == null)
        //            throw new ApiException() { ErrorCode = (int)HttpStatusCode.BadRequest, ErrorDescription = "Bad Request..." };

        //        foreach (var dropCall in dropCallList)
        //        {
        //            string priority = null;
        //            //if (!string.IsNullOrEmpty(dropCall.CallerMobile))
        //            //priority = await _bookingServices.GetCallerPriorityAsync(dropCall.CallerMobile);
        //            //dropCall.Priority = "P1";
        //            _dropCallServices.AddNewCall(dropCall);
        //        }

        //        return Request.CreateResponse(HttpStatusCode.OK, new { Success = true });
        //    }
        //    catch (Exception ex)
        //    {
        //        logger.Error(ex);
        //        return Request.CreateResponse(HttpStatusCode.BadRequest, new { Success = false });
        //    }
        //}
    }
}