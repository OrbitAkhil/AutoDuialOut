﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace SMSManagerService.App_Classes
{
    public class TinyUrlRequest
    {
        public TinyUrlPayLoad TINYURL { get; set; }
    }

    public class TinyUrlPayLoad
    {
        public PayLoadUser USER { get; set; }
        public IList<PayLoadRequestUrl> URL { get; set; }
    }

    public class PayLoadUser
    {
        public string USERNAME { get; set; }
        public string PASSWORD { get; set; }
        public string SERVICE { get; set; }
    }

    public class PayLoadDlr
    {
        public string DlrUrl { get; set; }
    }

    public class PayLoadRequestUrl
    {
        public string Seq { get; set; }
        public string MobileNo { get; set; }
        public string Date { get; set; }
        public string Action { get; set; }
        public string URL { get; set; }
    }
}
