﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Xml.Serialization;

namespace SMSManagerService.App_Classes
{
    public class MESSAGEACK
    {
        [XmlElement("GUID")]
        public List<SEQGUID> GUID { get; set; }

        public Error Err { get; set; }
    }

    public class SEQGUID
    {
        [XmlAttribute]
        public string GUID {get;set;}
        [XmlAttribute]
        public string SUBMITDATE { get; set; }
        [XmlAttribute]
        public string ID { get; set; }

        public SequenceError ERROR { get; set; }
    }
    public class SequenceError
    {
        [XmlAttribute]
        public string SEQ { get; set; }
        [XmlAttribute]
        public string CODE { get; set; }
    }
    public class Error
    {
        [XmlAttribute]
        public string Code { get; set; }
        [XmlAttribute]
        public string Desc { get; set; }
    }
}
