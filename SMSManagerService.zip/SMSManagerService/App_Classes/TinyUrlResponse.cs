﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace SMSManagerService.App_Classes
{
    public class TinyUrlResponse
    {
        public TinyUrlResponsePayLoad TINYURL { get; set; }
    }

    public class TinyUrlResponsePayLoad
    {
        public IList<PayLoadResponseUrl> URL { get; set; }
    }

    public class PayLoadResponseUrl
    {
        public string Seq { get; set; }
        public string URL { get; set; }
    }
}
