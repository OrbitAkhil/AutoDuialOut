﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Xml.Serialization;

namespace SMSManagerService.App_Classes
{
   
    [Serializable]
    public class MESSAGE
    {
        
        public SMSUser USER { get; set; }
        [XmlElement("SMS")]
        public List<SMS> SMSRequests { get; set; }
    }
    [Serializable]
    public class SMSUser
    {
        [XmlAttribute]
        public string USERNAME { get; set; }
        [XmlAttribute]
        public string PASSWORD { get; set; }
    }
    [Serializable]
    public class SMS
    {
       
        [XmlAttribute]
        public string UDH { get; set; }
        [XmlAttribute]
        public string CODING { get; set; }
        [XmlAttribute]
        public string TEXT { get; set; }
        [XmlAttribute]
        public string PROPERTY { get; set; }
        [XmlAttribute]
        public string ID { get; set; }
        [XmlElement("ADDRESS")]
        public List<ADDRESS> ADDRESS { get; set; }
    }
    [Serializable]
    public class ADDRESS
    {
        
        [XmlAttribute]
        public string FROM { get; set; }
        [XmlAttribute]
        public string TO { get; set; }
        [XmlAttribute]
        public string SEQ { get; set; }
        [XmlAttribute]
        public string TAG { get; set; }
    }
}
