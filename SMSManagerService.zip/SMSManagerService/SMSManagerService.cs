﻿using NLog;
using SMSManagerService.App_Classes;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Configuration;
using System.Data;
using System.Diagnostics;
using System.IO;
using System.Linq;
using System.Net;
using System.ServiceProcess;
using System.Text;
using System.Threading.Tasks;
using TSAPIDAL;
using TSAPIDAL.DataAccessLayer;

namespace SMSManagerService
{
    public partial class SMSManagerService : ServiceBase
    {
        private readonly static string VFirstSMSUser = ConfigurationManager.AppSettings["VFirstSMSUser"].ToString();
        private readonly static string VFirstSMSPassword = ConfigurationManager.AppSettings["VFirstSMSPassword"].ToString();
        private readonly static string VFirstSMSFrom = ConfigurationManager.AppSettings["VFirstSMSFrom"].ToString();
        private readonly static string VFirstTinyUrlUser = ConfigurationManager.AppSettings["VFirstTinyUrlUser"].ToString();
        private readonly static string VFirstTinyUrlPassword = ConfigurationManager.AppSettings["VFirstTinyUrlPassword"].ToString();
        private readonly static string VFirstTinyUrlApi = ConfigurationManager.AppSettings["VFirstTinyUrlApi"].ToString();
        private readonly static string VFirstSMSApi = ConfigurationManager.AppSettings["VFirstSMSApi"].ToString();
        private readonly static bool IsDebug = Convert.ToBoolean(ConfigurationManager.AppSettings["IsDebug"]);
        private readonly static string SMSText = Convert.ToString(ConfigurationManager.AppSettings["SMSText"]);
        private readonly static string TestCallerMobile = Convert.ToString(ConfigurationManager.AppSettings["TestCallerMobile"]);
        private readonly static string TinyUrlHost = Convert.ToString(ConfigurationManager.AppSettings["TinyUrlHost"]);
        private readonly static NLog.Logger logger = LogManager.GetLogger("databaseLogger");
        System.Timers.Timer timer = new System.Timers.Timer();


        public SMSManagerService()
        {
            timer.Interval = 10000;
            timer.Elapsed += new System.Timers.ElapsedEventHandler(timer_Elapsed); 

            InitializeComponent();
        }

        protected override void OnStart(string[] args)
        {
            timer.Enabled = true;
            logger.Info("SMS Manager service is started on {0}",DateTime.Now);
        }

        protected override void OnStop()
        {
            timer.Enabled = false;
            logger.Info("Call distribution service is stopped on {0}", DateTime.Now);
        }

        void timer_Elapsed(object sender, System.Timers.ElapsedEventArgs e)
        {
            try
            {
                var ds = GetCampaignSMSData();

                if (ds != null && ds.Tables.Count > 0)
                {
                    var tinyUrlResponse = CreateBulkTinyUrlLink(ds);

                    if (tinyUrlResponse != null && tinyUrlResponse.TINYURL != null && tinyUrlResponse.TINYURL.URL.Count > 0)
                    {
                        var tinyUrls = tinyUrlResponse.TINYURL.URL;

                        var bulkSMSRequest = CreateBulkSMSRequest(ds, tinyUrls);

                        ShootBulkSMS(bulkSMSRequest);
                    }
                }
            }
            catch (Exception ex)
            {
                //logger.Error(ex.Message);
            }
        }

        #region Private Methods
        private static DataSet GetCampaignSMSData()
        {
            var objCall = new Repository();
            var cmd = new CommandBuilder();
            cmd.CommandText = "Select CampaignId,CallerId,CallerNumber,CreatedOn,B.AgentId,B.AgentName from tbl_SMS_Survey_Campaign  A Left Outer Join tbl_ScreenPopup_Agent B on a.AgentId=B.AgentId Where Status = 'A' and Convert(Date,GETDATE())=Convert(Date,CreatedOn) and IsMessageSent IS NULL order by CampaignId Desc";
            var ds = objCall.Select(cmd);
            return ds;
        }


        private static TinyUrlResponse CreateBulkTinyUrlLink(DataSet ds)
        {
            TinyUrlPayLoad TinyUrl = null;
            try
            {

                if (ds != null && ds.Tables.Count > 0)
                {
                    TinyUrl = new TinyUrlPayLoad();
                    var User = new PayLoadUser { USERNAME = VFirstTinyUrlUser, PASSWORD = VFirstTinyUrlPassword, SERVICE = "0" };
                    TinyUrl.USER = User;
                    TinyUrl.URL = new List<PayLoadRequestUrl>();
                    foreach (DataRow row in ds.Tables[0].Rows)
                    {
                        string mobileNo = Convert.ToString(row["CallerNumber"]);
                        //bool isValidRecord = Convert.ToBoolean(row["IsValidRecord"]);
                        //if (isValidRecord)
                        //{
                        PayLoadRequestUrl payloadUrl = new PayLoadRequestUrl
                        {
                            Seq = Convert.ToString(row["CampaignId"]),
                            Action = "0",
                            Date = Convert.ToDateTime(row["CreatedOn"]).AddDays(10).ToString("yyyy-MM-dd"),
                            MobileNo = mobileNo.Length > 10 ? string.Format("91{0}", mobileNo.Substring(mobileNo.Length - 10, 10)) : string.Format("91{0}", mobileNo),
                            URL = string.Format("{0}?token={1}", TinyUrlHost, Convert.ToString(row["CampaignId"]))

                        };
                        TinyUrl.URL.Add(payloadUrl);
                        //}
                    }
                }

                var payload = Newtonsoft.Json.JsonConvert.SerializeObject(new TinyUrlRequest { TINYURL = TinyUrl });
                string response = CallValueFirstApi(VFirstTinyUrlApi, payload);
                if (response != null)
                    return Newtonsoft.Json.JsonConvert.DeserializeObject<TinyUrlResponse>(response);

            }
            catch (Exception ex)
            {
                logger.Error(ex.Message);
            }
            return null;
        }

        private static string CallValueFirstApi(string api, string payload)
        {
            try
            {
                string url = string.Format("{0}?data={1}&action=send", api, payload);
                WebRequest webRequest = WebRequest.Create(url);
                WebResponse webResponse = webRequest.GetResponse();
                Stream recieveStream = webResponse.GetResponseStream();
                Encoding encode = System.Text.Encoding.GetEncoding("utf-8");
                StreamReader readStream2 = new StreamReader(recieveStream, encode);
                return readStream2.ReadToEnd();
            }
            catch (Exception ex)
            {
                logger.Error(ex.Message);
            }
            return null;
        }

        private static MESSAGE CreateBulkSMSRequest(DataSet ds, IList<PayLoadResponseUrl> tinyUrls)
        {
            try
            {
                MESSAGE MESSAGE = null;
                if (ds != null && ds.Tables.Count > 0)
                {
                    MESSAGE = new MESSAGE();
                    var user = new SMSUser();
                    user.USERNAME = VFirstSMSUser;
                    user.PASSWORD = VFirstSMSPassword;
                    MESSAGE.USER = user;
                    MESSAGE.SMSRequests = new List<SMS>();

                    int id = 0;
                    foreach (DataRow row in ds.Tables[0].Rows)
                    {
                        id++;
                        string SeqNo = Convert.ToString(row["CampaignId"]);
                        string mobileNo = Convert.ToString(row["CallerNumber"]);
                        string agentName = Convert.ToString(row["AgentName"]);

                        if (string.IsNullOrEmpty(agentName))
                            agentName = "us";

                        // bool isValidRecord = Convert.ToBoolean(row["IsValidRecord"]);
                        // if (isValidRecord)
                        //  {
                        var tinyUrl = tinyUrls.FirstOrDefault(url => url.Seq == SeqNo);
                        if (tinyUrl != null && !string.IsNullOrEmpty(tinyUrl.URL))
                        {
                            string text = SMSText.Replace("XXURLXX", tinyUrl.URL);
                            text = text.Replace("XXAGENTXX", agentName);

                            SMS smsRequest = new SMS
                            {
                                UDH = "0",
                                CODING = "1",
                                TEXT = text,
                                ID = SeqNo,
                                PROPERTY = string.Empty,
                                ADDRESS = new List<ADDRESS>()
                            };
                            smsRequest.ADDRESS.Add(new ADDRESS
                            {
                                FROM = VFirstSMSFrom,
                                TO = IsDebug ? TestCallerMobile : mobileNo.Length > 10 ? string.Format("91{0}", mobileNo.Substring(mobileNo.Length - 10, 10)) : string.Format("91{0}", mobileNo),
                                SEQ = SeqNo,
                                TAG = string.Empty
                            });
                            MESSAGE.SMSRequests.Add(smsRequest);
                        }
                        // }
                    }
                }
                return MESSAGE;
            }
            catch (Exception ex)
            {
                logger.Error(ex.Message);
                
            }
            return null;
        }

        private static bool UpdateBulkSMSAck(MESSAGEACK messageAck)
        {
            try
            {
                if (messageAck != null)
                {
                    if (messageAck.GUID != null)
                    {
                        foreach (var seqGuid in messageAck.GUID)
                        {
                            var objCall = new Repository();
                            var cmd = new CommandBuilder();
                            if (seqGuid.GUID != null)
                            {
                                cmd.CommandText = "update tbl_SMS_Survey_Campaign Set Status = 'C', IsMessageSent = 'Y' ,MessageAckGuid = '" + seqGuid.GUID + "',SubmitDate='" + Convert.ToDateTime(seqGuid.SUBMITDATE) + "' where CampaignId=" + Convert.ToDecimal(seqGuid.ID) + "";
                                cmd.Execute();
                            }
                            else if (seqGuid.ERROR != null)
                            {
                                cmd.CommandText = "update tbl_SMS_Survey_Campaign Set Status = 'C',IsMessageSent = 'N' ,ErrorCode = '" + seqGuid.ERROR.CODE + "' where CampaignId=" + Convert.ToDecimal(seqGuid.ID) + "";
                                cmd.Execute();
                            }
                        }
                        return true;
                    }
                    else if (messageAck.Err != null)
                    {

                    }

                }
                return false;
            }
            catch (Exception ex)
            {
                logger.Error(ex.Message);
                return false;
            }
        }

        private static bool ShootBulkSMS(MESSAGE bulkSMSRequest)
        {
            try
            {
                if (bulkSMSRequest != null)
                {
                    var serializedXMLRequest = Serializer.Serialize(bulkSMSRequest);

                    //string encodedRequestXml = System.Web.HttpUtility.HtmlEncode(serializedXMLRequest);
                    //Encode XML Data as mentioned in Value First Guide
                    string encodedRequestUrl = System.Web.HttpUtility.UrlEncode(serializedXMLRequest);

                    string response = CallValueFirstApi(VFirstSMSApi, encodedRequestUrl);

                    if (response != null)
                    {
                        var messageAck = Serializer.Deserialize<MESSAGEACK>(response);

                        if (messageAck != null)
                            return UpdateBulkSMSAck(messageAck);
                        else
                            return false;
                    }
                    else
                        return false;
                }
                return false;
            }
            catch (Exception ex)
            {
                logger.Error(ex.Message);
            }
            return false;
        }
        #endregion
    }
}
