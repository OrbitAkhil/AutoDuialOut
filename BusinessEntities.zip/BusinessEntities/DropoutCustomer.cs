﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Runtime.Serialization;
using System.Text;
using System.Threading.Tasks;

namespace BusinessEntities
{
    [Serializable]
    [DataContract(Namespace = "", Name = "DropoutCustomer")]
    public class DropoutCustomer
    {
        public int Id { get; set; }
        [DataMember]
        [Required(ErrorMessage="Name is mandatory.")]
        [StringLength(200, ErrorMessage = "Name must be less than or equal to 200 characters")]
        public string Name { get; set; }

        [DataMember]
        [EmailAddress(ErrorMessage = "Email Address must be in a Valid Format")]
        [StringLength(200, ErrorMessage = "Email Address must be less than or equal to 200 characters")]
        public string Email { get; set; }

        [DataMember]
        [Required]
        [RegularExpression("^[0-9]*$", ErrorMessage = "Contact Number is not in a correct format")]
        [StringLength(15, ErrorMessage = "Contact Number must less than or equal to 15 characters")]
        public string ContactNumber { get; set; }

        [DataMember]
        [Required]
        [Range(1,9, ErrorMessage = "Total pax count must be less than or equal to 9.")]
        public int PaxCount { get; set; }

        [DataMember]
        public List<Pax> PaxList { get; set; }

        [StringLength(200, ErrorMessage = "Lost page name must be less than 200 characters")]
        [DataMember]
        public string LostPageName { get; set; }

        [DataMember]
        [StringLength(500, ErrorMessage = "Flight Details name must be less than 500 characters")]
        public string FlightDetails { get; set; }

       public Priority Priority { get; set; }

        public  bool IsValidRecord {get;set;}
    }
    [Serializable]
    [DataContract(Namespace = "", Name = "DropoutCustomerV2")]
    public class DropoutCustomerV2 : DropoutCustomer
    {

        [DataMember]
        [Required]
        public string CaseType { get; set; }

    }
    [Serializable]
    [DataContract(Namespace = "", Name = "TestDropoutCustomer")]
    public class TestDropoutCustomer :DropoutCustomer
    {
        
        [DataMember]
        [Required]
        public string CaseType { get; set; }

    }

    [Serializable]
    [DataContract(Namespace = "", Name = "Pax")]
    public class Pax
    {
        [DataMember]
        public string Name { get; set; }

        [DataMember]
        public string PaxType { get; set; }
    }
    

    public enum CaseType
    {
        NB = 0,
        HB = 1,
        SR = 2
    }

    public enum Priority
    {
        P1 = 0,
        P2 = 1,
        P3 = 2,
        P4 = 3
    }
}
