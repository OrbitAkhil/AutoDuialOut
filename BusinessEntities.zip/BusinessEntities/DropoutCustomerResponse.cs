﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Runtime.Serialization;
using System.Text;
using System.Threading.Tasks;

namespace BusinessEntities
{
    [Serializable]
    [DataContract(Namespace="",Name="Response")]
    public class DropoutCustomerResponse
    {
        [DataMember(IsRequired = true)]
        public bool IsRecordSaved {get;set;}
        [DataMember(IsRequired = true)]
        public string Message { get; set; }
        [DataMember(IsRequired=false,EmitDefaultValue = false)]
        public Error Error { get; set; }
        [DataMember(IsRequired = false, EmitDefaultValue = false)]
        public List<Error> ErrorList { get; set; }
    }
    
    [Serializable]
    [DataContract(Namespace = "", Name = "Error")]
    public class Error
    {
        //[DataMember(IsRequired = false, EmitDefaultValue = false)]
        //public int Code { get; set; }
        [DataMember(IsRequired = true)]
        public string Description { get; set; }
    }
}
