﻿using BusinessEntities;
using DataModel.DataAccessLayer;
using System;
using System.Collections.Generic;
using System.Data.SqlClient;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace MosiacWebDropOutApi.BusinessServices
{
    class DropCallServices : IDropCallServices
    {
        public bool AddNewCall(DropoutCustomerV2 dropCall)
        {
            try
            {
                var objCall = new CallInfo();
                var cmd = new CommandBuilder();
                cmd.SpName = "sp_AddDropCalls";
                cmd.SqlParams = new List<SqlParameter>()
                {
                    new SqlParameter("@CallerName",dropCall.Name),
                    new SqlParameter("@CallerEmail",dropCall.Email),
                    new SqlParameter("@CallerMobile",dropCall.ContactNumber),
                    new SqlParameter("@LostPageName",dropCall.LostPageName),
                    new SqlParameter("@PaxCount",dropCall.PaxCount),
                    new SqlParameter("@PaxNames",dropCall.PaxList != null ? String.Join(",",  dropCall.PaxList.Select(x=>x.Name).ToList()) : string.Empty),
                    new SqlParameter("@FlightDetails",dropCall.FlightDetails),
                    new SqlParameter("@CaseType",dropCall.CaseType),
                    new SqlParameter("@Priority",dropCall.Priority.ToString()),
                    new SqlParameter("@IsValidRecord",dropCall.IsValidRecord)
                };
                return objCall.Insert(cmd);
            }
            catch(Exception ex)
            {
                throw ex;
            }

        }

        public bool AddNewTestCall(TestDropoutCustomer dropCall)
        {
            try
            {
                var objCall = new CallInfo();
                var cmd = new TestCommandBuilder();
                cmd.SpName = "sp_AddDropCalls";
                cmd.SqlParams = new List<SqlParameter>()
                {
                    new SqlParameter("@CallerName",dropCall.Name),
                    new SqlParameter("@CallerEmail",dropCall.Email),
                    new SqlParameter("@CallerMobile",dropCall.ContactNumber),
                    new SqlParameter("@LostPageName",dropCall.LostPageName),
                    new SqlParameter("@PaxCount",dropCall.PaxCount),
                    new SqlParameter("@PaxNames",dropCall.PaxList != null ? String.Join(",",  dropCall.PaxList.Select(x=>x.Name).ToList()) : string.Empty),
                    new SqlParameter("@FlightDetails",dropCall.FlightDetails),
                    new SqlParameter("@CaseType",dropCall.CaseType),
                    new SqlParameter("@Priority",dropCall.Priority.ToString()),
                    new SqlParameter("@IsValidRecord",dropCall.IsValidRecord)
                };
                return objCall.Insert(cmd);
            }
            catch (Exception ex)
            {
                throw ex;
            }

        }
    }
}
