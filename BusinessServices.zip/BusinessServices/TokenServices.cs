﻿using BusinessEntities;
using DataModel.DataAccessLayer;
using DataModel.DataEntity;
using DataModel.UnitOfWork;
using System;
using System.Collections.Generic;
using System.Configuration;
using System.Data.SqlClient;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace MosiacWebDropOutApi.BusinessServices
{
    public class TokenServices : ITokenServices
    {
        #region Private member variables.
        private readonly UnitOfWork _unitOfWork;
        #endregion

        #region Public constructor.
        /// <summary>
        /// Public constructor.
        /// </summary>
        public TokenServices(UnitOfWork unitOfWork)
        {
            _unitOfWork = unitOfWork;
        }
        #endregion


        #region Public member methods.

        /// <summary>
        ///  Function to generate unique token with expiry against the provided userId.
        ///  Also add a record in database for generated token.
        /// </summary>
        /// <param name="userId"></param>
        /// <returns></returns>
        public TokenEntity GenerateToken(int userId)
        {
            string token = Guid.NewGuid().ToString();
            DateTime issuedOn = DateTime.Now;
            DateTime expiredOn = DateTime.Now.AddSeconds(
            Convert.ToDouble(ConfigurationManager.AppSettings["AuthTokenExpiry"]));
            
            var objCall = new CallInfo();
            var cmd = new CommandBuilder();
            cmd.SpName = "sp_CreateToken";
            cmd.SqlParams = new List<SqlParameter>()
            {
                new SqlParameter("@UserId",userId),
                new SqlParameter("@AuthToken",token),
                new SqlParameter("@IssuedOn",issuedOn),
                new SqlParameter("@ExpiredOn",expiredOn)
            };
            
            bool ret = objCall.Insert(cmd);
            
            var tokenModel = new TokenEntity()
            {
                UserId = userId,
                IssuedOn = issuedOn,
                ExpiredOn = expiredOn,
                AuthToken = token
            };

            return tokenModel;
        }

        /// <summary>
        /// Method to validate token against expiry and existence in database.
        /// </summary>
        /// <param name="tokenId"></param>
        /// <returns></returns>
        public bool ValidateToken(string tokenId)
        {
            var objCall = new CallInfo();
            var cmd = new CommandBuilder();
            cmd.SpName = "sp_ValidateToken";
            cmd.SqlParams = new List<SqlParameter>()
            {
                new SqlParameter("@AuthToken",tokenId),
                new SqlParameter("@AuthTokenExpiry",ConfigurationManager.AppSettings["AuthTokenExpiry"])
            };

            return objCall.Update(cmd);

        }

        /// <summary>
        /// Method to kill the provided token id.
        /// </summary>
        /// <param name="tokenId">true for successful delete</param>
        public bool Kill(string tokenId)
        {
            var objCall = new CallInfo();
            var cmd = new CommandBuilder();
            cmd.SpName = "sp_KillToken";
            cmd.SqlParams = new List<SqlParameter>()
            {
                new SqlParameter("@AuthToken",tokenId)
            };

            return objCall.Update(cmd);
        }

        /// <summary>
        /// Delete tokens for the specific deleted user
        /// </summary>
        /// <param name="userId"></param>
        /// <returns>true for successful delete</returns>
        public bool DeleteByUserId(int userId)
        {
            var objCall = new CallInfo();
            var cmd = new CommandBuilder();
            cmd.SpName = "sp_DeleteUserAllToken";
            cmd.SqlParams = new List<SqlParameter>()
            {
                new SqlParameter("@UserId",userId)
            };

            return objCall.Update(cmd);
        }

        #endregion
    }
}
