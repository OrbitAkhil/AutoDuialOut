﻿using DataModel.DataAccessLayer;
using DataModel.UnitOfWork;
using System;
using System.Collections.Generic;
using System.Data.SqlClient;
using System.Linq;
using System.Web;

namespace MosiacWebDropOutApi.BusinessServices
{
    /// <summary>
    /// Offers services for user specific operations
    /// </summary>
    public class UserServices : IUserServices
    {
        private readonly UnitOfWork _unitOfWork;

        /// <summary>
        /// Public constructor.
        /// </summary>
        public UserServices(UnitOfWork unitOfWork)
        {
            _unitOfWork = unitOfWork;
        }

        /// <summary>
        /// Public method to authenticate user by user name and password.
        /// </summary>
        /// <param name="userName"></param>
        /// <param name="password"></param>
        /// <returns></returns>
        public int Authenticate(string userName, string password)
        {
            var objCall = new CallInfo();
            var cmd = new CommandBuilder();
            cmd.SpName = "sp_GetWebApiUser";
            cmd.SqlParams = new List<SqlParameter>()
            {
                new SqlParameter("@UserName",userName),
                new SqlParameter("@Password",password)
            };
            var ds = objCall.Select(cmd);
            if (ds.Tables.Count > 0)
            {
                if (ds.Tables[0].Rows.Count > 0)
                {
                    var row = ds.Tables[0].Rows[0];
                    return row["UserId"] != DBNull.Value ? Convert.ToInt32(row["UserId"]) : 0;
                }
                else
                    return 0;
            }
            return 0;
        }

        public int TestAuthenticate(string userName, string password)
        {
            var objCall = new CallInfo();
            var cmd = new TestCommandBuilder();
            cmd.SpName = "sp_GetWebApiUser";
            cmd.SqlParams = new List<SqlParameter>()
            {
                new SqlParameter("@UserName",userName),
                new SqlParameter("@Password",password)
            };
            var ds = objCall.Select(cmd);
            if (ds.Tables.Count > 0)
            {
                if (ds.Tables[0].Rows.Count > 0)
                {
                    var row = ds.Tables[0].Rows[0];
                    return row["UserId"] != DBNull.Value ? Convert.ToInt32(row["UserId"]) : 0;
                }
                else
                    return 0;
            }
            return 0;
        }
    }
}