﻿using BusinessEntities;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace MosiacWebDropOutApi.BusinessServices
{
    public interface IDropCallServices
    {
        bool AddNewCall(DropoutCustomerV2 dropCall);
        bool AddNewTestCall(TestDropoutCustomer dropCall);
    }
}
