import sun.misc.BASE64Decoder;
import sun.misc.BASE64Encoder;


public class ConvertToBase64 {

	/**
	 * @param args
	 */
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		String json ="{"+
			    "\"messageCode\": \"1002\","+
			    "\"traceId\": \"ABC0001\","+
			    "\"timestamp\": \"20160624154123\","+
			    "\"campaignId\": \"801\","+
			    "\"campaignCode\": \"J1HYj64P8SHpoZvtCjDM8+Q90nF3l/NxwMT8+g+Q/8M=\","+
			    "\"fields\": [{"+
			        "\"fieldName\": \"UDF 1\","+
			        "\"value\": \"abc@gmail.com\","+
			        "\"display\": \"fixed\""+
			    "}, {"+
			        "\"fieldName\": \"UDF 2\","+
			        "\"value\": \"Renewal\","+
			        "\"display\": \"fixed\""+
			    "},{"+
			        "\"fieldName\": \"UDF 5\","+
			        "\"value\": \"Suraj\","+
			        "\"display\": \"fixed\""+
			    "},{"+
			        "\"fieldName\": \"UDF 7\","+
			        "\"value\": \"1234567890\","+
			        "\"display\": \"hidden\""+
			    "},{"+
			        "\"fieldName\": \"UDF 8\","+
			        "\"value\": \"50\","+
			        "\"display\": \"fixed\""+
			    "}],"+
			    "\"checksum\":\"a57c3a6c0524069a1cda2fb91f229b3d\""+
			"}";
			//json = "123";
			byte[] bytes = json.getBytes();
	
			//E38C573162EC80F08971D2BCBD0C7A70BC4B1A6F1FA24C53BE341287B0130389
			BASE64Encoder encoder = new BASE64Encoder();
			String encodedJson	=	encoder.encode(bytes);
			System.out.println("encodedJson : "+encodedJson);
			
			BASE64Decoder decoder = new BASE64Decoder();
			try{
				byte a[] = decoder.decodeBuffer(encodedJson);
				System.out.println("Decoded String :"+new String(a));
			}catch(Exception e){
				e.printStackTrace();
			}

	}

}
