import java.security.MessageDigest;


public class MD5Checksum {

	/**
	 * @param args
	 */
	private static String bytesToHex (byte[] b) {
		char hexDigit[] = { '0', '1', '2', '3', '4', '5', '6', '7', '8', '9', 'a', 'b', 'c', 'd', 'e', 'f' };
		StringBuffer buf = new StringBuffer ( );
		for ( int j = 0; j < b.length; j++ ){
			buf.append(hexDigit[(b[j] >> 4 ) & 0x0f]);
			buf.append(hexDigit[b[j] & 0x0f]);
		}
		return buf.toString ( );
	}
	public static String calculateMD5CheckSum (String input){
		String checkSum = "";
		try{
			MessageDigest md = MessageDigest.getInstance("MD5");
			md.update (input.getBytes());
			byte[] output = md.digest();
			checkSum = bytesToHex(output);
		} catch ( Exception e ){
			System.out.println("Error in checksum computation:"+e);
		}
		return checkSum;
	}
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		String key = "J1HYj64P8SHpoZvtCjDM8+Q90nF3l/NxwMT8+g+Q/8M=";
		String str = "UDF 1|abc@gmail.com|UDF 2|Fresh|UDF 5|Suraj|UDF 7|1234567890|UDF 8|50|"+key;
		System.out.println(str);
		String checkSum = calculateMD5CheckSum(str);
		System.out.println("checkSum : ["+checkSum+"]");
	}

}
