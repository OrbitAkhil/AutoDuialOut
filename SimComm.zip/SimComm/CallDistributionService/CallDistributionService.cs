﻿using DataAccessLayer;
using NLog;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Configuration;
using System.Data;
using System.Diagnostics;
using System.Linq;
using System.ServiceProcess;
using System.Text;
using System.Threading.Tasks;
using TSAPIClient;
using TSAPIClient.CSTA;
using TSAPIMaster;

namespace CallDistributionService
{
    public partial class CallDistributionService : ServiceBase
    {
        private Client m_Client;
        private Logger logger = LogManager.GetLogger("DatabaseLogger");
        private System.Timers.Timer _timer;
        private readonly DataAccess dataAccess = new DataAccess();
        private readonly  CommandBuilder cmd = new CommandBuilder();
        private readonly string countryCode = config.AppSettings.Settings["DialPrefix"].ToString();
        private readonly int reasonCode = Convert.ToInt32(config.AppSettings.Settings["AgentReasonCode"].Value);
        public CallDistributionService()
        {
            if (config.AppSettings.Settings["ServerID"].Value != "" ||
                    config.AppSettings.Settings["ServerID"].Value != "AVAYA#Switch_Connection#Service_Type#AE_Service")
            {
                config.AppSettings.Settings["ServerID"].Value = ServerCommand.GetServerName();
            }

            try { this.tsapiServer = config.AppSettings.Settings["ServerID"].Value; }
            catch { this.configured = false; }
            try { this.tsapiLogin = config.AppSettings.Settings["TSAPI_login"].Value; }
            catch { this.configured = false; }
            try { this.tsapiPassword = config.AppSettings.Settings["TSAPI_Password"].Value; }
            catch { this.configured = false; }
            try { this.tsapiApplicationName = config.AppSettings.Settings["ApplicationName"].Value; }
            catch { this.configured = false; }
            try { this.tsapiApplicationVersion = config.AppSettings.Settings["ApiVersion"].Value; }
            catch { this.configured = false; }

            _timer = new System.Timers.Timer();
            _timer.Interval = Convert.ToInt32( config.AppSettings.Settings["TimerInterval"].Value); // 60000;
            _timer.Elapsed += new System.Timers.ElapsedEventHandler(timeDelay_Elapsed); 

            InitializeComponent();
        }

        protected override void OnStart(string[] args)
        {
            OpenStream();
        }

        protected override void OnStop()
        {
            logger.Info(" Service closes at {0}.", DateTime.Now);
            if (m_Client == null)
                return;
            
            m_Client.acsAbortStream();
        }

        void timeDelay_Elapsed(object sender, System.Timers.ElapsedEventArgs e)
        {
            try
            {
                //Restart handle if it is inactive
                CheckHandler();

                if (configured)
                {
                    cmd.CommandText = "Select Count(*) from tbl_Call_Diversion with(nolock) where IsAllocated='N' and CallIncomingDateTime <= Getdate() ";
                    int callCount = Convert.ToInt32(dataAccess.GetScalerRecord(cmd));
                    if (callCount > 0)
                    {
                        cmd.CommandText = "Select AgentId,ExtensionNo,LoginType from tbl_AutoDial_Login with(nolock) where LoginStatus='D' order by LoginDateTime";
                        var ds = dataAccess.Select(cmd);
                        if (ds.Tables[0].Rows.Count > 0)
                        {
                            foreach (DataRow dr in ds.Tables[0].Rows)
                            {
                                int agentId = Convert.ToInt32(dr["AgentId"]);
                                int extensionNo = Convert.ToInt32(dr["ExtensionNo"]);

                                cmd.CommandText = "select count(*) from tbl_AutoDial_Call_Diversion with(nolock) where AgentId='" + agentId + "' and ExtensionNo='" + extensionNo + "' and CallStatus NOT IN ('I','S')";
                                int agentCallCount = Convert.ToInt32(dataAccess.GetScalerRecord(cmd));
                                //Allocate call to Idle agent
                                if (agentCallCount == 0)
                                {
                                    AllocateCallToAgent(agentId.ToString(), extensionNo.ToString());
                                }
                            }
                        }
                    }
                }
            }
            catch (Exception ex)
            {
                logger.Error(ex);
            }
        }
        #region Private Methods

        private void OpenStream()
        {
            if (string.IsNullOrWhiteSpace(tsapiServer))
            {
                return;
            }

            if (string.IsNullOrWhiteSpace(tsapiLogin))
            {
                return;
            }

            if (string.IsNullOrWhiteSpace(tsapiPassword))
            {
                return;
            }

            m_Client = new Client();

            BackgroundWorker worker = new BackgroundWorker();
            worker.WorkerReportsProgress = true;
            var connectCmd = new ConnectCommand(m_Client, tsapiServer, tsapiLogin, tsapiPassword);

            worker.DoWork += (o, args) =>
            {
                connectCmd.Connect();

                worker.ReportProgress(100);
            };

            worker.RunWorkerCompleted += (o, args) =>
            {
                if (connectCmd.Connected)
                {
                    logger.Info("Connected!\n");
                    logger.Info(string.Format("ApiVersion={0}\n", connectCmd.ApiVersion));
                    logger.Info(string.Format("DriverVersion={0}\n", connectCmd.DriverVersion));
                    logger.Info(string.Format("LibraryVersion={0}\n", connectCmd.LibraryVersion));
                    logger.Info(string.Format("ServerVersion={0}\n", connectCmd.ServerVersion));
                    logger.Info(string.Format("PrivateDataVersion={0}\n", connectCmd.PrivateDataVersion));
                    configured = true;
                    //m_Client.TSAPIEvent += onTSAPIEvent;
                }
                else
                {
                    configured = false;
                    logger.Info("Connection Failed!\n");
                    logger.Info(string.Format("ErrorMessage={0}\n", connectCmd.ErrorMessage));
                }
            };

            logger.Info("connect...\n");
            worker.RunWorkerAsync();
        }

        private void AllocateCallToAgent(string agentId,string extensionNo )
        {
            BackgroundWorker worker = new BackgroundWorker();
            worker.WorkerReportsProgress = true;
            QueryAgentStateCommand agentStateCmd = null;
            worker.DoWork += (o, args) =>
            {
                agentStateCmd = new QueryAgentStateCommand(m_Client, extensionNo);
                agentStateCmd.QueryAgentState();


                worker.ReportProgress(100);
            };

            worker.RunWorkerCompleted += (o, args) =>
            {
                logger.Info("done getting Agent State.\n");
                
                if (agentStateCmd.WorkMode == TSAPIClient.ATT.ATTWorkMode_t.WM_AUX_WORK && agentStateCmd.ReasonCode == reasonCode)
                {
                    try
                    {
                        // Get new call
                        cmd.CommandText = "select top 1  CallerId,CallerName,right(CallerMobile,10) as CallerNumber,Id from tbl_Call_Diversion with(nolock) where IsAllocated='N' and CallIncomingDateTime <= Getdate() Order By CreatedOn desc ";
                        var ds = dataAccess.Select(cmd);
                        if (ds.Tables[0].Rows.Count > 0)
                        {


                            var dr = ds.Tables[0].Rows[0];

                            int recordId = Convert.ToInt32(dr["Id"]);
                            int callerId = Convert.ToInt32(dr["CallerId"]);
                            string callerName = Convert.ToString(dr["CallerName"]);
                            string callerNumber = dr["CallerNumber"] != DBNull.Value ? Convert.ToString(dr["CallerNumber"]) : string.Empty;


                            logger.Info("Query Agent State for Caller Id {0} , Caller Number {1}  - Agent State {2} , ReasonCode {3}", callerId, callerNumber, agentStateCmd.AgentState, reasonCode);
                            if (!string.IsNullOrEmpty(callerNumber))
                            {
                                if (callerNumber.StartsWith("0"))
                                    callerNumber = Convert.ToString(dr["CallerNumber"]).TrimStart('0');
                                else
                                    callerNumber = Convert.ToString(dr["CallerNumber"]);

                                callerNumber = countryCode + callerNumber;

                                // Allocate call to agent..
                                cmd.CommandText = "Insert into tbl_AutoDial_Call_Diversion(CallerId,CallerName,CallStatus,CallerMobile,AgentId,ExtensionNo,DropOutId) values (" + callerId + ",'" + callerName + "','A','" + callerNumber + "'," + agentId + ",'" + extensionNo + "'," + recordId + ")";
                                dataAccess.Insert(cmd);

                               
                                cmd.CommandText = "Update tbl_Call_Diversion set IsAllocated = 'Y' where IsAllocated = 'N' and Id=" + recordId + " ";
                                dataAccess.Update(cmd);
                            }
                        }
                    }
                    catch(Exception ex)
                    {
                        logger.Error(ex);
                    }
                }
                //else
                //{
                    //Simulator.Instance.LSetAgentState(agentId.ToString(), extensionNo.ToString(), Tsapi.Csta.AgentMode_t.AM_NOT_READY, Tsapi.Att.ATTWorkMode_t.WM_AUX_WORK);

                    //var agentState = Simulator.Instance.GetAgentState(agentId.ToString(), extensionNo.ToString());
                    //logger.Info(agentState);
                    //if (agentState == Tsapi.Att.ATTWorkMode_t.WM_AUX_WORK)
                    //{
                    //    cmd = new CommandBuilder();
                    //    cmd.CommandText = "Insert into tbl_AutoDial_Call_Diversion(CallerId,CallerName,CallStatus,CallerMobile,AgentId,ExtensionNo,DropOutId) values (" + premiumCallerId + ",'" + premiumCallerName + "','A','" + premiumCallerNumber + "'," + agentId + ",'" + extensionNo + "'," + recordId + ")";
                    //    objCall.Insert(cmd);

                    //    cmd = new CommandBuilder();
                    //    cmd.CommandText = "Update tbl_Call_Diversion set IsAllocated = 'Y' where IsAllocated = 'N' and Id=" + recordId + " ";
                    //    objCall.Update(cmd);
                    //}
                //}

            };

            logger.Info("get Agent State...\n");
            worker.RunWorkerAsync();

            
        }

        private void CheckHandler()
        {
            if (new CheckHandlerCommand(m_Client).IsBadHandler())
            {
                configured = false;
                OpenStream();
            }
        }
        #endregion
        

    }
}
