﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading;
using System.Threading.Tasks;
using TSAPIClient;
using TSAPIClient.CSTA;
using Constants = TSAPIClient.CSTA.Constants;
namespace TSAPIMaster
{
    public class HangUpCommand
    {
        private readonly Client m_Client;
        private readonly string m_DeviceDN;
        private readonly int m_CallID;
        private readonly ManualResetEvent m_ResponseReceived = new ManualResetEvent(false);
        private readonly int m_InvokeID = InvokeIDGenerator.Generate();

        public string ErrorMessage { get; private set; }

        public HangUpCommand(Client client, string deviceDN, int callID)
        {
            m_Client = client;
            m_DeviceDN = deviceDN;
            m_CallID = callID;
        }

        public bool HangUp()
        {
            try
            {
                m_Client.TSAPIEvent += onTSAPIEvent;

                int result = m_Client.cstaClearConnection(new TSAPIClearConnectionRequest() { InvokeID = m_InvokeID, DeviceID = m_DeviceDN, CallID = m_CallID });

                if (result != 0)
                {
                    return false;
                }

                return m_ResponseReceived.WaitOne(TimeSpan.FromSeconds(5));
            }
            finally
            {
                m_Client.TSAPIEvent -= onTSAPIEvent;
            }
        }

        private void onTSAPIEvent(object sender, TSAPIEventArgs e)
        {
            if (e == null || e.cstaEvent == null || e.cstaEvent.eventHeader.eventClass != Constants.CSTACONFIRMATION)
            {
                return;
            }

            if (e.cstaEvent.eventHeader.eventType == Constants.CSTA_CLEAR_CONNECTION_CONF)
            {
                m_ResponseReceived.Set();
            }
            else if (e.cstaEvent.eventHeader.eventType == Constants.ACS_UNIVERSAL_FAILURE_CONF)
            {
                ACSConfirmationEvent acsConfirmation = e.cstaEvent.Event.acsConfirmation;

                if (acsConfirmation.u.failureEvent != null)
                {
                    ACSUniversalFailureConfEvent_t failureEvent = (ACSUniversalFailureConfEvent_t)acsConfirmation.u.failureEvent;

                    ErrorMessage = failureEvent.error.ToString();

                    m_ResponseReceived.Set();
                }
            }
        }
    }
}
