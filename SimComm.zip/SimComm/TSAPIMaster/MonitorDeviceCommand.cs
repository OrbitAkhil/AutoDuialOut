﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading;
using System.Threading.Tasks;
using TSAPIClient;
using TSAPIClient.CSTA;
using Constants = TSAPIClient.CSTA.Constants;
namespace TSAPIMaster
{
    public class MonitorDeviceCommand
    {
        private readonly Client m_Client;
        private readonly ManualResetEvent m_ResponseReceived = new ManualResetEvent(false);
        private readonly string m_DeviceID;
        private readonly int m_InvokeID = InvokeIDGenerator.Generate();

        public int MonitorCrossRef { get; private set; }

        public MonitorDeviceCommand(Client client, string deviceID)
        {
            m_Client = client;
            m_DeviceID = deviceID;
        }

        public void MonitorDevice()
        {
            try
            {
                m_Client.TSAPIEvent += onTSAPIEvent;

                int ret = m_Client.cstaMonitorCallsViaDevice(new TSAPIMonitorCallsViaDeviceRequest() { InvokeID = m_InvokeID, DeviceID = m_DeviceID, AgentFilter = 0, FeatureFilter = 0, MaintenanceFilter = 0, PrivateFilter = 0, FilterPrivateData = false, CallFilter = 0 });

                if (ret != 0)
                {
                    return;
                }

                m_ResponseReceived.WaitOne(TimeSpan.FromSeconds(5));
            }
            finally
            {
                m_Client.TSAPIEvent -= onTSAPIEvent;
            }
        }

        private void onTSAPIEvent(object sender, TSAPIEventArgs e)
        {
            if (e == null || e.cstaEvent == null || e.cstaEvent.eventHeader.eventClass != Constants.CSTACONFIRMATION || e.cstaEvent.Event.cstaConfirmation == null || e.cstaEvent.Event.cstaConfirmation.invokeID != m_InvokeID || e.cstaEvent.eventHeader.eventType != Constants.CSTA_MONITOR_CONF || e.cstaEvent.Event.cstaConfirmation.u.monitorStart == null)
            {
                return;
            }

            CSTAMonitorConfEvent_t monitorStart = (CSTAMonitorConfEvent_t)e.cstaEvent.Event.cstaConfirmation.u.monitorStart;

            MonitorCrossRef = monitorStart.monitorCrossRefID;

            m_ResponseReceived.Set();
        }
    }
}
