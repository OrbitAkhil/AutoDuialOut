﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading;
using System.Threading.Tasks;
using TSAPIClient;
using TSAPIClient.ATT;
using TSAPIClient.CSTA;
using Constants = TSAPIClient.CSTA.Constants;
namespace TSAPIMaster
{
    public class QueryDeviceCommand
    {
        private readonly Client m_Client;
        private readonly ManualResetEvent m_ResponseReceived = new ManualResetEvent(false);
        private readonly string m_DeviceID;
        private readonly int m_InvokeID = InvokeIDGenerator.Generate();
        private string m_DeviceType = string.Empty;

        public string DeviceType { get { return m_DeviceType; } }

        private string m_AssociatedDevice = string.Empty;

        public string AssociatedDevice { get { return m_AssociatedDevice; } }

        public QueryDeviceCommand(Client client, string deviceID)
        {
            m_Client = client;
            m_DeviceID = deviceID;
        }

        public void QueryDevice()
        {
            try
            {
                m_Client.TSAPIEvent += onTSAPIEvent;

                int ret = m_Client.cstaQueryDeviceInfo(new TSAPIQueryDeviceInfoRequest() { InvokeID = m_InvokeID, DeviceID = m_DeviceID });

                if (ret != 0)
                {
                    return;
                }

                m_ResponseReceived.WaitOne(TimeSpan.FromSeconds(5));
            }
            finally
            {
                m_Client.TSAPIEvent -= onTSAPIEvent;
            }
        }

        private void onTSAPIEvent(object sender, TSAPIEventArgs e)
        {
            if (e == null || e.cstaEvent == null || e.cstaEvent.eventHeader.eventClass != Constants.CSTACONFIRMATION || e.cstaEvent.Event.cstaConfirmation == null || e.cstaEvent.Event.cstaConfirmation.invokeID != m_InvokeID || e.cstaEvent.eventHeader.eventType != Constants.CSTA_QUERY_DEVICE_INFO_CONF || e.cstaEvent.Event.cstaConfirmation.u.queryDeviceInfo == null)
            {
                return;
            }


            ATTEvent_t attEvent = e.attEvent;
            CSTAConfirmationEvent cstaConfirmation = e.cstaEvent.Event.cstaConfirmation;
            if (e.cstaEvent.eventHeader.eventType == Constants.CSTA_QUERY_DEVICE_INFO_CONF)
            {
                if (cstaConfirmation.u.queryDeviceInfo != null)
                {
                    CSTAQueryDeviceInfoConfEvent_t queryDeviceInfo = (CSTAQueryDeviceInfoConfEvent_t)e.cstaEvent.Event.cstaConfirmation.u.queryDeviceInfo;
                    m_DeviceType = queryDeviceInfo.deviceType.ToString();

                    if (attEvent.u.queryDeviceInfo != null)
                    {
                        ATTQueryDeviceInfoConfEvent_t attQueryDeviceInfo = (ATTQueryDeviceInfoConfEvent_t)attEvent.u.queryDeviceInfo;

                        m_AssociatedDevice = attQueryDeviceInfo.associatedDevice.device;
                    }
                }

                m_ResponseReceived.Set();
            }

        }
    }
}
