﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using TSAPIClient;

namespace TSAPIMaster
{
    public class ServerCommand
    {
        public static string GetServerName()
        {
            var serverNames = Client.acsEnumServerNames();

            //outputLogger.Info(string.Format("Server Names: [{0}]\n", string.Join(",", serverNames)));
            if (serverNames.Length == 0)
                return null;

            return serverNames[serverNames.Length - 1];

        }

        
    }
}
