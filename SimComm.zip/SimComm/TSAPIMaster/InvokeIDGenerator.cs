﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading;
using System.Threading.Tasks;
namespace TSAPIMaster
{
    public static class InvokeIDGenerator
    {
        private static int m_LastInvokeID;
        private static readonly object locker = new object();
        public static int Generate()
        {
            int intNextInvokeID;

            lock (locker)
            {
                if (m_LastInvokeID == int.MaxValue)
                {
                    m_LastInvokeID = 0;
                }

                m_LastInvokeID++;

                intNextInvokeID = m_LastInvokeID;
            }

            return intNextInvokeID;
        }
    }
}
