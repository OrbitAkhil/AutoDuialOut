﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading;
using System.Threading.Tasks;
using TSAPIClient;
using TSAPIClient.ATT;
using TSAPIClient.CSTA;
using Constants = TSAPIClient.CSTA.Constants;
namespace TSAPIMaster
{
    public class QueryAgentStateCommand
    {
        private readonly Client m_Client;
        private readonly ManualResetEvent m_ResponseReceived = new ManualResetEvent(false);
        private readonly string m_DeviceID;
        private readonly int m_InvokeID = InvokeIDGenerator.Generate();
        private AgentState_t m_AgentState = 0;

        public AgentState_t AgentState { get { return m_AgentState; } }

        private int m_ReasonCode = 0;

        public int ReasonCode { get { return m_ReasonCode; } }

        private ATTWorkMode_t m_WorkMode = 0;

        public ATTWorkMode_t WorkMode { get { return m_WorkMode; } }

        private ATTTalkState_t m_TalkState = 0;

        public ATTTalkState_t TalkState { get { return m_TalkState; } }

        private int m_PendingReasonCode = 0;

        public int PendingReasonCode { get { return m_PendingReasonCode; } }

        private ATTWorkMode_t m_PendingWorkMode = 0;

        public ATTWorkMode_t PendingWorkMode { get { return m_PendingWorkMode; } }

        public QueryAgentStateCommand(Client client, string deviceID)
        {
            m_Client = client;
            m_DeviceID = deviceID;
        }

        public void QueryAgentState()
        {
            try
            {
                m_Client.TSAPIEvent += onTSAPIEvent;

                int ret = m_Client.cstaQueryAgentState(new TSAPIQueryAgentStateRequest() { InvokeID = m_InvokeID, DeviceID = m_DeviceID });

                if (ret != 0)
                {
                    return;
                }

                m_ResponseReceived.WaitOne(TimeSpan.FromSeconds(5));
            }
            finally
            {
                m_Client.TSAPIEvent -= onTSAPIEvent;
            }
        }

        private void onTSAPIEvent(object sender, TSAPIEventArgs e)
        {
            if (e == null || e.cstaEvent == null || e.cstaEvent.eventHeader.eventClass != Constants.CSTACONFIRMATION || e.cstaEvent.Event.cstaConfirmation == null || e.cstaEvent.Event.cstaConfirmation.invokeID != m_InvokeID || e.cstaEvent.eventHeader.eventType != Constants.CSTA_QUERY_AGENT_STATE_CONF || e.cstaEvent.Event.cstaConfirmation.u.queryAgentState == null)
            {
                return;
            }


            ATTEvent_t attEvent = e.attEvent;
            CSTAConfirmationEvent cstaConfirmation = e.cstaEvent.Event.cstaConfirmation;
            if (e.cstaEvent.eventHeader.eventType == Constants.CSTA_QUERY_AGENT_STATE_CONF)
            {
                if (cstaConfirmation.u.queryAgentState != null)
                {
                    CSTAQueryAgentStateConfEvent_t queryAgentState = (CSTAQueryAgentStateConfEvent_t)e.cstaEvent.Event.cstaConfirmation.u.queryAgentState;
                    m_AgentState = queryAgentState.agentState;
                    if (attEvent.u.queryAgentState != null)
                    {
                        ATTQueryAgentStateConfEvent_t attQueryAgentState = (ATTQueryAgentStateConfEvent_t)attEvent.u.queryAgentState;

                        m_ReasonCode = attQueryAgentState.reasonCode;
                        m_PendingReasonCode = attQueryAgentState.pendingReasonCode;
                        m_WorkMode = attQueryAgentState.workMode;
                        m_PendingWorkMode = attQueryAgentState.pendingWorkMode;
                        m_TalkState = attQueryAgentState.talkState;
                    }
                }

                m_ResponseReceived.Set();
            }

        }
    }
}
