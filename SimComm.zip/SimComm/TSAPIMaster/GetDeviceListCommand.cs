﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading;
using System.Threading.Tasks;
using TSAPIClient;
using TSAPIClient.CSTA;
using Constants = TSAPIClient.CSTA.Constants;
namespace TSAPIMaster
{
    public class GetDeviceListCommand
    {
        private readonly Client m_Client;
        private readonly ManualResetEvent m_ResponseReceived = new ManualResetEvent(false);
        private readonly int m_InvokeID = InvokeIDGenerator.Generate();
        private string[] m_Devices = new string[] { };

        public GetDeviceListCommand(Client client)
        {
            m_Client = client;
        }

        public string[] GetDeviceList()
        {
            try
            {
                m_Client.TSAPIEvent += onTSAPIEvent;

                int result = m_Client.cstaGetDeviceList(new TSAPIGetDeviceListRequest() { InvokeID = m_InvokeID, Index = -1, Level = CSTALevel_t.CSTA_DEVICE_DEVICE_MONITOR });

                if (result != 0)
                {
                    return new string[] { };
                }

                m_ResponseReceived.WaitOne(TimeSpan.FromSeconds(5));

                return m_Devices;
            }
            finally
            {
                m_Client.TSAPIEvent -= onTSAPIEvent;
            }
        }

        private void onTSAPIEvent(object sender, TSAPIEventArgs e)
        {
            if (e == null || e.cstaEvent == null || e.cstaEvent.eventHeader.eventClass != Constants.CSTACONFIRMATION || e.cstaEvent.Event.cstaConfirmation == null || e.cstaEvent.Event.cstaConfirmation.invokeID != m_InvokeID || e.cstaEvent.eventHeader.eventType != Constants.CSTA_GET_DEVICE_LIST_CONF || e.cstaEvent.Event.cstaConfirmation.u.getDeviceList == null)
            {
                return;
            }

            CSTAGetDeviceListConfEvent_t getDeviceList = (CSTAGetDeviceListConfEvent_t)e.cstaEvent.Event.cstaConfirmation.u.getDeviceList;

            m_Devices = getDeviceList.devList.device.Select(d => d.device).ToArray();
        }
    }
}
