﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading;
using System.Threading.Tasks;
using TSAPIClient;
using TSAPIClient.CSTA;
using Constants = TSAPIClient.CSTA.Constants;
namespace TSAPIMaster
{
    public class DisconnectCommand
    {
        private readonly Client m_Client;
        private readonly ManualResetEvent m_ResponseReceived = new ManualResetEvent(false);
        private readonly int m_InvokeID = InvokeIDGenerator.Generate();

        public bool Disconnected { get; private set; }
        public string ErrorMessage { get; private set; }

        public DisconnectCommand(Client client)
        {
            m_Client = client;
        }

        public bool Disconnect()
        {
            try
            {
                m_Client.TSAPIEvent += onTSAPIEvent;

                int result = m_Client.acsCloseStream(new TSAPICloseStreamRequest() { InvokeID = m_InvokeID });

                if (result != 0)
                {
                    return false;
                }

                m_ResponseReceived.WaitOne(TimeSpan.FromMinutes(1));

                return Disconnected;
            }
            finally
            {
                m_Client.TSAPIEvent -= onTSAPIEvent;
            }
        }

        private void onTSAPIEvent(object sender, TSAPIEventArgs e)
        {
            if (e == null || e.cstaEvent == null || e.cstaEvent.eventHeader.eventClass != Constants.ACSCONFIRMATION)
            {
                return;
            }

            ACSConfirmationEvent acsConfirmation = e.cstaEvent.Event.acsConfirmation;

            if (e.cstaEvent.eventHeader.eventType == Constants.ACS_CLOSE_STREAM_CONF)
            {
                Disconnected = true;

                if (acsConfirmation.u.acsclose != null)
                {
                    ACSCloseStreamConfEvent_t acsclose = (ACSCloseStreamConfEvent_t)acsConfirmation.u.acsclose;

                    //consoleLogger.Info("ACS Handle closed successfully");
                    //consoleLogger.Info(string.Format("TSAPIFacade.Connect: apiVer={0};drvrVer={1};libVer={2};tsrvVer={3};", acsopen.apiVer, acsopen.drvrVer, acsopen.libVer, acsopen.tsrvVer));
                }

                m_ResponseReceived.Set();
            }
            else if (e.cstaEvent.eventHeader.eventType == Constants.ACS_UNIVERSAL_FAILURE_CONF)
            {
                if (acsConfirmation.u.failureEvent != null)
                {
                    ACSUniversalFailureConfEvent_t failureEvent = (ACSUniversalFailureConfEvent_t)acsConfirmation.u.failureEvent;

                    ErrorMessage = failureEvent.error.ToString();
                    //consoleLogger.Info("ACS Handle closed unSuccessfully with error {0}",ErrorMessage);
                    m_ResponseReceived.Set();
                }
            }
        }
    }
}
