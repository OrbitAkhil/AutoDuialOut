﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading;
using System.Threading.Tasks;
using TSAPIClient;
using TSAPIClient.ATT;
using TSAPIClient.CSTA;
using Constants = TSAPIClient.CSTA.Constants;
namespace TSAPIMaster
{
    public class SetAgentStateCommand
    {
        private readonly Client m_Client;
        private readonly ManualResetEvent m_ResponseReceived = new ManualResetEvent(false);
        private readonly int m_InvokeID = InvokeIDGenerator.Generate();
        private string m_DeviceID = string.Empty;


        private string m_AgentID = string.Empty;


        private string m_AgentGroup = string.Empty;


        private string m_AgentPassword = string.Empty;

        private AgentMode_t m_AgentMode = AgentMode_t.AM_READY;


        private ATTWorkMode_t m_WorkMode = ATTWorkMode_t.WM_NONE;


        private int m_ReasonCode;


        private bool m_EnablePending = true;


        public SetAgentStateCommand(Client client, string deviceID, string agentId, string agentGroup, AgentMode_t agentMode, string agentPassword, int reasonCode, bool enablePending, ATTWorkMode_t workMode)
        {
            m_Client = client;
            m_DeviceID = deviceID;
            m_ReasonCode = reasonCode;
            m_AgentID = agentId;
            m_AgentGroup = agentGroup;
            m_AgentPassword = agentPassword;
            m_AgentMode = agentMode;
            m_EnablePending = enablePending;
            m_WorkMode = workMode;
        }

        public void SetAgentState()
        {
            try
            {
                m_Client.TSAPIEvent += onTSAPIEvent;

                int ret = m_Client.cstaSetAgentState(new TSAPISetAgentStateRequest() { InvokeID = m_InvokeID, DeviceID = m_DeviceID, AgentID = m_AgentID, AgentGroup = m_AgentGroup, AgentMode = m_AgentMode, AgentPassword = m_AgentPassword, EnablePending = m_EnablePending, ReasonCode = m_ReasonCode, WorkMode = m_WorkMode });

                if (ret != 0)
                {
                    return;
                }

                m_ResponseReceived.WaitOne(TimeSpan.FromSeconds(5));
            }
            finally
            {
                m_Client.TSAPIEvent -= onTSAPIEvent;
            }
        }

        private void onTSAPIEvent(object sender, TSAPIEventArgs e)
        {
            if (e == null || e.cstaEvent == null || e.cstaEvent.eventHeader.eventClass != Constants.CSTACONFIRMATION || e.cstaEvent.Event.cstaConfirmation == null || e.cstaEvent.Event.cstaConfirmation.invokeID != m_InvokeID || e.cstaEvent.eventHeader.eventType != Constants.CSTA_QUERY_AGENT_STATE_CONF || e.cstaEvent.Event.cstaConfirmation.u.queryAgentState == null)
            {
                return;
            }


            ATTEvent_t attEvent = e.attEvent;
            CSTAConfirmationEvent cstaConfirmation = e.cstaEvent.Event.cstaConfirmation;
            if (e.cstaEvent.eventHeader.eventType == Constants.CSTA_SET_AGENT_STATE_CONF)
            {
                if (cstaConfirmation.u.setAgentState != null)
                {
                    CSTASetAgentStateConfEvent_t setAgentState = (CSTASetAgentStateConfEvent_t)e.cstaEvent.Event.cstaConfirmation.u.setAgentState;

                }

                m_ResponseReceived.Set();
            }

        }
    }
}
