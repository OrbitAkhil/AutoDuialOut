﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading;
using System.Threading.Tasks;
using TSAPIClient;
using TSAPIClient.CSTA;
using Constants = TSAPIClient.CSTA.Constants;
namespace TSAPIMaster
{
    public class AbortCommand
    {
        private readonly Client m_Client;

        public AbortCommand(Client client)
        {
            m_Client = client;
        }

        public bool Abort()
        {
            try
            {
                //m_Client.TSAPIEvent += onTSAPIEvent;

                int result = m_Client.acsAbortStream();

                if (result != 0)
                {
                    return false;
                }

                //m_ResponseReceived.WaitOne(TimeSpan.FromMinutes(1));

                return true;
            }
            finally
            {
                // m_Client.TSAPIEvent -= onTSAPIEvent;
            }
        }


    }
}
