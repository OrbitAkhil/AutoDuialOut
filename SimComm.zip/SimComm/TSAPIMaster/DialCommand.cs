﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading;
using System.Threading.Tasks;
using TSAPIClient;
using TSAPIClient.ATT;
using TSAPIClient.CSTA;
using Constants = TSAPIClient.CSTA.Constants;
namespace TSAPIMaster
{
    public class DialCommand
    {
        private readonly Client m_Client;
        private readonly string m_CallingDeviceDN;
        private readonly string m_CalledDeviceDN;
        private readonly ManualResetEvent m_ResponseReceived = new ManualResetEvent(false);
        private readonly int m_InvokeID = InvokeIDGenerator.Generate();

        public int CallID { get; private set; }
        public string UCID { get; private set; }
        public string ErrorMessage { get; private set; }

        public DialCommand(Client client, string callingDeviceDN, string calledDevice)
        {
            m_Client = client;
            m_CallingDeviceDN = callingDeviceDN;
            m_CalledDeviceDN = calledDevice;
        }

        public bool Dial()
        {
            try
            {
                m_Client.TSAPIEvent += onTSAPIEvent;

                int result = m_Client.cstaMakeCall(new TSAPIMakeCallRequest() { InvokeID = m_InvokeID, CallingDevice = m_CallingDeviceDN, CalledDevice = m_CalledDeviceDN, UserInfo = string.Empty });

                if (result != 0)
                {
                    return false;
                }

                m_ResponseReceived.WaitOne(TimeSpan.FromMinutes(1));

                return CallID > 0;
            }
            finally
            {
                m_Client.TSAPIEvent -= onTSAPIEvent;
            }
        }

        private void onTSAPIEvent(object sender, TSAPIEventArgs e)
        {
            if (e == null || e.cstaEvent == null || e.cstaEvent.eventHeader.eventClass != Constants.CSTACONFIRMATION)
            {
                return;
            }

            CSTAEvent_t cstaEvent = e.cstaEvent;
            ATTEvent_t attEvent = e.attEvent;
            CSTAConfirmationEvent cstaConfirmation = e.cstaEvent.Event.cstaConfirmation;

            if (e.cstaEvent.eventHeader.eventType == Constants.CSTA_MAKE_CALL_CONF)
            {
                if (cstaConfirmation.u.makeCall != null)
                {
                    CSTAMakeCallConfEvent_t makeCall = (CSTAMakeCallConfEvent_t)cstaEvent.Event.cstaConfirmation.u.makeCall;

                    CallID = makeCall.newCall.callID;

                    if (attEvent.u.makeCall != null)
                    {
                        ATTMakeCallConfEvent_t attMakeCall = (ATTMakeCallConfEvent_t)attEvent.u.makeCall;

                        UCID = attMakeCall.ucid.value;
                    }
                }

                m_ResponseReceived.Set();
            }
            else if (e.cstaEvent.eventHeader.eventType == Constants.ACS_UNIVERSAL_FAILURE_CONF)
            {
                ACSConfirmationEvent acsConfirmation = e.cstaEvent.Event.acsConfirmation;

                if (acsConfirmation.u.failureEvent != null)
                {
                    ACSUniversalFailureConfEvent_t failureEvent = (ACSUniversalFailureConfEvent_t)acsConfirmation.u.failureEvent;

                    ErrorMessage = failureEvent.error.ToString();

                    m_ResponseReceived.Set();
                }
            }
        }
    }
}
