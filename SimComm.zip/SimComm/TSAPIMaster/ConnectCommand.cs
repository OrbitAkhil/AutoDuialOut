﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading;
using System.Threading.Tasks;
using TSAPIClient;
using TSAPIClient.CSTA;
using Constants = TSAPIClient.CSTA.Constants;
namespace TSAPIMaster
{

    public class ConnectCommand
    {
        private readonly Client m_Client;
        private readonly string m_ServerID;
        private readonly string m_LoginID;
        private readonly string m_Password;
        private readonly ManualResetEvent m_ResponseReceived = new ManualResetEvent(false);
        private readonly int m_InvokeID = InvokeIDGenerator.Generate();

        public bool Connected { get; private set; }
        public string ApiVersion { get; private set; }
        public string DriverVersion { get; private set; }
        public string LibraryVersion { get; private set; }
        public string ServerVersion { get; private set; }
        public int PrivateDataVersion { get; private set; }
        public string ErrorMessage { get; private set; }

        public ConnectCommand(Client client, string serverID, string loginID, string password)
        {
            m_Client = client;
            m_ServerID = serverID;
            m_LoginID = loginID;
            m_Password = password;
        }

        public bool Connect()
        {
            try
            {
                m_Client.TSAPIEvent += onTSAPIEvent;

                int result = m_Client.acsOpenStream(new TSAPIOpenStreamRequest() { InvokeID = m_InvokeID, ServerID = m_ServerID, LoginID = m_LoginID, Passwd = m_Password });

                if (result != 0)
                {
                    return false;
                }

                m_ResponseReceived.WaitOne(TimeSpan.FromMinutes(1));

                return Connected;
            }
            finally
            {
                m_Client.TSAPIEvent -= onTSAPIEvent;
            }
        }

        private void onTSAPIEvent(object sender, TSAPIEventArgs e)
        {
            if (e == null || e.cstaEvent == null || e.cstaEvent.eventHeader.eventClass != Constants.ACSCONFIRMATION)
            {
                return;
            }

            ACSConfirmationEvent acsConfirmation = e.cstaEvent.Event.acsConfirmation;

            if (e.cstaEvent.eventHeader.eventType == Constants.ACS_OPEN_STREAM_CONF)
            {
                Connected = true;

                if (acsConfirmation.u.acsopen != null)
                {
                    ACSOpenStreamConfEvent_t acsopen = (ACSOpenStreamConfEvent_t)acsConfirmation.u.acsopen;

                    //consoleLogger.Info(string.Format("TSAPIFacade.Connect: apiVer={0};drvrVer={1};libVer={2};tsrvVer={3};", acsopen.apiVer, acsopen.drvrVer, acsopen.libVer, acsopen.tsrvVer));

                    ApiVersion = acsopen.apiVer.version;
                    DriverVersion = acsopen.drvrVer.version;
                    LibraryVersion = acsopen.libVer.version;
                    ServerVersion = acsopen.tsrvVer.version;

                    if (e.privateData != null)
                    {
                        PrivateData_t privateData = (PrivateData_t)e.privateData;

                        if (privateData.length > 0)
                        {
                            //consoleLogger.Info(string.Format("TSAPIFacade.Connect: vendor={0}", privateData.vendor));

                            if (privateData.data[0] == Constants.PRIVATE_DATA_ENCODING)
                            {
                                char c = privateData.data[1];
                                PrivateDataVersion = int.Parse(c.ToString());
                            }
                        }
                    }
                }

                m_ResponseReceived.Set();
            }
            else if (e.cstaEvent.eventHeader.eventType == Constants.ACS_UNIVERSAL_FAILURE_CONF)
            {
                if (acsConfirmation.u.failureEvent != null)
                {
                    ACSUniversalFailureConfEvent_t failureEvent = (ACSUniversalFailureConfEvent_t)acsConfirmation.u.failureEvent;

                    ErrorMessage = failureEvent.error.ToString();

                    m_ResponseReceived.Set();
                }
            }
        }
    }
}
