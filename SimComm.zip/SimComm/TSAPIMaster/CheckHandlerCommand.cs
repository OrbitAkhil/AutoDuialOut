﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading;
using System.Threading.Tasks;
using TSAPIClient;
using TSAPIClient.CSTA;
using Constants = TSAPIClient.CSTA.Constants;
namespace TSAPIMaster
{
    public class CheckHandlerCommand
    {
        private readonly Client m_Client;
        private readonly int m_InvokeID = InvokeIDGenerator.Generate();

        public CheckHandlerCommand(Client client)
        {
            m_Client = client;
        }

        public bool IsBadHandler()
        {
            try
            {

                int result = m_Client.cstaGetDeviceList(new TSAPIGetDeviceListRequest() { InvokeID = m_InvokeID, Index = -1, Level = CSTALevel_t.CSTA_DEVICE_DEVICE_MONITOR });
                if (result < 0)
                {
                    return true;
                }
                return false;
            }
            finally
            {
                //m_Client.TSAPIEvent -= onTSAPIEvent;
            }
        }

        private void onTSAPIEvent(object sender, TSAPIEventArgs e)
        {
            if (e == null || e.cstaEvent == null || e.cstaEvent.eventHeader.eventClass != Constants.CSTACONFIRMATION || e.cstaEvent.Event.cstaConfirmation == null || e.cstaEvent.Event.cstaConfirmation.invokeID != m_InvokeID || e.cstaEvent.eventHeader.eventType != Constants.CSTA_GET_DEVICE_LIST_CONF || e.cstaEvent.Event.cstaConfirmation.u.getDeviceList == null)
            {
                return;
            }

        }
    }
}
