﻿using System;
using System.Threading.Tasks;
using Microsoft.AspNet.SignalR;
using TSAPIClientService.Classes;
using System.Linq;
using NLog;

namespace TSAPIClientService
{
    public class TelephonyHub : Hub
    {
        Logger outputLogger = LogManager.GetLogger("OutputLogger");
        
        public void AddMessage(string name, string message)
        {
            Console.WriteLine("Hub AddMessage {0} {1}\n", name, message);
            Clients.All.addMessage(name, message);
        }

        public void Heartbeat()
        {
            Console.WriteLine("Hub Heartbeat\n");
            Clients.All.heartbeat();
        }

        //public override Task OnConnected()
        //{
        //    Console.WriteLine("Hub OnConnected {0}\n", Context.ConnectionId);
        //    return (base.OnConnected());
        //}

        //public override Task OnDisconnected()
        //{
        //    Console.WriteLine("Hub OnDisconnected {0}\n", Context.ConnectionId);
        //    return (base.OnDisconnected());
        //}

        //public override Task OnReconnected()
        //{
        //    Console.WriteLine("Hub OnReconnected {0}\n", Context.ConnectionId);
        //    return (base.OnDisconnected());
        //}
        public ActiveCall GetActiveCall(string extensionNo)
        {
            if (string.IsNullOrEmpty(extensionNo))
                return null;
            //Create an instance of the Repository class
            TelephonyRepository objRepository = new TelephonyRepository();
            return objRepository.GetActiveCall(extensionNo);
        }

        public void DisconnectUser(string agentId, string extensionNo, string uniqueIdentifier)
        {
            LoginRepository objRepository = new LoginRepository();
            objRepository.DeActivateLogin(Convert.ToInt32(agentId), Convert.ToInt32(extensionNo), uniqueIdentifier);

        }

        public override System.Threading.Tasks.Task OnConnected()
        {
            int agentId, extensionNo;
            string uniqueIdentifier;
            Int32.TryParse(this.Context.QueryString["agentId"], out agentId);
            Int32.TryParse(this.Context.QueryString["extensionNo"], out extensionNo);
            uniqueIdentifier = Convert.ToString(this.Context.QueryString["uniqueIdentifier"]);
            //new LoginRepository().ReActivateLogin(agentId, extensionNo, uniqueIdentifier);
            outputLogger.Info("Hub OnConnected AgentId - {0} ExtensionNo - {1}  UniqueIdentifier - {2}", agentId, extensionNo, uniqueIdentifier);
            return base.OnConnected();

        }

        public override Task OnReconnected()
        {
            int agentId, extensionNo;
            string uniqueIdentifier;
            Int32.TryParse(this.Context.QueryString["agentId"], out agentId);
            Int32.TryParse(this.Context.QueryString["extensionNo"], out extensionNo);
            uniqueIdentifier = Convert.ToString(this.Context.QueryString["uniqueIdentifier"]);
            outputLogger.Info("Hub OnReconnected AgentId - {0} ExtensionNo - {1}  UniqueIdentifier - {2}", agentId, extensionNo, uniqueIdentifier);
            
            return base.OnReconnected();
        }
        public override Task OnDisconnected(bool stopCalled)
        {
            int agentId, extensionNo;
            string uniqueIdentifier;
            Int32.TryParse(this.Context.QueryString["agentId"], out agentId);
            Int32.TryParse(this.Context.QueryString["extensionNo"], out extensionNo);
            uniqueIdentifier = Convert.ToString(this.Context.QueryString["uniqueIdentifier"]);
            outputLogger.Info("Hub OnDisconnected AgentId - {0} ExtensionNo - {1}  UniqueIdentifier - {2}", agentId, extensionNo, uniqueIdentifier);
            
            return base.OnDisconnected(stopCalled);
        }

    }
}