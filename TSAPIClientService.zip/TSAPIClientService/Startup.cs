﻿using Microsoft.AspNet.SignalR;
using Microsoft.Owin;
using Microsoft.Owin.Cors;
using Microsoft.Owin.Hosting;
using NLog;
using Owin;
using System;
using System.Configuration;
using System.Threading;
using System.Threading.Tasks;
using TSAPIClientService.Classes;

[assembly: OwinStartupAttribute(typeof(TSAPIClientService.Startup))]
namespace TSAPIClientService
{
    
    public class Startup
    {

        static Logger outputLogger = LogManager.GetLogger("OutputLogger");
        static CancellationTokenSource _cancellationTokenSource = new CancellationTokenSource();

        // Your startup logic
        public static void StartServer()
        {
            outputLogger.Info("Self Hosting Server initiate on {0}", DateTime.Now);
            var cancellationTokenSource = new CancellationTokenSource();
            Task.Factory.StartNew(RunSignalRServer, TaskCreationOptions.LongRunning
                                  , cancellationTokenSource.Token);
        }

        private static void RunSignalRServer(object task)
        {
            string url = string.Format("http://{0}:8089", ConfigurationManager.AppSettings["LocalIp"].ToString());
            outputLogger.Info("Self Hosting Server initiate on {0}", url);
            using (WebApp.Start(url))
            {
                outputLogger.Info("Self Hosting Server running on {0}", url);
                while (true)
                {

                }
            }
            
        }

        public static void StopServer()
        {
            _cancellationTokenSource.Cancel();
        }
 

        public void Configuration(IAppBuilder app)
        {
            // Branch the pipeline here for requests that start with "/signalr"
            
            var idProvider = new CustomUserIdProvider();

            GlobalHost.DependencyResolver.Register(typeof(IUserIdProvider), () => idProvider);

            app.Map("/signalr", map =>
            {
                // Setup the CORS middleware to run before SignalR.
                // By default this will allow all origins. You can 
                // configure the set of origins and/or http verbs by
                // providing a cors options with a different policy.
                map.UseCors(CorsOptions.AllowAll);
                var hubConfiguration = new HubConfiguration
                {
                    // You can enable JSONP by uncommenting line below.
                    // JSONP requests are insecure but some older browsers (and some
                    // versions of IE) require JSONP to work cross domain
                    // EnableJSONP = true
                };
                // Run the SignalR pipeline. We're not using MapSignalR
                // since this branch already runs under the "/signalr"
                // path.

                hubConfiguration.EnableDetailedErrors = true;
                map.RunSignalR(hubConfiguration);
            });
            outputLogger.Info("Compelete configuration of signalr");
        }
    }
}