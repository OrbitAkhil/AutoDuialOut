﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.ServiceProcess;
using System.Text;
using System.Threading.Tasks;

namespace TSAPIClientService
{
    static class Program
    {
        /// <summary>
        /// The main entry point for the application.
        /// </summary>
        static void Main(string[] args)
        {
            ServiceBase[] ServicesToRun;
            ServicesToRun = new ServiceBase[] 
            { 
                new TsapiClientService() 
            };
            ServiceBase.Run(ServicesToRun);
            //if (args != null)
            //{
            //    try
            //    {
            //        Startup.StartServer();
            //        Console.ReadKey();
            //    }
            //    finally
            //    {
            //        Startup.StopServer();
            //    }
            //}

            //string arg0 = string.Empty;
            //if (args.Length > 0)
            //    arg0 = (args[0] ?? string.Empty).ToLower();

            //if (arg0 == "-service")
            //{
            //    ServiceBase[] ServicesToRun;
            //    ServicesToRun = new ServiceBase[] 
            //    { 
            //        new TsapiClientService() 
            //    };
            //    ServiceBase.Run(ServicesToRun);
            //    return;
            //}
            //if (arg0 == "-fakeservice")
            //{

            //    var service = new TsapiClientService();
            //    service.Start();

            //    //LogManager.Current.LogInfo("Queue Service started as FakeService for debugging.");            

            //    // never ends but waits
            //    Console.ReadLine();

            //    return;
            //}
        }
    }
}
