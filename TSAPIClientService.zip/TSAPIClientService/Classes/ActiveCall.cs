﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace TSAPIClientService.Classes
{
    public class ActiveCall
    {
        public Nullable<int> CallerId { get; set; }
        public string CallerMobile { get; set; }
        public string ExtensionNo { get; set; }
        public Nullable<int> TodayCallCount { get; set; }
        public Nullable<bool> IsTravelAgentCall { get; set; }
    }
}
