﻿using NLog;
using System;
using System.Collections.Generic;
using System.Data;
using System.Data.SqlClient;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using TSAPIDAL;
using TSAPIDAL.DataAccessLayer;

namespace TSAPIClientService.Classes
{
    public class TelephonyRepository
    {
        NLog.Logger logger = LogManager.GetLogger("databaseLogger");


        public ActiveCall GetActiveCall(string extensionNo)
        {
            ActiveCall activeCall = null;
            try
            {
                var objCall = new Repository();
                var cmd = new CommandBuilder();
                cmd.SpName = "GetAllActiveCalls";
                cmd.SqlParams = new List<SqlParameter>()
                {
                    new SqlParameter("@Extension",extensionNo)
                };
                var ds = objCall.Select(cmd);
                if (ds.Tables.Count > 0 && ds.Tables[0].Rows.Count>0)
                {
                    DataRow row = ds.Tables[0].Rows[0];
                    activeCall = new ActiveCall
                    {
                        CallerId = row["CallerId"] != DBNull.Value ? Convert.ToInt32(row["CallerId"]) : 0,
                        CallerMobile = row["CallerMobile"] != DBNull.Value ? Convert.ToString(row["CallerMobile"]) : string.Empty,
                        ExtensionNo = row["ExtensionNo"] != DBNull.Value ? Convert.ToString(row["ExtensionNo"]) : string.Empty,
                        TodayCallCount = row["TodayCallCount"] != DBNull.Value ? Convert.ToInt32(row["TodayCallCount"]) : 0,
                        IsTravelAgentCall = row["IsTravelAgentCall"] != DBNull.Value ? Convert.ToBoolean(row["IsTravelAgentCall"]) : false
                    };
                    
                }
            }
            catch (Exception ex)
            {
                logger.Error(ex);
            }
            return activeCall;
        }

    }

}
