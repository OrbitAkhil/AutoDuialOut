﻿using NLog;
using System;
using System.Collections.Generic;
using System.Data.SqlClient;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using TSAPIDAL;
using TSAPIDAL.DataAccessLayer;

namespace TSAPIClientService.Classes
{
    public class LoginRepository
    {
        NLog.Logger logger = LogManager.GetLogger("databaseLogger");
        public bool CheckExtensionAvailability(int agentId, int extensionNo)
        {
            try
            {
                var objCall = new Repository();
                var cmd = new CommandBuilder();
                cmd.CommandText = "Select Count(AgentId) from tbl_ScreenPopup_Login Where AgentId = @AgentId and LoginStatus = 'A'";
                cmd.SqlParams = new List<SqlParameter>()
                {
                    new SqlParameter("@AgentId",agentId)
                };
                return Convert.ToBoolean(objCall.GetScalerRecord(cmd));
            }
            catch (Exception ex)
            {
                logger.Error(ex);
            }

            return false;
        }

        public int GetAgentLoggedInExtension(int agentId)
        {
            try
            {
                var objCall = new Repository();
                var cmd = new CommandBuilder();
                cmd.CommandText = "Select top 1 ExtensionNo from tbl_ScreenPopup_Login Where AgentId = @AgentId and LoginStatus = 'A' order by LoginDateTime desc";
                cmd.SqlParams = new List<SqlParameter>()
                {
                    new SqlParameter("@AgentId",agentId)
                };
                return Convert.ToInt32(objCall.GetScalerRecord(cmd));
            }
            catch (Exception ex)
            {
                logger.Error(ex);
            }
            return 0;
        }

        public void AddLoginRecord(int agentId, int extensionNo, string uniqueIdentifier, string ipAdress, string hostIpAdress)
        {
            try
            {
                var objCall = new Repository();
                var cmd = new CommandBuilder();
                cmd.SpName = "sp_InsertQuickpopLoginLog";
                cmd.SqlParams = new List<SqlParameter>()
                {
                    new SqlParameter("@AgentId",agentId),
                    new SqlParameter("@ExtensionNo",extensionNo),
                    new SqlParameter("@SessionId",uniqueIdentifier),
                    new SqlParameter("@IpAddress",ipAdress),
                    new SqlParameter("@HostIpAddress",hostIpAdress)
                };
                objCall.Insert(cmd);
            }
            catch (Exception ex)
            {
                logger.Error(ex);
            }
        }



        public void LogoutAgentExistingSession(int agentId)
        {
            //try
            //{
            //    using (ESSEntities ent = new ESSEntities())
            //    {
            //        var login = ent.Logins.FirstOrDefault(e => e.AgentId == agentId && e.LoginStatus == "A");
            //        if (login != null)
            //        {
            //            login.LoginStatus = "C";
            //            ent.SaveChanges();
            //        }

            //    }
            //}
            //catch (Exception ex)
            //{
            //    logger.Error(ex);
            //}
        }

        public void ReActivateLogin(int agentId, int extensionNo, string uniqueIdentifier)
        {
            try
            {
                var objCall = new Repository();
                var cmd = new CommandBuilder();
                cmd.SpName = "sp_InsertQuickpopLoginLog";
                cmd.SqlParams = new List<SqlParameter>()
                {
                    new SqlParameter("@AgentId",agentId),
                    new SqlParameter("@ExtensionNo",extensionNo),
                    new SqlParameter("@SessionId",uniqueIdentifier)
                };
                objCall.Insert(cmd);
            }
            catch (Exception ex)
            {
                logger.Error(ex);
            }
        }

        public void DeActivateLogin(int agentId, int extensionNo, string uniqueIdentifier)
        {
            try
            {
                var objCall = new Repository();
                var cmd = new CommandBuilder();
                cmd.SpName = "sp_LogoutQuickpopAgent";
                cmd.SqlParams = new List<SqlParameter>()
                {
                    new SqlParameter("@AgentId",agentId),
                    new SqlParameter("@ExtensionNo",extensionNo),
                    new SqlParameter("@SessionId",uniqueIdentifier)
                };
                objCall.Update(cmd);
            }
            catch (Exception ex)
            {
                logger.Error(ex);
            }
        }



    }

}
