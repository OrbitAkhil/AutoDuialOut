﻿using NLog;
using System;
using System.Collections.Generic;
using System.Data.SqlClient;
using System.Diagnostics;
using System.Linq;
using System.Threading.Tasks;
using System.Web;
using System.Data;
using MosiacVoc.Models;
using System.Reflection;
using Microsoft.SqlServer.Server;
using TSAPIDAL.DataAccessLayer;
using TSAPIDAL;

namespace MosiacVoc.Repositories
{
    public class SurveyRepository
    {
        NLog.Logger logger = LogManager.GetLogger("databaseLogger");

        public async Task<SurveyViewModel> GetCustomerVoiceSurveyData(long tokenNo)
        {
            SurveyViewModel surveyViewModel = null;
            try
            {
                var objCall = new Repository();
                var cmd = new CommandBuilder();
                cmd.SpName = "sp_GetCustomerVoiceSurvey";
                cmd.SqlParams = new List<SqlParameter>()
                {
                    new SqlParameter("@TokenNo",tokenNo)
                };

                var ds = await objCall.SelectAsync(cmd);
                if (ds.Tables.Count > 0)
                {
                    var row = ds.Tables[0].Rows[0];
                    surveyViewModel = new SurveyViewModel();
                    surveyViewModel.LogoURL = row["LogoURL"] != DBNull.Value ? Convert.ToString(row["LogoURL"]) : string.Empty;
                    surveyViewModel.BackgroundURL = row["BackgroundURL"] != DBNull.Value ? Convert.ToString(row["BackgroundURL"]) : string.Empty;
                    surveyViewModel.BrandName = row["BrandName"] != DBNull.Value ? Convert.ToString(row["BrandName"]) : string.Empty;
                    surveyViewModel.BrandCountry = row["BrandCountry"] != DBNull.Value ? Convert.ToString(row["BrandCountry"]) : string.Empty;
                    surveyViewModel.ColorCode1 = row["ColorCode1"] != DBNull.Value ? Convert.ToString(row["ColorCode1"]) : string.Empty;
                    surveyViewModel.ColorCode2 = row["ColorCode2"] != DBNull.Value ? Convert.ToString(row["ColorCode2"]) : string.Empty;
                    surveyViewModel.ColorCode3 = row["ColorCode3"] != DBNull.Value ? Convert.ToString(row["ColorCode3"]) : string.Empty;
                    surveyViewModel.SurveyMessage = row["SurveyMessage"] != DBNull.Value ? Convert.ToString(row["SurveyMessage"]) : string.Empty;
                    surveyViewModel.WelcomeText = row["WelcomeText"] != DBNull.Value ? Convert.ToString(row["WelcomeText"]) : string.Empty;
                    surveyViewModel.WelcomeSubText = row["WelcomeSubText"] != DBNull.Value ? Convert.ToString(row["WelcomeSubText"]) : string.Empty;
                    surveyViewModel.WelcomeImage = row["WelcomeImage"] != DBNull.Value ? Convert.ToString(row["WelcomeImage"]) : string.Empty;
                    surveyViewModel.ThankyouText = row["ThankyouText"] != DBNull.Value ? Convert.ToString(row["ThankyouText"]) : string.Empty;
                    surveyViewModel.ThankyouImage = row["ThankyouImage"] != DBNull.Value ? Convert.ToString(row["ThankyouImage"]) : string.Empty;
                    surveyViewModel.PartialResponseId = row["PartialResponseId"] != DBNull.Value ? Convert.ToString(row["PartialResponseId"]) : string.Empty;
                    surveyViewModel.SkipWelcome = row["SkipWelcome"] != DBNull.Value ? Convert.ToBoolean(row["SkipWelcome"]) : false;

                    surveyViewModel.Questions = new List<Question>();
                    foreach (DataRow questionRow in ds.Tables[1].Rows)
                    {
                        Question question = new Question();
                        question.Id = questionRow["QuestionId"] != DBNull.Value ? Convert.ToString(questionRow["QuestionId"]) : string.Empty;
                        question.User = questionRow["User"] != DBNull.Value ? Convert.ToString(questionRow["User"]) : string.Empty;
                        question.Text = questionRow["Text"] != DBNull.Value ? Convert.ToString(questionRow["Text"]) : string.Empty;
                        question.DisplayType = questionRow["DisplayType"] != DBNull.Value ? Convert.ToString(questionRow["DisplayType"]) : string.Empty;
                        
                        string multiSelect = questionRow["MultiSelect"] != DBNull.Value ? Convert.ToString(questionRow["MultiSelect"]) : string.Empty;
                        string questionTags = questionRow["QuestionTags"] != DBNull.Value ? Convert.ToString(questionRow["QuestionTags"]) : string.Empty;
                        
                        question.MultiSelect = new List<string>();
                        if (!string.IsNullOrEmpty(multiSelect))
                        {
                            foreach (var item in multiSelect.Split('|'))
                            {
                                question.MultiSelect.Add(item);
                            }
                        }

                        question.QuestionTags = new List<string>();
                        if (!string.IsNullOrEmpty(questionTags))
                        {
                            foreach (var item in questionTags.Split('|'))
                            {
                                question.QuestionTags.Add(item);
                            }
                        }

                        question.Sequence = questionRow["Sequence"] != DBNull.Value ? Convert.ToInt32(questionRow["Sequence"]) : 0;
                        question.EndOfSurvey = questionRow["EndOfSurvey"] != DBNull.Value ? Convert.ToBoolean(questionRow["EndOfSurvey"]) : false;
                        question.EndOfSurveyMessage = questionRow["EndOfSurveyMessage"] != DBNull.Value ? Convert.ToString(questionRow["EndOfSurveyMessage"]) : string.Empty;
                        question.EndOfPartialSurvey = questionRow["EndOfPartialSurvey"] != DBNull.Value ? Convert.ToBoolean(questionRow["EndOfPartialSurvey"]) : false;
                        question.EndOfPartialSurveyMessage = questionRow["EndOfPartialSurveyMessage"] != DBNull.Value ? Convert.ToString(questionRow["EndOfPartialSurveyMessage"]) : string.Empty;

                        question.PresentationMode = questionRow["PresentationMode"] != DBNull.Value ? Convert.ToString(questionRow["PresentationMode"]) : string.Empty;
                        question.IsRequired = questionRow["IsRequired"] != DBNull.Value ? Convert.ToBoolean(questionRow["IsRequired"]) : false;
                        question.ConditionalFilter = new ConditionalFilter();
                        question.ConditionalFilter.Filterquestions = new List<FilterQuestion>();

                        foreach (DataRow filterQuestionRow in ds.Tables[2].Rows)
                        {
                            string filterRowQuestionId = filterQuestionRow["QuestionId"] != DBNull.Value ? Convert.ToString(filterQuestionRow["QuestionId"]) : string.Empty;

                            if (filterRowQuestionId == question.Id)
                            {
                                var filterQuestion = new FilterQuestion();

                                filterQuestion.QuestionId = filterQuestionRow["FilterQuestionId"] != DBNull.Value ? Convert.ToString(filterQuestionRow["FilterQuestionId"]) : string.Empty;
                                filterQuestion.AnswerCheck = new List<string>();
                                string answers = filterQuestionRow["Answer"] != DBNull.Value ? Convert.ToString(filterQuestionRow["Answer"]) : string.Empty;
                                if (!string.IsNullOrEmpty(answers))
                                {
                                    foreach (var item in answers.Split('|'))
                                    {
                                        filterQuestion.AnswerCheck.Add(item);
                                    }
                                }
                                question.ConditionalFilter.Filterquestions.Add(filterQuestion);
                            }
                        }
                        question.OptionalQuestions = new List<OptionalQuestion>();
                        foreach (DataRow optionalQuestionRow in ds.Tables[3].Rows)
                        {
                            string optionalRowQuestionId = optionalQuestionRow["QuestionId"] != DBNull.Value ? Convert.ToString(optionalQuestionRow["QuestionId"]) : string.Empty;

                            if (optionalRowQuestionId == question.Id)
                            {
                                var optionalQuestion = new OptionalQuestion();

                                optionalQuestion.Text = optionalQuestionRow["Text"] != DBNull.Value ? Convert.ToString(optionalQuestionRow["Text"]) : string.Empty;
                                optionalQuestion.DisplayType = optionalQuestionRow["DisplayType"] != DBNull.Value ? Convert.ToString(optionalQuestionRow["DisplayType"]) : string.Empty;
                                optionalQuestion.Responses = new List<string>();
                                string responses = optionalQuestionRow["ResponseValue"] != DBNull.Value ? Convert.ToString(optionalQuestionRow["ResponseValue"]) : string.Empty;
                                if (!string.IsNullOrEmpty(responses))
                                {
                                    foreach (var item in responses.Split('|'))
                                    {
                                        optionalQuestion.Responses.Add(item);
                                    }
                                }
                                question.OptionalQuestions.Add(optionalQuestion);
                            }
                        }

                        if (ds.Tables[4].Rows.Count > 0)
                        {
                            foreach (DataRow responseRow in ds.Tables[4].Rows)
                            {
                                string responseRowQuestionId = responseRow["QuestionId"] != DBNull.Value ? Convert.ToString(responseRow["QuestionId"]) : string.Empty;

                                if (responseRowQuestionId == question.Id)
                                {
                                    question.Response = new Response();
                                    question.Response.TextInput = responseRow["TextInput"] != DBNull.Value ? Convert.ToString(responseRow["TextInput"]) : string.Empty;
                                    question.Response.NumberInput = responseRow["NumberInput"] != DBNull.Value ? Convert.ToInt32(responseRow["NumberInput"]) : 0;
                                }
                            }
                        }
                        surveyViewModel.Questions.Add(question);
                    
                    }
                    
                }
            }
            catch (Exception ex)
            {
                logger.Error(ex);
            }
            return surveyViewModel;
        }

        public async Task<bool> SaveCustomerVoiceSurvey(long tokenNo, SurveyResponseViewModel surveyResponseViewModel)
        {
            try
            {
                var objCall = new Repository();
                var cmd = new CommandBuilder();
                cmd.SpName = "sp_SaveCustomerSurveyResponse";
                cmd.SqlParams = new List<SqlParameter>()
                {
                    new SqlParameter("@TokenNo",tokenNo),
                    new SqlParameter("@ResponseDateTime",surveyResponseViewModel.ResponseDateTime),
                    new SqlParameter("@User",surveyResponseViewModel.User),
                    new SqlParameter("@SurveyClient",surveyResponseViewModel.SurveyClient),
                    new SqlParameter("@ResponseDuration",surveyResponseViewModel.ResponseDuration),
                    new SqlParameter("@CreatedIpAddress",HttpContext.Current.Request.ServerVariables["REMOTE_ADDR"])
                    
                };
                SqlParameter sqlParam = new SqlParameter("@QuestionResponses", ToDataTable(surveyResponseViewModel.Responses));
                sqlParam.SqlDbType = SqlDbType.Structured;
                cmd.SqlParams.Add(sqlParam);


                return await objCall.UpdateAsync(cmd);
            }
            catch (Exception ex)
            {
                logger.Error(ex);
            }
            return false;
        }

        public class DataCollection : List<ResponseViewModel>, IEnumerable<SqlDataRecord>
        {
            IEnumerator<SqlDataRecord> IEnumerable<SqlDataRecord>.GetEnumerator()
            {
                SqlDataRecord ret = new SqlDataRecord(
                    new SqlMetaData("QuestionId", SqlDbType.VarChar,20),
                    new SqlMetaData("QuestionText", SqlDbType.VarChar,500),
                    new SqlMetaData("NumberInput", SqlDbType.Int),
                    new SqlMetaData("TextInput", SqlDbType.VarChar,100)
                    );

                foreach (var data in this)
                {
                    ret.SetString(0, data.QuestionId);
                    ret.SetString(1, data.QuestionText);
                    ret.SetInt32(2, data.NumberInput);
                    ret.SetString(3, !string.IsNullOrEmpty(data.TextInput) ? data.TextInput : string.Empty);
                    yield return ret;
                }
            }
        }

        private DataCollection ToDataTable(List<ResponseViewModel> items)
        {
            DataCollection collection = new DataCollection();
            foreach (var item in items)
            {
                collection.Add(item);
            }
            //put a breakpoint here and check datatable
            return collection;
        }
    }

}