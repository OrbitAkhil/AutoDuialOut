﻿using MosiacVoc.Models;
using MosiacVoc.Repositories;
using Newtonsoft.Json;
using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Net;
using System.Net.Http;
using System.Threading.Tasks;
using System.Web.Http;

namespace MosiacVoc.Controllers
{
    public class SurveyController : ApiController
    {
        // GET api/<controller>/5
        [Route("api/Survey/{token}")]
        public async Task<IHttpActionResult> Get(long token)
        {
            SurveyViewModel model = null;

            if (token<=0)
                return BadRequest();
            
            SurveyRepository repo = new SurveyRepository();

            model = await repo.GetCustomerVoiceSurveyData(token);
            
            if (model == null)
                return NotFound();

            return Ok(model);
        }



        // POST api/<controller>
        [HttpPost]
        [Route("api/PartialSurvey/{token}")]
        public void Post([FromUri]long token, [FromBody] IList<ResponseViewModel> value)
        {
            if (token <= 0)
                return;


            SurveyRepository repo = new SurveyRepository();
            //await repo.SaveCustomerVoiceSurvey(token, value);
        }

        [HttpPost]
        [Route("api/SurveyByToken/{token}")]
        public async void Post([FromUri]long token, [FromBody] SurveyResponseViewModel value)
        {
            if (token <= 0)
                return;
            

            SurveyRepository repo = new SurveyRepository();
            await repo.SaveCustomerVoiceSurvey(token, value);
        }

        

        #region Private Methods
        private void LoadJson()
        {
            using (StreamReader r = new StreamReader("settings.json"))
            {
                string json = r.ReadToEnd();
                SurveyViewModel model = JsonConvert.DeserializeObject<SurveyViewModel>(json);
            }
        }

        #endregion
    }
}