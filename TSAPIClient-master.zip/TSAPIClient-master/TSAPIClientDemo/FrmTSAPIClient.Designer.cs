﻿
using System.Configuration;
namespace TSAPIClientDemo
{
    partial class FrmTSAPIClient
    {
        public static System.Configuration.Configuration config = ConfigurationManager.OpenExeConfiguration(ConfigurationUserLevel.None);
        private string tsapiUser;
        private string tsapiPassword;
        private string tsapiServer;
        private string tsapiApplicationName;
        private string tsapiApplicationVersion;
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;
       
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            this.timerMonitor = new System.Windows.Forms.Timer(this.components);
            this.SuspendLayout();
            // 
            // timerMonitor
            // 
            this.timerMonitor.Interval = 60000;
            this.timerMonitor.Tick += new System.EventHandler(this.timerMonitor_Tick);
            // 
            // FrmTSAPIClient
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(450, 43);
            this.Name = "FrmTSAPIClient";
            this.Text = "TSAPI Client Demo";
            this.FormClosed += new System.Windows.Forms.FormClosedEventHandler(this.FrmTSAPIClient_FormClosed);
            this.Load += new System.EventHandler(this.FrmTSAPIClient_Load);
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.Timer timerMonitor;
    }
}

