﻿using NLog;
using System;
using System.Collections.Generic;
using System.Data.SqlClient;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using TSAPIDAL.DataAccessLayer;

namespace TSAPIDAL
{
    public class CallRepository
    {
        Logger consoleLogger = LogManager.GetLogger("ConsoleLogger");
        Logger outputLogger = LogManager.GetLogger("OutputLogger");

        public void UpdateCallToEstablished(int lcallID, string szCallingDeviceID, string alertingDevice)
        {
            try
            {
                
                    var objCall = new Repository();
                    var cmd = new CommandBuilder();
                    cmd.SpName = "sp_UpdateCallToEstablished";
                    cmd.SqlParams = new List<SqlParameter>()
                    {
                        new SqlParameter("@CallerId",lcallID),
                        new SqlParameter("@ExtensionNo",szCallingDeviceID)
                    };
                    objCall.Update(cmd);
            }
            catch (AggregateException ae)
            {
                foreach (var e in ae.InnerExceptions)
                {
                    // Handle the custom exception.

                    outputLogger.Info(e.Message);

                }
            }
        }

        public void UpdateCallToCleared(int lcallID, string szCallingDeviceID)
        {
            try
            {
                Task.Factory.StartNew(() =>
                {
                    var objCall = new Repository();
                    var cmd = new CommandBuilder();
                    cmd.SpName = "sp_UpdateCallToCleared";
                    cmd.SqlParams = new List<SqlParameter>()
                    {
                        new SqlParameter("@CallerId",lcallID),
                        new SqlParameter("@CallerNumber",szCallingDeviceID)
                    };
                    objCall.Update(cmd);
                });
            }
            catch (AggregateException ae)
            {
                foreach (var e in ae.InnerExceptions)
                {
                    // Handle the custom exception.

                    outputLogger.Info(e.Message);

                }
            }
        }

        public void InsertDeliveredCall(string ucid, int lcallID, string szCallingDeviceID, string alertingDevice, string agentId)
        {
            try
            {


                var objCall = new Repository();
                var cmd = new CommandBuilder();
                cmd.SpName = "sp_InsertNewIncomingCall";
                cmd.SqlParams = new List<SqlParameter>()
                {
                    new SqlParameter("@CallerId",lcallID),
                    new SqlParameter("@CallerName",lcallID.ToString()),
                    new SqlParameter("@CallStatus","A"),
                    new SqlParameter("@ExtensionNo",alertingDevice),
                    new SqlParameter("@CallerMobile",szCallingDeviceID),
                    new SqlParameter("@AgentId",agentId)
                };
                objCall.Insert(cmd);

            }
            catch (Exception ae)
            {
                outputLogger.Error(ae.Message);
            }
        }

        public void InsertTransferCall(string ucid, int lcallID, string szCallingDeviceID, string alertingDevice,string agentId)
        {
            try
            {
                var objCall = new Repository();
                var cmd = new CommandBuilder();
                cmd.SpName = "sp_InsertTransferCall";
                cmd.SqlParams = new List<SqlParameter>()
                {
                    new SqlParameter("@CallerId",lcallID),
                    new SqlParameter("@CallerName",lcallID.ToString()),
                    new SqlParameter("@CallStatus","A"),
                    new SqlParameter("@ExtensionNo",alertingDevice),
                    new SqlParameter("@CallerMobile",szCallingDeviceID),
                    new SqlParameter("@AgentId",agentId)
                };
                objCall.Insert(cmd);

                   
            }
            catch (Exception ae)
            {
                outputLogger.Error(ae.Message);
            }
        }
    }
}
