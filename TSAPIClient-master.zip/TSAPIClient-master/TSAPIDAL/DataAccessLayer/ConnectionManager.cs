﻿using System;
using System.Collections.Generic;
using System.Configuration;
using System.Data.SqlClient;
using System.Linq;
using System.Text;

namespace TSAPIDAL.DataAccessLayer
{
    public class ConnectionManager : IConnection
    {
        private string GetConnectionString()
        {
            string connectionString = string.Empty;
            var connection = ConfigurationManager.ConnectionStrings["TelephonyConnection"];

            connectionString = connection != null ? connection.ConnectionString : string.Empty;
            return connectionString;
        }


        private SqlConnection GetConnection()
        {
            return new SqlConnection(GetConnectionString());
        }

        public SqlConnection Connection
        {
            get
            {
                return GetConnection();
            }

        }
    }
}
