﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Linq;
using System.Text;

namespace TSAPIDAL.DataAccessLayer
{
    public   interface ICrud<T>
    {
        bool Insert(T obj);
        bool Update(T obj);
        bool Delete(T obj);
        DataSet Select(T obj);
    }
}
