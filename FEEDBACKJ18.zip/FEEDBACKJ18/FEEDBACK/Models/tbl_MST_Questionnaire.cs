namespace FEEDBACK.Models
{
    using System;
    using System.Collections.Generic;
    using System.ComponentModel.DataAnnotations;
    using System.ComponentModel.DataAnnotations.Schema;
    using System.Data.Entity.Spatial;

    public partial class tbl_MST_Questionnaire
    {
        public int Id { get; set; }

        [StringLength(3000)]
        public string QuestionText { get; set; }

        [StringLength(50)]
        public string VDNNo { get; set; }

        public int? SubBusinessId { get; set; }

        [StringLength(10)]
        public string IsActive { get; set; }

        public DateTime? CreatedDate { get; set; }

        [StringLength(50)]
        public string CreatedBy { get; set; }

        public DateTime? ModifyDate { get; set; }

        [StringLength(50)]
        public string ModifyBy { get; set; }

        [StringLength(50)]
        public string RangeType { get; set; }
    }
}
