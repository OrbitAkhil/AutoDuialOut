﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;
using System.ComponentModel.DataAnnotations;
using System.Data;

namespace FEEDBACK.Models
{

    public class DNISDetails
    {
        [Display(Name = "DNIS Number")]

        public List<SelectListItem> DNIS { get; set; }

        [Required(ErrorMessage = "DNIS Number is Required")]
        public string DNISID { get; set; }

        [Display(Name = "Threshold (in sec)")]
        [Required(ErrorMessage = "Threshold is Required")]
        public int Threshold { get; set; }

        [Display(Name = "Action Type")]
        [Required(ErrorMessage = "Action is Required")]
        public string Action { get; set; } = "EMAIL";

        [Display(Name = "Window start Time ")]
        [Required(ErrorMessage = "Window start Time  is Required")]
        [DataType(DataType.Time)]
        public string Window_start { get; set; }

        [Display(Name = "Window Duration (in min) ")]
        [Required(ErrorMessage = "Window Duration  is Required")]
        public int Windoin_min { get; set; }

        [Display(Name = "Trigger Email")]
        [Required(ErrorMessage = "Trigger Email  is Required")]
        [DataType(DataType.EmailAddress)]
        public string Email { get; set; }

    }
    public class DNISSubBusiness
    {
        [Display(Name = "DNIS Number")]
        [Required(ErrorMessage = "DNIS Number is Required")]
        public string DNISNumber { get; set; }

        [Display(Name = "Primary Number")]
        [Required(ErrorMessage = "Primary Number is Required")]
        public string PrimaryNumber { get; set; }

        [Required(ErrorMessage = "Sub Business Name is Required")]
        [Display(Name = "Sub Business Name")]
        public string SubBusinessName { get; set; }

        public List<SelectListItem> SubBusinessId { get; set; }

        public List<DNISSubBusiness> GetAllDNISwithSBusiness()
        {
            List<DNISSubBusiness> objL = new List<DNISSubBusiness>();
            System.Data.SqlClient.SqlParameter[] sp = new System.Data.SqlClient.SqlParameter[0];
            SQLU S = new SQLU("");
            DataSet ds = S.GetData("dbo.usp_getallDNISdetails", sp);
            if (ds != null)
                if (ds.Tables[0].Rows.Count > 0)
                {
                    DataTable dt = ds.Tables[0];
                    foreach (DataRow dr in dt.Rows)
                    {
                        DNISSubBusiness MB = new DNISSubBusiness();

                        MB.DNISNumber = dr["DNIS"].ToString();
                        MB.PrimaryNumber = dr["pNumber"].ToString();
                        MB.SubBusinessName = dr["subbusinessname"].ToString();
                        objL.Add(MB);

                    }
                }

            return objL;
        }

        public string DeleteDNISMapping(string dnis)
        {
            System.Data.SqlClient.SqlParameter spout = new System.Data.SqlClient.SqlParameter("@ERROR", SqlDbType.VarChar);
            spout.Direction = ParameterDirection.Output;
            spout.Size = 100;

            System.Data.SqlClient.SqlParameter[] sp = new System.Data.SqlClient.SqlParameter[1];
            sp[0] = new System.Data.SqlClient.SqlParameter("@dnis", SqlDbType.VarChar);
            sp[0].Value = dnis;          
            SQLU s = new SQLU("");
            string msg = s.ExecuteProcOut("usp_deletednis", spout, sp);
            //DataSet ds = SQLU.GetData("sp_utom_AddBusiness", sp);

            return msg;
        }
    }



}