namespace FEEDBACK.Models
{
    using System;
    using System.Collections.Generic;
    using System.ComponentModel.DataAnnotations;
    using System.ComponentModel.DataAnnotations.Schema;
    using System.Data.Entity.Spatial;

    public partial class tbl_MST_SurveyDetails
    {
        public int Id { get; set; }

        [StringLength(10)]
        public string SurveyId { get; set; }

        [StringLength(10)]
        public string SubBusinessId { get; set; }

        [StringLength(10)]
        public string BusinessId { get; set; }

        [StringLength(10)]
        public string SurveyType { get; set; }
    }
}
