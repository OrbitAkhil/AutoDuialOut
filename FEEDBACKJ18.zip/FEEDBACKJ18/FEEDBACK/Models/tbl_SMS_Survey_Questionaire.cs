namespace FEEDBACK.Models
{
    using System;
    using System.Collections.Generic;
    using System.ComponentModel.DataAnnotations;
    using System.ComponentModel.DataAnnotations.Schema;
    using System.Data.Entity.Spatial;

    public partial class tbl_SMS_Survey_Questionaire
    {
        public int Id { get; set; }

        public int? TemplateId { get; set; }

        [StringLength(20)]
        public string User { get; set; }

        public string Text { get; set; }

        [StringLength(20)]
        public string DisplayType { get; set; }

        [StringLength(100)]
        public string MultiSelect { get; set; }

        public bool? EndOfSurvey { get; set; }

        [StringLength(100)]
        public string EndOfSurveyMessage { get; set; }

        [StringLength(100)]
        public string ConditionalFilter { get; set; }

        [StringLength(20)]
        public string PresentationMode { get; set; }

        public bool? IsRequired { get; set; }

        [StringLength(200)]
        public string QuestionTags { get; set; }

        [StringLength(1)]
        public string Status { get; set; }

        public int? Sequence { get; set; }

        [StringLength(50)]
        public string SubBusinessId { get; set; }
    }
}
