namespace FEEDBACK.Models
{
    using System;
    using System.Data.Entity;
    using System.ComponentModel.DataAnnotations.Schema;
    using System.Linq;

    public partial class Model1 : DbContext
    {
        public Model1()
            : base("name=Model1")
        {
        }

        public virtual DbSet<tbl_MST_Questionnaire> tbl_MST_Questionnaire { get; set; }
        public virtual DbSet<tbl_MST_SurveyDetails> tbl_MST_SurveyDetails { get; set; }
        public virtual DbSet<tbl_SMS_Survey_Questionaire> tbl_SMS_Survey_Questionaire { get; set; }
        public virtual DbSet<tbl_SMS_Survey_Template> tbl_SMS_Survey_Template { get; set; }

        protected override void OnModelCreating(DbModelBuilder modelBuilder)
        {
            modelBuilder.Entity<tbl_MST_Questionnaire>()
                .Property(e => e.VDNNo)
                .IsUnicode(false);

            modelBuilder.Entity<tbl_MST_Questionnaire>()
                .Property(e => e.IsActive)
                .IsFixedLength()
                .IsUnicode(false);

            modelBuilder.Entity<tbl_MST_Questionnaire>()
                .Property(e => e.CreatedBy)
                .IsUnicode(false);

            modelBuilder.Entity<tbl_MST_Questionnaire>()
                .Property(e => e.ModifyBy)
                .IsUnicode(false);

            modelBuilder.Entity<tbl_SMS_Survey_Questionaire>()
                .Property(e => e.User)
                .IsUnicode(false);

            modelBuilder.Entity<tbl_SMS_Survey_Questionaire>()
                .Property(e => e.Text)
                .IsUnicode(false);

            modelBuilder.Entity<tbl_SMS_Survey_Questionaire>()
                .Property(e => e.DisplayType)
                .IsUnicode(false);

            modelBuilder.Entity<tbl_SMS_Survey_Questionaire>()
                .Property(e => e.MultiSelect)
                .IsUnicode(false);

            modelBuilder.Entity<tbl_SMS_Survey_Questionaire>()
                .Property(e => e.EndOfSurveyMessage)
                .IsUnicode(false);

            modelBuilder.Entity<tbl_SMS_Survey_Questionaire>()
                .Property(e => e.ConditionalFilter)
                .IsUnicode(false);

            modelBuilder.Entity<tbl_SMS_Survey_Questionaire>()
                .Property(e => e.PresentationMode)
                .IsUnicode(false);

            modelBuilder.Entity<tbl_SMS_Survey_Questionaire>()
                .Property(e => e.QuestionTags)
                .IsUnicode(false);

            modelBuilder.Entity<tbl_SMS_Survey_Questionaire>()
                .Property(e => e.Status)
                .IsUnicode(false);

            modelBuilder.Entity<tbl_SMS_Survey_Questionaire>()
                .Property(e => e.SubBusinessId)
                .IsUnicode(false);

            modelBuilder.Entity<tbl_SMS_Survey_Template>()
                .Property(e => e.ApplicationCode)
                .IsUnicode(false);

            modelBuilder.Entity<tbl_SMS_Survey_Template>()
                .Property(e => e.LogoURL)
                .IsUnicode(false);

            modelBuilder.Entity<tbl_SMS_Survey_Template>()
                .Property(e => e.BackgroundURL)
                .IsUnicode(false);

            modelBuilder.Entity<tbl_SMS_Survey_Template>()
                .Property(e => e.BrandName)
                .IsUnicode(false);

            modelBuilder.Entity<tbl_SMS_Survey_Template>()
                .Property(e => e.BrandCountry)
                .IsUnicode(false);

            modelBuilder.Entity<tbl_SMS_Survey_Template>()
                .Property(e => e.ColorCode1)
                .IsUnicode(false);

            modelBuilder.Entity<tbl_SMS_Survey_Template>()
                .Property(e => e.ColorCode2)
                .IsUnicode(false);

            modelBuilder.Entity<tbl_SMS_Survey_Template>()
                .Property(e => e.ColorCode3)
                .IsUnicode(false);

            modelBuilder.Entity<tbl_SMS_Survey_Template>()
                .Property(e => e.WelcomeText)
                .IsUnicode(false);

            modelBuilder.Entity<tbl_SMS_Survey_Template>()
                .Property(e => e.WelcomeImage)
                .IsUnicode(false);

            modelBuilder.Entity<tbl_SMS_Survey_Template>()
                .Property(e => e.ThankyouText)
                .IsUnicode(false);

            modelBuilder.Entity<tbl_SMS_Survey_Template>()
                .Property(e => e.ThankyouImage)
                .IsUnicode(false);

            modelBuilder.Entity<tbl_SMS_Survey_Template>()
                .Property(e => e.PartialResponseId)
                .IsUnicode(false);

            modelBuilder.Entity<tbl_SMS_Survey_Template>()
                .Property(e => e.SurveyMessage)
                .IsUnicode(false);

            modelBuilder.Entity<tbl_SMS_Survey_Template>()
                .Property(e => e.Status)
                .IsUnicode(false);

            modelBuilder.Entity<tbl_SMS_Survey_Template>()
                .Property(e => e.SubBusinessId)
                .IsUnicode(false);
        }
    }
}
