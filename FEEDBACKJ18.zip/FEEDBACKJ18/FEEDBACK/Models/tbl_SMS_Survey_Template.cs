namespace FEEDBACK.Models
{
    using System;
    using System.Collections.Generic;
    using System.ComponentModel.DataAnnotations;
    using System.ComponentModel.DataAnnotations.Schema;
    using System.Data.Entity.Spatial;

    public partial class tbl_SMS_Survey_Template
    {
        public int Id { get; set; }

        public int? ApplicationId { get; set; }

        [StringLength(20)]
        public string ApplicationCode { get; set; }

        [StringLength(100)]
        public string LogoURL { get; set; }

        [StringLength(100)]
        public string BackgroundURL { get; set; }

        [StringLength(50)]
        public string BrandName { get; set; }

        [StringLength(4)]
        public string BrandCountry { get; set; }

        [StringLength(10)]
        public string ColorCode1 { get; set; }

        [StringLength(10)]
        public string ColorCode2 { get; set; }

        [StringLength(10)]
        public string ColorCode3 { get; set; }

        [StringLength(200)]
        public string WelcomeText { get; set; }

        [StringLength(100)]
        public string WelcomeImage { get; set; }

        [StringLength(200)]
        public string ThankyouText { get; set; }

        [StringLength(100)]
        public string ThankyouImage { get; set; }

        [StringLength(100)]
        public string PartialResponseId { get; set; }

        [StringLength(100)]
        public string SurveyMessage { get; set; }

        public bool? SkipWelcome { get; set; }

        public DateTime? CreatedOn { get; set; }

        [StringLength(1)]
        public string Status { get; set; }

        [StringLength(50)]
        public string SubBusinessId { get; set; }
    }
}
