﻿
//Function to open mdel dialog 
//create a div with dialog name in view
function OpenPopup(name,pageurl,w, h ) {

    if (!h)
    { h = 500; }
    if (!w)
    { w = 500; }
    $('#dialog').dialog({
        autoOpen: false,
        width: w,
        height: h,
        resizable: false,
        title: name,
        modal: true,
        open: function (event, ui) {
            //Load the CreateAlbumPartial action which will return
            // the partial view _CreateAlbumPartial
            $(this).load(pageurl + '?id2=' + Math.random());
        }

    });
    $('#dialog').dialog('open');
};

function ClosePopup() {
    $('#dialog').dialog('close');
    location.reload();
};

