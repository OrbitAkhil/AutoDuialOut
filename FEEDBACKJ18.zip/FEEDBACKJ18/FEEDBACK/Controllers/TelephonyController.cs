﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Data.Entity;
using System.Linq;
using System.Net;
using System.Web;
using System.Web.Mvc;
using FEEDBACK.BL;
using FEEDBACK.Models;

namespace FEEDBACK.Controllers
{
    public class TelephonyController : Controller
    {
        private Model1 db = new Model1();


        public ActionResult EditQuestions(string id)
        {
            //id = "S0017";
            BL.Dashboard dd = new BL.Dashboard();
            SQLU ss = new SQLU("");

            DataSet ds1 = new DataSet();
            DataTable allSubBusinessList = new DataTable();
            DataTable allOptionTypeList = new DataTable();
            ds1 = Dashboard.GetOptionTypeList(1);
            allOptionTypeList = ds1.Tables[0];
            ViewBag.Surveyid = id;
            ViewBag.allOptionTypeList = ss.ddlListItem(allOptionTypeList, "RangeName", "id");
            Model1 DbCompany = new Model1();
            string sbid = (from s in DbCompany.tbl_MST_SurveyDetails
                           where s.SurveyId == id
                           select s.SubBusinessId.ToString()).First();
            int SubBusinessId = Convert.ToInt32(sbid);
            var data = (from item in DbCompany.tbl_MST_Questionnaire
                       where (item.SubBusinessId == SubBusinessId)
                       orderby item.Id
                       select item).ToList();
            return PartialView(data.ToList());
        }
        [HttpPost]
        public ActionResult EditQuestions(List<tbl_MST_Questionnaire> tbl_MST_Questionnaire,string id)
        {
            //string idstr = "50003";
            if (ModelState.IsValid)
            {
                Model1 DbCompany = new Model1();
                foreach (tbl_MST_Questionnaire Emp in tbl_MST_Questionnaire)
                {
                    tbl_MST_Questionnaire Existed_Emp = DbCompany.tbl_MST_Questionnaire.Find(Emp.Id);

                    Existed_Emp.QuestionText = Emp.QuestionText;

                    Existed_Emp.VDNNo = Emp.VDNNo;

                    Existed_Emp.RangeType = Emp.RangeType;
               

                }
                DbCompany.SaveChanges();
                //using (Model1 dc = new Model1())
                //{
                //    var sbid =from r in db.tbl_MST_SurveyDetails
                //               where r.SurveyId == id.ToString()
                //               select r.SubBusinessId;
                //    var sa = (from u in db.tbl_MST_Questionnaire
                //              where u.SubBusinessId == Convert.ToInt32(sbid)
                //                         select u);

                //    // var result = db.tbl_MST_Questionnaire.Where(u => u.SubBusinessId && u.SubBusinessId.ToString()(r => r.Name.Equals("Management"))).ToList();

                //    foreach (var i in tbl_MST_Questionnaire)
                //    {
                //        tbl_MST_Questionnaire Xmdl = (from c in dc.tbl_MST_Questionnaire
                //                           where c.Id == Convert.ToInt32(i)
                //                                      select c).FirstOrDefault();
                //        //Xmdl.QuestionText = mdl.QuestionText;
                //        //Xmdl.sCls = tbl_MST_Questionnaire[0].QuestionText;
                //        //Xmdl.sRoll = mdl.sRoll;
                //        //Xmdl.sFName = mdl.sFName;
                //        //Xmdl.sFName = mdl.sFName;
                //        //Xmdl.sSec = mdl.sSec;
                //        ////Xmdl.sDOB = mdl.sDOB;
                //        //Xmdl.sAdhar = mdl.sAdhar;
                //        //Xmdl.sContact = mdl.sContact;
                //        //MDL.SaveChanges();
                //        dc.tbl_MST_Questionnaire.Add(i);
                //    }
                //    dc.SaveChanges();
                //    ViewBag.Message = "Data successfully saved!";
                //    ModelState.Clear();
                //ci = new List<ContactInfo> { new ContactInfo { ID = 0, ContactName = "", ContactNo = "" } };

            
            }
          return  RedirectToAction("FeedBackIndex", "Admin");
            //BL.Dashboard dd = new BL.Dashboard();
            //SQLU ss = new SQLU("");

            //DataSet ds1 = new DataSet();
            //DataTable allSubBusinessList = new DataTable();
            //DataTable allOptionTypeList = new DataTable();
            //ds1 = Dashboard.GetOptionTypeList(1);
            //allOptionTypeList = ds1.Tables[0];
            //ViewBag.Surveyid = id;
            //ViewBag.allOptionTypeList = ss.ddlListItem(allOptionTypeList, "RangeName", "id");
            //Model1 DbCompany = new Model1();
            //string sbid = (from s in DbCompany.tbl_MST_SurveyDetails
            //               where s.SurveyId == id
            //               select s.SubBusinessId.ToString()).First();
            //int SubBusinessId = Convert.ToInt32(sbid);
            //var data = from item in DbCompany.tbl_MST_Questionnaire
            //           where (item.SubBusinessId == SubBusinessId)
            //           orderby item.Id
            //           select item;
            //return PartialView(data.ToList());
        }
        // GET: Telephony
        public ActionResult Index()
        {
            return View(db.tbl_MST_Questionnaire.ToList());
        }

        // GET: Telephony/Details/5
        public ActionResult Details(int? id)
        {
            if (id == null)
            {
                return new HttpStatusCodeResult(HttpStatusCode.BadRequest);
            }
            tbl_MST_Questionnaire tbl_MST_Questionnaire = db.tbl_MST_Questionnaire.Find(id);
            if (tbl_MST_Questionnaire == null)
            {
                return HttpNotFound();
            }
            return View(tbl_MST_Questionnaire);
        }

        // GET: Telephony/Create
        public ActionResult Create()
        {
            return View();
        }

        // POST: Telephony/Create
        // To protect from overposting attacks, please enable the specific properties you want to bind to, for 
        // more details see https://go.microsoft.com/fwlink/?LinkId=317598.
        [HttpPost]
        [ValidateAntiForgeryToken]
        public ActionResult Create([Bind(Include = "Id,QuestionText,VDNNo,SubBusinessId,IsActive,CreatedDate,CreatedBy,ModifyDate,ModifyBy,RangeType")] tbl_MST_Questionnaire tbl_MST_Questionnaire)
        {
            if (ModelState.IsValid)
            {
                db.tbl_MST_Questionnaire.Add(tbl_MST_Questionnaire);
                db.SaveChanges();
                return RedirectToAction("Index");
            }

            return View(tbl_MST_Questionnaire);
        }

        // GET: Telephony/Edit/5
        public ActionResult Edit(int? id)
        {
            if (id == null)
            {
                return new HttpStatusCodeResult(HttpStatusCode.BadRequest);
            }
            tbl_MST_Questionnaire tbl_MST_Questionnaire = db.tbl_MST_Questionnaire.Find(id);
            if (tbl_MST_Questionnaire == null)
            {
                return HttpNotFound();
            }
            return View(tbl_MST_Questionnaire);
        }

        // POST: Telephony/Edit/5
        // To protect from overposting attacks, please enable the specific properties you want to bind to, for 
        // more details see https://go.microsoft.com/fwlink/?LinkId=317598.
        [HttpPost]
        [ValidateAntiForgeryToken]
        public ActionResult Edit([Bind(Include = "Id,QuestionText,VDNNo,SubBusinessId,IsActive,CreatedDate,CreatedBy,ModifyDate,ModifyBy,RangeType")] tbl_MST_Questionnaire tbl_MST_Questionnaire)
        {
            if (ModelState.IsValid)
            {
                db.Entry(tbl_MST_Questionnaire).State = EntityState.Modified;
                db.SaveChanges();
                return RedirectToAction("Index");
            }
            return View(tbl_MST_Questionnaire);
        }

        // GET: Telephony/Delete/5
        public ActionResult Delete(int? id)
        {
            if (id == null)
            {
                return new HttpStatusCodeResult(HttpStatusCode.BadRequest);
            }
            tbl_MST_Questionnaire tbl_MST_Questionnaire = db.tbl_MST_Questionnaire.Find(id);
            if (tbl_MST_Questionnaire == null)
            {
                return HttpNotFound();
            }
            return View(tbl_MST_Questionnaire);
        }

        // POST: Telephony/Delete/5
        [HttpPost, ActionName("Delete")]
        [ValidateAntiForgeryToken]
        public ActionResult DeleteConfirmed(int id)
        {
            tbl_MST_Questionnaire tbl_MST_Questionnaire = db.tbl_MST_Questionnaire.Find(id);
            db.tbl_MST_Questionnaire.Remove(tbl_MST_Questionnaire);
            db.SaveChanges();
            return RedirectToAction("Index");
        }

        protected override void Dispose(bool disposing)
        {
            if (disposing)
            {
                db.Dispose();
            }
            base.Dispose(disposing);
        }
    }
}
