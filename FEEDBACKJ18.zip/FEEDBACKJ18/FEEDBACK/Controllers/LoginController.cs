﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;

namespace FEEDBACK.Controllers
{
    public class LoginController : Controller
    {
        // GET: Login
        [AllowAnonymous]
        public ActionResult Index()
        {
           
            return View();
        }
        [AllowAnonymous]
        [HttpPost]
        public ActionResult Index(FormCollection FC)
        {
            BL.User objuser = new BL.User();

            if (objuser.validateuser(FC["user"].ToString(), FC["pass"].ToString()))
            {
                //objuser.Userid = FC["user"].ToString();
                //objuser.UserName = "Ramesh " + DateTime.Now.ToString();
                HttpContext.Session["user"] = objuser;
                if(objuser.UserType!=1)
                    return RedirectToAction("businessIndex", "Home");
                else
                return RedirectToAction("Index", "Home");
            }
            else
            {
                TempData["loginmsg"] = "Invalid Credentials";
                return RedirectToAction("Index", "Login");
            }
        }
        [HttpPost]
        public ActionResult Logout(FormCollection FC)
        {

            Session.Abandon();
            return RedirectToAction("Index", "Home");
            
        }

    }
}