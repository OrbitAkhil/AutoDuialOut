﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;
using System.Data;
using FEEDBACK.BL;
using FEEDBACK.Models;

namespace FEEDBACK.Controllers
{
    public class HomeController : Controller
    {
        public ActionResult Index()
        { 
                Session["startdate"] = DateTime.Now;
                Session["enddate"] = DateTime.Now;
                Session["range"] = "1";
            

            return View();
        }
        public ActionResult ReportAgentVdnIndex()
        {


            return View();
        }
        
        public ActionResult BusinessIndex()
        {
            Session["startdate"] = DateTime.Now;
            Session["enddate"] = DateTime.Now;
            Session["range"] = "1";

            return View();
        }
        public ActionResult BusinessIndexPartial()
        {


            return PartialView();
        }
        public ActionResult ReportBusinessIndex()
        {


            return View();
        }

        public ActionResult ReportBusinessIndexPartial()
        {
            FEEDBACK.BL.Dashboard db = new Dashboard();
            db.fromDate = DateTime.Now;
            db.toDate = DateTime.Now;
            db.RadioField = "1";

            return PartialView(db);
        }
        [HttpPost]
        public ActionResult ReportBusinessIndexPartial(FormCollection form, Dashboard db)
        {
            //FEEDBACK.BL.Dashboard db = new Dashboard();


            if (form["RadioField"].ToString() == "")
            {
                db.RadioField = "1";
            }
            else
            {
                db.RadioField = form["RadioField"]; //the value will be the item id of the size
            }
            if (form["RadioField"].ToString() == "1" || form["RadioField"].ToString() == "2" || form["RadioField"].ToString() == "3")
            {
                Dashboard ds = new Dashboard();
                if (form["RadioField"].ToString() == "1")
                {

                    ds.fromDate = Convert.ToDateTime(DateTime.Now);
                    ds.toDate = Convert.ToDateTime(DateTime.Now);
                }
                else if (form["RadioField"].ToString() == "2")
                {

                    ds.fromDate = Convert.ToDateTime(DateTime.Now);
                    ds.toDate = Convert.ToDateTime(DateTime.Now);

                }
                else if (form["RadioField"].ToString() == "3")
                {

                    ds.fromDate = Convert.ToDateTime(DateTime.Now);
                    ds.toDate = Convert.ToDateTime(DateTime.Now);
                }
                else
                {
                    db.fromDate = Convert.ToDateTime(DateTime.Now);
                    db.toDate = Convert.ToDateTime(DateTime.Now);
                }
            }
          

            return PartialView(db);
        }
        public ActionResult ReportIndex()
        {

      
            //FEEDBACK.BL.Dashboard.fromDate = Convert.ToDateTime(DateTime.Now.ToString());
            //FEEDBACK.BL.Dashboard.toDate = Convert.ToDateTime(DateTime.Now.ToString());
            //FEEDBACK.BL.Dashboard.RadioField = "0";
            return View();
        }
        //[HttpPost]
        //public ActionResult ReportIndex(FormCollection form)
        //{
        //    FEEDBACK.BL.Dashboard.RadioField = form["RadioField"]; //the value will be the item id of the size
        //    if (form["RadioField"].ToString() == "1" || form["RadioField"].ToString() == "2" || form["RadioField"].ToString() == "3")
        //    {
        //        FEEDBACK.BL.Dashboard.fromDate = Convert.ToDateTime(DateTime.Now);
        //        FEEDBACK.BL.Dashboard.toDate = Convert.ToDateTime(DateTime.Now);
        //    }
        //    else
        //    {
        //        FEEDBACK.BL.Dashboard.fromDate = Convert.ToDateTime(form["fromDate"]);
        //        FEEDBACK.BL.Dashboard.toDate = Convert.ToDateTime(form["toDate"]);
        //    }
        //    return PartialView();
        //}
        public ActionResult ReportIndexPartial()
        {
            FEEDBACK.BL.Dashboard db = new Dashboard();
            db.fromDate = DateTime.Now;
            db.toDate = DateTime.Now;
            db.RadioField = "1";
                      
            return PartialView(db);
        }
    
        [HttpPost]
        public ActionResult ReportIndexPartial(FormCollection form, Dashboard db)
        {
            //FEEDBACK.BL.Dashboard db = new Dashboard();


            if (form["RadioField"].ToString() == "")
            {
                db.RadioField = "1";
            }
      
            else
            {
           db.RadioField = form["RadioField"]; //the value will be the item id of the size
            }
            if (form["RadioField"].ToString() == "1" || form["RadioField"].ToString() == "2" || form["RadioField"].ToString() == "3")
            {
                Dashboard ds = new Dashboard();
                if (form["RadioField"].ToString() == "1")
                {

                 ds.fromDate = Convert.ToDateTime(DateTime.Now);
                 ds.toDate = Convert.ToDateTime(DateTime.Now);
                }
                else if (form["RadioField"].ToString() == "2")
                {

                   ds.fromDate = Convert.ToDateTime(DateTime.Now);
                   ds.toDate = Convert.ToDateTime(DateTime.Now);

                }
                else if (form["RadioField"].ToString() == "3")
                {

                    ds.fromDate = Convert.ToDateTime(DateTime.Now);
                    ds.toDate = Convert.ToDateTime(DateTime.Now);
                }
                else
                {
                   db.fromDate = Convert.ToDateTime(DateTime.Now);
                   db.toDate = Convert.ToDateTime(DateTime.Now);
                }
            }
         
          
            return PartialView(db);
        }
        public ActionResult About()
        {
            ViewBag.Message = "Your application description page.";

            return View();
        }

        public ActionResult Contact()
        {
            ViewBag.Message = "Your contact page.";

            return View();
        }
        [OutputCache(Duration = 3)]
        public ActionResult IndexPartial()
        {
            //ViewBag.Message = "Your contact page.";

            return PartialView();
        }
      
        public ActionResult ReportIPartial(string id)
        {
            ViewBag.sbid = id;
            ViewBag.StartDate = Session["startdate"];
            ViewBag.EndDate = Session["enddate"];
            ViewBag.Range = Session["range"];






            return PartialView("ReportIPartial");
            
        }
        [HttpPost]
        public ActionResult ExportToExcel()
        {


            return View();
        }
        
        public ActionResult PiChartPartial()
        {


            return PartialView();
        }
        public ActionResult HourlyComplianceReportIndex()
        {
            FEEDBACK.BL.Dashboard db = new Dashboard();
            db.fromDate = DateTime.Now;
            return PartialView(db);
        }
        [HttpPost]
        public ActionResult HourlyComplianceReportIndex(Dashboard db)
        {
  
            return PartialView(db);
        }
        public ActionResult HourlyComplianceReportDashboardIndex()
        {
            FEEDBACK.BL.Dashboard db = new Dashboard();
            db.fromDate = DateTime.Now;
            return PartialView(db);
        }
        public ActionResult HourlyBusinessComplianceReportIndex()
        {
            FEEDBACK.BL.Dashboard db = new Dashboard();
            db.fromDate = DateTime.Now;
            return PartialView(db);
        }
        [HttpPost]
        public ActionResult HourlyBusinessComplianceReportIndex(Dashboard db)
        {
            return PartialView(db);
        }
        public ActionResult HourlyBusinessComplianceReportDashboardIndex()
        {
            FEEDBACK.BL.Dashboard db = new Dashboard();
            db.fromDate = DateTime.Now;
            return PartialView(db);
        }






    }
}