﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;
using System.Data;
using FEEDBACK.BL;
using FEEDBACK.Models;
using System.Web.UI.WebControls;
using System.IO;
using System.Web.UI;
using System.Data.SqlClient;
using System.Web.Script.Serialization;

namespace FEEDBACK.Controllers
{
    public class AdminController : Controller
    {
        // GET: Admin
        public ActionResult Index()
        {
            //DataTable dt = BL.Dashboard.getadmindashboard().Tables[0];
            //return View(dt);
            return View();
        }
        //[ChildActionOnly]
        [OutputCache(  Duration = 3)]
        public ActionResult partialindex()
        {
            DataTable dt = BL.Dashboard.getadmindashboard().Tables[0];
            return PartialView(dt);
        }
        #region Business
        public ActionResult ShowBusiness()
        {
            BL.Business objB = new BL.Business();
            List<BL.MBusiness> objL = new List<BL.MBusiness>();
            DataTable dt = objB.ReturnTable("");
            foreach (DataRow dr in dt.Rows)
            {
                if (dr["BusinessID"].ToString() != "0")
                {
                    BL.MBusiness MB = new BL.MBusiness();
                    MB.BusinessId = dr["BusinessID"].ToString();
                    MB.BusinessName = dr["BusinessName"].ToString(); 
                    MB.AddressOfContact = dr["AddressOfContact"].ToString();
                    MB.Location = dr["location"].ToString();
                    MB.ContactPerson = dr["contactperson"].ToString();
                    MB.ContactNumber = dr["ContactNumber"].ToString();
                    MB.Status = dr["Status"].ToString();
                    objL.Add(MB);
                }
            }

            return View(objL);
        }
        public ActionResult AddBusiness()
        {
            return PartialView();
        }
        [HttpPost]
        public ActionResult AddBusiness(MBusiness MB,FormCollection FC)
        {
            
            BL.Business Business = new BL.Business();


            //TempData["AddBusiness"] = "New Business added successfully.";

            if (ModelState.IsValid && MB.BusinessName != "")
            {
            
                    Business.AddBusiness(MB.BusinessName, MB.Location, MB.AddressOfContact, MB.ContactPerson, MB.ContactNumber, "1", (((FEEDBACK.BL.User)Session["user"]).Userid).ToString());

                    return Json(new { success = true, msg = "Data saved." });
       

            }
            else
            {
                return Json(new { success = true, msg = "Error while Data Save........." });
            }
                
          
            

        }
        BL.Business objB = new BL.Business();
        BL.MBusiness MB = new BL.MBusiness();
        public ActionResult Editbusiness(string id)
        {
     
            DataTable dt = objB.ReturnTable("");
            foreach (DataRow dr in dt.Rows)
            {
                if (dr["BusinessID"].ToString() == id)
                {

                    MB.BusinessId = dr["BusinessID"].ToString();
                    MB.BusinessName = dr["BusinessName"].ToString();
                    MB.Location = dr["Location"].ToString();
                    MB.AddressOfContact = dr["AddressOfContact"].ToString();
                    MB.ContactPerson = dr["ContactPerson"].ToString();
                    MB.ContactNumber = dr["ContactNumber"].ToString();
                    MB.Status = dr["Status"].ToString();


                }
            }
            if (Request.IsAjaxRequest())
            {
                return PartialView("Editbusiness", MB);
            }
            else
            {
                return PartialView("Editbusiness", MB);
            }
        }
        [HttpPost]
        public ActionResult Editbusiness(BL.MBusiness MBNEW,FormCollection fc)
        {
            //BL.Business objB = new BL.Business();
            //BL.MBusiness MB = new BL.MBusiness();
            //DataTable dt = objB.ReturnTable("");
            //foreach (DataRow dr in dt.Rows)
            //{
            //    if (dr["BusinessID"].ToString() == MBNEW.BusinessId)
            //    {

            //        MB.BusinessId = dr["BusinessID"].ToString();
            //        MB.BusinessName = dr["BusinessName"].ToString();

            //    }
            //}
            if (ModelState.IsValid)
            { 
                if (MBNEW.EditBusiness(MBNEW))
                {
                    return Json(new { success = true, msg = "Data saved." });
                }
                else
                { return Json(new { success = false, msg = "Error while data save." }); }
            }
            else
            {
                return  Json(new { success = false, msg = "valfalse" }); ;
            }
            //if (Request.IsAjaxRequest())
            //{
            //    return Json(new { success = true });
            //}
            //else
            //{
            //    return PartialView("Editbusiness", MBNEW);
            //}
        }
        #endregion

        #region Router

        public ActionResult RouterAdd()
        {
            return View();
        }

        [HttpPost]
        public ActionResult RouterAdd(FormCollection FC)
        {
            BL.Business Business = new BL.Business();
            //var BusinessId = 
            string MSG = Business.AddRouter(FC["RouterIP"].ToString(), FC["LoginUser"].ToString(), FC["Password"].ToString(),
                FC["datacenter"].ToString(), FC["Rackno"].ToString(), Convert.ToInt32(FC["CardNo"]), FC["OEM"].ToString(), ((BL.User)HttpContext.Session["user"]).Userid.ToString());
            {
                TempData["RouterAdd"] = MSG;
            }

            return View();
        } 
        #endregion
        
        #region Sub Business
        public ActionResult AddSubBusiness()
        {
            BL.Business Business = new BL.Business();
            System.Data.DataTable DT = new System.Data.DataTable();
            DT = Business.ReturnTable("Business");
            SelectListItem[] items = new SelectListItem[DT.Rows.Count];
            int i = 0;
            foreach (System.Data.DataRow DR in DT.Rows)
            {

                SelectListItem item = new SelectListItem { Text = DR["BusinessName"].ToString(), Value = DR["BusinessID"].ToString() };
                items.SetValue(item, i);
                i++;
            }
            ViewData["table_name"] = items;
            ViewBag.Items = items;

            //ViewBag.tablle_name = new SelectList()
            return PartialView();
        }
        [HttpPost]
        public ActionResult AddSubBusiness(FormCollection FC)
        {
            BL.Business Business = new BL.Business();
            //var BusinessId = 
            string MSG = Business.AddSubBusiness(FC["SubBusiName"].ToString(), Convert.ToInt32(FC["table_name"]), ((BL.User)HttpContext.Session["user"]).Userid.ToString());
            {
                TempData["AddSubBusiness"] = MSG;
            }
            //BL.Business Business = new BL.Business();
            System.Data.DataTable DT = new System.Data.DataTable();
            DT = Business.ReturnTable("Business");
            SelectListItem[] items = new SelectListItem[DT.Rows.Count];
            int i = 0;
            foreach (System.Data.DataRow DR in DT.Rows)
            {
                SelectListItem item = new SelectListItem { Text = DR["BusinessName"].ToString(), Value = DR["BusinessID"].ToString() };
                items.SetValue(item, i);
                i++;
            }
            ViewData["table_name"] = items;
            ViewBag.Items = items;
            return PartialView();
        }

        public ActionResult ShowSubBusiness()
        {
            return View(new FEEDBACK.Models.SubBusiness().GetAllSBwithBusiness("0"));
        }

        public ActionResult Editsubbusiness(string id)
        {
           FEEDBACK.Models.SubBusiness MB = new FEEDBACK.Models.SubBusiness().GetAllSBwithBusiness(id)[0];
            
          
            if (Request.IsAjaxRequest())
            {
                return PartialView("Editsubbusiness", MB);
            }
            else
            {
                return PartialView("Editsubbusiness", MB);
            }
        }
        [HttpPost]
        public ActionResult Editsubbusiness(FEEDBACK.Models.SubBusiness MBNEW)
        {
            
            if (ModelState.IsValid)
            {
                if (MBNEW.EditSubBusiness(MBNEW))
                {
                    return Json(new { success = true, msg = "Data saved." });
                }
                else
                { return Json(new { success = false, msg = "Error while data save." }); }
            }
            else
            {
                return Json(new { success = false, msg = "valfalse" }); ;
            }
            //if (Request.IsAjaxRequest())
            //{
            //    return Json(new { success = true });
            //}
            //else
            //{
            //    return PartialView("Editbusiness", MBNEW);
            //}
        }

        #endregion

        #region Media Gateway LOB
        public ActionResult MGLOBMapping()
        {
            BL.Business Business = new BL.Business();
            System.Data.DataTable DT = new System.Data.DataTable();
            DT = Business.ReturnLOB();
            SelectListItem[] items = new SelectListItem[DT.Rows.Count];
            int i = 0;
            foreach (System.Data.DataRow DR in DT.Rows)
            {
                SelectListItem item = new SelectListItem { Text = DR["LOBName"].ToString(), Value = DR["LOBID"].ToString() };
                items.SetValue(item, i);
                i++;
            }
            ViewData["LOB"] = items;

            System.Data.DataTable DNISType = new System.Data.DataTable();
            DNISType = Business.GetDNISType();
            SelectListItem[] DNIS = new SelectListItem[DNISType.Rows.Count];
            int a = 0;
            foreach (System.Data.DataRow DR in DNISType.Rows)
            {
                SelectListItem item = new SelectListItem { Text = DR["Name"].ToString(), Value = DR["ID"].ToString() };
                DNIS.SetValue(item, a);
                a++;
            }
            ViewData["DNISType"] = DNIS;

            System.Data.DataTable DTRouter = new System.Data.DataTable();
            DTRouter = Business.ReturnRouter();
            SelectListItem[] router = new SelectListItem[DTRouter.Rows.Count];
            int b = 0;
            foreach (System.Data.DataRow DR in DTRouter.Rows)
            {
                SelectListItem R = new SelectListItem { Text = DR["RouterIP"].ToString(), Value = DR["ID"].ToString() };
                router.SetValue(R, b);
                b++;
            }
            ViewData["Router_IP"] = router;
            return View();
        }
        [HttpPost]
        public ActionResult MGLOBMapping(FormCollection FC)
        {
            BL.Business Business = new BL.Business();
            //string msg = Business.AddRouterPRIMapping(Convert.ToInt32(FC["Router_IP"]), FC["PortNo"].ToString(), FC["CircuitID"].ToString(), FC["ServiceProvider"].ToString(), Convert.ToInt32(FC["DNISType"]),
            //    FC["PRINo"].ToString(), FC["DNIS"].ToString(), Convert.ToInt32(FC["LOB"]), ((BL.User)HttpContext.Session["user"]).Userid.ToString());
            string msg = Business.AddRouterPRIMapping(0, "0","0", "", 0,
               FC["PRINo"].ToString(), FC["DNIS"].ToString(), Convert.ToInt32(FC["LOB"]), ((BL.User)HttpContext.Session["user"]).Userid.ToString());

            TempData["MGLOBMapping"] = msg;
            //BL.Business Business = new BL.Business();
            System.Data.DataTable DT = new System.Data.DataTable();
            DT = Business.ReturnLOB();
            SelectListItem[] items = new SelectListItem[DT.Rows.Count];
            int i = 0;
            foreach (System.Data.DataRow DR in DT.Rows)
            {
                SelectListItem item = new SelectListItem { Text = DR["LOBName"].ToString(), Value = DR["LOBID"].ToString() };
                items.SetValue(item, i);
                i++;
            }
            ViewData["LOB"] = items;

            System.Data.DataTable DNISType = new System.Data.DataTable();
            DNISType = Business.GetDNISType();
            SelectListItem[] DNIS = new SelectListItem[DNISType.Rows.Count];
            int a = 0;
            foreach (System.Data.DataRow DR in DNISType.Rows)
            {
                SelectListItem item = new SelectListItem { Text = DR["Name"].ToString(), Value = DR["ID"].ToString() };
                DNIS.SetValue(item, a);
                a++;
            }
            ViewData["DNISType"] = DNIS;

            System.Data.DataTable DTRouter = new System.Data.DataTable();
            DTRouter = Business.ReturnRouter();
            SelectListItem[] router = new SelectListItem[DTRouter.Rows.Count];
            int b = 0;
            foreach (System.Data.DataRow DR in DTRouter.Rows)
            {
                SelectListItem R = new SelectListItem { Text = DR["RouterIP"].ToString(), Value = DR["ID"].ToString() };
                router.SetValue(R, b);
                b++;
            }
            ViewData["Router_IP"] = router;
            return View();

        }


        public ActionResult ShowDNIS()
        {
            
            return View(new FEEDBACK.Models.DNISSubBusiness().GetAllDNISwithSBusiness());
        }

        public void DeleteDNIS(string id)
        {
            string msg = new FEEDBACK.Models.DNISSubBusiness().DeleteDNISMapping(id);
            TempData["DeleteDNIS"] = "DNIS SubBusiness mapping deleted successfully.";
            Response.Redirect("~/admin/ShowDNIS",true);

        }

        #endregion

        #region DNIS



        public ActionResult AddDNIS()
        {
            Models.DNISDetails DD = new Models.DNISDetails();
            DD.DNIS = BL.Business.PopulateDNIS();
            return View(DD);
        }
        [HttpPost]
        public ActionResult AddDNIS(Models.DNISDetails DDNEW)
        {
            Models.DNISDetails DD = new Models.DNISDetails();
            DD.DNIS = BL.Business.PopulateDNIS();
            if (ModelState.IsValid)
            {
                TempData["adddnis"] = BL.Business.AddDNIS(DDNEW);
            }
            return View(DD);
        }
        #endregion

        #region User
        public ActionResult user()
        {
            return View(new BL.UserDetails().GetAlluser(((FEEDBACK.BL.User)Session["user"]).Userid));
        }
        public ActionResult Edituser(BL.UserDetails users, string id)
         {

            ViewBag.listitem = users.GetuserWithList(((FEEDBACK.BL.User)Session["user"]).Userid, id);
            ViewData["UserTypeLists"] = users.getListItems("ID","UserType","GetUserType");
            ViewBag.UserTypesItems = users.getListItems("ID", "UserType", "GetUserType");
          

            if (Request.IsAjaxRequest())
            {
                return PartialView("edituser", new BL.UserDetails().GetSingleUserDetails(((FEEDBACK.BL.User)Session["user"]).Userid, id)[0] );
            }
            else
            {
                return PartialView("edituser", new BL.UserDetails().GetSingleUserDetails(((FEEDBACK.BL.User)Session["user"]).Userid, id)[0]);
            }
        }
        [HttpPost]
        public ActionResult Edituser(BL.UserDetails MBNEW,FormCollection fc)
        {
            MBNEW.usertype = MBNEW.usertypeid.ToString();
            if (ModelState.IsValid)
            {
               
                string smsg = MBNEW.Saveuser(MBNEW, ((FEEDBACK.BL.User)Session["user"]).Userid);
                string message = "";
                string txtvalue = "";
                try
                { 
                     txtvalue = fc["chkSubBusiness"].ToString();
                }
                catch
                {
                    txtvalue = "";
                }
                if (smsg == "ok")
                {
                    if (txtvalue != "")
                    {
                        var values = fc["chkSubBusiness"].Split(',');
                        DataTable DT = new DataTable();
                        DataRow DR = null;
                        DT.Columns.Add("UserID", typeof(string));
                        DT.Columns.Add("SBID", typeof(string));
                        DT.Columns.Add("CreateBy", typeof(string));
                        foreach (var value in values)
                        {
                            // string query = string.Format("exec dbo.sp_userSBusinessMapping '{0}','{1}','{2}'", smsg, value, ((FEEDBACK.BL.User)Session["user"]).Userid);
                            DR = DT.NewRow();
                            DR["UserId"] = MBNEW.userid.ToString();
                            DR["SBID"] = value;
                            DR["CreateBy"] = ((FEEDBACK.BL.User)Session["user"]).Userid.ToString();

                            DT.Rows.Add(DR);
                            // message = MBNEW.SaveUserSubBusinessMapping(MBNEW.userid.ToString(), value, ((FEEDBACK.BL.User)Session["user"]).Userid);
                        }
                        message = MBNEW.SaveUserSubBusinessMapping(DT);
                    }
                    else
                    {
                        DataTable DT = new DataTable();
                        DataRow DR = null;
                        DT.Columns.Add("UserID", typeof(string));
                        DT.Columns.Add("SBID", typeof(string));
                        DT.Columns.Add("CreateBy", typeof(string));
                        DR = DT.NewRow();
                        DR["UserID"] = MBNEW.userid.ToString();
                        DR["SBID"] = "";
                        DR["CreateBy"] = ((FEEDBACK.BL.User)Session["user"]).Userid.ToString();
                        DT.Rows.Add(DR);

                        message = MBNEW.SaveUserSubBusinessMapping(DT);
                    }
                }
                if (message == "ok")
                {
                    return Json(new { success = true, msg = "Data saved." });
                }
                else
                { return Json(new { success = false, msg = smsg }); }
            }
            else
            {
                return Json(new { success = false, msg = "valfalse" }); ;
            }


        }
        MBusiness MBusiness = new MBusiness();
        BL.Business Business = new BL.Business();
        BL.UserDetails users = new BL.UserDetails();
        Models.SubBusiness SubBusinesses = new Models.SubBusiness();
        System.Data.DataTable DT = new System.Data.DataTable();
        SelectListItem[] UserTypesitems;
        SelectListItem[] Businessitems;
        SelectListItem[] SubBusinessitems;
        SQLU dbsql = new SQLU("");



        public ActionResult adduser()
        {
            int i;// User Type Drop Down
      
            DT = users.ReturnTable("UserType");
 /* SelectListItem[]*/ UserTypesitems = new SelectListItem[DT.Rows.Count];
             i = 0;
            foreach (System.Data.DataRow DR in DT.Rows)
            {

                SelectListItem UTitems = new SelectListItem { Text = DR["UserType"].ToString(), Value = DR["ID"].ToString() };
                UserTypesitems.SetValue(UTitems, i);
                i++;
            }
            ViewData["UserTypeLists"] = UserTypesitems;
            ViewBag.UserTypesItems = UserTypesitems;

            // Business Drop Down
            DT = Business.ReturnTable("Business");
            Businessitems = new SelectListItem[DT.Rows.Count];
             i = 0;
            foreach (System.Data.DataRow DR in DT.Rows)
            {

                SelectListItem Businessitem = new SelectListItem { Text = DR["BusinessName"].ToString(), Value = DR["BusinessID"].ToString() };
                Businessitems.SetValue(Businessitem, i);
                i++;
            }
            ViewData["BusinessLists"] = Businessitems;
            ViewBag.BusinessItems = Businessitems;

            //dropdown Sub Business

            SubBusinesses.BusinessId = MBusiness.BusinessId;
            DT = SubBusinesses.ReturnTable("SubBusiness");
            SubBusinessitems = new SelectListItem[DT.Rows.Count];
            i = 0;
            foreach (System.Data.DataRow DR in DT.Rows)
            {

                SelectListItem SubBusinessitem = new SelectListItem { Text = DR["subbusinessname"].ToString(), Value = DR["id"].ToString() };
                SubBusinessitems.SetValue(SubBusinessitem, i);
                i++;
            }
            ViewData["SubBusinessLists"] = SubBusinessitems;
            ViewBag.SubBusinessItems = SubBusinessitems;

            return PartialView("adduser");
        }
   
        [HttpPost]
        public ActionResult adduser(BL.UserDetails MBNEW, FormCollection fc)
        {
            string txtvalue = "";
            try
             {
                txtvalue = fc["chkSubBusiness"].ToString();
            }
            catch
            {
                txtvalue = "";
            }
            
      
            if (ModelState.IsValid)
            {
                MBNEW.useractive = "1";
                string smsg = MBNEW.Saveuser(MBNEW, ((FEEDBACK.BL.User)Session["user"]).Userid);

                string message = "";
                
                if (txtvalue != "" && MBNEW.usertypeid != 3)
                {
                    var values = fc["chkSubBusiness"].Split(',');
                    DataTable DT = new DataTable();
                    DataRow DR = null;
                    DT.Columns.Add("UserID", typeof(string));
                    DT.Columns.Add("SBID", typeof(string));
                    DT.Columns.Add("CreateBy", typeof(string));
                    foreach (var value in values)
                    {
                        DR = DT.NewRow();
                        DR["UserId"] = smsg.ToString();
                        DR["SBID"] = value;
                        DR["CreateBy"] = ((FEEDBACK.BL.User)Session["user"]).Userid.ToString();

                        DT.Rows.Add(DR);
                    }
                    message = MBNEW.SaveUserSubBusinessMapping(DT);
                }
                if (message == "ok")
                {
                    return Json(new { success = true, msg = "Data saved." });
                }
                else if(IsItOnlyNumbers(smsg) == true)
                    {
                    return Json(new { success = true, msg = "IT User Data saved  ." });
                    }
                else
                { return Json(new { success = false, msg = smsg }); }
            
            }
            else
            {
                return Json(new { success = false, msg = "valfalse" }); ;
            }
        }
        [HttpPost]
        public JsonResult GetSubBusinessList(string BusinessID)
        {

            var dt = dbsql.ShowDataDT("Exec sp_utom_SelectSubBusiness '" + BusinessID  + "'");
            //var subBusinessitems = new SelectListItem[DT.Rows.Count];
            List<SubBusiness> list = null;
            if (dt.Rows.Count > 0)
            {
                list = new List<SubBusiness>();
                foreach (System.Data.DataRow dr in dt.Rows)
                {
                    list.Add(new SubBusiness() { SubBusinessName = dr["subbusinessname"].ToString() , SubBusinessId = dr["id"].ToString() });
                }
            }

            return Json(new { data = list, name="Akhil" });
        }
        public ActionResult ExportToExcel()
        {
            System.Data.DataSet ds = FEEDBACK.BL.Dashboard.ReportAgentVdngetdashboard();
            var gv = new GridView();
            gv.DataSource = ds;
            gv.DataBind();
            Response.ClearContent();
            Response.Buffer = true;
            Response.AddHeader("content-disposition", "attachment; filename=AgentReportData.xls");
            Response.ContentType = "application/ms-excel";
            Response.Charset = "";
            StringWriter objStringWriter = new StringWriter();
            HtmlTextWriter objHtmlTextWriter = new HtmlTextWriter(objStringWriter);
            gv.RenderControl(objHtmlTextWriter);
            Response.Output.Write(objStringWriter.ToString());
            Response.Flush();
            Response.End();
            return View();
        }
        public ActionResult ExportToExcelVDN()
        {
            System.Data.DataSet ds = FEEDBACK.BL.Dashboard.ReportAgentVdngetdashboard();
            var gv = new GridView();
            gv.DataSource = ds.Tables[1];
            gv.DataBind();
            Response.ClearContent();
            Response.Buffer = true;
            Response.AddHeader("content-disposition", "attachment; filename=VDNReportData.xls");
            Response.ContentType = "application/ms-excel";
            Response.Charset = "";
            StringWriter objStringWriter = new StringWriter();
            HtmlTextWriter objHtmlTextWriter = new HtmlTextWriter(objStringWriter);
            gv.RenderControl(objHtmlTextWriter);
            Response.Output.Write(objStringWriter.ToString());
            Response.Flush();
            Response.End();
            return View();
        }
        #endregion

        #region FeedBack
        public ActionResult QuestionDetails()
        {
            return PartialView();

        }
      
        public ActionResult QuetionBySurveyIdSMSIndex(string id)
        {
            ViewBag.SurveyId = id;
            return PartialView();

        }
        public ActionResult FeedBackIndex()
        {
            SurveyDataAccessLayer dal = new SurveyDataAccessLayer();

            var list = dal.SelectalldataTelephony();

            return View(list.ToList());

            
        }
        public ActionResult FeedBackSMSIndex()
        {
            SurveyDataAccessLayer dal = new SurveyDataAccessLayer();

            var list = dal.SelectalldataSMS();

            return View(list.ToList());


        }

        public ActionResult AddFeedBack(QuestionEntry mdl)
        {
            BL.Dashboard dd = new BL.Dashboard();
            SQLU ss = new SQLU("");
            DataSet ds = new DataSet();
            DataSet ds1 = new DataSet();
            DataSet ds2 = new DataSet();
            DataTable allSubBusinessList = new DataTable();
            DataTable allOptionTypeList = new DataTable();
            DataTable allSMSOptionTypeList = new DataTable();
            ds = Dashboard.GetSubBusinessList();
            ds1 = Dashboard.GetOptionTypeList(1);
            ds2 = Dashboard.GetSMSOptionTypeList();
            allSubBusinessList = ds.Tables[0];
            allOptionTypeList = ds1.Tables[0];
            allSMSOptionTypeList = ds2.Tables[0];
            ViewBag.allSubBusinessList = ss.ddlListItem(allSubBusinessList, "subbusinessname", "id");
            ViewBag.allOptionTypeList = ss.ddlListItem(allOptionTypeList, "RangeName", "id");
            ViewBag.allSMSOptionTypeList = ss.ddlListItem(allSMSOptionTypeList, "DisplayType", "id");
            return PartialView(mdl);
        }

        [HttpPost]
        public ActionResult AddFeedBack(QuestionEntry mdl, FormCollection frm)
        {
            QuestionDataAccessLayer MDL = new QuestionDataAccessLayer();
            SurveyFeedback obj = new SurveyFeedback();
            string txtvalue = "";
            string message = "";
            string subBusinessID = "";

            try
            {
                txtvalue = frm["NoOfQuestion"].ToString();
                subBusinessID = frm["allSubBusinessList"].ToString();

                //allSubBusinessList

            }
            catch
            {
                txtvalue = "";
            }

            obj.insertDataTelephony(mdl, txtvalue, subBusinessID);
            if (message == "ok")
            {
                return RedirectToAction("FeedBackIndex");
            }


            return RedirectToAction("FeedBackIndex");

        }
        public ActionResult QuetionBySurveyIdIndex(string id)
        {
            ViewBag.SurveyId = id;
            return PartialView();

        }
        public ActionResult EditFeedback(QuestionEntry mdl, string id)
        {
            BL.Dashboard dd = new BL.Dashboard();
            SQLU ss = new SQLU("");
            DataSet ds = new DataSet();
            DataSet ds1 = new DataSet();
            DataSet ds2 = new DataSet();
            DataTable allSubBusinessList = new DataTable();
            DataTable allOptionTypeList = new DataTable();
            DataTable allSMSOptionTypeList = new DataTable();
            ds = Dashboard.GetSubBusinessList();
            ds1 = Dashboard.GetOptionTypeList(1);
            ds2 = Dashboard.GetSMSOptionTypeList();
            allSubBusinessList = ds.Tables[0];
            allOptionTypeList = ds1.Tables[0];
            allSMSOptionTypeList = ds2.Tables[0];
            ViewBag.allSubBusinessList = ss.ddlListItem(allSubBusinessList, "subbusinessname", "id");
            ViewBag.allOptionTypeList = ss.ddlListItem(allOptionTypeList, "RangeName", "id");
            ViewBag.allSMSOptionTypeList = ss.ddlListItem(allSMSOptionTypeList, "DisplayType", "id");
            ViewBag.SurveyId = id;
            return PartialView(mdl);
        }
        [HttpPost]
        public ActionResult EditFeedBack(string id, QuestionEntry mdl, FormCollection frm)
        {
            QuestionDataAccessLayer MDL = new QuestionDataAccessLayer();
            SurveyFeedback obj = new SurveyFeedback();
            string txtvalue = "";
            string message = "";
            string subBusinessID = "";

            try
            {
                txtvalue = frm["NoOfQuestion"].ToString();
                subBusinessID = frm["sbid"].ToString();

                //allSubBusinessList

            }
            catch
            {
                txtvalue = "";
            }

            obj.insertDataTelephony(mdl, txtvalue, subBusinessID);
            if (message == "ok")
            {
                return RedirectToAction("FeedBackIndex");
            }


            return RedirectToAction("FeedBackIndex");
        }
        public ActionResult EditFeedBack31Jul(string id)
        {

            FEEDBACK.BL.QuestionEntry MB = new FEEDBACK.BL.QuestionEntry();
            List<QuestionEntry> obj = new List<QuestionEntry>();
            obj = MB.GetQuesVDNOptionType(id).ToList();
            var list = (from a in obj.ToList()
                        select a);
            BL.Dashboard dd = new BL.Dashboard();
            SQLU ss = new SQLU("");

            DataSet ds1 = new DataSet();
            DataTable allSubBusinessList = new DataTable();
            DataTable allOptionTypeList = new DataTable();
            ds1 = Dashboard.GetOptionTypeList(1);
            allOptionTypeList = ds1.Tables[0];
            ViewBag.Surveyid = id;
            ViewBag.allOptionTypeList = ss.ddlListItem(allOptionTypeList, "RangeName", "id");
            return PartialView(list.ToList());
        }
        [HttpPost]
        public ActionResult EditFeedBack31Jul(List<QuestionEntry> lstData,string id)
        {

            FEEDBACK.BL.QuestionEntry MB = new FEEDBACK.BL.QuestionEntry();
            List<QuestionEntry> obj = new List<QuestionEntry>();
            obj = MB.GetQuesVDNOptionType(id).ToList();
            var list = (from a in obj.ToList()
                        select a);
            BL.Dashboard dd = new BL.Dashboard();
            SQLU ss = new SQLU("");

            DataSet ds1 = new DataSet();
            DataTable allSubBusinessList = new DataTable();
            DataTable allOptionTypeList = new DataTable();
            ds1 = Dashboard.GetOptionTypeList(1);
            allOptionTypeList = ds1.Tables[0];
            ViewBag.Surveyid = id;
            ViewBag.allOptionTypeList = ss.ddlListItem(allOptionTypeList, "RangeName", "id");
            return PartialView(list.ToList());
        }




        public ActionResult AddFeedBackSMS(QuestionEntry mdl)
        {
            BL.Dashboard dd = new BL.Dashboard();
            SQLU ss = new SQLU("");
            DataSet ds = new DataSet();
            DataSet ds1 = new DataSet();
            DataSet ds2 = new DataSet();
            DataTable allSubBusinessList = new DataTable();
            DataTable allOptionTypeList = new DataTable();
            DataTable allSMSOptionTypeList = new DataTable();
            ds = Dashboard.GetSubBusinessList();
            ds1 = Dashboard.GetOptionTypeList(1);
            ds2 = Dashboard.GetSMSOptionTypeList();
            allSubBusinessList = ds.Tables[0];
            allOptionTypeList = ds1.Tables[0];
            allSMSOptionTypeList = ds2.Tables[0];
            ViewBag.allSubBusinessList = ss.ddlListItem(allSubBusinessList, "subbusinessname", "id");
            ViewBag.allOptionTypeList = ss.ddlListItem(allOptionTypeList, "RangeName", "id");
            ViewBag.allSMSOptionTypeList = ss.ddlListItem(allSMSOptionTypeList, "DisplayType", "id");
            return PartialView(mdl);
        }
        [HttpPost]
        public ActionResult AddFeedBackSMS(QuestionEntry mdl, FormCollection frm)
        {
            QuestionDataAccessLayer MDL = new QuestionDataAccessLayer();
            SurveyFeedback obj = new SurveyFeedback();
            string txtvalue = "";
            string message = "";
            string subBusinessID = "";

            try
            {
                txtvalue = frm["NoOfQuestion"].ToString();
                subBusinessID = frm["allSubBusinessList"].ToString();

                //allSubBusinessList

            }
            catch
            {
                txtvalue = "";
            }

            obj.insertDataSMSSurvey(mdl, txtvalue, subBusinessID);
            if (message == "ok")
            {
                return RedirectToAction("FeedBackSMSIndex");
            }


            return RedirectToAction("FeedBackSMSIndex");

        }

        public ActionResult EditFeedBackSMS(QuestionEntry mdl,string id)
        {
            BL.Dashboard dd = new BL.Dashboard();
            SQLU ss = new SQLU("");
            DataSet ds = new DataSet();
            DataSet ds1 = new DataSet();
            DataSet ds2 = new DataSet();
            DataTable allSubBusinessList = new DataTable();
            DataTable allOptionTypeList = new DataTable();
            DataTable allSMSOptionTypeList = new DataTable();
            ds = Dashboard.GetSubBusinessList();
            ds1 = Dashboard.GetOptionTypeList(1);
            ds2 = Dashboard.GetSMSOptionTypeList();
            allSubBusinessList = ds.Tables[0];
            allOptionTypeList = ds1.Tables[0];
            allSMSOptionTypeList = ds2.Tables[0];
            ViewBag.allSubBusinessList = ss.ddlListItem(allSubBusinessList, "subbusinessname", "id");
            ViewBag.allOptionTypeList = ss.ddlListItem(allOptionTypeList, "RangeName", "id");
            ViewBag.allSMSOptionTypeList = ss.ddlListItem(allSMSOptionTypeList, "DisplayType", "id");
            ViewBag.Surveyid = id;
            return PartialView(mdl);
        }
        [HttpPost]
        public ActionResult EditFeedBackSMS(QuestionEntry mdl, FormCollection frm,string id)
        {
            QuestionDataAccessLayer MDL = new QuestionDataAccessLayer();
            SurveyFeedback obj = new SurveyFeedback();
            string txtvalue = "";
            string message = "";
            string subBusinessID = "";

            try
            {
                txtvalue = frm["NoOfQuestion"].ToString();
                subBusinessID = frm["sbid"].ToString();

                //allSubBusinessList

            }
            catch
            {
                txtvalue = "";
            }

            obj.insertDataSMSSurvey(mdl, txtvalue, subBusinessID);
            if (message == "ok")
            {
                return RedirectToAction("FeedBackSMSIndex");
            }


            return RedirectToAction("FeedBackSMSIndex");

        }

        [HttpPost]
        public JsonResult GetUserSBList(string userid)
        {
            List<UserDetails> list = null;

            if (userid != "")
            {
                list = Getalluserdetails(userid);
            }


            return Json(new { data = list, name = "Akhil" });
        }
        public ActionResult EditFeedBackSMS31Jul(string id)
        {

            FEEDBACK.BL.SurveySMS MB = new FEEDBACK.BL.SurveySMS();
            List<SurveySMS> obj = new List<SurveySMS>();
            obj = MB.GetQuesVDNOptionTypeSMS(id).ToList();

            BL.Dashboard dd = new BL.Dashboard();
            SQLU ss = new SQLU("");

            DataSet ds1 = new DataSet();
            DataTable allSubBusinessList = new DataTable();
            DataTable allOptionTypeList = new DataTable();
            ds1 = Dashboard.GetOptionTypeList(2);
            allOptionTypeList = ds1.Tables[0];
            ViewBag.Surveyid = id;
            ViewBag.allOptionTypeList = ss.ddlListItem(allOptionTypeList, "RangeName", "id");
            return PartialView(obj);
        }
        public List<UserDetails> Getalluserdetails(string userid)
        {
            List<UserDetails> list = null;
            UserDetails mdl = new UserDetails();
            var dt = dbsql.ShowDataDT("exec usp_getalluserdetails '0'," + userid + "");
            //var subBusinessitems = new SelectListItem[DT.Rows.Count];

            if (dt.Rows.Count > 0)
            {
                list = new List<UserDetails>();
                foreach (System.Data.DataRow dr in dt.Rows)
                {
                    list.Add(new UserDetails() { username = dr["USERNAME"].ToString(), useremail = dr["USEREMAIL"].ToString(), useractive = dr["ACTIVE"].ToString() });
                }
            }
            return list;
        }

        #endregion

        public bool IsItOnlyNumbers(string searchString)
        {
            return !String.IsNullOrEmpty(searchString) && searchString.All(char.IsDigit);
        }
    }
}