﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Data;
using System.Data.SqlClient;

namespace FEEDBACK.BL
{
    public class DBConnSql
    { 
        //public static string con = FEEDBACK.Properties.Settings.Default.CON;

    //    public DBConnSql(string cons)
    //    {
    //        if (cons != "")
    //            con = cons;

    //    }

    //    public DataSet ShowData(string SqlProcedure)
    //    {
    //        try
    //        {
    //            using (SqlConnection oSqlConnection = new SqlConnection(con))
    //            {
    //                //string SqlQ = string.Format("exec dbo.GetReportData '{0}'", first);
    //                SqlDataAdapter oSqlDataAdapter = new SqlDataAdapter(SqlProcedure, oSqlConnection);
    //                DataSet dsRecords = new DataSet();
    //                oSqlDataAdapter.Fill(dsRecords);

    //                oSqlDataAdapter.Dispose();

    //                return dsRecords;
    //            }
    //        }
    //        catch (Exception ex)
    //        {
    //            throw ex;
    //        }
    //    }
    //    public DataTable ShowDataDT(string SqlProcedure)
    //    {
    //        try
    //        {
    //            using (SqlConnection oSqlConnection = new SqlConnection(con))
    //            {
    //                //string SqlQ = string.Format("exec dbo.GetReportData '{0}'", first);
    //                SqlDataAdapter oSqlDataAdapter = new SqlDataAdapter(SqlProcedure, oSqlConnection);
    //                DataTable dsRecords = new DataTable();
    //                oSqlDataAdapter.Fill(dsRecords);

    //                oSqlDataAdapter.Dispose();

    //                return dsRecords;
    //            }
    //        }
    //        catch (Exception ex)
    //        {
    //            throw ex;
    //        }
    //    }
    //    public string  UpdateData(string Sql)
    //    {
    //        string OutputMsg = "";          
    //        try
    //        {
    //            using (SqlConnection SqlConn = new SqlConnection(con))
    //            {
    //                //string SqlQ = string.Format("exec dbo.GetReportData '{0}'", first);
    //                SqlDataAdapter oSqlDataAdapter = new SqlDataAdapter(Sql, SqlConn);
    //                DataSet dsRecords = new DataSet();
    //                oSqlDataAdapter.Fill(dsRecords);
    //                oSqlDataAdapter.Dispose();
    //                OutputMsg = "ok";
    //                return OutputMsg;
    //            }
    //        }
    //        catch (Exception ex)
    //        {
    //            OutputMsg = "";
    //            throw ex;
    //        }
    //        finally
    //        {
               
    //        }
           
    //    }
    }
}