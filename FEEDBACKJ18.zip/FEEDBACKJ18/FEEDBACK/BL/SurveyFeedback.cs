﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Linq;
using System.Web;
using FEEDBACK.Models;

namespace FEEDBACK.BL
{
    public class SurveyQuestion
    {
        public int Id { get; set; }
        public string  TemplateId{ get; set; }
        public string User { get; set; }
        public string  Text { get; set; }
        public string  DisplayType { get; set; }
        public string  MultiSelect { get; set; }
        public string  EndOfSurvey { get; set; }
        public string  EndOfSurveyMessage { get; set; }
        public string  ConditionalFilter { get; set; }
        public string  PresentationMode { get; set; }
        public string  IsRequired { get; set; }
        public string  QuestionTags { get; set; }
        public string  Status { get; set; }
        public string  Sequence { get; set; }

    }
    public class SurveyFeedback
    {
        
        public string insertDataTelephony(QuestionEntry mdl, string noq, string sbid)
        {
            QuestionDataAccessLayer MDL = new QuestionDataAccessLayer();
            string txtvalue = "";
            string message = "";
            try
            {
                txtvalue = noq.ToString();
                //allSubBusinessList

            }
            catch
            {
                txtvalue = "";
            }





            if (mdl.SubBusinessId != "" && txtvalue != "")
            {
                string subBusinessID = sbid;
                int NOQ = Convert.ToInt32(txtvalue);
                DataTable DT = new DataTable();
                DataRow DR = null;
                DT.Columns.Add("QuestionText", typeof(string));
                DT.Columns.Add("VDNNo", typeof(string));
                DT.Columns.Add("SubBusinessId", typeof(string));
                DT.Columns.Add("IsActive", typeof(string));
                DT.Columns.Add("CreatedDate", typeof(string));
                DT.Columns.Add("CreatedBy", typeof(string));
                DT.Columns.Add("ModifyDate", typeof(string));
                DT.Columns.Add("ModifyBy", typeof(string));
                //DT.Columns.Add("SurveyId", typeof(string));
                DT.Columns.Add("RangeType", typeof(string));
                for (int i = 0; i <= NOQ; i++)
                {
                    if (i == 0)
                    {
                        mdl.QuestionText0 = mdl.QuestionText0; mdl.RangeType0 = "0"; mdl.VDNNo0 = mdl.VDNNo0;
                    }
                    if (i == 1)
                    {
                        mdl.QuestionText0 = mdl.QuestionText1; mdl.RangeType0 = mdl.RangeType1; mdl.VDNNo0 = mdl.VDNNo1;
                    }
                    if (i == 2)
                    {
                        mdl.QuestionText0 = mdl.QuestionText2; mdl.RangeType0 = mdl.RangeType2; mdl.VDNNo0 = mdl.VDNNo2;
                    }
                    if (i == 3)
                    {
                        mdl.QuestionText0 = mdl.QuestionText3; mdl.RangeType0 = mdl.RangeType3; mdl.VDNNo0 = mdl.VDNNo3;
                    }
                    if (i == 4)
                    {
                        mdl.QuestionText0 = mdl.QuestionText4; mdl.RangeType0 = mdl.RangeType4; mdl.VDNNo0 = mdl.VDNNo4;
                    }
                    if (i == 5)
                    {
                        mdl.QuestionText0 = mdl.QuestionText5; mdl.RangeType0 = mdl.RangeType5; mdl.VDNNo0 = mdl.VDNNo5;
                    }
                    //else
                    //{
                    //    mdl.QuestionText0 = mdl.QuestionText6; mdl.VDNNo0 = mdl.VDNNo6;
                    //}
                    DR = DT.NewRow();
                    DR["QuestionText"] = mdl.QuestionText0;
                    DR["VDNNo"] = mdl.VDNNo0;
                    DR["SubBusinessId"] = subBusinessID;
                    DR["IsActive"] = "1";
                    DR["CreatedDate"] = DateTime.Now;
                    DR["CreatedBy"] = "1";
                    DR["ModifyDate"] = DateTime.Now;
                    DR["ModifyBy"] = "1";
                    DR["RangeType"] = mdl.RangeType0;


                    DT.Rows.Add(DR);
                }
                DR = DT.NewRow();
                DR["QuestionText"] = mdl.QuestionText6;
                DR["VDNNo"] = mdl.VDNNo6;
                DR["SubBusinessId"] = subBusinessID;
                DR["IsActive"] = "1";
                DR["CreatedDate"] = DateTime.Now;
                DR["CreatedBy"] = "1";
                DR["ModifyDate"] = DateTime.Now;
                DR["ModifyBy"] = "1";
                DR["RangeType"] = "0";
                DT.Rows.Add(DR);
                return message = MDL.SaveQuestionsBYSubBusiness(DT);
            }
            return message;
        }

        public string insertDataSMSSurvey(QuestionEntry mdl, string noq, string sbid)
        {
            SurveyQuestion sq = new SurveyQuestion();
            QuestionDataAccessLayer MDL = new QuestionDataAccessLayer();
            string txtvalue = "";
            string message = "";
            try
            {
                txtvalue = noq.ToString();
                //allSubBusinessList

            }
            catch
            {
                txtvalue = "";
            }





            if ( txtvalue != "")
            {
               // string subBusinessID = sbid;
                int NOQ = Convert.ToInt32(txtvalue);
                DataTable DT = new DataTable();
                DataRow DR = null;
                DT.Columns.Add("TemplateId", typeof(string));
                DT.Columns.Add("User", typeof(string));
                DT.Columns.Add("Text", typeof(string));
                DT.Columns.Add("DisplayType", typeof(string));
                DT.Columns.Add("MultiSelect", typeof(string));
                DT.Columns.Add("EndOfSurvey", typeof(string));
                DT.Columns.Add("EndOfSurveyMessage", typeof(string));
                DT.Columns.Add("ConditionalFilter", typeof(string));
                DT.Columns.Add("PresentationMode", typeof(string));
                DT.Columns.Add("IsRequired", typeof(string));
                DT.Columns.Add("QuestionTags", typeof(string));
                DT.Columns.Add("Status", typeof(string));
                DT.Columns.Add("Sequence", typeof(string));
                DT.Columns.Add("SubBusinessId", typeof(string));
                for (int i = 1; i <= NOQ; i++)
                {
                    if (i == 0)
                    {
                        sq.Text = mdl.QuestionText0; sq.DisplayType = "0";
                    }
                    if (i == 1)
                    {
                        sq.Text = mdl.QuestionText1; sq.DisplayType = mdl.RangeType1;
                    }
                    if (i == 2)
                    {
                        sq.Text = mdl.QuestionText2; sq.DisplayType = mdl.RangeType2; 
                    }
                    if (i == 3)
                    {
                        sq.Text = mdl.QuestionText3; sq.DisplayType = mdl.RangeType3; 
                    }
                    if (i == 4)
                    {
                        sq.Text = mdl.QuestionText4; sq.DisplayType = mdl.RangeType4;
                    }
                    if (i == 5)
                    {
                        sq.Text = mdl.QuestionText5; sq.DisplayType = mdl.RangeType5; 
                    }
                    //else
                    //{
                    //    mdl.QuestionText0 = mdl.QuestionText6; mdl.VDNNo0 = mdl.VDNNo6;
                    //}
                    DR = DT.NewRow();
                    DR["TemplateId"] = sq.TemplateId;
                    DR["User"] = sq.User;
                    DR["Text"] = sq.Text;
                    DR["DisplayType"] = sq.DisplayType;
                    DR["MultiSelect"] = "";
                    DR["EndOfSurvey"] = "0";
                    DR["EndOfSurveyMessage"] = mdl.QuestionText6;
                    DR["ConditionalFilter"] = "";
                    DR["PresentationMode"] = "";
                    DR["IsRequired"] = "1";
                    DR["QuestionTags"] = "";
                    DR["Status"] = "A";
                    DR["Sequence"] = "";
                    DR["SubBusinessId"] = sbid;
                    DT.Rows.Add(DR);
                
                }
                return message = MDL.SaveQuestionsBYSMSfeeback(DT, mdl.QuestionText0);
            }
            return message;
        }


    }
}