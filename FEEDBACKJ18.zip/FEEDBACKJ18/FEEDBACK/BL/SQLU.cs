﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Data;
using System.Data.SqlClient;
using System.Web.Mvc;

namespace FEEDBACK
{
    public class SQLU
    {
        public static string con = FEEDBACK.Properties.Settings.Default.CON;

        public SQLU(string cons)
        {
            if (cons != "")
                con = cons; 
          
        }

        public  DataSet GetData(string Proc , SqlParameter[] SP)
        {
            try
            {
               
                using (SqlConnection oSqlConnection = new SqlConnection(con))
                {
                   
                    SqlCommand oSqlCommand = oSqlConnection.CreateCommand();
                    oSqlCommand.CommandType = CommandType.StoredProcedure;
                    oSqlCommand.CommandText = Proc;
                    oSqlCommand.CommandTimeout = 0;
                    foreach (SqlParameter oSqlParameter in SP)
                    {
                        oSqlCommand.Parameters.Add(oSqlParameter);
                    }
                    SqlDataAdapter oSqlDataAdapter = new SqlDataAdapter(oSqlCommand);
                    DataSet dsRecords = new DataSet();
                    oSqlDataAdapter.Fill(dsRecords);
                    oSqlCommand.Dispose();
                    oSqlDataAdapter.Dispose();

                    return dsRecords;
                }
            }
            catch (Exception ex)
            {
                throw ex;
            }
        }

        public  string ExecuteProcOut(string uspProcedure, SqlParameter outparameter, params SqlParameter[] oSqlParameterArr)
        {
            string OutputMsg = "";
            try
            {
               

                using (SqlConnection oSqlConnection = new SqlConnection(con))
                {
                   
                    oSqlConnection.Open();
                    SqlCommand oSqlCommand = oSqlConnection.CreateCommand();
                    oSqlCommand.CommandType = CommandType.StoredProcedure;
                    oSqlCommand.CommandText = uspProcedure;
                    oSqlCommand.CommandTimeout = 0;
                    foreach (SqlParameter oSqlParameter in oSqlParameterArr)
                    {
                        oSqlCommand.Parameters.Add(oSqlParameter);
                    }
                    oSqlCommand.Parameters.Add(outparameter);

                    oSqlCommand.ExecuteNonQuery();
                    OutputMsg = outparameter.Value.ToString();
                }
            }
            catch (Exception ex)
            {
                OutputMsg = "";
              // throw ex;
            }
            finally
            {

            }
            return OutputMsg;
        }
        public string getSubBusinessname(string Sql)
        {
            string OutputMsg = "";
            try
            {
                using (SqlConnection SqlConn = new SqlConnection(con))
                {
                    //string SqlQ = string.Format("exec dbo.GetReportData '{0}'", first);
                    SqlCommand cmd = new SqlCommand(Sql, SqlConn);
                    SqlConn.Open();
                    SqlDataReader dr = cmd.ExecuteReader();
                    if (dr.Read())
                    {
                        OutputMsg = dr[0].ToString();
                    }

                    SqlConn.Close();

                }
                return OutputMsg;
            }
            catch (Exception ex)
            {
                OutputMsg = "";
                throw ex;
            }
            finally
            {
             
            }
        }
        public DataSet ShowData(string SqlProcedure)
        {
            try
            {
                using (SqlConnection oSqlConnection = new SqlConnection(con))
                {
                    //string SqlQ = string.Format("exec dbo.GetReportData '{0}'", first);
                    SqlDataAdapter oSqlDataAdapter = new SqlDataAdapter(SqlProcedure, oSqlConnection);
                    DataSet dsRecords = new DataSet();
                    oSqlDataAdapter.Fill(dsRecords);

                    oSqlDataAdapter.Dispose();

                    return dsRecords;
                }
            }
            catch (Exception ex)
            {
                throw ex;
            }
        }
        public DataTable ShowDataDT(string SqlProcedure)
        {
            try
            {
                using (SqlConnection oSqlConnection = new SqlConnection(con))
                {
                    //string SqlQ = string.Format("exec dbo.GetReportData '{0}'", first);
                    SqlDataAdapter oSqlDataAdapter = new SqlDataAdapter(SqlProcedure, oSqlConnection);
                    DataTable dsRecords = new DataTable();
                    oSqlDataAdapter.Fill(dsRecords);

                    oSqlDataAdapter.Dispose();

                    return dsRecords;
                }
            }
            catch (Exception ex)
            {
                throw ex;
            }
        }
        public string UpdateData(string Sql)
        {
            string OutputMsg = "";
            try
            {
                using (SqlConnection SqlConn = new SqlConnection(con))
                {
                    //string SqlQ = string.Format("exec dbo.GetReportData '{0}'", first);
                    SqlDataAdapter oSqlDataAdapter = new SqlDataAdapter(Sql, SqlConn);
                    DataSet dsRecords = new DataSet();
                    oSqlDataAdapter.Fill(dsRecords);
                    oSqlDataAdapter.Dispose();
                    OutputMsg = "ok";
                    return OutputMsg;
                }
            }
            catch (Exception ex)
            {
                OutputMsg = "";
                throw ex;
            }
            finally
            {

            }

        }
        private static bool IsItOnlyNumbers(string searchString)
        {
            return !String.IsNullOrEmpty(searchString) && searchString.All(char.IsDigit);
        }
        public SelectListItem[] ddlListItem(DataTable DT, string Text, string value)
        {
            int i;// User Type Drop Down
            SelectListItem[] items = new SelectListItem[DT.Rows.Count];
            i = 0;
            foreach (System.Data.DataRow DR in DT.Rows)
            {

                SelectListItem UTitems = new SelectListItem { Text = DR[Text].ToString(), Value = DR[value].ToString() };
                items.SetValue(UTitems, i);
                i++;
            }
            return items;
        }
    }
}
