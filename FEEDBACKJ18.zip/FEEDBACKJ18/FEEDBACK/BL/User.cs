﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;
using System.Data;
using System.ComponentModel.DataAnnotations;
using FEEDBACK.Models;
using System.Data.SqlClient;

namespace FEEDBACK.BL
{
    public class User : AuthorizeAttribute
    {
        public string Userid
        {
            get;
            set;
        }
        [Required(ErrorMessage = "User Name is Required")]
        public string UserName
        {
            get;
            set;
        }

        public string UserEmail
        {
            get;
            set;
        }
        public int UserType
        {
            get;
            set;
        }
        [Required(ErrorMessage = "UserType is Required")]
        public string strUserType
        {
            get;
            set;
        }
        public string userBusiness
        {
            get;
            set;
        }

        public bool validateuser(string userid, string pass)
        {
            bool isAuthenticated = false;

            System.Data.SqlClient.SqlParameter[] sp = new System.Data.SqlClient.SqlParameter[2];
            sp[0] = new System.Data.SqlClient.SqlParameter("@user", SqlDbType.VarChar);
            sp[0].Value = userid;
            sp[1] = new System.Data.SqlClient.SqlParameter("@pass", SqlDbType.VarChar);
            sp[1].Value = pass;
            SQLU S = new SQLU(System.Configuration.ConfigurationManager.AppSettings["CON"]);
            DataSet ds = S.GetData("dbo.usp_getuserdata", sp);
            if (ds != null)
            {
                if (ds.Tables[0].Rows.Count > 0)
                {
                    isAuthenticated = true;
                    Userid = ds.Tables[0].Rows[0]["id"].ToString();
                    UserName = ds.Tables[0].Rows[0]["username"].ToString();
                    UserEmail = ds.Tables[0].Rows[0]["useremail"].ToString();
                    UserType = Convert.ToInt16(ds.Tables[0].Rows[0]["usertype"].ToString());
                    strUserType = GetUserType(ds.Tables[0].Rows[0]["usertype"].ToString());

                }
                if (ds.Tables[1].Rows.Count > 0)
                {
                    userBusiness = ds.Tables[1].Rows[0]["businessname"].ToString();
                }
            }


            return isAuthenticated;

        }

        protected override bool AuthorizeCore(HttpContextBase httpContext)
        {
            if (httpContext.Session == null)
                return false;

            if (httpContext.Session["user"] != null)
                return true;
            else
                return false;
        }

        public string GetUserType(string id)
        {

            System.Data.SqlClient.SqlParameter spout = new System.Data.SqlClient.SqlParameter("@ERROR", SqlDbType.VarChar);
            spout.Direction = ParameterDirection.Output;
            spout.Size = 100;

            System.Data.SqlClient.SqlParameter[] sp = new System.Data.SqlClient.SqlParameter[1];
            sp[0] = new System.Data.SqlClient.SqlParameter("@usertypeID", SqlDbType.VarChar);
            sp[0].Value = id;

            SQLU s = new SQLU("");
            string msg = s.ExecuteProcOut("usp_getusertypebyId", spout, sp);
            //DataSet ds = SQLU.GetData("sp_utom_AddBusiness", sp);



            return msg;

        }

    }

    public class UserDetails
    {
        [Display(Name = "Id")]

        public int userid
        { get; set; }
        [Display(Name = "User Name")]
        [Required(ErrorMessage = "User Name is Required")]
        public string username
        { get; set; }
        [Display(Name = "Login Id")]

        public string userloginid
        { get; set; }
        [Required(ErrorMessage = "Email Id is Required")]
        [Display(Name = "Email")]
        public string useremail
        { get; set; }

        [Display(Name = "Status")]
        public string useractive
        { get; set; }



        [Required(ErrorMessage = "UserType is Required")]
        [Display(Name = "UserType")]
        public string usertype
        { get; set; }



        public int usertypeid
        { get; set; }

        public int BusinessID { get; set; }
        public String BusinessName { get; set; }
        public int SubBusinessID { get; set; }
        //public int UserTypeID { get; set; }
        public List<SubBusiness> sblist { get; set; }
        public List<SubBusiness> allsblist { get; set; }

        public List<UserDetails> GetAlluser(string loginid = null)
        {
            return Getuser(loginid, "1");
        }
        public UserDetails Getuserbyid(string loginid, string userid)
        {
            return Getuser(loginid, userid)[0];
        }

        public List<UserDetails> Getuser(string loginid, string userid)
        {

            List<BL.UserDetails> objL = new List<BL.UserDetails>();
            System.Data.SqlClient.SqlParameter[] sp = new System.Data.SqlClient.SqlParameter[2];
            sp[0] = new System.Data.SqlClient.SqlParameter("@loginid", SqlDbType.VarChar);
            sp[0].Value = loginid;
            sp[1] = new System.Data.SqlClient.SqlParameter("@userid", SqlDbType.Int);
            sp[1].Value = userid;
            SQLU S = new SQLU("");
            DataSet ds = S.GetData("dbo.usp_getalluserdetails", sp);
            if (ds != null)
                if (ds.Tables[0].Rows.Count > 0)
                {
                    DataTable dt = ds.Tables[0];
                    foreach (DataRow dr in dt.Rows)
                    {
                        BL.UserDetails MB = new BL.UserDetails();
                        MB.userid = Convert.ToInt16(dr["id"].ToString());
                        MB.userloginid = dr["userloginid"].ToString();
                        MB.username = dr["username"].ToString();
                        MB.useremail = dr["useremail"].ToString();
                        MB.usertype = dr["usertypeText"].ToString();
                        MB.usertypeid = Convert.ToInt16(dr["usertypeid"].ToString());
                        MB.useractive = dr["active"].ToString();

                        objL.Add(MB);

                    }
                }


            return objL;
        }

        public List<UserDetails> GetSingleUserDetails(string loginid, string userid)
        {

            List<BL.UserDetails> objL = new List<BL.UserDetails>();
            System.Data.SqlClient.SqlParameter[] sp = new System.Data.SqlClient.SqlParameter[2];
            sp[0] = new System.Data.SqlClient.SqlParameter("@loginid", SqlDbType.VarChar);
            sp[0].Value = loginid;
            sp[1] = new System.Data.SqlClient.SqlParameter("@userid", SqlDbType.Int);
            sp[1].Value = userid;
            SQLU S = new SQLU("");
            DataSet ds = S.GetData("dbo.usp_getalluserdetails", sp);
            if (ds != null)
                if (ds.Tables[0].Rows.Count > 0)
                {
                    DataTable dt = ds.Tables[0];
                    foreach (DataRow dr in dt.Rows)
                    {
                        BL.UserDetails MB = new BL.UserDetails();
                        MB.userid = Convert.ToInt16(dr["id"].ToString());
                        MB.userloginid = dr["userloginid"].ToString();
                        MB.username = dr["username"].ToString();
                        MB.useremail = dr["useremail"].ToString();
                        MB.usertype = dr["usertypeText"].ToString();
                        MB.usertypeid = Convert.ToInt16(dr["usertypeid"].ToString());
                        MB.useractive = dr["active"].ToString();
                        MB.sblist = getSubBusinessList(MB.userid.ToString());
                        MB.allsblist = getSBusinessList_byBussinessID(MB.BusinessID.ToString());
                        objL.Add(MB);

                    }
                }


            return objL;
        }
        public UserDetails GetuserbyidWithList(string loginid, string userid)
        {
            return GetuserWithList(loginid, userid)[0];
        }
        // DBConnSql dbsql = new DBConnSql("");
        public List<UserDetails> GetuserWithList(string loginid, string userid)
        {

            List<BL.UserDetails> objL = new List<BL.UserDetails>();
            System.Data.SqlClient.SqlParameter[] sp = new System.Data.SqlClient.SqlParameter[2];
            sp[0] = new System.Data.SqlClient.SqlParameter("@loginid", SqlDbType.VarChar);
            sp[0].Value = loginid;
            sp[1] = new System.Data.SqlClient.SqlParameter("@userid", SqlDbType.Int);
            sp[1].Value = userid;
            SQLU S = new SQLU("");
            DataSet ds = S.GetData("dbo.usp_getalluserdetails", sp);
            if (ds != null)
                if (ds.Tables[0].Rows.Count > 0)
                {
                    DataTable dt = ds.Tables[0];
                    foreach (DataRow dr in dt.Rows)
                    {
                        BL.UserDetails MB = new BL.UserDetails();
                        MB.userid = Convert.ToInt16(dr["id"].ToString());

                        MB.sblist = getSubBusinessList(MB.userid.ToString());
                        objL.Add(MB);

                    }
                }


            return objL;
        }
        public List<SubBusiness> getSubBusinessList(string id)
        {
            DataTable DT = new DataTable();
            DT = dbsql.ShowDataDT("Exec sp_getSBlistbyUserID '" + id + "'");
            //var subBusinessitems = new SelectListItem[DT.Rows.Count];
            List<SubBusiness> list = new List<SubBusiness>();
            if (DT.Rows.Count > 0)
            {
                //list = new List<SubBusiness>();
                foreach (System.Data.DataRow dr in DT.Rows)
                {
                    list.Add(new SubBusiness() { SubBusinessName = dr["subbusinessname"].ToString(), SubBusinessId = dr["SubBusinessID"].ToString(), Checked = dr["Checked"].ToString() });
                }
            }
            return list;

        }
        SQLU dbsql = new SQLU("");
        public List<SubBusiness> getSBusinessList_byBussinessID(string businessid)
        {
            DataTable DT = new DataTable();
            DT = dbsql.ShowDataDT("Exec sp_utom_SelectSubBusiness '" + businessid + "'");
            //var subBusinessitems = new SelectListItem[DT.Rows.Count];
            List<SubBusiness> list1 = null;
            if (DT.Rows.Count > 0)
            {
                list1 = new List<SubBusiness>();
                foreach (System.Data.DataRow dr in DT.Rows)
                {
                    list1.Add(new SubBusiness() { SubBusinessName = dr["subbusinessname"].ToString(), SubBusinessId = dr["id"].ToString() });
                }
            }
            return list1;

        }
        public DataTable ReturnTable(string ActionType)
        {
            DataTable DT;
            System.Data.SqlClient.SqlParameter[] sp = new System.Data.SqlClient.SqlParameter[0];
            SQLU s = new SQLU(System.Configuration.ConfigurationManager.AppSettings["CON"]);
            DataSet DS = new DataSet();
            DS = s.GetData("sp_utom_SelectUserType", sp);
            DT = DS.Tables[0];
            return DT;
        }

        public string Saveuser(UserDetails uDetails, string loginid)
        {


            System.Data.SqlClient.SqlParameter spout = new System.Data.SqlClient.SqlParameter("@ERROR", SqlDbType.VarChar);
            spout.Direction = ParameterDirection.Output;
            spout.Size = 100;

            System.Data.SqlClient.SqlParameter[] sp = new System.Data.SqlClient.SqlParameter[6];
            sp[0] = new System.Data.SqlClient.SqlParameter("@userName", SqlDbType.VarChar);
            sp[0].Value = uDetails.username;
            sp[1] = new System.Data.SqlClient.SqlParameter("@useremail", SqlDbType.VarChar);
            sp[1].Value = uDetails.useremail;
            sp[2] = new System.Data.SqlClient.SqlParameter("@useractive", SqlDbType.VarChar);
            sp[2].Value = uDetails.useractive;
            sp[3] = new System.Data.SqlClient.SqlParameter("@userId", SqlDbType.Int);
            sp[3].Value = uDetails.userid;
            //sp[4] = new System.Data.SqlClient.SqlParameter("@userloginid", SqlDbType.VarChar);
            //sp[4].Value = uDetails.userloginid;
            sp[4] = new System.Data.SqlClient.SqlParameter("@updatedby", SqlDbType.VarChar);
            sp[4].Value = loginid;
            sp[5] = new System.Data.SqlClient.SqlParameter("@usertype", SqlDbType.VarChar);
            sp[5].Value = uDetails.usertype;
            SQLU s = new SQLU("");
            string msg = s.ExecuteProcOut("usp_updateuser", spout, sp);
            //DataSet ds = SQLU.GetData("sp_utom_AddBusiness", sp);

            return msg;
        }
        public string SaveUserSubBusinessMapping(DataTable DT)
        {


            System.Data.SqlClient.SqlParameter spout = new System.Data.SqlClient.SqlParameter("@ERROR", SqlDbType.VarChar);
            spout.Direction = ParameterDirection.Output;
            spout.Size = 100;

            System.Data.SqlClient.SqlParameter[] sp = new System.Data.SqlClient.SqlParameter[1];
            sp[0] = new System.Data.SqlClient.SqlParameter("@UT_UserSbMap", DT);
       
            SQLU s = new SQLU("");
            string msg = s.ExecuteProcOut("sp_userSBusinessMapping", spout, sp);
            //DataSet ds = SQLU.GetData("sp_utom_AddBusiness", sp);

            return msg;
        }

        public string DeleteUserSubBusinessMapping(string UserId, string loginid)
        {


            System.Data.SqlClient.SqlParameter spout = new System.Data.SqlClient.SqlParameter("@ERROR", SqlDbType.VarChar);
            spout.Direction = ParameterDirection.Output;
            spout.Size = 100;

            System.Data.SqlClient.SqlParameter[] sp = new System.Data.SqlClient.SqlParameter[2];
            sp[0] = new System.Data.SqlClient.SqlParameter("@UserId", SqlDbType.VarChar);
            sp[0].Value = UserId;
            sp[1] = new System.Data.SqlClient.SqlParameter("@SubBusiID", SqlDbType.VarChar);
            sp[1].Value = loginid;



            SQLU s = new SQLU("");
            string msg = s.ExecuteProcOut("sp_DELETEuserSBusinessMapping", spout, sp);
            //DataSet ds = SQLU.GetData("sp_utom_AddBusiness", sp);

            return msg;
        }
        public SelectListItem[] getListItems(string ValueColumn, string TextColumn, string PurposeName)
        {
            int i = 0;
            DataTable DT = ReturnTable(PurposeName);
            SelectListItem[] getListItem = new SelectListItem[DT.Rows.Count];
            i = 0;
            foreach (System.Data.DataRow DR in DT.Rows)
            {
                SelectListItem UTitems = new SelectListItem { Text = DR[TextColumn].ToString(), Value = DR[ValueColumn].ToString() };
                getListItem.SetValue(UTitems, i);
                i++;
            }
            return getListItem;
        }


    }

    public class CheckboxModel
    {
        public int Value { get; set; }
        public string Text { get; set; }
        public bool IsChecked { get; set; }
    }
    public class CheckBoxList
    {
        public List<CheckboxModel> CheckBoxItems { get; set; }
    }
    #region UserFeedBack


    public class Question
    {
        public int Id { get; set; }
        public string OptionType { get; set; }
        public string QuestionText { get; set; }
        public string VDNNo { get; set; }
        public string SubBusinessId { get; set; }
        public string BusinessName { get; set; }
        public string SubBusinessName { get; set; }
        public string IsActive { get; set; }
        public DateTime CreatedDate { get; set; }
        public string CreatedBy { get; set; }
        public DateTime ModifyDate { get; set; }
        public string ModifyBy { get; set; }
        public List<UserDetails> userlist { get; set; }
        public List<SubBusiness> SubBusinesslist { get; set; }

    }



    public class QuestionEntry
    {
        [Display(Name ="QuestionText")]
        public string QuestionText0 { get; set; }
        public string QuestionText1 { get; set; }
        public string QuestionText2 { get; set; }
        public string QuestionText3 { get; set; }
        public string QuestionText4 { get; set; }
        public string QuestionText5 { get; set; }
        public string QuestionText6 { get; set; }
        [Display(Name ="VDNNumber")]
        public string VDNNo0 { get; set; }
        public string VDNNo1 { get; set; }
        public string VDNNo2 { get; set; }
        public string VDNNo3 { get; set; }
        public string VDNNo4 { get; set; }
        public string VDNNo5 { get; set; }
        public string VDNNo6 { get; set; }
        public string RangeType0 { get; set; }
        public string RangeType1 { get; set; }
        public string RangeType2 { get; set; }
        public string RangeType3 { get; set; }
        public string RangeType4 { get; set; }
        public string RangeType5 { get; set; }
        public string SubBusinessId { get; set; }
        public string IsActive { get; set; }
        public DateTime CreatedDate { get; set; }
        public DateTime CreatedBy { get; set; }
        public DateTime ModifyDate { get; set; }
        public DateTime ModifyBy { get; set; }
        public List<QuestionEntry> GetQuesVDNOptionType(string ID)
        {
            List<QuestionEntry> objL = new List<QuestionEntry>();
            System.Data.SqlClient.SqlParameter[] sp = new System.Data.SqlClient.SqlParameter[1];
            sp[0] = new System.Data.SqlClient.SqlParameter("@SurveyId", SqlDbType.VarChar);
            sp[0].Value = ID;
            SQLU S = new SQLU("");
            DataSet ds = S.GetData("sp_SelectQuesVDNRangeTypeBySurveyId", sp);
            if (ds != null)
                if (ds.Tables[0].Rows.Count > 0)
                {
                    DataTable dt = ds.Tables[0];
                    foreach (DataRow dr in dt.Rows)
                    {
                        QuestionEntry MB = new QuestionEntry();

                     
                            MB.SubBusinessId = dr["id"].ToString();
                            MB.QuestionText0 = dr["QuestionText"].ToString();
                            MB.VDNNo0 = dr["VDNNo"].ToString();
                            MB.RangeType0 = dr["RangeType"].ToString();
                            objL.Add(MB);
                   

                    }
                }

            return objL;
        }
        

    }

 
    public class QuestionDataAccessLayer

    {
        string StoredProc = "sp_QuestionCRUD";
        SqlConnection con = new SqlConnection(SQLU.con);
        public string InsertData(Question obj)
        {


            string result = "";
            try
            {
                //ID , UserName , BusinessID , IsActive , ExtensionID
                con.Close();
                SqlCommand cmd = new SqlCommand(StoredProc, con);
                cmd.CommandType = CommandType.StoredProcedure;
                //cmd.Parameters.AddWithValue("@ID", obj.ID);  
                cmd.Parameters.AddWithValue("@Id", null);
                cmd.Parameters.AddWithValue("@QuestionText", obj.QuestionText);
                cmd.Parameters.AddWithValue("@VDNNo", obj.VDNNo);
                cmd.Parameters.AddWithValue("@subbusinessid", obj.SubBusinessId);
                cmd.Parameters.AddWithValue("@isactive", "1");
          
                cmd.Parameters.AddWithValue("@createdby", obj.CreatedBy);
 
                cmd.Parameters.AddWithValue("@modifyby", obj.ModifyBy);
                cmd.Parameters.AddWithValue("@SurveyId", obj.ModifyBy);
                cmd.Parameters.AddWithValue("@RangeType", obj.ModifyBy);
                cmd.Parameters.AddWithValue("@Query", 1);

                con.Open();
                result = cmd.ExecuteScalar().ToString();
                return result;
            }
            catch (Exception ex)
            {
                return result = ex.ToString();
            }
            finally
            {
                con.Close();
            }
        }

        public string InsertDataCheckExistance(Question obj)
        {


            string result = "";
            try
            {
                //ID , UserName , BusinessID , IsActive , ExtensionID
                con.Close();
                SqlCommand cmd = new SqlCommand("sp_ITUserCheckExistance", con);
                cmd.CommandType = CommandType.StoredProcedure;
                //cmd.Parameters.AddWithValue("@ID", obj.ID);  
                cmd.Parameters.AddWithValue("@Id", obj.Id);
                cmd.Parameters.AddWithValue("@QuestionText", obj.QuestionText);
                cmd.Parameters.AddWithValue("@VDNNo", obj.VDNNo);
                cmd.Parameters.AddWithValue("@subbusinessid",null);
                cmd.Parameters.AddWithValue("@isactive", null);
  
                cmd.Parameters.AddWithValue("@createdby",null);
 
                cmd.Parameters.AddWithValue("@modifyby", null);

                //cmd.Parameters.AddWithValue("@Query", 1);

                con.Open();
                result = cmd.ExecuteScalar().ToString();
                return result;
            }
            catch (Exception ex)
            {
                return result = ex.ToString();
            }
            finally
            {
                con.Close();
            }
        }


        public string UpdateData(Question obj)
        {

            string result = "";
            try
            {
                //ID , UserName , BusinessID , IsActive , ExtensionID
                SqlCommand cmd = new SqlCommand(StoredProc, con);
                cmd.CommandType = CommandType.StoredProcedure;
                cmd.Parameters.AddWithValue("@Id", obj.Id);
                cmd.Parameters.AddWithValue("@QuestionText", obj.QuestionText);
                cmd.Parameters.AddWithValue("@VDNNo", obj.VDNNo);
                cmd.Parameters.AddWithValue("@subbusinessid", obj.SubBusinessId);
                cmd.Parameters.AddWithValue("@isactive", "1");

                cmd.Parameters.AddWithValue("@createdby", obj.CreatedBy);

                cmd.Parameters.AddWithValue("@modifyby", obj.ModifyBy);


                cmd.Parameters.AddWithValue("@Query", 2);
                con.Open();
                result = cmd.ExecuteScalar().ToString();
                return result;
            }
            catch (Exception ex)
            {
                return result = ex.ToString();
            }
            finally
            {
                con.Close();
            }
        }

        public string SaveQuestionsBYSubBusiness(DataTable DT)
        {


            System.Data.SqlClient.SqlParameter spout = new System.Data.SqlClient.SqlParameter("@ERROR", SqlDbType.VarChar);
            spout.Direction = ParameterDirection.Output;
            spout.Size = 100;

            System.Data.SqlClient.SqlParameter[] sp = new System.Data.SqlClient.SqlParameter[1];
            sp[0] = new System.Data.SqlClient.SqlParameter("@UDTT_Questionnaire", DT);
            //sp[0].Value = DT;
            //sp[1] = new System.Data.SqlClient.SqlParameter("@SubBusiID", SqlDbType.VarChar);
            //sp[1].Value = SubBusiID;
            //sp[2] = new System.Data.SqlClient.SqlParameter("@CreatedBy", SqlDbType.Int);
            //sp[2].Value = loginid;


            SQLU s = new SQLU("");
            string msg = s.ExecuteProcOut("sp_UDDTQuestionnaire", spout, sp);
            //DataSet ds = SQLU.GetData("sp_UTOM_AddBusiness", sp);

            return msg;
        }

        public string SaveQuestionsBYSMSfeeback(DataTable DT,string Text)
        {


            System.Data.SqlClient.SqlParameter spout = new System.Data.SqlClient.SqlParameter("@ERROR", SqlDbType.VarChar);
            spout.Direction = ParameterDirection.Output;
            spout.Size = 100;

            System.Data.SqlClient.SqlParameter[] sp = new System.Data.SqlClient.SqlParameter[2];
            sp[0] = new System.Data.SqlClient.SqlParameter("@UDTT_SMSFeedback", DT);

            //sp[0].Value = DT;
            sp[1] = new System.Data.SqlClient.SqlParameter("@Welcome", SqlDbType.VarChar);
            sp[1].Value = Text;
            //sp[2] = new System.Data.SqlClient.SqlParameter("@CreatedBy", SqlDbType.Int);
            //sp[2].Value = loginid;


            SQLU s = new SQLU("");
            string msg = s.ExecuteProcOut("sp_UDDTSMSFeedBack", spout, sp);
            //DataSet ds = SQLU.GetData("sp_UTOM_AddBusiness", sp);

            return msg;
        }

        public List<Question> Selectalldata()
        {

            DataSet ds = null;
            List<Question> custlist = null;
            try
            {
                //ID , UserName , BusinessID , IsActive , ExtensionID
                SqlCommand cmd = new SqlCommand(StoredProc, con);
                cmd.CommandType = CommandType.StoredProcedure;
                cmd.Parameters.AddWithValue("@Id", null);
                //cmd.Parameters.AddWithValue("@QuestionText", null);
                //cmd.Parameters.AddWithValue("@VDNNo", null);
                cmd.Parameters.AddWithValue("@subbusinessid", null);
                cmd.Parameters.AddWithValue("@businessname", null);
                cmd.Parameters.AddWithValue("@isactive", null);
                cmd.Parameters.AddWithValue("@SurveyId", null);
                //cmd.Parameters.AddWithValue("@createdby", null);

                cmd.Parameters.AddWithValue("@modifyby", null);

                cmd.Parameters.AddWithValue("@Query", 6);
                con.Open();
                SqlDataAdapter da = new SqlDataAdapter();
                da.SelectCommand = cmd;
                ds = new DataSet();
                da.Fill(ds);
                custlist = new List<Question>();
                for (int i = 0; i < ds.Tables[0].Rows.Count; i++)
                {
                    Question cobj = new Question();
                    cobj.SubBusinessName = ds.Tables[0].Rows[i]["SubBusinessName"].ToString();
                    cobj.BusinessName = ds.Tables[0].Rows[i]["BusinessName"].ToString();
                    custlist.Add(cobj);
                }
                return custlist;
            }
            catch (Exception ex)
            {
                string exp = ex.ToString();
                return custlist;
            }
            finally
            {
                con.Close();
            }
        }
        public Question SelectDatabyID(string SurveyId)
        {
            SqlConnection con = new SqlConnection(SQLU.con);
            DataSet ds = null;
            Question cobj = null;
            try
            {
                //ID , UserName , BusinessID , IsActive , ExtensionID
                SqlCommand cmd = new SqlCommand(StoredProc, con);
                cmd.CommandType = CommandType.StoredProcedure;
                cmd.Parameters.AddWithValue("@SurveyId", SurveyId);

                cmd.Parameters.AddWithValue("@Query", 5);
                SqlDataAdapter da = new SqlDataAdapter();
                da.SelectCommand = cmd;
                ds = new DataSet();
                da.Fill(ds);
                for (int i = 0; i < ds.Tables[0].Rows.Count; i++)
                {
                    cobj = new Question();
                    cobj.QuestionText = ds.Tables[0].Rows[i]["QuestionText"].ToString();
                    cobj.VDNNo = ds.Tables[0].Rows[i]["VDNNo"].ToString();


                }
                return cobj;
            }
            catch
            {
                return cobj;
            }
            finally
            {
                con.Close();
            }
        }


    }
    #endregion
    #region Survey
    public class Survey
    {
        public int Id { get; set; }
        public string BusinessName { get; set; }
        public string SubBusinessName { get; set; }
        public string SurveyId { get; set; }
        public string SurveyType { get; set; }

    }
    public class SurveySMS
    {
        public int Id { get; set; }
        public string Text { get; set; }
        public string DisplayType { get; set; }
        public string WelcomeText { get; set; }
        public string EndOfSurveyMessage { get; set; }
        public List<SurveySMS> GetQuesVDNOptionTypeSMS(string ID)
        {
            List<SurveySMS> objL = new List<SurveySMS>();
            System.Data.SqlClient.SqlParameter[] sp = new System.Data.SqlClient.SqlParameter[1];
            sp[0] = new System.Data.SqlClient.SqlParameter("@SurveyId", SqlDbType.VarChar);
            sp[0].Value = ID;
            SQLU S = new SQLU("");
            DataSet ds = S.GetData("sp_SelectQuesVDNRangeTypeBySurveyIdSMS", sp);
            if (ds != null)
                if (ds.Tables[0].Rows.Count > 0)
                {
                    DataTable dt = ds.Tables[0];
                    foreach (DataRow dr in dt.Rows)
                    {
                        SurveySMS MB = new SurveySMS();


                        MB.Id = Convert.ToInt32(dr["id"].ToString());
                        MB.Text = dr["Text"].ToString();
                        MB.DisplayType = dr["DisplayType"].ToString();
                        MB.WelcomeText = dr["WelcomeText"].ToString();
                        MB.EndOfSurveyMessage = dr["EndOfSurveyMessage"].ToString();
                        objL.Add(MB);


                    }
                }

            return objL;
        }
    }

    public class FeedbackOption
    {
        public int Id { get; set; }
        public string RangeName { get; set; }
 

    }
    public class SurveyDataAccessLayer

    {
        string StoredProc = "sp_SurveyCRUD";
        SqlConnection con = new SqlConnection(SQLU.con);
        public string InsertData(Question obj)
        {


            string result = "";
            try
            {
                //ID , UserName , BusinessID , IsActive , ExtensionID
                con.Close();
                SqlCommand cmd = new SqlCommand(StoredProc, con);
                cmd.CommandType = CommandType.StoredProcedure;
                //cmd.Parameters.AddWithValue("@ID", obj.ID);  
                cmd.Parameters.AddWithValue("@Id", null);
                cmd.Parameters.AddWithValue("@BusinessName", obj.BusinessName);
                cmd.Parameters.AddWithValue("@SubBusinessName", obj.SubBusinessName);
                cmd.Parameters.AddWithValue("@SurveyId", obj);
                cmd.Parameters.AddWithValue("@Query", 1);

                con.Open();
                result = cmd.ExecuteScalar().ToString();
                return result;
            }
            catch (Exception ex)
            {
                return result = ex.ToString();
            }
            finally
            {
                con.Close();
            }
        }

        public string InsertDataCheckExistance(Question obj)
        {


            string result = "";
            try
            {
                //ID , UserName , BusinessID , IsActive , ExtensionID
                con.Close();
                SqlCommand cmd = new SqlCommand("sp_ITUserCheckExistance", con);
                cmd.CommandType = CommandType.StoredProcedure;
                //cmd.Parameters.AddWithValue("@ID", obj.ID);  
                cmd.Parameters.AddWithValue("@Id", obj.Id);
                cmd.Parameters.AddWithValue("@QuestionText", obj.QuestionText);
                cmd.Parameters.AddWithValue("@VDNNo", obj.VDNNo);
                cmd.Parameters.AddWithValue("@subbusinessid", null);
                cmd.Parameters.AddWithValue("@isactive", null);

                cmd.Parameters.AddWithValue("@createdby", null);

                cmd.Parameters.AddWithValue("@modifyby", null);

                //cmd.Parameters.AddWithValue("@Query", 1);

                con.Open();
                result = cmd.ExecuteScalar().ToString();
                return result;
            }
            catch (Exception ex)
            {
                return result = ex.ToString();
            }
            finally
            {
                con.Close();
            }
        }


        public string UpdateData(Survey obj)
        {

            string result = "";
            try
            {
                //ID , UserName , BusinessID , IsActive , ExtensionID
                SqlCommand cmd = new SqlCommand(StoredProc, con);
                cmd.CommandType = CommandType.StoredProcedure;
                cmd.Parameters.AddWithValue("@Id", obj.Id);
                cmd.Parameters.AddWithValue("@BusinessName", obj.BusinessName);
                cmd.Parameters.AddWithValue("@SubBusinessName", obj.SubBusinessName);
                cmd.Parameters.AddWithValue("@SurveyId", obj.SurveyId);
                
                cmd.Parameters.AddWithValue("@Query", 2);
                con.Open();
                result = cmd.ExecuteScalar().ToString();
                return result;
            }
            catch (Exception ex)
            {
                return result = ex.ToString();
            }
            finally
            {
                con.Close();
            }
        }

        
        public List<Survey> SelectalldataTelephony()
        {

            DataSet ds = null;
            List<Survey> custlist = null;
            try
            {
                SqlCommand cmd = new SqlCommand("sp_GetAllSurveyDetailsTelephony", con);
                cmd.CommandType = CommandType.StoredProcedure;
                //cmd.Parameters.AddWithValue("@Id", null);
                //cmd.Parameters.AddWithValue("@BusinessName", null);
                //cmd.Parameters.AddWithValue("@SubBusinessName", null);
                //cmd.Parameters.AddWithValue("@SurveyId", null);
                //cmd.Parameters.AddWithValue("@Query", 6);
                con.Open();
                SqlDataAdapter da = new SqlDataAdapter();
                da.SelectCommand = cmd;
                ds = new DataSet();
                da.Fill(ds);
                custlist = new List<Survey>();
                for (int i = 0; i < ds.Tables[0].Rows.Count; i++)
                {
                    Survey cobj = new Survey();
                  
                    cobj.SubBusinessName = ds.Tables[0].Rows[i]["SubBusinessName"].ToString();
                    cobj.BusinessName = ds.Tables[0].Rows[i]["BusinessName"].ToString();
                    cobj.SurveyId = ds.Tables[0].Rows[i]["SurveyId"].ToString();
                    cobj.SurveyType = ds.Tables[0].Rows[i]["SurveyType"].ToString();
                    custlist.Add(cobj);
                }
                return custlist;
            }
            catch (Exception ex)
            {
                string exp = ex.ToString();
                return custlist;
            }
            finally
            {
                con.Close();
            }
        }
        public List<Survey> SelectalldataSMS()
        {

            DataSet ds = null;
            List<Survey> custlist = null;
            try
            {
                SqlCommand cmd = new SqlCommand("sp_GetAllSurveyDetailsSMS", con);
                cmd.CommandType = CommandType.StoredProcedure;
                //cmd.Parameters.AddWithValue("@Id", null);
                //cmd.Parameters.AddWithValue("@BusinessName", null);
                //cmd.Parameters.AddWithValue("@SubBusinessName", null);
                //cmd.Parameters.AddWithValue("@SurveyId", null);
                //cmd.Parameters.AddWithValue("@Query", 6);
                con.Open();
                SqlDataAdapter da = new SqlDataAdapter();
                da.SelectCommand = cmd;
                ds = new DataSet();
                da.Fill(ds);
                custlist = new List<Survey>();
                for (int i = 0; i < ds.Tables[0].Rows.Count; i++)
                {
                    Survey cobj = new Survey();

                    cobj.SubBusinessName = ds.Tables[0].Rows[i]["SubBusinessName"].ToString();
                    cobj.BusinessName = ds.Tables[0].Rows[i]["BusinessName"].ToString();
                    cobj.SurveyId = ds.Tables[0].Rows[i]["SurveyId"].ToString();
                    cobj.SurveyType = ds.Tables[0].Rows[i]["SurveyType"].ToString();
                    custlist.Add(cobj);
                }
                return custlist;
            }
            catch (Exception ex)
            {
                string exp = ex.ToString();
                return custlist;
            }
            finally
            {
                con.Close();
            }
        }
        //public Survey SelectDatabyID(string SurveyId)
        //{
        //    SqlConnection con = new SqlConnection(SQLU.con);
        //    DataSet ds = null;
        //    Survey cobj = null;
        //    try
        //    {
        //        //ID , UserName , BusinessID , IsActive , ExtensionID
        //        SqlCommand cmd = new SqlCommand(StoredProc, con);
        //        cmd.CommandType = CommandType.StoredProcedure;
        //        cmd.Parameters.AddWithValue("@SurveyId", SurveyId);

        //        cmd.Parameters.AddWithValue("@Query", 5);
        //        SqlDataAdapter da = new SqlDataAdapter();
        //        da.SelectCommand = cmd;
        //        ds = new DataSet();
        //        da.Fill(ds);
        //        for (int i = 0; i < ds.Tables[0].Rows.Count; i++)
        //        {
        //            cobj = new Survey();

        //            cobj.BusinessName = ds.Tables[0].Rows[i]["SubBusinessId"].ToString();
        //            cobj.SubBusinessName = ds.Tables[0].Rows[i]["SubBusinessName"].ToString();



        //        }
        //        return cobj;
        //    }
        //    catch
        //    {
        //        return cobj;
        //    }
        //    finally
        //    {
        //        con.Close();
        //    }
        //}


    }
    #endregion
}