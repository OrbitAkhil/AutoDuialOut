
/* Copyright (C) 2004 Avaya Inc.  All rights reserved.*/

#ifndef DRVRDEFS_H
#define DRVRDEFS_H

#include "tsplatfm.h"
#include "asn1code.h"
#include "ctidrvrdefs.h"

#define          TSRV_DRIVEROAM_REQ 1
#define          TSRV_DRIVEROAM_CONF 2
#define          TSRV_DRIVEROAM 3


#endif
