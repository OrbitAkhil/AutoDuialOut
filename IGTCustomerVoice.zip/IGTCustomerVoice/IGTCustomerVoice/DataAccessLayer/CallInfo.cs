﻿using IGTCustomerVoice.DataAccessLayer;
using System;
using System.Collections.Generic;
using System.Data;
using System.Linq;
using System.Threading.Tasks;
using System.Web;

namespace IGTCustomerVoice.DataAccessLayer
{
    public class CallInfo : ICrud<ICommand>
    {
        public bool Insert(ICommand obj)
        {
            return obj.Execute();
        }

        public async Task<bool> UpdateAsync(ICommand obj)
        {
            return await obj.ExecuteAsync();
        }

        public bool Update(ICommand obj)
        {
            return obj.Execute();
        }

        public bool Delete(ICommand obj)
        {
            return obj.Execute();
        }

        public async Task<DataSet> SelectAsync(ICommand obj)
        {
            return await obj.SelectDataAsync();
        }

        public  DataSet Select(ICommand obj)
        {
            return obj.SelectData();
        }

        public object GetScalerRecord(ICommand obj)
        {
            return obj.GetScalerRecord();
        }
    }
}