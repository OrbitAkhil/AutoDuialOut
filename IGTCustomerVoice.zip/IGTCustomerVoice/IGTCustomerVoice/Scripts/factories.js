﻿'use strict';
//</editor-fold>

//<editor-fold desc="API Interface">
angular.module('igtApp').factory('igtService', ['$rootScope', 'Restangular', '$http', '$q', '$location', 'DSCacheFactory',
    function ($rootScope, Restangular, $http, $q, $location, DSCacheFactory) {

        var apiURL = "/api/";

        apiURL = 'http://localhost:60983/'; //for local json-server

        Restangular.setBaseUrl(apiURL);
        $rootScope.apiURL = apiURL;

        Restangular.setRequestInterceptor(function (elem, operation) {
            NProgress.start();
            return elem;
        });

        Restangular.setResponseExtractor(function (response, operation) {
            NProgress.done();
            return response;
        });

        Restangular.setErrorInterceptor(function (response, operation) {
            NProgress.done();
            return true;
        });

        var igtcache = DSCacheFactory('igtCrate', {
            storageMode: 'sessionStorage', // this cache will sync itself to localStorage
            verifyIntegrity: false
        });
     
        var resetState = function () {
            $rootScope.user = null;
            $rootScope.role = null;
            $rootScope.managedBy = null;
            $rootScope.brandName = null;
            $rootScope.logoURL = null;
            Restangular.setDefaultHeaders({
                Authorization: undefined
            });
            igtcache.removeAll();
        };
        var getRequest = function (url) {
            var dfd = $q.defer();
            Restangular.one(url).get().then(function (response) {
                dfd.resolve(response);
            }, function (response) {
                if (response != undefined) {
                    if (response.status == 401) {
                        igtcache.removeAll();
                        $location.path('/login').replace();
                    } else
                        dfd.resolve(response);
                } else
                    dfd.reject();
            });
            return dfd.promise;
        };
        var postRequest = function (url, data) {
            var dfd = $q.defer();
            Restangular.all(url).post(data).then(function (response) {
                dfd.resolve(response);
            }, function (response) {
                if (response != undefined) {
                    if (response.status == 401) {
                        igtcache.removeAll();
                        $location.path('/login').replace();
                    } else
                        dfd.resolve(response);
                } else
                    dfd.reject();
            });
            return dfd.promise;
        };

        // Return the service
        return {
            resetState: function () { //clear state
                resetState();
            },
            getRequest: function (url) {
                return getRequest(url);
            },
            postRequest: function (url, data) {
                return postRequest(url, data);
            },
            get: function () {
                return UserModel;
            },
            cache: function () {
                return igtcache;
            },
            getSurveyByToken: function (token) {
                var url = "/api/survey/" + token;
                //var url = "settings.json";
                // local json server
                // url = '';

                return getRequest(url);

            },
            postSurveyByToken: function (token, response) {
                var url = "api/SurveyByToken/" + token;
                return postRequest(url, response);
            },
            postPartialResponse: function (partialid, response, complete) {
                var url = "api/PartialSurvey/" + partialid + "/" + complete;
                return postRequest(url, response);
            }
        };

    }
]);
//</editor-fold>

