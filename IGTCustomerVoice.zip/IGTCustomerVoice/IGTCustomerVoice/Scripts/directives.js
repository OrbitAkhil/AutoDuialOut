﻿'use strict';
angular
.module('igtControllers').directive('ngEnter', function () {
    return function (scope, element, attrs) {
        element.bind("keydown keypress", function (event) {
            if (event.which === 13) {
                scope.$apply(function () {
                    scope.$eval(attrs.ngEnter);
                });

                event.preventDefault();
            }
        });
    };
})
.directive("scale", function () {
    function link(scope, element, attr) {
        var questionTags = scope.question.questionTags.join(",").toLowerCase().split(",");
        var parentWidth = element.parent().parent().prop('scrollWidth');

        if (scope.question.presentationMode == "Random")
            scope.question.presentationMode = [null, "Invert"][Math.floor(Math.random() * 2)];
        if (scope.question.presentationMode == "Invert" && !(/[\u0600-\u06FF]/.test(scope.question.text)))
            element.addClass("pull-right");
        else if (scope.question.presentationMode != "Invert" && (/[\u0600-\u06FF]/.test(scope.question.text)))
            element.addClass("pull-right");
        var arr = [];
        var upp = scope.question.multiSelect[0].split('-')[1].split(";")[0];
        var low = scope.question.multiSelect[0].split('-')[0].split(";")[0];
        var difference = ((upp - low) + 1) > 11 ? ((upp - low) + 1) : 11;
        var increment = difference > 11 ? ((difference / 2) > 11 ? ((difference / 5) > 11 ? 10 : 5) : 2) : 1;
        if (scope.question.questionTags == null || scope.question.questionTags == undefined)
            scope.question.questionTags = [];
        for (var i = parseInt(low) ; i <= parseInt(upp) ; i += increment)
            arr.push(i);
        

        var upp = scope.question.multiSelect[0].split('-')[1];
        var low = scope.question.multiSelect[0].split('-')[0];
        var width;

        if (scope.question.presentationMode != "Vertical") {
            width = parseInt(parentWidth / 11);
            if (width < 41 && arr.length <= 7) {
                width = 41;
            }
        }
        else if (scope.question.presentationMode == "Vertical") {
            var width = parseInt(parentWidth / arr.length);
            element.css({
                "display": "block",
                "margin": "auto",
                "padding": "0px"
            });
        }

        if (scope.question.presentationMode == "Invert" && !(/[\u0600-\u06FF]/.test(scope.question.text)) && scope.isGroup) {
            element.parent().css('width', width * arr.length);
        } else if (scope.question.presentationMode !== "Invert" && (/[\u0600-\u06FF]/.test(scope.question.text)) && scope.isGroup) {
            element.parent().css('width', '100%');
        } else if (!scope.isGroup) {
            element.parent().css('width', width * arr.length);
            element.parent().css('margin', 'auto');
        } else if (scope.isGroup) {
            element.parent().css('width', width * arr.length);
        }

        var margin = parentWidth - (width * arr.length);
        element[0].style.width = width + 'px';
        element.css('height', width + 'px');
        element.css('max-width', width + 'px');
        element.css('min-width', width + 'px');
        element.css('padding-top', (width - 20) / 2 + 'px');
        element.css('position', 'relative');
        element.css('margin-top', 12 +'px');
        var currentModel = !scope.ngModel && scope.ngModel !== 0 ? scope.ngModel : scope.ngModel - parseInt(low.match(/\d+/)[0]);

        if ((questionTags.indexOf('npsplain') == -1 && questionTags.indexOf('nps') != -1) || questionTags.indexOf('c rating') != -1) {
            var npsColors = ['#bf0000', '#cc0a1e', '#db1d2b', '#ec1c24', '#ee4036', '#ea5932', '#00ff00', '#32cd32', '#228b22', '#008000', '#006400'];
            var colors;
            if (questionTags.indexOf('c rating') != -1) {
                colors = npsColors.slice(11 - arr.length, 11);
            } else {
                colors = npsColors;
            }
            if (scope.index != currentModel)
                element.css('background-color', colors[scope.index]);
            else
                element.css('background-color', '#8B8B8B');

            element.css('color', '#FFFFFF');

            element.click(function () {
                element.css('background-color', '#8B8B8B');
                element.parent().find('.scale').each(function (ind, elem) {
                    if ((ind + parseInt(low.match(/\d+/)[0])) != element[0].innerHTML) {
                        $(elem).css('background-color', colors[ind]);
                    }
                });
            });
        } else {
            element.css('background-color', '');
            element.addClass('btn-primary');
        }

       if (scope.last && ((upp.split(';')[1] != undefined && low.split(";")[1] != undefined))) {
            if (scope.question.presentationMode != "Vertical") {
                var div = document.createElement('div');
                div.style.width = (width * 2) + 'px';
                div.style.color = '#666666';

                div.style.fontSize = '11px';
                div.style.wordWrap = 'break-word';
                div.className = 'pull-left';
                div.style.textAlign = 'left';
                div.style.fontWeight = 'normal';
                var outerMostDiv = document.createElement('div');
                outerMostDiv.style.width = '100%';
                outerMostDiv.style.float = 'left';
                outerMostDiv.style.height = 'auto';

                var outerDiv = document.createElement('div');
                outerDiv.style.margin = 'auto';
                
                
                outerDiv.style.width = width * arr.length + 'px';
                

                $(outerDiv).append($(div))
                // element.parent().append($(div));

                var div = document.createElement('div');
                div.style.width = (width * 2) + 'px';
                div.style.color = '#666666';
                div.style.fontSize = '11px';
                div.style.fontWeight = 'normal';
                div.style.wordWrap = 'break-word';
                    div.className = 'pull-right';
                    div.style.textAlign = 'right';

                $(outerDiv).append($(div))
                
            } 
        }
        $(outerMostDiv).append($(outerDiv));
        element.parent().append($(outerMostDiv));
    }
    return {
        restrict: 'CA',
        scope: {
            question: '=',
            index: "=",
            isGroup: '=',
            last: '=',
            ngModel: "=",
            getLanguageText: '='
        },
        link: link
        //template:"<div style='width:200px; height:200px; border:1px solid;'></div>"
    };
})
.directive("setStyle", ['$route', function ($route) {
    function link(scope, element, attr) {
        function process() {
            if ($(window).width() > 420) {
                ($(window).width() <= 750) ? element.width($(window).width()) : element.width(650);
                ($(window).height() <= 480) ? element.height($(window).height()) : element.height(400);
            }
            if ($(window).width() < $(window).height())
                ($(window).height() <= 740) ? element.height($(window).height()) : element.height(400);
        }
        process();
        /*$(window).bind('resize',function(){
           process();
        });*/
    }
    return {
        restrict: 'CA',
        link: link
        //template:"<div style='width:200px; height:200px; border:1px solid;'></div>"
    };
}])
.directive("star", ['$route', function ($route) {
    function link(scope, element, attr) {
        if (scope.question.presentationMode == "Random")
            scope.question.presentationMode = [null, "Invert"][Math.floor(Math.random() * 2)];
        if (scope.question.presentationMode == "Invert" && !(/[\u0600-\u06FF]/.test(scope.question.text)))
            element.addClass("pull-right");
        else if (scope.question.presentationMode != "Invert" && (/[\u0600-\u06FF]/.test(scope.question.text)))
            element.addClass("pull-right");
        else if (scope.question.presentationMode == "Vertical")
            element.css("clear", "both");
        if (scope.type == 'Single') {
            if (scope.question.presentationMode != "Vertical")
                var width = element.parent().parent().width();
            else if (scope.question.presentationMode == "Vertical")
                var width = element.parent().parent().parent().height();
            element.width((width / 5) - 2);
            element.height((width / 5) - 2);
            element.css({
                'margin': '0px 0px 0px 0px',
                'background': (scope.index == 1 || scope.index == 5) ? 'url(survey-assets/star' + scope.index + '.png) no-repeat center' : 'url(survey-assets/star.png) no-repeat center',
                'background-size': '80%'
            });
            if (Modernizr && Modernizr.svg) {
                element.css({
                    'background': (scope.index == 1 || scope.index == 5) ? 'url(survey-assets/star' + scope.index + '.svg) no-repeat center' : 'url(survey-assets/star.svg) no-repeat center',
                    'background-size': '80%'
                });
            }
        } else if (scope.type == 'Group') {
            var val = (element.parent().parent().height() <= ((element.parent().parent().width() / 5) - 2)) ? element.parent().parent().height() : ((element.parent().parent().width() / 5) - 2);
            element.width(val);
            element.height(val);
            element.css({
                'margin': '0px 0px 0px 0px',
                'background': (scope.index == 1 || scope.index == 5) ? 'url(survey-assets/star' + scope.index + '.png) no-repeat center' : 'url(survey-assets/star.png) no-repeat center',
                'background-size': '80%'
            });
            if (Modernizr && Modernizr.svg) {
                element.css({
                    'background': (scope.index == 1 || scope.index == 5) ? 'url(survey-assets/star' + scope.index + '.svg) no-repeat center' : 'url(survey-assets/star.svg) no-repeat center',
                    'background-size': '80%'
                });
            }
        }

        var icon = element[0].style.background;

        if (scope.value >= scope.index) {
            if (Modernizr.svg) {
                element.css('background', icon.replace((scope.index == 1 || scope.index == 5) ? scope.index + '.svg' : '.svg', scope.index + '_on.svg'));
            } else {
                element.css('background', icon.replace((scope.index == 1 || scope.index == 5) ? scope.index + '.png' : '.png', scope.index + '_on.png'));
            }
            element.css({
                'background-size': '80%'
            });
        }

        element.on('mouseenter', function () {
            var icon = element[0].style.background;
            if (scope.value < scope.index) {
                if (Modernizr.svg) {
                    element.css('background', icon.replace((scope.index == 1 || scope.index == 5) ? scope.index + '.svg' : '.svg', scope.index + '_on.svg'));
                } else {
                    element.css('background', icon.replace((scope.index == 1 || scope.index == 5) ? scope.index + '.png' : '.png', scope.index + '_on.png'));
                }
                element.css({
                    'background-size': '80%'
                });

            }
        });
        element.on('mouseleave', function () {
            var icon = element[0].style.background;
            if (scope.value < scope.index) {
                if (Modernizr.svg) {
                    element.css('background', icon.replace(scope.index + '_on.svg', (scope.index == 1 || scope.index == 5) ? scope.index + '.svg' : '.svg'));
                } else {
                    element.css('background', icon.replace(scope.index + '_on.png', (scope.index == 1 || scope.index == 5) ? scope.index + '.png' : '.png'));
                }
            }
        });
        element.click(function () {
            element.parent().children().each(function (ind, elem) {
                var icon = elem.style.background;
                if (ind < scope.index - 1 && icon.indexOf('_on.png') == -1)
                    $(elem).css('background', icon.replace(((ind + 1) == 1 || (ind + 1) == 5) ? (ind + 1) + '.png' : '.png', (ind + 1) + '_on.png'));
                else if (ind > scope.index - 1)
                    $(elem).css('background', icon.replace((ind + 1) + '_on.png', ((ind + 1) == 1 || (ind + 1) == 5) ? (ind + 1) + '.png' : '.png'));

                if (Modernizr.svg) {
                    if (ind < scope.index - 1 && icon.indexOf('_on.svg') == -1)
                        $(elem).css('background', icon.replace(((ind + 1) == 1 || (ind + 1) == 5) ? (ind + 1) + '.svg' : '.svg', (ind + 1) + '_on.svg'));
                    else if (ind > scope.index - 1)
                        $(elem).css('background', icon.replace((ind + 1) + '_on.svg', ((ind + 1) == 1 || (ind + 1) == 5) ? (ind + 1) + '.svg' : '.svg'));
                }
            });
        });
    }
    return {
        restrict: 'CA',
        scope: {
            index: '=btnRadio',
            value: '=ngModel',
            type: '=',
            question: '='
        },
        link: link
        //template:"<div style='width:200px; height:200px; border:1px solid;'></div>"
    };
}])
.directive("select", ['$route', '$rootScope', '$compile', function ($route, $rootScope, $compile) {
    function link(scope, element, attr) {
        // Temp variables
        var style1;
        var multiIconStyle;
        if (scope.question.presentationMode == "Random")
            scope.question.presentationMode = [null, "Invert"][Math.floor(Math.random() * 2)];
        if (scope.question.presentationMode == "Invert" && !(/[\u0600-\u06FF]/.test(scope.question.text)))
            element.addClass("pull-right");
        else if (scope.question.presentationMode != "Invert" && (/[\u0600-\u06FF]/.test(scope.question.text)))
            element.addClass("pull-right");
        else if (scope.question.presentationMode == "Vertical")
            element.css("clear", "both");

        if (scope.type == 'Single')
        {
            if (scope.question.presentationMode != "Vertical") {
                var width = element.parent().parent().width();
                element.width((width / 5) - 2);
                element.height((width / 5) - 2);
                if (scope.value.indexOf(';') != -1) {
                    if (scope.value.indexOf('++') == -1) {
                        element.css({
                            'margin': '0px 0px 0px 0px',
                            'background': 'url(survey-assets/' + scope.value.split(';')[1] + ')',
                            'background-repeat': 'no-repeat',
                            'background-position': 'center top',
                            'backgroundSize': '70%'
                        });
                        if (Modernizr && Modernizr.svg) {
                            element.css({
                                'background': 'url(survey-assets/' + scope.value.split(';')[1].replace('png', 'svg') + ') no-repeat center top',
                                'backgroundSize': '70%'
                            });
                        }
                    } else {
                        element.css("position", "relative");
                        element.append($compile($.parseHTML('<div ng-if="selected == value.split(\';\')[0]" style="width: 70%;margin-left: 15%;height: 70%;background-color: rgba(0,0,0,0.5);position: absolute;top: 0;color: #FFF;text-align: right;"><i class="fa fa-check-circle"></i></div>'))(scope));
                    }
                } else {
                    {
                        style1 = {
                            'margin': '0px 0px 0px 0px',
                            'background': 'url(survey-assets/circle_' + scope.value.split(';')[0] + '.png) no-repeat center top',
                            'backgroundSize': '70%'
                        };
                        if (Modernizr && Modernizr.svg) {
                            element.css({
                                'background': 'url(survey-assets/circle_' + scope.value.split(';')[0] + '.svg) no-repeat center top',
                                'backgroundSize': '70%'
                            });
                        } else {
                            element.css(style1)
                        }
                    }
                }
                var span = document.createElement('span');
                span.innerHTML = scope.getLanguageText(scope.question, 'multiSelect', scope.question.multiSelect.indexOf(scope.value)).split(';')[0];
                span.style.display = 'block';
                span.style.fontWeight = 'normal';
                span.style.wordWrap = 'break-word';
                span.style.marginTop = (0.7 * element.height()) + 'px';
                element.append($(span));
            } 
        } 
        var icon = element[0].style.background;
        var css2Browser = false;
        if (!icon) {
            icon = element[0].style['background-image'];
            css2Browser = true;
        }

     
        if (scope.value.split(';')[0] == scope.selected && typeof scope.selected != 'boolean') {
            if (css2Browser) {
                element.css({
                    'background-image': icon.replace('.png', '_on.png')
                    // 'backgroundSize': '70%'
                });
            } else {
                element.css({
                    'background': icon.replace('.png', '_on.png')
                    // 'backgroundSize': '70%'
                });
            }
        } else if (typeof scope.selected == 'boolean' && scope.selected) {

            if (css2Browser) {
                element.css({
                    'background-image': icon.replace('.png', '_on.png')
                    // 'backgroundSize': '70%'
                });
            } else {
                element.css({
                    'background': icon.replace('.png', '_on.png')
                    // 'backgroundSize': '70%'
                });
            }

        }
        if (Modernizr && Modernizr.svg) {
            if (scope.value.split(';')[0] == scope.selected && typeof scope.selected != 'boolean') {
                if (css2Browser) {
                    element.css({
                        'background-image': icon.replace('.svg', '_on.svg'),
                        'background-size': '70%'
                    });
                } else {
                    element.css({
                        'background': icon.replace('.svg', '_on.svg')
                        // 'backgroundSize': '70%'
                    });
                }
            } else if (typeof scope.selected == 'boolean' && scope.selected) {
                if (css2Browser) {
                    element.css({
                        'background-image': icon.replace('.svg', '_on.svg'),
                        'background-size': '70%'
                    });
                } else {
                    element.css({
                        'background': icon.replace('.svg', '_on.svg')
                        // 'backgroundSize': '70%'
                    });
                }
            }
        }

        if (icon.match('px')) {
            var size = icon.match(/\d+\.?\d+px/);
            // console.log(size[0]);
            element.css('background-size', size[0]);
        } else if (icon.match('70%')) {
            element.css('background-size', '70%');
        } else if (icon.match('80%')) {
            element.css('background-size', '80%');
        } else if (icon.match('100%')) {
            element.css('background-size', '100%');
        }

    }
    return {
        restrict: 'CA',
        scope: {
            value: '=option',
            selected: '=ngModel',
            type: '=',
            question: '=',
            getLanguageText: '='
        },
        link: link
        //template:"<div style='width:200px; height:200px; border:1px solid;'></div>"
    };
}])
.directive("selectEvents", ['$route', function ($route) {
        function link(scope, element, attr) {
            element.on('mouseenter', function () {
                var icon = element[0].style.background;
                var css2Browser = false;
                if (!icon) {
                    icon = element[0].style['background-image'];
                    css2Browser = true;
                }

                if (icon.indexOf('url("survey-assets') != -1) {
                    if (!element.hasClass('active')) {
                        if (Modernizr.svg) {
                            if (css2Browser) {
                                element.css('background-image', icon.replace('.svg', '_on.svg'));
                            } else {
                                element.css('background', icon.replace('.svg', '_on.svg'));
                            }
                        } else {
                            if (css2Browser) {
                                element.css('background-image', icon.replace('.png', '_on.png'));
                            } else {
                                element.css('background', icon.replace('.png', '_on.png'));
                            }
                        }
                        if (icon.match('px')) {
                            var size = icon.match(/\d+\.?\d+px/);
                            element.css('background-size', size[0]);
                        } else if (icon.match('70%')) {
                            element.css('background-size', '70%');
                        } else if (icon.match('80%')) {
                            element.css('background-size', '80%');
                        } else if (icon.match('100%')) {
                            element.css('background-size', '100%');
                        }
                    }
                }
            });
            element.on('mouseleave', function () {
                // var icon = element[0].style.background;
                var icon = element[0].style.background;
                var css2Browser = false;
                if (!icon) {
                    css2Browser = true;
                    icon = element[0].style['background-image'];
                }
                if (icon.indexOf('url("survey-assets') != -1) {
                    if (!element.hasClass('active')) {
                        if (Modernizr.svg) {
                            if (css2Browser) {
                                element.css('background-image', icon.replace('_on.svg', '.svg'));
                            } else {
                                element.css('background', icon.replace('_on.svg', '.svg'));
                            }
                        } else {
                            if (css2Browser) {
                                element.css('background-image', icon.replace('_on.png', '.png'));
                            } else {
                                element.css('background', icon.replace('_on.png', '.png'));
                            }
                        }
                        if (icon.match('px')) {
                            var size = icon.match(/\d+\.?\d+px/);
                            element.css('background-size', size[0]);
                        } else if (icon.match('70%')) {
                            element.css('background-size', '70%');
                        } else if (icon.match('80%')) {
                            element.css('background-size', '80%');
                        } else if (icon.match('100%')) {
                            element.css('background-size', '100%');
                        }
                    }
                }
            });
            element.click(function () {
                // element.parent().children().each(function(ind, elem){
                // 	// console.log(elem.style, elem.style.background);
                // })
                element.parent().children().not(element).each(function (ind, elem) {
                    // var icon = elem.style.background;
                    var icon = elem.style.background;
                    var css2Browser = false;
                    if (!icon) {
                        css2Browser = true;
                        icon = elem.style['background-image'];
                    }

                    if (icon.indexOf('url("survey-assets') != -1) {
                        if (Modernizr.svg) {
                            if (icon.match('_on.svg')) {
                                if (!css2Browser) {
                                    $(elem).css({
                                        'background': icon.replace('_on.svg', '.svg')
                                    });
                                } else {
                                    $(elem).css({
                                        'background-image': icon.replace('_on.svg', '.svg')
                                    });
                                }

                                // } else {
                                // 	$(elem).css({
                                // 		'background': icon.replace('.svg', '_on.svg')
                                // 		'background-size' : '70%'
                                // 	});
                            }
                            // if (icon.match('px')) {
                            // 	var size = icon.match(/\d+\.?\d+px/);
                            // 	console.log(size[0]);
                            // 	element.css('background-size', size[0]);
                            // } else if (icon.match('70%')) {
                            // 	$(elem).css('background-size', '70%');
                            // } else if (icon.match('80%')) {
                            // 	$(elem).css('background-size', '80%');
                            // } else if (icon.match('100%')) {
                            // 	$(elem).css('background-size', '100%');
                            // }
                        } else {
                            $(elem).css({
                                'background': icon.replace('_on.png', '.png')
                                // 'background-size' : '70%'

                            })
                        }
                    }

                    if (icon.match('px')) {
                        var size = icon.match(/\d+\.?\d+px/);
                        // console.log(size[0]);
                        element.css('background-size', size[0]);
                    } else if (icon.match('70%')) {
                        $(elem).css('background-size', '70%');
                    } else if (icon.match('80%')) {
                        $(elem).css('background-size', '80%');
                    } else if (icon.match('100%')) {
                        $(elem).css('background-size', '100%');
                    }
                });
            });

        }
        return {
            restrict: 'CA',
            link: link
            //template:"<div style='width:200px; height:200px; border:1px solid;'></div>"
        };
    }])
.directive("elementCenter", ['$route', function ($route) {
    function link(scope, element, attr) {
        element.css({
            "visibility": "hidden",
            "transition": "visibility 500ms ease-in"
        });
        setTimeout(function () {
            if (!(element.hasClass('next-button') || element.hasClass('submit-button'))) {
                element.css("visibility", "visible");
            }
            if (element.parent()[0].offsetHeight > element[0].offsetHeight) {
                element.css({
                    'top': ((element.parent()[0].offsetHeight - element[0].offsetHeight) / 2) + 'px',
                    'position': 'relative'
                });
            }
        });
        setTimeout(function () {
            if (element.hasClass('next-button') || element.hasClass('submit-button')) {
                element.css('visibility', 'visible');
            }
        }, 900)
    }
    return {
        restrict: 'CA',
        link: link
        //template:"<div style='width:200px; height:200px; border:1px solid;'></div>"
    };
}])
.directive("logoHolder", ['$route', function ($route) {
    function link(scope, element, attr) {
        if (scope.src != null && scope.src != 'null' && scope.src != '' && scope.src != undefined) {
            element.css({
                'height': '90%',
                'width': '150px',
                'margin': '0 auto',
                'top': '5%',
                'position': 'relative',
                'background': 'url("' + scope.src + '") no-repeat',
                'background-size': 'contain',
                'background-position': 'center'
            });
            if (window.innerWidth <= 400)
                element.css("width", "100px");
        }
    }
    return {
        restrict: 'CA',
        scope: {
            src: '='
        },
        link: link
        //template:"<div style='width:200px; height:200px; border:1px solid;'></div>"
    };
}])
.directive("welcomeLogoHolder", ['$route', function ($route) {
    function link(scope, element, attr) {
        if (scope.src != null && scope.src != 'null' && scope.src != '' && scope.src != undefined) {
            element.css({
                'height': '60%',
                'width': '100%',
                'max-width': '360px',
                'margin': '0 auto',
                'top': '30%',
                'position': 'relative',
                //background': 'url("' + scope.src + '") no-repeat',
                'background-size': 'contain',
                'background-position': 'center'
            });
        }
    }
    return {
        restrict: 'CA',
        scope: {
            src: '='
        },
        link: link
        //template:"<div style='width:200px; height:200px; border:1px solid;'></div>"
    };
}])
.directive("nextButton", ['$route', function ($route) {
    function link(scope, element, attr) {

        if (scope.question instanceof Array) {
            if (['Text', 'Number'].indexOf(scope.question[0]['question'].displayType) != -1)
                element.addClass('glow');
        } else if (['Text', 'Number', 'MultilineText', 'Slider', 'MultiSelect', 'OrderBy'].indexOf(scope.question['question'].displayType) != -1)
            element.addClass('glow');
    }
    return {
        restrict: 'CA',
        scope: {
            question: '='
        },
        link: link
        //template:"<div style='width:200px; height:200px; border:1px solid;'></div>"
    };
}])
.directive("bgHolder", ['$route', function ($route) {
    function link(scope, element, attr) {
        function process() {
            if (scope.src != null && scope.src != 'null' && scope.src != '' && $(window).width() > 380) {
                element.css("width", "100%");
                element.css("height", "100%");
                element.css({
                    'margin': 'auto',
                    //'background': 'url(' + scope.src + ') no-repeat',
                    'background-size': '100% 100%'
                });
            } else {
                element.css("width", "100%");
                element.css("height", "100%");
                element.css({
                    'margin': 'auto',
                    'background': 'none',
                    'background-size': '100%'
                });
            }
        }
        process();
        /*$(window).bind('resize',function(){
            process();
        });*/
    }
    return {
        restrict: 'CA',
        scope: {
            src: '=',
            survey: '='
        },
        link: link
        //template:"<div style='width:200px; height:200px; border:1px solid;'></div>"
    };
}])
.directive("jqueryWordCloud", ["igtService", function (service) {

    return {
        restrict: 'A',
        scope: {
            words: '='
        },
        link: function ($scope, element, attr) {
            function process() {
                if ($(window).width() > 380) {
                    element.css("background-color", "#D2D2D2");
                    element.css("height", $(window).height());
                    drawCloud();
                } else {
                    element.css('background-color', 'none');
                    element.height(0);
                    element.empty();
                }
            }
            process();

            function drawCloud() {
                var value = ['Customer', 'Satisfaction', 'Delight', 'Experience'];
                var temp = [];
                for (var i = 0; i < 100; i++)
                    temp.push(value[parseInt(Math.random() * value.length)]);
                value = temp.slice();
                element.empty();

                d3.layout.cloud().size([element.width() * 0.9, $(window).height() * 0.98])
                .words(value.map(function (d) {
                    return {
                        text: d,
                        size: 7 + Math.random() * 50
                    };
                }))
                .padding(5)
                .rotate(function () {
                    return ~~(Math.random() * 2) * 90;
                })
                .text(function (d) {
                    return d.text;
                })
                .fontSize(function (d) {
                    return d.size;
                })
                .on("end", draw)
                .start();

                function draw(words) {
                    var translate = 'translate(' + element.width() / 2 + ',' + $(window).height() * 0.98 / 2 + ')';
                    d3.select(element[0]).append("svg")
                    .attr("width", element.width())
                    .attr("height", $(window).height() * 0.98)
                    .attr("class", "wordcloud")
                    .append("g")
                    // without the transform, words words would get cutoff to the left and top, they would
                    // appear outside of the SVG area
                    .attr("transform", translate)
                    .selectAll("text")
                    .data(words)
                    .enter().append("text")
                    .style("font-size", function (d) {
                        return d.size + "px";
                    })
                    .style("font-family", "Raleway")
                    .style("font-weight", "bold")
                    .style("fill", function (d, i) {
                        return "#FFFFFF";
                    })
                    .style("opacity", 0.3)
                    .attr("text-anchor", "middle")
                    .attr("transform", function (d) {
                        return "translate(" + [d.x, d.y] + ")rotate(" + d.rotate + ")";
                    })
                    .text(function (d) {
                        return d.text;
                    });
                    // .style("cursor","pointer");
                }
            }
            /*$(window).bind('resize',function(){
                    process();
                });*/
        }

    };
}])
.directive("validateMe", function () {
    function link(scope, element, attr) {
        if (attr.validateMe != null && attr.validateMe != '') {
            element.on('keypress', function (evt) {
                var charCode = (evt.which) ? evt.which : event.keyCode;
                var regex = new RegExp(attr.validateMe);
                if (regex.test(this.value + String.fromCharCode(charCode)))
                    return true;
                else
                    return false;
            });
        }
    }
    return {
        restrict: 'A',
        link: link
        //template:"<div style='width:200px; height:200px; border:1px solid;'></div>"
    };
})
.directive("smile", ['$route', function ($route) {
    function link(scope, element, attr) {
        if (scope.question.presentationMode == "Random")
            scope.question.presentationMode = [null, "Invert"][Math.floor(Math.random() * 2)];
        if (scope.question.presentationMode == "Invert" && !(/[\u0600-\u06FF]/.test(scope.question.text)))
            element.addClass("pull-right");
        else if (scope.question.presentationMode != "Invert" && (/[\u0600-\u06FF]/.test(scope.question.text)))
            element.addClass("pull-right");
        else if (scope.question.presentationMode == "Vertical")
            element.css("clear", "both");
        if (scope.type == 'Single') {
            if (scope.question.presentationMode != "Vertical")
                var width = element.parent().parent().width();
            else if (scope.question.presentationMode == "Vertical")
                var width = element.parent().parent().parent().height();
            element.width((width / 5) - 2);
            element.height((width / 5) - 2);
            var icons = ['extremelyhappy.png', 'happy.png', 'neutral.png', 'unhappy.png', 'extermelyunhappy.png'];
            var content = ['Excellent', 'Good', 'Average', 'Not Good', 'Below Average'];
            element.css({
                'margin': '0px 0px 0px 0px',
                'background': 'url(survey-assets/' + icons[scope.value - 1] + ') no-repeat center',
                'background-size': '80%'
            });
            if (Modernizr.svg) {
                element.css({
                    'background': 'url(survey-assets/' + icons[scope.value - 1].replace('png', 'svg') + ') no-repeat center',
                    'background-size': '80%'
                });
            }
            
            var span = document.createElement('span');
            span.innerHTML = scope.getLanguageText(scope.question, 'multiSelect', scope.question.multiSelect.indexOf(content[scope.value - 1])).split(';')[0];
            span.style.display = 'block';
            span.style.fontWeight = 'bold';
            span.style.wordWrap = 'break-word';
            span.style.marginTop = (0.9 * element.height()) + 'px';
            element.append($(span));

        } else if (scope.type == 'Group') {
            var val = (element.parent().parent().height() <= ((element.parent().parent().width() / 5) - 2)) ? element.parent().parent().height() : ((element.parent().parent().width() / 5) - 2);
            element.width(val);
            element.height(val);
            var icons = ['extremelyhappy.png', 'happy.png', 'unhappy.png'];
            element.css({
                'margin': '0px 0px 0px 0px',
                'background': 'url(survey-assets/' + icons[scope.value - 1] + ') no-repeat center',
                'background-size': '80%'
            });
            if (Modernizr.svg) {
                element.css({
                    'background': 'url(survey-assets/' + icons[scope.value - 1].replace('png', 'svg') + ') no-repeat center',
                    'background-size': '80%'
                });

            }
        }
        var icon = element[0].style.background;
        // console.log(icon, scope.value, scope.selected)
        if (scope.value == scope.selected) {
            if (Modernizr.svg) {
                element.css('background', icon.replace('.svg', '_on.svg'));
                element.css('background-size', '80%');
            } else {
                element.css('background-size', '80%');
                element.css('background', icon.replace('.png', '_on.png'));
            }
        }

    }
    return {
        restrict: 'CA',
        scope: {
            value: '=btnRadio',
            selected: '=ngModel',
            type: '=',
            question: '=',
            getLanguageText: '='
        },
        link: link
        //template:"<div style='width:200px; height:200px; border:1px solid;'></div>"
    };
}])
.directive('scrollIndicator', [function () {
      function link(scope, element, attr) {
          setTimeout(function () {
              var parent = element.parent();
              var scrollableHeight = parent[0].scrollHeight - parent[0].clientHeight;
              if (scrollableHeight > 5) {
                  element.css('visibility', 'visible');
              } else {
                  return;
              }
              parent.on('scroll', function ($event) {
                  if (scrollableHeight == 0 || (scrollableHeight > 0 && parent.scrollTop() >= scrollableHeight - 10)) {
                      element.css('visibility', 'hidden');
                  } else if (scrollableHeight > 0 || parent.scrollTop() < scrollableHeight) {
                      element.css('visibility', 'visible');
                  }
              });

          }, 5);
      }
      return {
          restrict: 'C',
          link: link,
          template: '<div style="position: absolute; float: left;left: calc(100% - 34px); width: 24px; z-index: 999"><i class="fa fa-angle-double-down" style="fill:#bbbbbb; font-size: 24px;" ></i></div>'
      };
  }]);

