﻿'use strict';
//<editor-fold desc="User Controllers">
var igtControllers = angular.module('igtControllers', ['ui.bootstrap']);

igtControllers.controller('RedirectToLogin', ['$scope', '$location', '$routeParams', function ($scope, $location, $routeParams) {

    var safeToLogin = true;
    try {
        localStorage.test = 'testing';
    } catch (e) {
        safeToLogin = false;
    }
    if (safeToLogin && $location.url().match(/inprivate/i)) {
        $location.path('/login').replace();
    }

    $scope.backToLogin = function () {
        $location.url('/login');
    }
}]);

igtControllers.controller('MultiChannelFeedbackCtrl', ['$scope', 'igtService', '$location', '$route', '$rootScope', '$ocLazyLoad', '$compile', '$injector', '$modal', '$http', '$q', '$routeParams',
  function ($scope, service, $location, $route, $rootScope, $ocLazyLoad, $compile, $injector, $modal, $http, $q, $routeParams) {
      setTimeout(function () {
          try {
              window.localStorage.test = 'testing';
          } catch (err) {
              $location.path('/inprivate').replace();
              return;
          }
      }, 500)
      
      $scope.qa = [];
      $scope.questions = [];
      $scope.url = "#" + $location.url();
      $scope.response = {
          "id": null,
          "user": "IndiGo",
          "locationId": null,
          "responseDateTime": new Date(),
          "responses": [],
          "nps": 0,
          "surveyClient": "JS-Web",
          "responseDuration": 0
      };
      $scope.token = null;
      $scope.refreshed = true;
      $scope.resized = true;

      // New code for resize and orientation change

      $scope.previousOrientation = window.orientation;
      $scope.previousWidth = window.innerWidth;

      var getBrowserInfoFromAPI = function () {
          return $http.post($rootScope.apiURL + "useragent", {
              ua: navigator.userAgent
          }, {
              headers: {
                  'Content-Type': 'application/json'
              }
          });
      }

      var getIpAddressFromAPI = function () {
          return $http.get("http://ipinfo.io",{
              headers: {
                  'Content-Type': 'application/json'
              }
          });
      }

      // $scope.browserData;

      // cache device type information
      $scope.getDeviceType = function () {
          var deviceType = service.cache().get('device_type');
          if (!deviceType) {
              $.get("http://ipinfo.io", function (response) {
              }, "jsonp");
              //getBrowserInfoFromAPI().then(
              //  function (response) {
              //      if (response.data.data)
              //          service.cache().put('device_type', response.data.data.ua_type + response.data.data.browser_name);
              //  });
          }

          var ipAddress = service.cache().get('ipAddress');
          if (!ipAddress)
          {
              getIpAddressFromAPI().then(
                function (response) {
                    service.cache().get('ipAddress', response.ip);
                });
          }
      }

      $scope.getDeviceType();

      var markUp = function (text) {
          var i = 40;
          if (!text) {
              return '';
          }
          // We want to hide all kind of formatting
          while (text.match(/(\/\/|\|\||--|\[\[|\*\*|__|\^\^|~~|\mr|\m)/) && i > 0) {
              text = text.replace(/\|\|(.*?)\|(.*?)\|\|/, '$2')
              text = text.replace(/--(.*?)\|(.*?)--/, '$2')
              text = text.replace(/\[\[(.*?)\|(.*?)\]\]/, '$2')
              text = text.replace(/\*\*(.*?)\|(.*?)\*\*/, '$2');
              text = text.replace(/\/\/(.*?)\|(.*?)\/\//, '$2');
              text = text.replace(/__(.*?)\|(.*?)__/, '$2');
              text = text.replace(/\^\^(.*?)\^\^/, ' $1 ');
              text = text.replace(/~~(.*?)~~/, ' $1 ');
              text = text.replace(/\\mr/g, '\n');
              text = text.replace(/\\m(.*?)\\m/g, '\n$1');
              i--;
          }

          text = text.replace(/((http|ftp|https|ftps|www).*?)(\.*\s+|\n+|\)|\r+|$)/g, function (arg0, arg1, arg2, arg3) {
              var a = '<a href="';
              if (arg2 === 'www') {
                  a = a + '//'
              }
              return a + arg1 + '" class="texturl" target="_blank">' + arg1 + '</a>' + arg3;
          });
          return text;
      }

      if (typeof window.orientation !== 'undefined' && navigator.userAgent.match(/iPhone|iPad|iPod/i)) {
          document.addEventListener("orientationchange", function (evt) {
              if ($scope.previousOrientation != window.orientation) {
                  $scope.resized = false;
                  $scope.$apply();
                  setTimeout(function () {
                      $scope.resized = true;
                      $scope.$apply();
                  }, 500);
              }
              $scope.previousOrientation = window.orientation;
          }, false);
      } else {
          window.addEventListener("resize", function (evt) {
              if (typeof window.orientation !== 'undefined' && $scope.previousOrientation != window.orientation) {
                  $scope.resized = false;
                  $scope.$apply();
                  setTimeout(function () {
                      $scope.resized = true;
                      $scope.$apply();
                  }, 500);
              }
              if (typeof window.orientation === 'undefined' && $scope.previousWidth != window.innerWidth) {
                  $scope.resized = false;
                  $scope.$apply();
                  setTimeout(function () {
                      $scope.resized = true;
                      $scope.$apply();
                  }, 500);
              }
              $scope.previousOrientation = window.orientation;
              $scope.previousWidth = window.innerWidth;
          }, false);
      }

     
      $scope.conditionSet = function (list, q) {
          var data = q.response == undefined ? q.filter : q.question.conditionalFilter;
          if (data != null && data.filterquestions.length > 0) {
              //return false;
              var toBeShown = true;
              jQuery.each(data.filterquestions, function (ind, elem) {
                  var found = jQuery.grep(list, function (obj) {
                      return obj['question'].id === elem.questionId;
                  });

                  if (found != undefined && found.length > 0 && toBeShown) {
                      var parentQ = found[0];
                      if (parentQ['response'].textInput == null && parentQ['response'].numberInput == null)
                          elem.status = false;
                      else {
                          if (elem.answerCheck != null && elem.answerCheck.length >= 1) { //compare text answers
                              if (parentQ['response'].textInput != null) {
                                  if (parentQ['question'].displayType == 'MultiSelect')
                                      var text = parentQ['response'].textInput.toString().split(',');
                                  else
                                      var text = [parentQ['response'].textInput];
                                  var check = false;
                                  jQuery.each(elem.answerCheck, function (i, e) {
                                      elem.answerCheck[i] = $scope.filterImage(e);
                                  });
                                  for (var i = 0; i < text.length; i++) {
                                      if (elem.answerCheck.indexOf(text[i].toString()) != -1)
                                          check = true;
                                  }
                                  elem.status = check;
                              } else
                                  elem.status = false;

                          }
                          
                      }
                  } else
                      elem.status = false;
              });

              var toBeShown = data.filterquestions[0].status;
              //console.log(toBeShown);
              return toBeShown;
          } else
              return true;
      };

      var orderBySequence = function (a, b) {
          if (a.sequence < b.sequence)
              return -1;
          if (a.sequence > b.sequence)
              return 1;
          return 0;
      };

      function getCookie(cname) {
          var name = cname + "=";
          var ca = document.cookie.split(';');
          for (var i = 0; i < ca.length; i++) {
              var c = ca[i];
              while (c.charAt(0) == ' ') c = c.substring(1);
              if (c.indexOf(name) != -1) {
                  return c.substring(name.length, c.length);
              }
          }
          return "";
      }

      function setCookie(cname, cvalue, exhours) {
          var d = new Date();
          d.setTime(d.getTime() + (exhours * 60 * 60 * 1000));
          var expires = "expires=" + d.toGMTString();
          document.cookie = cname + "=" + cvalue + "; " + expires + "; path=/";
      }

      var postPartial = function (resp, complete) {

          var partialId = $routeParams['partialId'] ? $routeParams['partialId'] : $scope.settings.partialResponseId;
          if (partialId != null) {
              var responses = [];
              var questionTags = resp.question && resp.question.questionTags ? resp.question.questionTags.join(",").toLowerCase().split(",") : [];
              if (resp.response != undefined && ((questionTags.indexOf("nps") != -1 && resp.response.numberInput >= 0) || (questionTags.indexOf("nps") == -1 && (resp.response.textInput || resp.response.numberInput > 0))))
                  responses.push(resp.response);
              else if (resp instanceof Array) {
                  jQuery.each(resp, function (index, elem) {
                      var questionTags = elem.question && elem.question.questionTags ? elem.question.questionTags.join(",").toLowerCase().split(",") : [];
                      if (elem.response != undefined && ((questionTags.indexOf("nps") != -1 && elem.response.numberInput >= 0) || (questionTags.indexOf("nps") == -1 && (elem.response.textInput || elem.response.numberInput > 0))))
                          responses.push(elem.response);
                  });
              }

              if (responses.length > 0)
                  service.postPartialResponse(partialId, responses, complete);
          }
      }

      //$scope.token = getCookie('cc_token');
      $scope.TryLogin = function (type) {
          service.resetState();
          if ($routeParams["mode"] != "reuse")
              var cookieToken = getCookie('cc_token');
          if (cookieToken == $scope.token) {
              $location.path('/filled').replace();
              return;
          } else {
              var promise = service.getSurveyByToken($scope.token);
              promise.then(function (response) {
                  console.log(response);
                  if (response == null || response == 'null') {
                      $location.path('/expired').replace();
                      return;
                  } else {
                      response.showLanguageMenu = false;
                      response.chosenLanguage = "Default";

                      // Remove Branding
                      response.removeBranding = false;
                      if (response.questions != null && response.questions.length > 0) {
                          var exists = response.questions.filter(function (question) {
                              return question.questionTags != null && question.questionTags.join('~').toLowerCase().split('~').indexOf("unbrand") != -1;
                          });
                          if (exists.length > 0)
                              response.removeBranding = true;
                      }

                      var prefillTags = Object.keys($routeParams).filter(function (item) {
                          return ['token', 'id', 'textanswer', 'numberanswer', 'mode', 'type'].indexOf(item) == -1;
                      });

                      if (($routeParams["id"] && ($routeParams["textanswer"] || $routeParams["numberanswer"])) || (prefillTags.length > 0)) {
                          var location = decodeURIComponent(window.location.href);
                          jQuery.each(response.questions, function (ind, val) {
                              if ($routeParams["id"] && val.id == $routeParams["id"]) {
                                  var temp = {
                                      'questionId': val.id,
                                      'questionText': val.text,
                                      "textInput": null,
                                      "numberInput": null,
                                      "comparator": 0
                                  };
                                  if ($routeParams["textanswer"])
                                      temp.textInput = $routeParams["textanswer"];
                                  else if ($routeParams["numberanswer"])
                                      temp.numberInput = $routeParams["numberanswer"];
                                  if (response.preFill == null || response.preFill == undefined)
                                      response.preFill = [];
                                  response.preFill.push(temp);
                              } else if (prefillTags.length > 0) {
                                  var exists = prefillTags.filter(function (item) {
                                      return val.questionTags && val.questionTags.join('~').toLowerCase().split('~').indexOf(item.toLowerCase()) != -1;
                                  });

                                  if (exists.length > 0) {
                                      var temp = {
                                          'questionId': val.id,
                                          'questionText': val.text,
                                          "textInput": null,
                                          "numberInput": null,
                                          "comparator": 0
                                      };
                                      if (['Smile-5', 'Smile-3', 'Star-5', 'Scale', 'Slider', 'Number', 'Date'].indexOf(val.displayType) != -1)
                                          temp.numberInput = $routeParams[exists[0]];
                                      else
                                          temp.textInput = $routeParams[exists[0]];
                                      if (response.preFill == null || response.preFill == undefined)
                                          response.preFill = [];
                                      response.preFill.push(temp);
                                  }
                              }
                          });
                          service.cache().put('surveyresponse', response);
                          service.cache().put('surveytoken', $scope.token);
                          $scope.settings = response;
                          $rootScope.partialResponseId = response.partialResponseId;
                          $location.path('/question-list').replace();
                          var partialPrefills = [];
                          if (response.preFill) {
                              response.preFill.map(function (item) {
                                  partialPrefills.push({
                                      response: item
                                  });
                              })
                              postPartial(partialPrefills, false);
                          }

                      } else {
                          service.cache().put('surveyresponse', response);
                          service.cache().put('surveytoken', $scope.token);
                          $scope.settings = response;
                          if ($scope.settings.reCaptchaSiteKey == null && (type == "skip-welcome" || $routeParams["type"] == "internal"))
                              $location.path('/question-list').replace();
                          else
                              $location.path('/welcome').replace();
                      }
                  }
              });
          }
      };
      
      $scope.showLogin = window.location.href.indexOf('?token=');

      if (window.location.href.indexOf('login') >= 0 && $routeParams["token"]) {
          $scope.token = $routeParams["token"];
          if ($scope.token.split("-").length > 2) {
              $scope.token = $scope.token.slice(0, $scope.token.lastIndexOf('-'));
              $scope.TryLogin("skip-welcome");
          } else
              $scope.TryLogin();
      } else if (window.location.href.indexOf('login') >= 0)
          service.resetState();
      else if (service.cache().get('surveyresponse') || window.location.href.indexOf('welcome?token=') >= 0) {
          $scope.settings = service.cache().get('surveyresponse');
          if ($scope.settings == undefined)
              $location.path('/login').replace();
          if (window.location.href.indexOf('welcome') != -1) {
            $scope.showWelcomeButton = true;
          }
          var response = service.cache().get('surveyresponse').questions;
          response = response.sort(orderBySequence);
          $scope.questions = response;
          if (service.cache().get('qa') && service.cache().get('qa').length > 0) {
              $scope.qa = service.cache().get('qa');
          } else {
              $scope.qa = [];
              jQuery.each(response, function (index, element) {
                  var r = {
                      "questionId": element.id,
                      "questionText": element.text,
                      "textInput": null,
                      "numberInput": null
                  };

                    $scope.qa.push({
                        "question": element,
                        "response": r,
                        show: false
                    });
              });

          }
          if (service.cache().get('metrics') != undefined && Object.keys(service.cache().get('metrics')).length > 0) {
              $scope.displayQuestionIndex = service.cache().get('metrics').index;
              $scope.displayQuestionNumber = service.cache().get('metrics').number;
              $scope.numberOfQuestions = service.cache().get('metrics').length;
              $scope.displayQuestion = $scope.qa[$scope.displayQuestionIndex];
          }
          else
          {
            $scope.displayQuestionNumber = 1;
            $scope.displayQuestion = $scope.qa[0];
          }

          if (window.location.href.indexOf('welcome') != -1) {
              jQuery.get('js/icons.txt', function (data) {
                  var icons = data.split("\n");
                  jQuery.each(icons, function (ind, elm) {
                      icons[ind] = 'survey-assets/' + elm;
                  });

                  var str = '';
                  jQuery.each(icons, function (ind, elm) {
                      str += 'url(' + elm + ') ';
                  });
                  var style = document.createElement('style');
                  style.innerHTML = 'body:after{display:none;content:' + str + '}';
                  document.head.appendChild(style);
              });
          }
      } else
          $location.path('/login').replace();


      $scope.redirect = function (html) {
          if (html == 'thanks') {
              var resp = [];
              jQuery.each($scope.qa, function (index, element) {
                  resp.push(element.response);
              });

              $scope.response.responses = [];

              var screenSize = service.cache().get('screen_size');

              if (screenSize && screenSize.textInput) {
                  $scope.response.responses.push(screenSize);
              }

              jQuery.each(resp, function (ind, elem) {
                  if (elem.textInput != null || elem.numberInput != null)
                      $scope.response.responses.push(elem);
              });

              $scope.response.responseDuration = Math.round((new Date() - $scope.response.responseDateTime) / 1000);
              $scope.response.responseDateTime = new Date();
              if ($routeParams["mode"] == "reuse" || getCookie('cc_token') != service.cache().get('surveytoken')) {
                  var promise = service.postSurveyByToken(service.cache().get('surveytoken'), $scope.response);
                  setCookie('cc_token', service.cache().get('surveytoken'), 4);
                  promise.then(function (response) {
                      if (response != null && response != "null") {
                          $scope.message = "Successful!";          
                      }
                  });
              }
              if ($routeParams["type"] != "internal")
                  $location.path('/' + html).replace();
          } else
              $location.path('/' + html).replace();

      };

      var validateFunction = function (element) {
          var validate = false;
          var reqCheck = true;
          var message;
          if (element.question.isRequired && element.show) {
              if ((element.response.textInput == null || element.response.textInput == '') && element.response.numberInput == null) {
                  if (element.question.text.indexOf(':') !== -1) {
                      message = "In order to proceed, you need to answer all the mandatory questions (marked with *)";
                  } else {
                      message = 'This question is mandatory';
                  }
                  reqCheck = false;
              }
          }
          
          return [validate, reqCheck, message]
      }

      $scope.nextQuest = function (html, quest) {

          if ($scope.apiInProgress) {
              return;
          }
          // Check isRequired
          $scope.processType = 'next';
          var reqCheck = true;
          var validate;
          var message = '';

          var tempInd = validateFunction(quest);
          validate = tempInd[0];
          reqCheck = tempInd[1];
          message += tempInd[2] ? tempInd[2] : '';

          if (quest.question.endOfSurveyMessage != null && quest.question.endOfSurveyMessage != '') {
              var text = quest.question.endOfSurveyMessage;
              $scope.settings.surveyMessage = text;
              service.cache().put("surveyresponse", $scope.settings);
          }
          
          if (!validate && reqCheck) {
            if (html != undefined)
                $scope.redirect(html);

            if ($scope.displayQuestionNumber < $scope.numberOfQuestions ) {
                $scope.displayQuestionNumber++;
                $scope.displayQuestionIndex += 1 + $scope.shownQuestions.slice($scope.displayQuestionIndex + 1).indexOf(1);
                $scope.displayQuestion = $scope.qa[$scope.displayQuestionIndex];
           }
          } else {

              noty({
                  type: 'confirm',
                  text: message,
                  buttons: [{
                      addClass: 'btn btn-primary',
                      text: 'OK',
                      onClick: function ($noty) {
                          $noty.close();
                      }
                  }]
              });

              return;
          }

          if (quest != null) {
              if (html == "thanks")
                  postPartial(quest, true);
              else
                  postPartial(quest, false);
          }
      };

      $scope.prevQuest = function () {

          if ($scope.apiInProgress) {
              return;
          }

          $scope.processType = 'prev';
          if ($scope.displayQuestionNumber >= 2) {
              $scope.displayQuestionNumber--;
              $scope.displayQuestionIndex = $scope.shownQuestions.slice(0, $scope.displayQuestionIndex).lastIndexOf(1);
              $scope.displayQuestion = $scope.qa[$scope.displayQuestionIndex];
          }
      };

      $scope.getObjectLength = function (obj) {
          return obj == null ? 0 : Object.keys(obj).length;
      };

      $scope.getLanguageText = function (which, key, ind) {
          var result;
          if (which == 'Welcome') {

              result =  $scope.settings.welcomeText;
              return markUp(result)
          } else if (which == 'Thanks') {
              $scope.settings = service.cache().get("surveyresponse");
              if ($scope.settings != undefined) {
                  if ($scope.settings.surveyMessage != undefined) {
                      result = $scope.settings.surveyMessage;
                      return markUp(result)
                  } else {
                      result =  $scope.settings.thankyouText;
                      return markUp(result)
                  }
              }
          } else 
          {
              if (key == 'text') 
                 result = which.text;
              else
                  result = which.multiSelect && which.multiSelect[ind];

                  return markUp(result);
          }
      }

      $scope.filterImage = function (opt) {
          if (opt.indexOf(';') != -1)
              return opt.split(';')[0];
          else
              return opt;
      };

      $scope.$watch('displayQuestion', function (newvalue, oldvalue) {
          service.cache().put('qa', $scope.qa);
          if ($scope.displayQuestionIndex && $scope.displayQuestionNumber && $scope.numberOfQuestions)
              service.cache().put('metrics', {
                  index: $scope.displayQuestionIndex,
                  number: $scope.displayQuestionNumber,
                  length: $scope.numberOfQuestions
              });

          if ($scope.displayQuestion != undefined) {
              var temp = {};
              var qa = [];
              $scope.shownQuestions = [];
              jQuery.each($scope.qa, function (index, element) {
                  if (element instanceof Array) {
                      jQuery.each(element, function (index, elem) {
                          qa.push(elem);
                      });
                  } else
                      qa.push(element);
              });

              jQuery.each($scope.qa, function (index, element) {
                  $scope.shownQuestions[index] = 0;
                  if (element instanceof Array) {
                      jQuery.each(element, function (ind, elem) {
                          elem.show = elem.question && elem.question.skippedByInteractiveAPIFill === true ? false : ($scope.conditionSet(qa, elem));
                          if (elem.show)
                              $scope.shownQuestions[index] = 1;
                      });
                  } else {
                      element.show = element.question && element.question.skippedByInteractiveAPIFill === true ? false : $scope.conditionSet(qa, element);
                      if (element.show)
                          $scope.shownQuestions[index] = 1;

                  }
              });
              //console.log($scope.qa);
              $scope.numberOfQuestions = 0;
              jQuery.each($scope.shownQuestions, function (ind, val) {
                  if (val == 1)
                      $scope.numberOfQuestions += 1;
              });
              if ($scope.numberOfQuestions == 0)
                  $scope.redirect('thanks');

              if ($scope.displayQuestionIndex == undefined) {
                  $scope.displayQuestionIndex = $scope.shownQuestions.indexOf(1);
                  $scope.displayQuestion = $scope.qa[$scope.displayQuestionIndex];
              }

              if (!(oldvalue instanceof Array) && !(newvalue instanceof Array)) {
                  if (['Text', 'Number', 'MultilineText', 'Slider', 'MultiSelect', 'OrderBy', 'Date'].indexOf($scope.displayQuestion['question'].displayType) == -1 && newvalue['response'].questionId == oldvalue['response'].questionId && !$scope.refreshed) {
                      if (newvalue['response'].textInput != oldvalue['response'].textInput || newvalue['response'].numberInput != oldvalue['response'].numberInput) {
                          setTimeout(function () {
                              $scope.nextQuest(undefined, $scope.displayQuestion);
                              $scope.$apply();
                          }, 500);
                      }
                  }
              } else if (oldvalue instanceof Array && newvalue instanceof Array && oldvalue.length == newvalue.length) {
                  var jump = true;
                  jQuery.each($scope.displayQuestion, function (i, e) {
                      if (e['question'].displayType === 'Scale' && e.response && e.response.numberInput >= 0) {
                          postPartial(e, false);
                      }
                      if (['Smile-3', 'Smile-5', 'Star-5', 'Select', 'Scale'].indexOf(e['question'].displayType) != -1 && e['response'].questionId == oldvalue[i]['response'].questionId && !$scope.refreshed) {
                          if (e['response'].textInput == null && e['response'].numberInput == null && e.show)
                              jump = false;
                      } else
                          jump = false;
                  });

                  if (jump && $scope.processType != 'prev') {
                      setTimeout(function () {
                          $scope.nextQuest(undefined, $scope.displayQuestion);
                          $scope.$apply();
                      }, 500);
                  }
              }
              $scope.refreshed = false;
          }
      }, true);

      $scope.thanksButton = 'Close';
      
      $scope.modifyURL = function () {
          $location.url('/login');
      };

      $scope.SignOut = function () {
          parent.window.postMessage("Delete_CC_Survey", "*");
          service.resetState();

          if ($routeParams["mode"] != "reuse") {
              $location.url('/login');
              window.open('', '_self').close();
          } else
              $location.path('/login').replace();
      };

      $scope.getHeaderStyle = function (qa) {
          return {
              "color": $scope.settings.colorCode3,
              "text-align": /[\u0600-\u06FF]/.test(qa.question.text) ? "right" : "left"
          };
      };

      $scope.getArray = function (displayQuestion) {
          var questionTags = displayQuestion.question.questionTags.join(',');
          var array = [];
          
            var low = displayQuestion.question.multiSelect[0].split('-')[0],
            upp = displayQuestion.question.multiSelect[0].split('-')[1]
            var arr = [];
            low = low.split(";")[0];
            upp = upp.split(";")[0];
            var difference = ((upp - low) + 1) > 11 ? ((upp - low) + 1) : 11;
            var increment = difference > 11 ? ((difference / 2) > 11 ? ((difference / 5) > 11 ? 10 : 5) : 2) : 1;
            for (var i = parseInt(low) ; i <= parseInt(upp) ; i += increment) {
                arr.push(i);
            }
            return arr;

      };

      $scope.ResetLogin = function () {
          $scope.token = null;
          $scope.message = null;
          service.resetState();
      };

      $scope.setDisplayStyle = function (qa) {
          if (qa.length == undefined && (qa.question.displayType == "Select")) {
              if (qa.question.displayStyle != null && qa.question.displayStyle != '')
                  return;
              else {
                  qa.question.displayStyle = "icon";
                  return;
              }
          }
      };

      $scope.showFooterButtons = true;
  }
])


igtControllers.animation('.animation', function () {
    return {
        enter: function (element, done) {
            element.css({
                opacity: 0
            }).animate({
                opacity: 1
            }, 500, "swing");
        }
    };
});

igtControllers.filter('newline', function () {
    return function (text) {
        return text == null ? text : text.replace(/\n/g, '<br />');
    };
});