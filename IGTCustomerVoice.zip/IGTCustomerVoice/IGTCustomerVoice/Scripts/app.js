﻿'use strict';

//<editor-fold desc="Config">
angular.module('igtApp', [
  'ngRoute',
  'ngCookies',
  'ngAnimate',
  'ngSanitize',
  'restangular',
  'igtControllers',
  'angular-data.DSCacheFactory',
  'oc.lazyLoad'
]);
