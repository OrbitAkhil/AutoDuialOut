﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace IGTCustomerVoice.Models
{

    public class SurveyViewModel
    {
        public string LogoURL { get; set; }
        public string BackgroundURL { get; set; }
        public string BrandName { get; set; }
        public string BrandCountry { get; set; }
        public string ColorCode1 { get; set; }
        public string ColorCode2 { get; set; }
        public string ColorCode3 { get; set; }
        public string WelcomeText { get; set; }
        public string WelcomeImage { get; set; }
        public string ThankyouText { get; set; }
        public string ThankyouImage { get; set; }
        public List<Question> Questions { get; set; }
        public bool SkipWelcome { get; set; }
        public string PartialResponseId { get; set; }
        public string Route { get; set; }
        public string SurveyMessage { get; set; }
    }

    public class ConditionalFilter
    {
        public List<FilterQuestion> Filterquestions { get; set; }
    }

    public class FilterQuestion
    {
        public string QuestionId { get; set; }
        public List<string> AnswerCheck { get; set; }

    }
    public class Question
    {
        public string Id { get; set; }
        public string User { get; set; }
        public int Sequence { get; set; }
        public string Text { get; set; }
        public string DisplayType { get; set; }
        public List<string> MultiSelect { get; set; }
        public bool EndOfSurvey { get; set; }
        public string EndOfSurveyMessage { get; set; }
        public ConditionalFilter ConditionalFilter { get; set; }
        public string PresentationMode { get; set; }
        public bool IsRequired { get; set; }
        public List<string> QuestionTags { get; set; }
    }

}