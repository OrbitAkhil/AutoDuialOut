﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace IGTCustomerVoice.Models
{
    
    public class SurveyResponseViewModel
    {
        public object Id { get; set; }
        public object User { get; set; }
        public object LocationId { get; set; }
        public DateTime ResponseDateTime { get; set; }
        public List<ResponseViewModel> Responses { get; set; }
        public int Nps { get; set; }
        public string SurveyClient { get; set; }
        public int ResponseDuration { get; set; }
    }

    public class ResponseViewModel
    {
        public string QuestionId { get; set; }
        public string QuestionText { get; set; }
        public string TextInput { get; set; }
        public int NumberInput { get; set; }
    }
}