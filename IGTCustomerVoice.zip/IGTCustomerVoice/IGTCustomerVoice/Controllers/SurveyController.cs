﻿using IGTCustomerVoice.Models;
using IGTCustomerVoice.Repository;
using Newtonsoft.Json;
using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Net;
using System.Net.Http;
using System.Threading.Tasks;
using System.Web.Http;

namespace IGTCustomerVoice.Controllers
{
    public class SurveyController : ApiController
    {
        // GET api/<controller>/5
        [Route("api/Survey/{token}")]
        public async Task<IHttpActionResult> Get(long token)
        {
            SurveyViewModel model = null;

            if (token<=0)
                return BadRequest();
            
            SurveyRepository repo = new SurveyRepository();

            model = await repo.GetCustomerVoiceSurveyData(token);
            
            if (model == null)
                return NotFound();

            return Ok(model);
        }



        // POST api/<controller>
        [HttpPost]
        [Route("api/PartialSurvey/{id}/{complete}")]
        public void Post([FromUri]string id, [FromUri]bool complete, [FromBody] IList<ResponseViewModel> value)
        {

        }

        [HttpPost]
        [Route("api/SurveyByToken/{token}")]
        public async void Post([FromUri]long token, [FromBody] SurveyResponseViewModel value)
        {
            if (token <= 0)
                return;
            

            SurveyRepository repo = new SurveyRepository();
            await repo.SaveCustomerVoiceSurvey(token, value);
        }

        

        #region Private Methods
        private void LoadJson()
        {
            using (StreamReader r = new StreamReader("settings.json"))
            {
                string json = r.ReadToEnd();
                SurveyViewModel model = JsonConvert.DeserializeObject<SurveyViewModel>(json);
            }
        }

        #endregion
    }
}